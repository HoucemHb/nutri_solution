"use strict";
(self["webpackChunkNutrisolutions"] = self["webpackChunkNutrisolutions"] || []).push([["main"],{

/***/ 4114:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppRoutingModule: () => (/* binding */ AppRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/router */ 5072);
/* harmony import */ var _features_landing_landing_page_landing_page_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./features/landing/landing-page/landing-page.component */ 9238);
/* harmony import */ var _auth_login_login_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./auth/login/login.component */ 6539);
/* harmony import */ var _auth_signup_signup_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./auth/signup/signup.component */ 6101);
/* harmony import */ var _features_nutritionists_nutritionists_list_nutritionists_list_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./features/nutritionists/nutritionists-list/nutritionists-list.component */ 3990);
/* harmony import */ var _core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./core/guards/auth.guard */ 4978);
/* harmony import */ var _features_planning_planning_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./features/planning/planning.component */ 5490);
/* harmony import */ var _features_profile_profile_page_profile_page_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./features/profile/profile-page/profile-page.component */ 1620);
/* harmony import */ var _features_home_admin_home_admin_home_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./features/home/admin-home/admin-home.component */ 2692);
/* harmony import */ var _core_guards_role_guard__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./core/guards/role.guard */ 400);
/* harmony import */ var _features_home_home_page_home_page_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./features/home/home-page/home-page.component */ 5724);
/* harmony import */ var _features_home_home_nutritioniste_home_nutritioniste_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./features/home/home-nutritioniste/home-nutritioniste.component */ 492);
/* harmony import */ var _auth_reset_password_reset_password_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./auth/reset-password/reset-password.component */ 6503);
/* harmony import */ var _models_client_model__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./models/client.model */ 4477);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 7580);
















const routes = [{
  path: '',
  component: _features_landing_landing_page_landing_page_component__WEBPACK_IMPORTED_MODULE_0__.LandingPageComponent
}, {
  path: 'login',
  component: _auth_login_login_component__WEBPACK_IMPORTED_MODULE_1__.LoginComponent
}, {
  path: 'signup',
  component: _auth_signup_signup_component__WEBPACK_IMPORTED_MODULE_2__.SignupComponent
}, {
  path: 'reset-password/:resetToken',
  component: _auth_reset_password_reset_password_component__WEBPACK_IMPORTED_MODULE_11__.ResetPasswordComponent
}, {
  path: 'nutritionists',
  component: _features_nutritionists_nutritionists_list_nutritionists_list_component__WEBPACK_IMPORTED_MODULE_3__.NutritionistsListComponent,
  canActivate: [_core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_4__.authGuard]
}, {
  path: 'recipes',
  loadChildren: () => Promise.resolve(/*! import() */).then(__webpack_require__.bind(__webpack_require__, /*! ./features/recipes/recipes.module */ 5237)).then(m => m.RecipesModule)
}, {
  path: 'nutritionnists/:nutritionistId/planning',
  component: _features_planning_planning_component__WEBPACK_IMPORTED_MODULE_5__.PlanningComponent,
  canActivate: [_core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_4__.authGuard]
}, {
  path: 'profile',
  component: _features_profile_profile_page_profile_page_component__WEBPACK_IMPORTED_MODULE_6__.ProfilePageComponent,
  canActivate: [_core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_4__.authGuard]
}, {
  path: 'admin-home',
  component: _features_home_admin_home_admin_home_component__WEBPACK_IMPORTED_MODULE_7__.AdminHomeComponent,
  canActivate: [_core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_4__.authGuard, _core_guards_role_guard__WEBPACK_IMPORTED_MODULE_8__.roleGuard],
  data: {
    roles: [_models_client_model__WEBPACK_IMPORTED_MODULE_12__.UserRoleEnum.ADMIN]
  }
}, {
  path: 'client-home',
  component: _features_home_home_page_home_page_component__WEBPACK_IMPORTED_MODULE_9__.HomePageComponent,
  canActivate: [_core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_4__.authGuard, _core_guards_role_guard__WEBPACK_IMPORTED_MODULE_8__.roleGuard],
  data: {
    roles: [_models_client_model__WEBPACK_IMPORTED_MODULE_12__.UserRoleEnum.CLIENT]
  }
}, {
  path: 'nutritionist-home',
  component: _features_home_home_nutritioniste_home_nutritioniste_component__WEBPACK_IMPORTED_MODULE_10__.HomeNutritionisteComponent,
  canActivate: [_core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_4__.authGuard, _core_guards_role_guard__WEBPACK_IMPORTED_MODULE_8__.roleGuard],
  data: {
    roles: [_models_client_model__WEBPACK_IMPORTED_MODULE_12__.UserRoleEnum.NUTRITIONIST]
  }
}, {
  path: '**',
  redirectTo: '',
  pathMatch: 'full'
}];
class AppRoutingModule {
  static {
    this.ɵfac = function AppRoutingModule_Factory(t) {
      return new (t || AppRoutingModule)();
    };
  }
  static {
    this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineNgModule"]({
      type: AppRoutingModule
    });
  }
  static {
    this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineInjector"]({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_14__.RouterModule.forRoot(routes), _angular_router__WEBPACK_IMPORTED_MODULE_14__.RouterModule]
    });
  }
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵsetNgModuleScope"](AppRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_14__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_14__.RouterModule]
  });
})();

/***/ }),

/***/ 92:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppComponent: () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 5072);


class AppComponent {
  constructor() {
    this.coords = {
      x: 0,
      y: 0
    };
    this.colors = ['#cc5500', '#cc5500', '#cc5500', '#cc5500', '#c05200', '#c05200', '#c05200', '#c05200', '#b44e00', '#b44e00', '#a84b00', '#a84b00', '#9d4700', '#9d4700', '#924400', '#924400', '#874000', '#874000', '#7c3c00'];
  }
  ngAfterViewInit() {
    const circles = document.querySelectorAll('.circle');
    circles.forEach((circle, index) => {
      circle.x = 0; // Initialize the `x` property
      circle.y = 0; // Initialize the `y` property
      circle.style.backgroundColor = this.colors[index % this.colors.length];
    });
    window.addEventListener('mousemove', e => {
      this.coords.x = e.clientX;
      this.coords.y = e.clientY;
    });
    const animateCircles = () => {
      let x = this.coords.x;
      let y = this.coords.y;
      circles.forEach((circle, index) => {
        circle.style.left = `${x - 12}px`;
        circle.style.top = `${y - 12}px`;
        // Scale the circle based on its index
        circle.style.transform = `scale(${(circles.length - index) / circles.length})`;
        circle.x = x; // Update the `x` property
        circle.y = y; // Update the `y` property
        const nextCircle = circles[index + 1] || circles[0];
        x += (nextCircle.x - x) * 0.3;
        y += (nextCircle.y - y) * 0.3;
      });
      requestAnimationFrame(animateCircles);
    };
    animateCircles();
  }
  static {
    this.ɵfac = function AppComponent_Factory(t) {
      return new (t || AppComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: AppComponent,
      selectors: [["app-root"]],
      decls: 21,
      vars: 0,
      consts: [[1, "circle"]],
      template: function AppComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "div", 0)(1, "div", 0)(2, "div", 0)(3, "div", 0)(4, "div", 0)(5, "div", 0)(6, "div", 0)(7, "div", 0)(8, "div", 0)(9, "div", 0)(10, "div", 0)(11, "div", 0)(12, "div", 0)(13, "div", 0)(14, "div", 0)(15, "div", 0)(16, "div", 0)(17, "div", 0)(18, "div", 0)(19, "div", 0)(20, "router-outlet");
        }
      },
      dependencies: [_angular_router__WEBPACK_IMPORTED_MODULE_1__.RouterOutlet],
      styles: [".circle[_ngcontent-%COMP%] {\n  height: 15px;\n  width: 15px;\n  border-radius: 15px;\n  background-color: black;\n  position: fixed;\n  top: 0;\n  left: 0;\n  pointer-events: none;\n  z-index: 99999999; \n\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvYXBwLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxZQUFZO0VBQ1osV0FBVztFQUNYLG1CQUFtQjtFQUNuQix1QkFBdUI7RUFDdkIsZUFBZTtFQUNmLE1BQU07RUFDTixPQUFPO0VBQ1Asb0JBQW9CO0VBQ3BCLGlCQUFpQixFQUFFLGtEQUFrRDtBQUN2RSIsInNvdXJjZXNDb250ZW50IjpbIi5jaXJjbGUge1xyXG4gIGhlaWdodDogMTVweDtcclxuICB3aWR0aDogMTVweDtcclxuICBib3JkZXItcmFkaXVzOiAxNXB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6IGJsYWNrO1xyXG4gIHBvc2l0aW9uOiBmaXhlZDtcclxuICB0b3A6IDA7XHJcbiAgbGVmdDogMDtcclxuICBwb2ludGVyLWV2ZW50czogbm9uZTtcclxuICB6LWluZGV4OiA5OTk5OTk5OTsgLyogc28gdGhhdCBpdCBzdGF5cyBvbiB0b3Agb2YgYWxsIG90aGVyIGVsZW1lbnRzICovXHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 635:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppModule: () => (/* binding */ AppModule)
/* harmony export */ });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/platform-browser */ 436);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app-routing.module */ 4114);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component */ 92);
/* harmony import */ var _auth_auth_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./auth/auth.module */ 841);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/forms */ 4456);
/* harmony import */ var _features_recipes_recipes_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./features/recipes/recipes.module */ 5237);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./shared/shared.module */ 3887);
/* harmony import */ var _features_nutritionists_nutritionists_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./features/nutritionists/nutritionists.module */ 7629);
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ngx-toastr */ 4285);
/* harmony import */ var _features_home_home_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./features/home/home.module */ 2829);
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/platform-browser/animations */ 3835);
/* harmony import */ var _features_planning_planning_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./features/planning/planning.component */ 5490);
/* harmony import */ var _features_profile_profile_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./features/profile/profile.module */ 337);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common/http */ 6443);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/router */ 5072);
/* harmony import */ var _core_interceptors_token_interceptor__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./core/interceptors/token.interceptor */ 909);
/* harmony import */ var _core_core_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./core/core.module */ 8423);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 7580);



















class AppModule {
  static {
    this.ɵfac = function AppModule_Factory(t) {
      return new (t || AppModule)();
    };
  }
  static {
    this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineNgModule"]({
      type: AppModule,
      bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_1__.AppComponent]
    });
  }
  static {
    this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineInjector"]({
      providers: [{
        provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_12__.HTTP_INTERCEPTORS,
        useClass: _core_interceptors_token_interceptor__WEBPACK_IMPORTED_MODULE_9__.TokenInterceptor,
        multi: true
      }],
      imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_13__.BrowserModule, _app_routing_module__WEBPACK_IMPORTED_MODULE_0__.AppRoutingModule, _auth_auth_module__WEBPACK_IMPORTED_MODULE_2__.AuthModule, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormsModule, _features_recipes_recipes_module__WEBPACK_IMPORTED_MODULE_3__.RecipesModule, _features_nutritionists_nutritionists_module__WEBPACK_IMPORTED_MODULE_5__.NutritionistsModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.SharedModule, _features_profile_profile_module__WEBPACK_IMPORTED_MODULE_8__.ProfileModule, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.ReactiveFormsModule, ngx_toastr__WEBPACK_IMPORTED_MODULE_15__.ToastrModule.forRoot({
        timeOut: 3000,
        positionClass: 'toast-top-right',
        preventDuplicates: true,
        closeButton: true // Show close button in the notification
      }), _features_home_home_module__WEBPACK_IMPORTED_MODULE_6__.HomeModule, _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_16__.BrowserAnimationsModule, _angular_common_http__WEBPACK_IMPORTED_MODULE_12__.HttpClientModule, _angular_router__WEBPACK_IMPORTED_MODULE_17__.RouterModule, _core_core_module__WEBPACK_IMPORTED_MODULE_10__.CoreModule]
    });
  }
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵsetNgModuleScope"](AppModule, {
    declarations: [_app_component__WEBPACK_IMPORTED_MODULE_1__.AppComponent, _features_planning_planning_component__WEBPACK_IMPORTED_MODULE_7__.PlanningComponent],
    imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_13__.BrowserModule, _app_routing_module__WEBPACK_IMPORTED_MODULE_0__.AppRoutingModule, _auth_auth_module__WEBPACK_IMPORTED_MODULE_2__.AuthModule, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormsModule, _features_recipes_recipes_module__WEBPACK_IMPORTED_MODULE_3__.RecipesModule, _features_nutritionists_nutritionists_module__WEBPACK_IMPORTED_MODULE_5__.NutritionistsModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.SharedModule, _features_profile_profile_module__WEBPACK_IMPORTED_MODULE_8__.ProfileModule, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.ReactiveFormsModule, ngx_toastr__WEBPACK_IMPORTED_MODULE_15__.ToastrModule, _features_home_home_module__WEBPACK_IMPORTED_MODULE_6__.HomeModule, _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_16__.BrowserAnimationsModule, _angular_common_http__WEBPACK_IMPORTED_MODULE_12__.HttpClientModule, _angular_router__WEBPACK_IMPORTED_MODULE_17__.RouterModule, _angular_router__WEBPACK_IMPORTED_MODULE_17__.RouterOutlet, _angular_router__WEBPACK_IMPORTED_MODULE_17__.RouterLink, _core_core_module__WEBPACK_IMPORTED_MODULE_10__.CoreModule]
  });
})();

/***/ }),

/***/ 841:
/*!*************************************!*\
  !*** ./src/app/auth/auth.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthModule: () => (/* binding */ AuthModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login/login.component */ 6539);
/* harmony import */ var _reset_password_reset_password_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./reset-password/reset-password.component */ 6503);
/* harmony import */ var _signup_signup_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./signup/signup.component */ 6101);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 4456);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../shared/shared.module */ 3887);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 5072);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7580);








class AuthModule {
  static {
    this.ɵfac = function AuthModule_Factory(t) {
      return new (t || AuthModule)();
    };
  }
  static {
    this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineNgModule"]({
      type: AuthModule
    });
  }
  static {
    this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_3__.SharedModule, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule, _angular_router__WEBPACK_IMPORTED_MODULE_7__.RouterModule, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule]
    });
  }
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsetNgModuleScope"](AuthModule, {
    declarations: [_login_login_component__WEBPACK_IMPORTED_MODULE_0__.LoginComponent, _reset_password_reset_password_component__WEBPACK_IMPORTED_MODULE_1__.ResetPasswordComponent, _signup_signup_component__WEBPACK_IMPORTED_MODULE_2__.SignupComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_3__.SharedModule, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule, _angular_router__WEBPACK_IMPORTED_MODULE_7__.RouterModule, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule],
    exports: [_login_login_component__WEBPACK_IMPORTED_MODULE_0__.LoginComponent, _reset_password_reset_password_component__WEBPACK_IMPORTED_MODULE_1__.ResetPasswordComponent, _signup_signup_component__WEBPACK_IMPORTED_MODULE_2__.SignupComponent]
  });
})();

/***/ }),

/***/ 6539:
/*!***********************************************!*\
  !*** ./src/app/auth/login/login.component.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LoginComponent: () => (/* binding */ LoginComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 4456);
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ngx-toastr */ 4285);
/* harmony import */ var src_app_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/utils/functions.utils */ 3584);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/auth.service */ 4796);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _shared_components_auth_background_auth_background_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../shared/components/auth-background/auth-background.component */ 3793);
/* harmony import */ var _shared_components_auth_input_field_auth_input_field_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../shared/components/auth-input-field/auth-input-field.component */ 4591);
/* harmony import */ var _shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../shared/components/button/button.component */ 8219);
/* harmony import */ var _shared_components_input_field_input_field_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../shared/components/input-field/input-field.component */ 1029);
/* harmony import */ var _shared_components_popup_popup_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../shared/components/popup/popup.component */ 4061);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ 5072);














function LoginComponent_app_popup_24_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "app-popup", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("popupClosed", function LoginComponent_app_popup_24_Template_app_popup_popupClosed_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r3);
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵresetView"](ctx_r2.isRequestPopupVisible = false);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](1, "app-input-field", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](2, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](3, "app-button", 19)(4, "app-button", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("text", "Veuillez ins\u00E9rer votre email");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("placeholder", "Votre email...")("control", ctx_r1.emailControl);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("text", "Confirmer")("onClick", ctx_r1.sendResetPassRequest);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("boxShadow", "0 4px 8px 2px #ffc5c5")("backgroundColor", "#df0404")("onClick", ctx_r1.closeRequestPopup)("text", "Annuler");
  }
}
class LoginComponent {
  constructor() {
    this.email = '';
    this.password = '';
    this.authService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.inject)(src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_1__.AuthService);
    this.emailControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControl('');
    this.toastr = (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.inject)(ngx_toastr__WEBPACK_IMPORTED_MODULE_9__.ToastrService);
    this.connexion = () => {
      this.authService.login(this.email, this.password);
    };
    this.isRequestPopupVisible = false;
    // Method to hide the popup
    this.closeRequestPopup = () => {
      this.isRequestPopupVisible = false;
      this.emailControl.reset();
    };
    this.sendResetPassRequest = () => {
      if (this.emailControl.valid) this.authService.resetPasswordRequest(this.emailControl.value).subscribe({
        next: response => {
          this.toastr.success(response.message);
          this.closeRequestPopup();
        },
        error: err => {
          this.toastr.error(src_app_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_0__.AppUtils.getErrorMessage(err));
        }
      });
      this.emailControl.reset();
    };
  }
  setEmail(event) {
    console.log('Email set');
    this.email = event;
  }
  setPassword(event) {
    console.log('password set');
    this.password = event;
  }
  showRequestPassPopup() {
    this.isRequestPopupVisible = true;
  }
  static {
    this.ɵfac = function LoginComponent_Factory(t) {
      return new (t || LoginComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineComponent"]({
      type: LoginComponent,
      selectors: [["app-login"]],
      decls: 25,
      vars: 11,
      consts: [["loginForm", "ngForm"], [1, "inputs"], ["label", "Email Address", "placeholder", "Type your email here", "type", "email", "name", "email", 3, "inputValue", "required", "onInputChange"], ["label", "Password", "placeholder", "Type your password here", "ngModel", "", "name", "password", 3, "inputValue", "isPassword", "required", "onInputChange"], [1, "extra-options"], [1, "checkbox"], ["type", "checkbox"], [1, "forgot-password", 3, "click"], [3, "type", "disabled", "text", "onClick"], [1, "signup"], ["id", "signup", 3, "routerLink"], [1, "social-login"], ["src", "assets/images/facebook-logo.png", "alt", "Facebook Logo", 1, "social-logo"], ["src", "assets/images/apple-logo.png", "alt", "Apple Logo", 1, "social-logo"], ["src", "assets/images/google-logo.png", "alt", "Google Logo", 1, "social-logo"], [3, "text", "popupClosed", 4, "ngIf"], [3, "text", "popupClosed"], [3, "placeholder", "control"], [2, "display", "flex", "gap", "10px"], [3, "text", "onClick"], [3, "boxShadow", "backgroundColor", "onClick", "text"]],
      template: function LoginComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "app-auth-background")(1, "form", null, 0)(3, "h1");
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](4, "Connexion");
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](5, "div", 1)(6, "app-auth-input-field", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("onInputChange", function LoginComponent_Template_app_auth_input_field_onInputChange_6_listener($event) {
            return ctx.setEmail($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](7, "app-auth-input-field", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("onInputChange", function LoginComponent_Template_app_auth_input_field_onInputChange_7_listener($event) {
            return ctx.setPassword($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](8, "div", 4)(9, "div", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](10, "input", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](11, "label");
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](12, " Remember me ? ");
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](13, "a", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function LoginComponent_Template_a_click_13_listener() {
            return ctx.showRequestPassPopup();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](14, "Forgot Password ?");
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](15, "app-button", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](16, "div", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](17, " Don't have an account? ");
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](18, "a", 10);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](19, "Sign up");
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](20, "div", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](21, "img", 12)(22, "img", 13)(23, "img", 14);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](24, LoginComponent_app_popup_24_Template, 5, 9, "app-popup", 15);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        }
        if (rf & 2) {
          const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵreference"](2);
          let tmp_6_0;
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("inputValue", ctx.email)("required", true);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("inputValue", ctx.password)("isPassword", true)("required", true);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](8);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("type", "submit")("disabled", (tmp_6_0 = _r0.invalid) !== null && tmp_6_0 !== undefined ? tmp_6_0 : false)("text", "Connexion")("onClick", ctx.connexion);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("routerLink", "/signup");
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.isRequestPopupVisible);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_10__.NgIf, _shared_components_auth_background_auth_background_component__WEBPACK_IMPORTED_MODULE_2__.AuthBackgroundComponent, _shared_components_auth_input_field_auth_input_field_component__WEBPACK_IMPORTED_MODULE_3__.AuthInputFieldComponent, _shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_4__.ButtonComponent, _shared_components_input_field_input_field_component__WEBPACK_IMPORTED_MODULE_5__.InputFieldComponent, _shared_components_popup_popup_component__WEBPACK_IMPORTED_MODULE_6__.PopupComponent, _angular_forms__WEBPACK_IMPORTED_MODULE_8__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_8__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.RequiredValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.NgModel, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.NgForm, _angular_router__WEBPACK_IMPORTED_MODULE_11__.RouterLink],
      styles: ["form[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%] {\n  font-size: 2.1rem;\n  font-weight: 600;\n  color: var(--primary-color);\n  text-align: center;\n  margin-bottom: 2rem;\n}\n.background[_ngcontent-%COMP%]   .logo[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: clamp(100px, 20%, 150px);\n}\n\nform[_ngcontent-%COMP%] {\n  width: 60%;\n  height: 90%;\n  display: flex;\n  flex-direction: column;\n  justify-content: space-between;\n  align-items: center;\n}\nform[_ngcontent-%COMP%]   .inputs[_ngcontent-%COMP%] {\n  width: 70%;\n  height: 100%;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  gap: 10px;\n}\ninput[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 0.7rem 0rem 0.7rem 0.5rem;\n  font-size: 0.8rem;\n  border: 1px solid #ccc;\n  border-radius: 6px;\n  position: relative;\n}\n\ninput[_ngcontent-%COMP%]:focus {\n  border: 2px solid var(--secondary-color);\n  box-shadow: 0 0 10px var(--light-green);\n  outline: none;\n}\n\ninput.ng-valid.ng-dirty[_ngcontent-%COMP%] {\n  border-bottom: 5px solid var(--secondary-color);\n}\n\ninput.valid.ng-dirty[_ngcontent-%COMP%] {\n  border-bottom: 5px solid var(--secondary-color) !important;\n}\n\ninput.ng-invalid.ng-dirty[_ngcontent-%COMP%] {\n  border-bottom: 5px solid red;\n}\ninput.ng-invalid.ng-dirty[_ngcontent-%COMP%]:focus {\n  border: 2px solid red;\n  box-shadow: 0 0 10px rgba(255, 0, 0, 0.3);\n}\ninput.invalid.ng-dirty[_ngcontent-%COMP%] {\n  border-bottom: 5px solid red !important;\n}\ninput.invalid.ng-dirty[_ngcontent-%COMP%]:focus {\n  border: 2px solid red;\n  box-shadow: 0 0 10px rgba(255, 0, 0, 0.3);\n}\n\ninput[_ngcontent-%COMP%]::placeholder {\n  color: var(--hint-text);\n}\n\n@media screen and (max-width: 768px) {\n  form[_ngcontent-%COMP%] {\n    width: max(80%, 500px);\n  }\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hc3NldHMvY3NzL2F1dGgtY29tbW9uLmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGlCQUFpQjtFQUNqQixnQkFBZ0I7RUFDaEIsMkJBQTJCO0VBQzNCLGtCQUFrQjtFQUNsQixtQkFBbUI7QUFDckI7QUFDQTtFQUNFLGtCQUFrQjtFQUNsQixNQUFNO0VBQ04sT0FBTztFQUNQLCtCQUErQjtBQUNqQzs7QUFFQTtFQUNFLFVBQVU7RUFDVixXQUFXO0VBQ1gsYUFBYTtFQUNiLHNCQUFzQjtFQUN0Qiw4QkFBOEI7RUFDOUIsbUJBQW1CO0FBQ3JCO0FBQ0E7RUFDRSxVQUFVO0VBQ1YsWUFBWTtFQUNaLGFBQWE7RUFDYixzQkFBc0I7RUFDdEIsdUJBQXVCO0VBQ3ZCLFNBQVM7QUFDWDtBQUNBO0VBQ0UsV0FBVztFQUNYLGtDQUFrQztFQUNsQyxpQkFBaUI7RUFDakIsc0JBQXNCO0VBQ3RCLGtCQUFrQjtFQUNsQixrQkFBa0I7QUFDcEI7O0FBRUE7RUFDRSx3Q0FBd0M7RUFDeEMsdUNBQXVDO0VBQ3ZDLGFBQWE7QUFDZjs7QUFFQTtFQUNFLCtDQUErQztBQUNqRDs7QUFFQTtFQUNFLDBEQUEwRDtBQUM1RDs7QUFFQTtFQUNFLDRCQUE0QjtBQUM5QjtBQUNBO0VBQ0UscUJBQXFCO0VBQ3JCLHlDQUF5QztBQUMzQztBQUNBO0VBQ0UsdUNBQXVDO0FBQ3pDO0FBQ0E7RUFDRSxxQkFBcUI7RUFDckIseUNBQXlDO0FBQzNDOztBQUVBO0VBQ0UsdUJBQXVCO0FBQ3pCOztBQUVBO0VBQ0U7SUFDRSxzQkFBc0I7RUFDeEI7QUFDRiIsInNvdXJjZXNDb250ZW50IjpbImZvcm0gaDEge1xyXG4gIGZvbnQtc2l6ZTogMi4xcmVtO1xyXG4gIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgY29sb3I6IHZhcigtLXByaW1hcnktY29sb3IpO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBtYXJnaW4tYm90dG9tOiAycmVtO1xyXG59XHJcbi5iYWNrZ3JvdW5kIC5sb2dvIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiAwO1xyXG4gIGxlZnQ6IDA7XHJcbiAgd2lkdGg6IGNsYW1wKDEwMHB4LCAyMCUsIDE1MHB4KTtcclxufVxyXG5cclxuZm9ybSB7XHJcbiAgd2lkdGg6IDYwJTtcclxuICBoZWlnaHQ6IDkwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuZm9ybSAuaW5wdXRzIHtcclxuICB3aWR0aDogNzAlO1xyXG4gIGhlaWdodDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgZ2FwOiAxMHB4O1xyXG59XHJcbmlucHV0IHtcclxuICB3aWR0aDogMTAwJTtcclxuICBwYWRkaW5nOiAwLjdyZW0gMHJlbSAwLjdyZW0gMC41cmVtO1xyXG4gIGZvbnQtc2l6ZTogMC44cmVtO1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkICNjY2M7XHJcbiAgYm9yZGVyLXJhZGl1czogNnB4O1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxufVxyXG5cclxuaW5wdXQ6Zm9jdXMge1xyXG4gIGJvcmRlcjogMnB4IHNvbGlkIHZhcigtLXNlY29uZGFyeS1jb2xvcik7XHJcbiAgYm94LXNoYWRvdzogMCAwIDEwcHggdmFyKC0tbGlnaHQtZ3JlZW4pO1xyXG4gIG91dGxpbmU6IG5vbmU7XHJcbn1cclxuXHJcbmlucHV0Lm5nLXZhbGlkLm5nLWRpcnR5IHtcclxuICBib3JkZXItYm90dG9tOiA1cHggc29saWQgdmFyKC0tc2Vjb25kYXJ5LWNvbG9yKTtcclxufVxyXG5cclxuaW5wdXQudmFsaWQubmctZGlydHkge1xyXG4gIGJvcmRlci1ib3R0b206IDVweCBzb2xpZCB2YXIoLS1zZWNvbmRhcnktY29sb3IpICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlucHV0Lm5nLWludmFsaWQubmctZGlydHkge1xyXG4gIGJvcmRlci1ib3R0b206IDVweCBzb2xpZCByZWQ7XHJcbn1cclxuaW5wdXQubmctaW52YWxpZC5uZy1kaXJ0eTpmb2N1cyB7XHJcbiAgYm9yZGVyOiAycHggc29saWQgcmVkO1xyXG4gIGJveC1zaGFkb3c6IDAgMCAxMHB4IHJnYmEoMjU1LCAwLCAwLCAwLjMpO1xyXG59XHJcbmlucHV0LmludmFsaWQubmctZGlydHkge1xyXG4gIGJvcmRlci1ib3R0b206IDVweCBzb2xpZCByZWQgIWltcG9ydGFudDtcclxufVxyXG5pbnB1dC5pbnZhbGlkLm5nLWRpcnR5OmZvY3VzIHtcclxuICBib3JkZXI6IDJweCBzb2xpZCByZWQ7XHJcbiAgYm94LXNoYWRvdzogMCAwIDEwcHggcmdiYSgyNTUsIDAsIDAsIDAuMyk7XHJcbn1cclxuXHJcbmlucHV0OjpwbGFjZWhvbGRlciB7XHJcbiAgY29sb3I6IHZhcigtLWhpbnQtdGV4dCk7XHJcbn1cclxuXHJcbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgZm9ybSB7XHJcbiAgICB3aWR0aDogbWF4KDgwJSwgNTAwcHgpO1xyXG4gIH1cclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */", ".extra-options[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n  justify-content: space-between;\n  margin-top: 10px;\n  color: var(--hint-text-color);\n  font-size: small;\n}\n.forgot-password[_ngcontent-%COMP%] {\n  color: var(--hint-text);\n  text-decoration: none;\n  cursor: pointer;\n}\n.checkbox[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n}\n.checkbox[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  margin-left: 5px;\n  color: var(--hint-text);\n}\ninput[type=\"checkbox\"][_ngcontent-%COMP%] {\n  appearance: none;\n  width: 25px;\n  height: 25px;\n  border: 2px solid var(--hint-text);\n  border-radius: 4px;\n  background-color: white;\n  cursor: pointer;\n}\n\ninput[type=\"checkbox\"][_ngcontent-%COMP%]:checked {\n  background-color: var(--primary-color);\n  border-color: var(--primary-color);\n  background-image: url('data:image/svg+xml;utf8,<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><path d=\"M20 6L9 17l-5-5\" fill=\"none\" stroke=\"white\" stroke-width=\"2\"/></svg>');\n  background-position: center;\n  background-repeat: no-repeat;\n  background-size: 18px;\n}\n.signup[_ngcontent-%COMP%] {\n  margin-top: 20px;\n  color: var(--text-color);\n  font-size: 0.9rem;\n  text-align: center;\n}\n#signup[_ngcontent-%COMP%] {\n  color: var(--primary-color);\n}\n.social-login[_ngcontent-%COMP%] {\n  margin-top: 10px;\n  display: flex;\n  justify-content: center;\n}\n.social-logo[_ngcontent-%COMP%] {\n  margin-left: 10px;\n  width: 15%;\n}\n.social-logo[_ngcontent-%COMP%]:hover {\n  transform: scale(1.2);\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvYXV0aC9sb2dpbi9sb2dpbi5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsV0FBVztFQUNYLGFBQWE7RUFDYiw4QkFBOEI7RUFDOUIsZ0JBQWdCO0VBQ2hCLDZCQUE2QjtFQUM3QixnQkFBZ0I7QUFDbEI7QUFDQTtFQUNFLHVCQUF1QjtFQUN2QixxQkFBcUI7RUFDckIsZUFBZTtBQUNqQjtBQUNBO0VBQ0UsYUFBYTtFQUNiLG1CQUFtQjtBQUNyQjtBQUNBO0VBQ0UsZ0JBQWdCO0VBQ2hCLHVCQUF1QjtBQUN6QjtBQUNBO0VBR0UsZ0JBQWdCO0VBQ2hCLFdBQVc7RUFDWCxZQUFZO0VBQ1osa0NBQWtDO0VBQ2xDLGtCQUFrQjtFQUNsQix1QkFBdUI7RUFDdkIsZUFBZTtBQUNqQjs7QUFFQTtFQUNFLHNDQUFzQztFQUN0QyxrQ0FBa0M7RUFDbEMsMExBQTBMO0VBQzFMLDJCQUEyQjtFQUMzQiw0QkFBNEI7RUFDNUIscUJBQXFCO0FBQ3ZCO0FBQ0E7RUFDRSxnQkFBZ0I7RUFDaEIsd0JBQXdCO0VBQ3hCLGlCQUFpQjtFQUNqQixrQkFBa0I7QUFDcEI7QUFDQTtFQUNFLDJCQUEyQjtBQUM3QjtBQUNBO0VBQ0UsZ0JBQWdCO0VBQ2hCLGFBQWE7RUFDYix1QkFBdUI7QUFDekI7QUFDQTtFQUNFLGlCQUFpQjtFQUNqQixVQUFVO0FBQ1o7QUFDQTtFQUNFLHFCQUFxQjtBQUN2QiIsInNvdXJjZXNDb250ZW50IjpbIi5leHRyYS1vcHRpb25zIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gIGNvbG9yOiB2YXIoLS1oaW50LXRleHQtY29sb3IpO1xyXG4gIGZvbnQtc2l6ZTogc21hbGw7XHJcbn1cclxuLmZvcmdvdC1wYXNzd29yZCB7XHJcbiAgY29sb3I6IHZhcigtLWhpbnQtdGV4dCk7XHJcbiAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG4uY2hlY2tib3gge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG4uY2hlY2tib3ggbGFiZWwge1xyXG4gIG1hcmdpbi1sZWZ0OiA1cHg7XHJcbiAgY29sb3I6IHZhcigtLWhpbnQtdGV4dCk7XHJcbn1cclxuaW5wdXRbdHlwZT1cImNoZWNrYm94XCJdIHtcclxuICAtd2Via2l0LWFwcGVhcmFuY2U6IG5vbmU7XHJcbiAgLW1vei1hcHBlYXJhbmNlOiBub25lO1xyXG4gIGFwcGVhcmFuY2U6IG5vbmU7XHJcbiAgd2lkdGg6IDI1cHg7XHJcbiAgaGVpZ2h0OiAyNXB4O1xyXG4gIGJvcmRlcjogMnB4IHNvbGlkIHZhcigtLWhpbnQtdGV4dCk7XHJcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5cclxuaW5wdXRbdHlwZT1cImNoZWNrYm94XCJdOmNoZWNrZWQge1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLXByaW1hcnktY29sb3IpO1xyXG4gIGJvcmRlci1jb2xvcjogdmFyKC0tcHJpbWFyeS1jb2xvcik7XHJcbiAgYmFja2dyb3VuZC1pbWFnZTogdXJsKCdkYXRhOmltYWdlL3N2Zyt4bWw7dXRmOCw8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+PHBhdGggZD1cIk0yMCA2TDkgMTdsLTUtNVwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwid2hpdGVcIiBzdHJva2Utd2lkdGg9XCIyXCIvPjwvc3ZnPicpO1xyXG4gIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcclxuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gIGJhY2tncm91bmQtc2l6ZTogMThweDtcclxufVxyXG4uc2lnbnVwIHtcclxuICBtYXJnaW4tdG9wOiAyMHB4O1xyXG4gIGNvbG9yOiB2YXIoLS10ZXh0LWNvbG9yKTtcclxuICBmb250LXNpemU6IDAuOXJlbTtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuI3NpZ251cCB7XHJcbiAgY29sb3I6IHZhcigtLXByaW1hcnktY29sb3IpO1xyXG59XHJcbi5zb2NpYWwtbG9naW4ge1xyXG4gIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxufVxyXG4uc29jaWFsLWxvZ28ge1xyXG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xyXG4gIHdpZHRoOiAxNSU7XHJcbn1cclxuLnNvY2lhbC1sb2dvOmhvdmVyIHtcclxuICB0cmFuc2Zvcm06IHNjYWxlKDEuMik7XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 6503:
/*!*****************************************************************!*\
  !*** ./src/app/auth/reset-password/reset-password.component.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ResetPasswordComponent: () => (/* binding */ ResetPasswordComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 5072);
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-toastr */ 4285);
/* harmony import */ var src_app_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/utils/functions.utils */ 3584);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/auth.service */ 4796);
/* harmony import */ var _shared_components_auth_background_auth_background_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../shared/components/auth-background/auth-background.component */ 3793);
/* harmony import */ var _shared_components_auth_input_field_auth_input_field_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../shared/components/auth-input-field/auth-input-field.component */ 4591);
/* harmony import */ var _shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../shared/components/button/button.component */ 8219);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 4456);










class ResetPasswordComponent {
  constructor() {
    this.actRoute = (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.inject)(_angular_router__WEBPACK_IMPORTED_MODULE_6__.ActivatedRoute);
    this.resetToken = this.actRoute.snapshot.params['resetToken'];
    this.oldPassword = '';
    this.newPassword = '';
    this.confirmNewPassword = '';
    this.authService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.inject)(src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_1__.AuthService);
    this.toastr = (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.inject)(ngx_toastr__WEBPACK_IMPORTED_MODULE_7__.ToastrService);
    this.router = (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.inject)(_angular_router__WEBPACK_IMPORTED_MODULE_6__.Router);
    this.resetPassword = () => {
      if (this.oldPassword && this.newPassword && this.confirmNewPassword) {
        if (this.newPassword == this.confirmNewPassword) {
          this.authService.resetPassword(this.resetToken, this.oldPassword, this.newPassword).subscribe({
            next: response => {
              this.toastr.success('Password Reset Success');
              this.router.navigate(['/login']);
            },
            error: err => {
              this.toastr.error(src_app_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_0__.AppUtils.getErrorMessage(err));
            }
          });
        } else {
          this.toastr.error('Password Mismatch');
        }
      }
    };
  }
  setOldPassword(event) {
    this.oldPassword = event;
  }
  setNewPassword(event) {
    this.newPassword = event;
  }
  setConfirmNewPassword(event) {
    this.confirmNewPassword = event;
  }
  static {
    this.ɵfac = function ResetPasswordComponent_Factory(t) {
      return new (t || ResetPasswordComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
      type: ResetPasswordComponent,
      selectors: [["app-reset-password"]],
      decls: 9,
      vars: 11,
      consts: [[1, "inputs"], ["label", "Old Password", "placeholder", "Type your password here", "ngModel", "", "name", "password", 3, "inputValue", "isPassword", "required", "onInputChange"], ["label", "New Password", "placeholder", "Type your password here", "ngModel", "", "name", "password", 3, "inputValue", "isPassword", "required", "onInputChange"], ["label", "Confirm New Password", "placeholder", "Type your password here", "ngModel", "", "name", "password", 3, "inputValue", "isPassword", "required", "onInputChange"], [3, "text", "onClick"]],
      template: function ResetPasswordComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "app-auth-background")(1, "form")(2, "h1");
          _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, "Reset Password");
          _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](4, "div", 0)(5, "app-auth-input-field", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("onInputChange", function ResetPasswordComponent_Template_app_auth_input_field_onInputChange_5_listener($event) {
            return ctx.setOldPassword($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](6, "app-auth-input-field", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("onInputChange", function ResetPasswordComponent_Template_app_auth_input_field_onInputChange_6_listener($event) {
            return ctx.setNewPassword($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](7, "app-auth-input-field", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("onInputChange", function ResetPasswordComponent_Template_app_auth_input_field_onInputChange_7_listener($event) {
            return ctx.setConfirmNewPassword($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](8, "app-button", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("inputValue", ctx.oldPassword)("isPassword", true)("required", true);
          _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("inputValue", ctx.newPassword)("isPassword", true)("required", true);
          _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("inputValue", ctx.confirmNewPassword)("isPassword", true)("required", true);
          _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("text", "Reset Password")("onClick", ctx.resetPassword);
        }
      },
      dependencies: [_shared_components_auth_background_auth_background_component__WEBPACK_IMPORTED_MODULE_2__.AuthBackgroundComponent, _shared_components_auth_input_field_auth_input_field_component__WEBPACK_IMPORTED_MODULE_3__.AuthInputFieldComponent, _shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_4__.ButtonComponent, _angular_forms__WEBPACK_IMPORTED_MODULE_8__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_8__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.RequiredValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.NgModel, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.NgForm],
      styles: ["form[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%] {\n  font-size: 2.1rem;\n  font-weight: 600;\n  color: var(--primary-color);\n  text-align: center;\n  margin-bottom: 2rem;\n}\n.background[_ngcontent-%COMP%]   .logo[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: clamp(100px, 20%, 150px);\n}\n\nform[_ngcontent-%COMP%] {\n  width: 60%;\n  height: 90%;\n  display: flex;\n  flex-direction: column;\n  justify-content: space-between;\n  align-items: center;\n}\nform[_ngcontent-%COMP%]   .inputs[_ngcontent-%COMP%] {\n  width: 70%;\n  height: 100%;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  gap: 10px;\n}\ninput[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 0.7rem 0rem 0.7rem 0.5rem;\n  font-size: 0.8rem;\n  border: 1px solid #ccc;\n  border-radius: 6px;\n  position: relative;\n}\n\ninput[_ngcontent-%COMP%]:focus {\n  border: 2px solid var(--secondary-color);\n  box-shadow: 0 0 10px var(--light-green);\n  outline: none;\n}\n\ninput.ng-valid.ng-dirty[_ngcontent-%COMP%] {\n  border-bottom: 5px solid var(--secondary-color);\n}\n\ninput.valid.ng-dirty[_ngcontent-%COMP%] {\n  border-bottom: 5px solid var(--secondary-color) !important;\n}\n\ninput.ng-invalid.ng-dirty[_ngcontent-%COMP%] {\n  border-bottom: 5px solid red;\n}\ninput.ng-invalid.ng-dirty[_ngcontent-%COMP%]:focus {\n  border: 2px solid red;\n  box-shadow: 0 0 10px rgba(255, 0, 0, 0.3);\n}\ninput.invalid.ng-dirty[_ngcontent-%COMP%] {\n  border-bottom: 5px solid red !important;\n}\ninput.invalid.ng-dirty[_ngcontent-%COMP%]:focus {\n  border: 2px solid red;\n  box-shadow: 0 0 10px rgba(255, 0, 0, 0.3);\n}\n\ninput[_ngcontent-%COMP%]::placeholder {\n  color: var(--hint-text);\n}\n\n@media screen and (max-width: 768px) {\n  form[_ngcontent-%COMP%] {\n    width: max(80%, 500px);\n  }\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hc3NldHMvY3NzL2F1dGgtY29tbW9uLmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGlCQUFpQjtFQUNqQixnQkFBZ0I7RUFDaEIsMkJBQTJCO0VBQzNCLGtCQUFrQjtFQUNsQixtQkFBbUI7QUFDckI7QUFDQTtFQUNFLGtCQUFrQjtFQUNsQixNQUFNO0VBQ04sT0FBTztFQUNQLCtCQUErQjtBQUNqQzs7QUFFQTtFQUNFLFVBQVU7RUFDVixXQUFXO0VBQ1gsYUFBYTtFQUNiLHNCQUFzQjtFQUN0Qiw4QkFBOEI7RUFDOUIsbUJBQW1CO0FBQ3JCO0FBQ0E7RUFDRSxVQUFVO0VBQ1YsWUFBWTtFQUNaLGFBQWE7RUFDYixzQkFBc0I7RUFDdEIsdUJBQXVCO0VBQ3ZCLFNBQVM7QUFDWDtBQUNBO0VBQ0UsV0FBVztFQUNYLGtDQUFrQztFQUNsQyxpQkFBaUI7RUFDakIsc0JBQXNCO0VBQ3RCLGtCQUFrQjtFQUNsQixrQkFBa0I7QUFDcEI7O0FBRUE7RUFDRSx3Q0FBd0M7RUFDeEMsdUNBQXVDO0VBQ3ZDLGFBQWE7QUFDZjs7QUFFQTtFQUNFLCtDQUErQztBQUNqRDs7QUFFQTtFQUNFLDBEQUEwRDtBQUM1RDs7QUFFQTtFQUNFLDRCQUE0QjtBQUM5QjtBQUNBO0VBQ0UscUJBQXFCO0VBQ3JCLHlDQUF5QztBQUMzQztBQUNBO0VBQ0UsdUNBQXVDO0FBQ3pDO0FBQ0E7RUFDRSxxQkFBcUI7RUFDckIseUNBQXlDO0FBQzNDOztBQUVBO0VBQ0UsdUJBQXVCO0FBQ3pCOztBQUVBO0VBQ0U7SUFDRSxzQkFBc0I7RUFDeEI7QUFDRiIsInNvdXJjZXNDb250ZW50IjpbImZvcm0gaDEge1xyXG4gIGZvbnQtc2l6ZTogMi4xcmVtO1xyXG4gIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgY29sb3I6IHZhcigtLXByaW1hcnktY29sb3IpO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBtYXJnaW4tYm90dG9tOiAycmVtO1xyXG59XHJcbi5iYWNrZ3JvdW5kIC5sb2dvIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiAwO1xyXG4gIGxlZnQ6IDA7XHJcbiAgd2lkdGg6IGNsYW1wKDEwMHB4LCAyMCUsIDE1MHB4KTtcclxufVxyXG5cclxuZm9ybSB7XHJcbiAgd2lkdGg6IDYwJTtcclxuICBoZWlnaHQ6IDkwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuZm9ybSAuaW5wdXRzIHtcclxuICB3aWR0aDogNzAlO1xyXG4gIGhlaWdodDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgZ2FwOiAxMHB4O1xyXG59XHJcbmlucHV0IHtcclxuICB3aWR0aDogMTAwJTtcclxuICBwYWRkaW5nOiAwLjdyZW0gMHJlbSAwLjdyZW0gMC41cmVtO1xyXG4gIGZvbnQtc2l6ZTogMC44cmVtO1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkICNjY2M7XHJcbiAgYm9yZGVyLXJhZGl1czogNnB4O1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxufVxyXG5cclxuaW5wdXQ6Zm9jdXMge1xyXG4gIGJvcmRlcjogMnB4IHNvbGlkIHZhcigtLXNlY29uZGFyeS1jb2xvcik7XHJcbiAgYm94LXNoYWRvdzogMCAwIDEwcHggdmFyKC0tbGlnaHQtZ3JlZW4pO1xyXG4gIG91dGxpbmU6IG5vbmU7XHJcbn1cclxuXHJcbmlucHV0Lm5nLXZhbGlkLm5nLWRpcnR5IHtcclxuICBib3JkZXItYm90dG9tOiA1cHggc29saWQgdmFyKC0tc2Vjb25kYXJ5LWNvbG9yKTtcclxufVxyXG5cclxuaW5wdXQudmFsaWQubmctZGlydHkge1xyXG4gIGJvcmRlci1ib3R0b206IDVweCBzb2xpZCB2YXIoLS1zZWNvbmRhcnktY29sb3IpICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlucHV0Lm5nLWludmFsaWQubmctZGlydHkge1xyXG4gIGJvcmRlci1ib3R0b206IDVweCBzb2xpZCByZWQ7XHJcbn1cclxuaW5wdXQubmctaW52YWxpZC5uZy1kaXJ0eTpmb2N1cyB7XHJcbiAgYm9yZGVyOiAycHggc29saWQgcmVkO1xyXG4gIGJveC1zaGFkb3c6IDAgMCAxMHB4IHJnYmEoMjU1LCAwLCAwLCAwLjMpO1xyXG59XHJcbmlucHV0LmludmFsaWQubmctZGlydHkge1xyXG4gIGJvcmRlci1ib3R0b206IDVweCBzb2xpZCByZWQgIWltcG9ydGFudDtcclxufVxyXG5pbnB1dC5pbnZhbGlkLm5nLWRpcnR5OmZvY3VzIHtcclxuICBib3JkZXI6IDJweCBzb2xpZCByZWQ7XHJcbiAgYm94LXNoYWRvdzogMCAwIDEwcHggcmdiYSgyNTUsIDAsIDAsIDAuMyk7XHJcbn1cclxuXHJcbmlucHV0OjpwbGFjZWhvbGRlciB7XHJcbiAgY29sb3I6IHZhcigtLWhpbnQtdGV4dCk7XHJcbn1cclxuXHJcbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgZm9ybSB7XHJcbiAgICB3aWR0aDogbWF4KDgwJSwgNTAwcHgpO1xyXG4gIH1cclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
    });
  }
}

/***/ }),

/***/ 6101:
/*!*************************************************!*\
  !*** ./src/app/auth/signup/signup.component.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SignupComponent: () => (/* binding */ SignupComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/forms */ 4456);
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ngx-toastr */ 4285);
/* harmony import */ var src_app_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/utils/functions.utils */ 3584);
/* harmony import */ var src_app_models_client_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/models/client.model */ 4477);
/* harmony import */ var src_app_models_nutritionist_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/models/nutritionist.model */ 4942);
/* harmony import */ var src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/models/recipe.model */ 6464);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/auth.service */ 4796);
/* harmony import */ var src_app_services_file_upload_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/file-upload.service */ 8222);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _shared_components_auth_background_auth_background_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../shared/components/auth-background/auth-background.component */ 3793);
/* harmony import */ var _shared_components_auth_input_field_auth_input_field_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../shared/components/auth-input-field/auth-input-field.component */ 4591);
/* harmony import */ var _shared_components_progress_indicator_progress_indicator_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../shared/components/progress-indicator/progress-indicator.component */ 2229);
/* harmony import */ var _shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../shared/components/button/button.component */ 8219);
/* harmony import */ var _shared_components_auth_dropdown_auth_dropdown_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../shared/components/auth-dropdown/auth-dropdown.component */ 8249);
/* harmony import */ var _shared_components_auth_account_type_auth_account_type_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../shared/components/auth-account-type/auth-account-type.component */ 1765);
/* harmony import */ var _shared_components_upload_image_upload_image_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../shared/components/upload-image/upload-image.component */ 6881);



















function SignupComponent_div_6_app_auth_account_type_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "app-auth-account-type", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("typeSelected", function SignupComponent_div_6_app_auth_account_type_3_Template_app_auth_account_type_typeSelected_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r12);
      const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r11.selectType($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const account_r10 = ctx.$implicit;
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("type", account_r10.type)("description", account_r10.description)("selectedType", ctx_r9.selectedType);
  }
}
function SignupComponent_div_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 7)(1, "h2");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](2, "Choose your Account Type");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](3, SignupComponent_div_6_app_auth_account_type_3_Template, 1, 3, "app-auth-account-type", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngForOf", ctx_r0.accountTypes);
  }
}
function SignupComponent_div_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 7)(1, "app-auth-input-field", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("onInputChange", function SignupComponent_div_7_Template_app_auth_input_field_onInputChange_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r14);
      const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r13.setEmail($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "app-auth-input-field", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("onInputChange", function SignupComponent_div_7_Template_app_auth_input_field_onInputChange_2_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r14);
      const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r15.setPassword($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](3, "app-auth-input-field", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("onInputChange", function SignupComponent_div_7_Template_app_auth_input_field_onInputChange_3_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r14);
      const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r16.setConfirmPassword($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("inputValue", ctx_r1.email)("required", true)("updateInputNote", ctx_r1.updateEmailInputNote);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("inputValue", ctx_r1.password)("isPassword", true)("required", true)("updateInputNote", ctx_r1.updatePasswordInputNote);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("inputValue", ctx_r1.confirmPassword)("isPassword", true)("required", true)("valid", ctx_r1.valid)("updateInputNote", ctx_r1.updateConfirmPasswordInputNote);
  }
}
function SignupComponent_div_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 7)(1, "app-auth-input-field", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("onInputChange", function SignupComponent_div_8_Template_app_auth_input_field_onInputChange_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r18);
      const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r17.setName($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "div", 14)(3, "app-auth-dropdown", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("onInputChange", function SignupComponent_div_8_Template_app_auth_dropdown_onInputChange_3_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r18);
      const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r19.selectGender($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](4, "div", 16)(5, "label", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](6, "Date de naissance");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](7, "input", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](8, "app-auth-input-field", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("onInputChange", function SignupComponent_div_8_Template_app_auth_input_field_onInputChange_8_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r18);
      const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r20.setPhoneNumber($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("inputValue", ctx_r2.name)("required", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("options", ctx_r2.genderOptions)("label", "Gender")("selectedOption", ctx_r2.selectedGender);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("formControl", ctx_r2.selectedDateControl);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("inputValue", ctx_r2.phoneNumber)("required", true);
  }
}
function SignupComponent_div_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r22 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 7)(1, "div", 14)(2, "app-auth-dropdown", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("onInputChange", function SignupComponent_div_9_Template_app_auth_dropdown_onInputChange_2_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r22);
      const ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r21.selectPoids($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](3, "app-auth-dropdown", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("onInputChange", function SignupComponent_div_9_Template_app_auth_dropdown_onInputChange_3_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r22);
      const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r23.selectTaille($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](4, "app-auth-dropdown", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("onInputChange", function SignupComponent_div_9_Template_app_auth_dropdown_onInputChange_4_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r22);
      const ctx_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r24.selectActiviteJournaliere($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](5, "app-auth-dropdown", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("onInputChange", function SignupComponent_div_9_Template_app_auth_dropdown_onInputChange_5_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r22);
      const ctx_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r25.selectObjectif($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("options", ctx_r3.poidsActuelOptions)("label", "Poids Actuel (Kg)")("selectedOption", ctx_r3.selectedPoids);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("options", ctx_r3.tailleOptions)("label", "Taille (cm)")("selectedOption", ctx_r3.selectedTaille);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("options", ctx_r3.activiteJournaliereOptions)("label", "Activit\u00E9 journali\u00E8re")("selectedOption", ctx_r3.selectedActiviteJournaliere);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("options", ctx_r3.objectifOptions)("label", "Objectif")("selectedOption", ctx_r3.selectedObjectif);
  }
}
function SignupComponent_div_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r27 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 7)(1, "div", 14)(2, "app-auth-dropdown", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("onInputChange", function SignupComponent_div_10_Template_app_auth_dropdown_onInputChange_2_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r27);
      const ctx_r26 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r26.selectExperienceYears($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](3, "app-auth-input-field", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("onInputChange", function SignupComponent_div_10_Template_app_auth_input_field_onInputChange_3_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r27);
      const ctx_r28 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r28.setLocation($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](4, "app-upload-image", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("fileSelected", function SignupComponent_div_10_Template_app_upload_image_fileSelected_4_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r27);
      const ctx_r29 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r29.selectFile($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("options", ctx_r4.experienceYearsOptions)("label", "Ann\u00E9es d'exp\u00E9rience")("selectedOption", ctx_r4.selectedExperienceYears);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("inputValue", ctx_r4.location)("required", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("uploadedFileName", ctx_r4.uploadedFile)("acceptedFileTypes", "application/pdf");
  }
}
function SignupComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    const _r31 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 7)(1, "app-upload-image", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("fileSelected", function SignupComponent_div_11_Template_app_upload_image_fileSelected_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r31);
      const ctx_r30 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r30.selectImage($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("acceptedFileTypes", "image/*")("uploadedImage", ctx_r5.uploadedImage);
  }
}
function SignupComponent_app_button_13_Template(rf, ctx) {
  if (rf & 1) {
    const _r33 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "app-button", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SignupComponent_app_button_13_Template_app_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r33);
      const ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r32.goPrevious());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("text", "Previous")("fontWeight", "300")("backgroundColor", "white")("textColor", "var(--hint-text)")("boxShadow", "0 4px 8px 2px var(--hint-text)");
  }
}
function SignupComponent_app_button_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r35 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "app-button", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SignupComponent_app_button_14_Template_app_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r35);
      const ctx_r34 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r34.goNext());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("text", "Next")("fontWeight", "300");
  }
}
function SignupComponent_app_button_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](0, "app-button", 25);
  }
  if (rf & 2) {
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("text", "Confirm")("fontWeight", "300")("onClick", ctx_r8.saveUser);
  }
}
class SignupComponent {
  constructor() {
    this.currentStep = 0;
    this.stepLabels = ['Account Type', 'Account Information', 'Profile Data', 'Additionnal Information', 'Profile Pictrue'];
    this.strengthLevels = {
      strong: /^(?=.*[A-Z])(?=.*[!@/#$&*])(?=.*[0-9])(?=.*[a-z].*[a-z].*[a-z].*[a-z].*[a-z]).{8,}$/,
      normal: /^(?=.*[A-Z]|(?=.*[!@#$&*/])|(?=.*[0-9])).{8,}$/ // At least one uppercase, one lowercase, and one number.
    };

    this.valid = true;
    // __________ STEP 1 : ACCOUNT TYPE ___________
    this.clientRole = src_app_models_client_model__WEBPACK_IMPORTED_MODULE_1__.UserRoleEnum.CLIENT;
    this.nutritionnistRole = src_app_models_client_model__WEBPACK_IMPORTED_MODULE_1__.UserRoleEnum.NUTRITIONIST;
    this.accountTypes = [{
      type: src_app_models_client_model__WEBPACK_IMPORTED_MODULE_1__.UserRoleEnum.NUTRITIONIST,
      description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit.'
    }, {
      type: src_app_models_client_model__WEBPACK_IMPORTED_MODULE_1__.UserRoleEnum.CLIENT,
      description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit.'
    }];
    this.selectedType = '';
    //__________ STEP 2 : EMAIL & PASSWORD ___________
    this.email = '';
    this.password = '';
    this.confirmPassword = '';
    this.updatePasswordInputNote = (password, errors) => {
      if (errors) {
        if (errors['required']) {
          return 'Required Field..';
        } else if (errors['minlength']) {
          return `Minimum length is ${errors['minlength'].requiredLength}..`;
        } else {
          return 'Invalid input..';
        }
      } else {
        if (this.strengthLevels['strong'].test(password)) {
          return 'Strong..'; // Valid password (strong).
        } else if (this.strengthLevels['normal'].test(password)) {
          return 'Normal..';
        } // Normal password strength.
        else {
          return 'Weak'; // Weak password strength.
        }
      }
    };

    this.updateConfirmPasswordInputNote = (newValue, errors) => {
      if (!errors && this.valid) return '';
      if (!this.valid) {
        return 'Password Mismatch..';
      }
      return '';
    };
    // __________ STEP 3 : NAME / GENDER / AGE / PHONENUMBER ___________
    this.name = '';
    this.genderOptions = ['Homme', 'Femme'];
    this.selectedGender = 'Homme';
    // ageOptions: number[] = [];
    // selectedAge: string = '';
    this.selectedDateControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormControl('');
    // selectAge(age: string) {
    //   this.selectedAge = age;
    // }
    // populateAgeOptions(): void {
    //   const minAge = 18; // Minimum age
    //   const maxAge = 80; // Maximum age
    //   for (let age = minAge; age <= maxAge; age++) {
    //     this.ageOptions.push(age);
    //   }
    // }
    this.phoneNumber = '';
    // __________ STEP 4 : Nutritionist Details___________
    this.experienceYearsOptions = [];
    this.selectedExperienceYears = '1';
    this.location = '';
    // __________ STEP 4 : POIDS / TAILLE / ACTIVITE / OBJECTIF ___________
    this.poidsActuelOptions = [];
    this.selectedPoids = '40';
    this.tailleOptions = [];
    this.selectedTaille = '150';
    this.activiteJournaliereOptions = ['Sédentaire', 'Légèrement actif', 'Modérément actif', 'Très actif', 'Extrêmement actif'];
    this.selectedActiviteJournaliere = this.activiteJournaliereOptions[0];
    this.objectifOptions = ['Perdre du poids', 'Prendre du poids', 'Se muscler', 'Maintenir le poids'];
    this.selectedObjectif = this.objectifOptions[0];
    this.uploadedImage = '';
    this.uploadedFile = '';
    this.isFormInvalid = true;
    this.toastr = (0,_angular_core__WEBPACK_IMPORTED_MODULE_13__.inject)(ngx_toastr__WEBPACK_IMPORTED_MODULE_15__.ToastrService);
    this.uploadFileService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_13__.inject)(src_app_services_file_upload_service__WEBPACK_IMPORTED_MODULE_5__.FileUploadService);
    this.saveUser = () => {
      if (this.imageFile) {
        // Upload the image first
        this.uploadFileService.uploadImage(this.imageFile).subscribe({
          next: response => {
            console.log('Upload Success:', response);
            this.uploadedImage = response.path;
            this.processSignup(); // Handle the recipe after uploading the image
          },

          error: err => {
            console.error('Upload Failed:', err);
            this.toastr.error('Image upload failed. Please try again.');
          }
        });
      }
    };
    this.processSignup = () => {
      if (this.pdfFile) {
        this.uploadFileService.uploadFile(this.pdfFile).subscribe({
          next: response => {
            console.log('Upload Success:', response);
            this.uploadedFile = response.path;
            this.finalizeSignup();
          },
          error: err => {
            console.error('Upload Failed:', err);
            this.toastr.error('File upload failed. Please try again.');
          }
        });
      } else {
        this.finalizeSignup();
      }
    };
    this.authService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_13__.inject)(src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_4__.AuthService);
    this.finalizeSignup = () => {
      const user = this.createUserModel();
      console.log('====================================');
      console.log('User:', user);
      console.log('====================================');
      this.authService.signupUser(user);
    };
    // this.populateAgeOptions();
    this.populatePoidsActuelOptions();
    this.populateTailleOptions();
    this.populateExpYearsOptions();
  }
  goNext() {
    this.currentStep++;
    console.log(this.currentStep);
  }
  goPrevious() {
    this.currentStep--;
    console.log(this.currentStep);
  }
  selectType(type) {
    this.selectedType = type;
  }
  setEmail(event) {
    console.log('password set');
    this.email = event;
  }
  setPassword(event) {
    console.log('password set');
    this.password = event;
  }
  setConfirmPassword(event) {
    console.log('confirm password set');
    this.confirmPassword = event;
    this.checkPasswordValidation();
  }
  checkPasswordValidation() {
    this.valid = this.password == this.confirmPassword;
    console.log('valid from signup: ' + this.valid);
  }
  updateEmailInputNote(newValue, errors) {
    if (errors) {
      if (errors['required']) {
        return 'Required Field..';
      } else if (errors['email']) {
        return 'Invalid email..';
      } else {
        return 'Invalid input..';
      }
    } else {
      return '';
    }
  }
  setName(name) {
    this.name = name;
  }
  selectGender(gender) {
    this.selectedGender = gender;
    console.log('new gender selected' + this.selectedGender);
  }
  setPhoneNumber(phoneNumber) {
    this.phoneNumber = phoneNumber;
  }
  populateExpYearsOptions() {
    const minExpYears = 1;
    const maxExpYears = 50;
    for (let expYears = minExpYears; expYears <= maxExpYears; expYears++) {
      this.experienceYearsOptions.push(expYears);
    }
  }
  selectExperienceYears($event) {
    this.selectedExperienceYears = $event;
  }
  setLocation(event) {
    this.location = event;
  }
  populatePoidsActuelOptions() {
    const poidsMin = 40; // Minimum age
    const poidsMax = 250; // Maximum age
    for (let poids = poidsMin; poids <= poidsMax; poids++) {
      this.poidsActuelOptions.push(poids.toString());
    }
  }
  selectPoids(poids) {
    this.selectedPoids = poids;
  }
  populateTailleOptions() {
    const tailleMin = 150; // Minimum age
    const tailleMax = 230; // Maximum age
    for (let taille = tailleMin; taille <= tailleMax; taille++) {
      this.tailleOptions.push(taille);
    }
  }
  selectTaille(taille) {
    this.selectedTaille = taille;
  }
  selectActiviteJournaliere(activiteJournaliere) {
    this.selectedActiviteJournaliere = activiteJournaliere;
  }
  selectObjectif(objectif) {
    this.selectedObjectif = objectif;
  }
  selectImage(selectedImage) {
    this.imageFile = selectedImage;
    const reader = new FileReader();
    reader.onload = e => {
      this.uploadedImage = e.target?.result;
    };
    reader.readAsDataURL(selectedImage);
    console.log('Selected image:', selectedImage.name);
  }
  selectFile(selectedFile) {
    this.pdfFile = selectedFile;
    this.uploadedFile = selectedFile.name;
  }
  createUserModel() {
    let user;
    if (this.selectedType === src_app_models_client_model__WEBPACK_IMPORTED_MODULE_1__.UserRoleEnum.CLIENT) {
      user = new src_app_models_client_model__WEBPACK_IMPORTED_MODULE_1__.ClientModel(this.name, this.email, this.password, this.phoneNumber, this.uploadedImage, src_app_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_0__.AppUtils.convertToEnum(src_app_models_client_model__WEBPACK_IMPORTED_MODULE_1__.GenderEnum, this.selectedGender), new Date(this.selectedDateControl.value ?? ''), src_app_models_client_model__WEBPACK_IMPORTED_MODULE_1__.UserRoleEnum.CLIENT, parseInt(this.selectedTaille), parseInt(this.selectedPoids), [], src_app_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_0__.AppUtils.convertToEnum(src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_3__.ObjectifEnum, this.selectedObjectif), src_app_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_0__.AppUtils.convertToEnum(src_app_models_client_model__WEBPACK_IMPORTED_MODULE_1__.ActivityLevelEnum, this.selectedActiviteJournaliere));
    } else {
      user = new src_app_models_nutritionist_model__WEBPACK_IMPORTED_MODULE_2__.NutritionistModel(this.name, this.email, this.password, this.phoneNumber, this.uploadedImage, src_app_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_0__.AppUtils.convertToEnum(src_app_models_client_model__WEBPACK_IMPORTED_MODULE_1__.GenderEnum, this.selectedGender), new Date(this.selectedDateControl.value ?? ''), src_app_models_client_model__WEBPACK_IMPORTED_MODULE_1__.UserRoleEnum.NUTRITIONIST, parseInt(this.selectedExperienceYears), this.uploadedFile, src_app_models_nutritionist_model__WEBPACK_IMPORTED_MODULE_2__.StatusEnum.Waiting, this.location);
    }
    return user;
  }
  isButtonDisabled() {
    this.isFormInvalid = !this.name || !this.email || !this.password || !this.confirmPassword || !this.selectedDateControl.value || !this.phoneNumber || !this.selectedType || !this.selectedPoids || !this.selectedTaille || !this.selectedActiviteJournaliere || !this.selectedObjectif || !this.selectedGender;
    return this.isFormInvalid;
  }
  static {
    this.ɵfac = function SignupComponent_Factory(t) {
      return new (t || SignupComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineComponent"]({
      type: SignupComponent,
      selectors: [["app-signup"]],
      decls: 16,
      vars: 11,
      consts: [[1, "steps-wrapper"], [3, "steps", "activeStep"], ["class", "inputs", 4, "ngIf"], [1, "buttons"], [3, "text", "fontWeight", "backgroundColor", "textColor", "boxShadow", "click", 4, "ngIf"], [3, "text", "fontWeight", "click", 4, "ngIf"], [3, "text", "fontWeight", "onClick", 4, "ngIf"], [1, "inputs"], [3, "type", "description", "selectedType", "typeSelected", 4, "ngFor", "ngForOf"], [3, "type", "description", "selectedType", "typeSelected"], ["label", "Email Address", "placeholder", "Type your email here", "type", "email", "name", "email", 3, "inputValue", "required", "updateInputNote", "onInputChange"], ["label", "Password", "placeholder", "Type your password here", "name", "password", 3, "inputValue", "isPassword", "required", "updateInputNote", "onInputChange"], ["label", "Confirm Password", "placeholder", "Confirm your password here", "name", "password", 3, "inputValue", "isPassword", "required", "valid", "updateInputNote", "onInputChange"], ["label", "Full Name", "placeholder", "Type your full name here", "type", "text", 3, "inputValue", "required", "onInputChange"], [1, "dropdowns"], [1, "dropdown", 3, "options", "label", "selectedOption", "onInputChange"], [1, "birthdate"], [1, "input-label"], ["id", "date-input", "type", "date", 1, "date-input", 3, "formControl"], ["label", "Phone Number", "placeholder", "+216", "type", "text", 3, "inputValue", "required", "onInputChange"], ["label", "Localisation", "placeholder", "Type your location here", "type", "text", "name", "location", 3, "inputValue", "required", "onInputChange"], [3, "uploadedFileName", "acceptedFileTypes", "fileSelected"], [3, "acceptedFileTypes", "uploadedImage", "fileSelected"], [3, "text", "fontWeight", "backgroundColor", "textColor", "boxShadow", "click"], [3, "text", "fontWeight", "click"], [3, "text", "fontWeight", "onClick"]],
      template: function SignupComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "app-auth-background")(1, "form")(2, "h1");
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, "Inscription");
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](4, "div", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](5, "app-progress-indicator", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](6, SignupComponent_div_6_Template, 4, 1, "div", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](7, SignupComponent_div_7_Template, 4, 12, "div", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](8, SignupComponent_div_8_Template, 9, 8, "div", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](9, SignupComponent_div_9_Template, 6, 12, "div", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](10, SignupComponent_div_10_Template, 5, 7, "div", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](11, SignupComponent_div_11_Template, 2, 2, "div", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](12, "div", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](13, SignupComponent_app_button_13_Template, 1, 5, "app-button", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](14, SignupComponent_app_button_14_Template, 1, 2, "app-button", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](15, SignupComponent_app_button_15_Template, 1, 3, "app-button", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("steps", ctx.stepLabels)("activeStep", ctx.currentStep);
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.currentStep == 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.currentStep == 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.currentStep == 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.currentStep == 3 && ctx.selectedType == ctx.clientRole);
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.currentStep == 3 && ctx.selectedType == ctx.nutritionnistRole);
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.currentStep == 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.currentStep > 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.currentStep < 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.currentStep == 4);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_16__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_16__.NgIf, _shared_components_auth_background_auth_background_component__WEBPACK_IMPORTED_MODULE_6__.AuthBackgroundComponent, _shared_components_auth_input_field_auth_input_field_component__WEBPACK_IMPORTED_MODULE_7__.AuthInputFieldComponent, _shared_components_progress_indicator_progress_indicator_component__WEBPACK_IMPORTED_MODULE_8__.ProgressIndicatorComponent, _shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_9__.ButtonComponent, _shared_components_auth_dropdown_auth_dropdown_component__WEBPACK_IMPORTED_MODULE_10__.AuthDropdownComponent, _shared_components_auth_account_type_auth_account_type_component__WEBPACK_IMPORTED_MODULE_11__.AuthAccountTypeComponent, _shared_components_upload_image_upload_image_component__WEBPACK_IMPORTED_MODULE_12__.UploadImageComponent, _angular_forms__WEBPACK_IMPORTED_MODULE_14__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_14__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.NgForm, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormControlDirective],
      styles: ["form[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%] {\n  font-size: 2.1rem;\n  font-weight: 600;\n  color: var(--primary-color);\n  text-align: center;\n  margin-bottom: 2rem;\n}\n.background[_ngcontent-%COMP%]   .logo[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: clamp(100px, 20%, 150px);\n}\n\nform[_ngcontent-%COMP%] {\n  width: 60%;\n  height: 90%;\n  display: flex;\n  flex-direction: column;\n  justify-content: space-between;\n  align-items: center;\n}\nform[_ngcontent-%COMP%]   .inputs[_ngcontent-%COMP%] {\n  width: 70%;\n  height: 100%;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  gap: 10px;\n}\ninput[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 0.7rem 0rem 0.7rem 0.5rem;\n  font-size: 0.8rem;\n  border: 1px solid #ccc;\n  border-radius: 6px;\n  position: relative;\n}\n\ninput[_ngcontent-%COMP%]:focus {\n  border: 2px solid var(--secondary-color);\n  box-shadow: 0 0 10px var(--light-green);\n  outline: none;\n}\n\ninput.ng-valid.ng-dirty[_ngcontent-%COMP%] {\n  border-bottom: 5px solid var(--secondary-color);\n}\n\ninput.valid.ng-dirty[_ngcontent-%COMP%] {\n  border-bottom: 5px solid var(--secondary-color) !important;\n}\n\ninput.ng-invalid.ng-dirty[_ngcontent-%COMP%] {\n  border-bottom: 5px solid red;\n}\ninput.ng-invalid.ng-dirty[_ngcontent-%COMP%]:focus {\n  border: 2px solid red;\n  box-shadow: 0 0 10px rgba(255, 0, 0, 0.3);\n}\ninput.invalid.ng-dirty[_ngcontent-%COMP%] {\n  border-bottom: 5px solid red !important;\n}\ninput.invalid.ng-dirty[_ngcontent-%COMP%]:focus {\n  border: 2px solid red;\n  box-shadow: 0 0 10px rgba(255, 0, 0, 0.3);\n}\n\ninput[_ngcontent-%COMP%]::placeholder {\n  color: var(--hint-text);\n}\n\n@media screen and (max-width: 768px) {\n  form[_ngcontent-%COMP%] {\n    width: max(80%, 500px);\n  }\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hc3NldHMvY3NzL2F1dGgtY29tbW9uLmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGlCQUFpQjtFQUNqQixnQkFBZ0I7RUFDaEIsMkJBQTJCO0VBQzNCLGtCQUFrQjtFQUNsQixtQkFBbUI7QUFDckI7QUFDQTtFQUNFLGtCQUFrQjtFQUNsQixNQUFNO0VBQ04sT0FBTztFQUNQLCtCQUErQjtBQUNqQzs7QUFFQTtFQUNFLFVBQVU7RUFDVixXQUFXO0VBQ1gsYUFBYTtFQUNiLHNCQUFzQjtFQUN0Qiw4QkFBOEI7RUFDOUIsbUJBQW1CO0FBQ3JCO0FBQ0E7RUFDRSxVQUFVO0VBQ1YsWUFBWTtFQUNaLGFBQWE7RUFDYixzQkFBc0I7RUFDdEIsdUJBQXVCO0VBQ3ZCLFNBQVM7QUFDWDtBQUNBO0VBQ0UsV0FBVztFQUNYLGtDQUFrQztFQUNsQyxpQkFBaUI7RUFDakIsc0JBQXNCO0VBQ3RCLGtCQUFrQjtFQUNsQixrQkFBa0I7QUFDcEI7O0FBRUE7RUFDRSx3Q0FBd0M7RUFDeEMsdUNBQXVDO0VBQ3ZDLGFBQWE7QUFDZjs7QUFFQTtFQUNFLCtDQUErQztBQUNqRDs7QUFFQTtFQUNFLDBEQUEwRDtBQUM1RDs7QUFFQTtFQUNFLDRCQUE0QjtBQUM5QjtBQUNBO0VBQ0UscUJBQXFCO0VBQ3JCLHlDQUF5QztBQUMzQztBQUNBO0VBQ0UsdUNBQXVDO0FBQ3pDO0FBQ0E7RUFDRSxxQkFBcUI7RUFDckIseUNBQXlDO0FBQzNDOztBQUVBO0VBQ0UsdUJBQXVCO0FBQ3pCOztBQUVBO0VBQ0U7SUFDRSxzQkFBc0I7RUFDeEI7QUFDRiIsInNvdXJjZXNDb250ZW50IjpbImZvcm0gaDEge1xyXG4gIGZvbnQtc2l6ZTogMi4xcmVtO1xyXG4gIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgY29sb3I6IHZhcigtLXByaW1hcnktY29sb3IpO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBtYXJnaW4tYm90dG9tOiAycmVtO1xyXG59XHJcbi5iYWNrZ3JvdW5kIC5sb2dvIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiAwO1xyXG4gIGxlZnQ6IDA7XHJcbiAgd2lkdGg6IGNsYW1wKDEwMHB4LCAyMCUsIDE1MHB4KTtcclxufVxyXG5cclxuZm9ybSB7XHJcbiAgd2lkdGg6IDYwJTtcclxuICBoZWlnaHQ6IDkwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuZm9ybSAuaW5wdXRzIHtcclxuICB3aWR0aDogNzAlO1xyXG4gIGhlaWdodDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgZ2FwOiAxMHB4O1xyXG59XHJcbmlucHV0IHtcclxuICB3aWR0aDogMTAwJTtcclxuICBwYWRkaW5nOiAwLjdyZW0gMHJlbSAwLjdyZW0gMC41cmVtO1xyXG4gIGZvbnQtc2l6ZTogMC44cmVtO1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkICNjY2M7XHJcbiAgYm9yZGVyLXJhZGl1czogNnB4O1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxufVxyXG5cclxuaW5wdXQ6Zm9jdXMge1xyXG4gIGJvcmRlcjogMnB4IHNvbGlkIHZhcigtLXNlY29uZGFyeS1jb2xvcik7XHJcbiAgYm94LXNoYWRvdzogMCAwIDEwcHggdmFyKC0tbGlnaHQtZ3JlZW4pO1xyXG4gIG91dGxpbmU6IG5vbmU7XHJcbn1cclxuXHJcbmlucHV0Lm5nLXZhbGlkLm5nLWRpcnR5IHtcclxuICBib3JkZXItYm90dG9tOiA1cHggc29saWQgdmFyKC0tc2Vjb25kYXJ5LWNvbG9yKTtcclxufVxyXG5cclxuaW5wdXQudmFsaWQubmctZGlydHkge1xyXG4gIGJvcmRlci1ib3R0b206IDVweCBzb2xpZCB2YXIoLS1zZWNvbmRhcnktY29sb3IpICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlucHV0Lm5nLWludmFsaWQubmctZGlydHkge1xyXG4gIGJvcmRlci1ib3R0b206IDVweCBzb2xpZCByZWQ7XHJcbn1cclxuaW5wdXQubmctaW52YWxpZC5uZy1kaXJ0eTpmb2N1cyB7XHJcbiAgYm9yZGVyOiAycHggc29saWQgcmVkO1xyXG4gIGJveC1zaGFkb3c6IDAgMCAxMHB4IHJnYmEoMjU1LCAwLCAwLCAwLjMpO1xyXG59XHJcbmlucHV0LmludmFsaWQubmctZGlydHkge1xyXG4gIGJvcmRlci1ib3R0b206IDVweCBzb2xpZCByZWQgIWltcG9ydGFudDtcclxufVxyXG5pbnB1dC5pbnZhbGlkLm5nLWRpcnR5OmZvY3VzIHtcclxuICBib3JkZXI6IDJweCBzb2xpZCByZWQ7XHJcbiAgYm94LXNoYWRvdzogMCAwIDEwcHggcmdiYSgyNTUsIDAsIDAsIDAuMyk7XHJcbn1cclxuXHJcbmlucHV0OjpwbGFjZWhvbGRlciB7XHJcbiAgY29sb3I6IHZhcigtLWhpbnQtdGV4dCk7XHJcbn1cclxuXHJcbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgZm9ybSB7XHJcbiAgICB3aWR0aDogbWF4KDgwJSwgNTAwcHgpO1xyXG4gIH1cclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */", ".inputs[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  color: var(--primary-color);\n  font-size: 1.5rem;\n  font-weight: 600;\n  color: var(--primary-color);\n  margin-bottom: 1rem;\n}\n\n.birthdate[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n}\ninput[type=\"date\"][_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 0.6rem 0rem 0.6rem 0.5rem;\n  font-size: 0.8rem;\n  border: 1px solid #ccc;\n  border-radius: 6px;\n  position: relative;\n}\n\n\n\n\n\n\n\n.buttons[_ngcontent-%COMP%] {\n  margin-top: auto;\n  width: 100%;\n  display: flex;\n  justify-content: end;\n  gap: 10px;\n}\n.steps-wrapper[_ngcontent-%COMP%] {\n  width: 90%;\n  height: 15%;\n}\n\n.dropdowns[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 10px;\n}\n.dropdowns[_ngcontent-%COMP%]   .dropdown[_ngcontent-%COMP%] {\n  flex: 50%;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvYXV0aC9zaWdudXAvc2lnbnVwLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSwyQkFBMkI7RUFDM0IsaUJBQWlCO0VBQ2pCLGdCQUFnQjtFQUNoQiwyQkFBMkI7RUFDM0IsbUJBQW1CO0FBQ3JCOztBQUVBO0VBQ0UsYUFBYTtFQUNiLHNCQUFzQjtBQUN4QjtBQUNBO0VBQ0UsV0FBVztFQUNYLGtDQUFrQztFQUNsQyxpQkFBaUI7RUFDakIsc0JBQXNCO0VBQ3RCLGtCQUFrQjtFQUNsQixrQkFBa0I7QUFDcEI7QUFDQTs7Ozs7R0FLRztBQUNIO0VBQ0UsZ0JBQWdCO0VBQ2hCLFdBQVc7RUFDWCxhQUFhO0VBQ2Isb0JBQW9CO0VBQ3BCLFNBQVM7QUFDWDtBQUNBO0VBQ0UsVUFBVTtFQUNWLFdBQVc7QUFDYjs7QUFFQTtFQUNFLGFBQWE7RUFDYixTQUFTO0FBQ1g7QUFDQTtFQUNFLFNBQVM7QUFDWCIsInNvdXJjZXNDb250ZW50IjpbIi5pbnB1dHMgaDIge1xyXG4gIGNvbG9yOiB2YXIoLS1wcmltYXJ5LWNvbG9yKTtcclxuICBmb250LXNpemU6IDEuNXJlbTtcclxuICBmb250LXdlaWdodDogNjAwO1xyXG4gIGNvbG9yOiB2YXIoLS1wcmltYXJ5LWNvbG9yKTtcclxuICBtYXJnaW4tYm90dG9tOiAxcmVtO1xyXG59XHJcblxyXG4uYmlydGhkYXRlIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbn1cclxuaW5wdXRbdHlwZT1cImRhdGVcIl0ge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIHBhZGRpbmc6IDAuNnJlbSAwcmVtIDAuNnJlbSAwLjVyZW07XHJcbiAgZm9udC1zaXplOiAwLjhyZW07XHJcbiAgYm9yZGVyOiAxcHggc29saWQgI2NjYztcclxuICBib3JkZXItcmFkaXVzOiA2cHg7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG59XHJcbi8qIC5hY2NvdW50LXR5cGUtY29udGFpbmVyIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgZ2FwOiAyMHB4O1xyXG59ICovXHJcbi5idXR0b25zIHtcclxuICBtYXJnaW4tdG9wOiBhdXRvO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBlbmQ7XHJcbiAgZ2FwOiAxMHB4O1xyXG59XHJcbi5zdGVwcy13cmFwcGVyIHtcclxuICB3aWR0aDogOTAlO1xyXG4gIGhlaWdodDogMTUlO1xyXG59XHJcblxyXG4uZHJvcGRvd25zIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGdhcDogMTBweDtcclxufVxyXG4uZHJvcGRvd25zIC5kcm9wZG93biB7XHJcbiAgZmxleDogNTAlO1xyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
    });
  }
}

/***/ }),

/***/ 8111:
/*!****************************************************!*\
  !*** ./src/app/core/constants/constants.config.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   APP_API: () => (/* binding */ APP_API),
/* harmony export */   APP_CONST: () => (/* binding */ APP_CONST)
/* harmony export */ });
const APP_API = {
  base_url: 'http://NutrisolutionsLB-834407706.us-east-1.elb.amazonaws.com:8080'
};
const APP_CONST = {
  tokenLocalStorage: 'accessToken',
  role: 'role',
  payloadIdKey: 'sub',
  nameLocalStorage: 'username',
  defaultImageUrl: 'assets/images/avatar.png'
};

/***/ }),

/***/ 8423:
/*!*************************************!*\
  !*** ./src/app/core/core.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CoreModule: () => (/* binding */ CoreModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _pipes_recipe_filter_pipe__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pipes/recipe-filter.pipe */ 9323);
/* harmony import */ var _pipes_nutritionists_filter_pipe__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pipes/nutritionists-filter.pipe */ 8818);
/* harmony import */ var _pipes_nutritionists_table_filter_pipe__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pipes/nutritionists-table-filter.pipe */ 4203);
/* harmony import */ var _pipes_get_initials_pipe__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pipes/get-initials.pipe */ 7014);
/* harmony import */ var _pipes_get_age_pipe__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pipes/get-age.pipe */ 4324);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7580);







class CoreModule {
  static {
    this.ɵfac = function CoreModule_Factory(t) {
      return new (t || CoreModule)();
    };
  }
  static {
    this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineNgModule"]({
      type: CoreModule
    });
  }
  static {
    this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule]
    });
  }
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsetNgModuleScope"](CoreModule, {
    declarations: [_pipes_recipe_filter_pipe__WEBPACK_IMPORTED_MODULE_0__.RecipeFilterPipe, _pipes_nutritionists_filter_pipe__WEBPACK_IMPORTED_MODULE_1__.NutritionistsFilterPipe, _pipes_nutritionists_filter_pipe__WEBPACK_IMPORTED_MODULE_1__.NutritionistsFilterPipe, _pipes_nutritionists_table_filter_pipe__WEBPACK_IMPORTED_MODULE_2__.NutritionistsTableFilterPipe, _pipes_get_initials_pipe__WEBPACK_IMPORTED_MODULE_3__.GetInitialsPipe, _pipes_get_age_pipe__WEBPACK_IMPORTED_MODULE_4__.GetAgePipe],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule],
    exports: [_pipes_recipe_filter_pipe__WEBPACK_IMPORTED_MODULE_0__.RecipeFilterPipe, _pipes_nutritionists_filter_pipe__WEBPACK_IMPORTED_MODULE_1__.NutritionistsFilterPipe, _pipes_nutritionists_table_filter_pipe__WEBPACK_IMPORTED_MODULE_2__.NutritionistsTableFilterPipe, _pipes_get_initials_pipe__WEBPACK_IMPORTED_MODULE_3__.GetInitialsPipe, _pipes_get_age_pipe__WEBPACK_IMPORTED_MODULE_4__.GetAgePipe]
  });
})();

/***/ }),

/***/ 4978:
/*!*******************************************!*\
  !*** ./src/app/core/guards/auth.guard.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   authGuard: () => (/* binding */ authGuard)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 5072);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/services/auth.service */ 4796);



const authGuard = (route, state) => {
  const authService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.inject)(src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService); // Inject the AuthService
  const router = (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.inject)(_angular_router__WEBPACK_IMPORTED_MODULE_2__.Router); // Inject the Router service
  if (authService.isLoggedIn()) {
    return true; // Allow access if the user is logged in
  }
  // Redirect to login page if not authenticated
  router.navigate(['/login'], {
    queryParams: {
      returnUrl: state.url
    }
  });
  return false;
};

/***/ }),

/***/ 400:
/*!*******************************************!*\
  !*** ./src/app/core/guards/role.guard.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   roleGuard: () => (/* binding */ roleGuard)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 5072);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/services/auth.service */ 4796);
/* harmony import */ var src_app_services_logger_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/logger.service */ 4798);




const roleGuard = (route, state) => {
  const authService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.inject)(src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService); // Inject services
  const router = (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.inject)(_angular_router__WEBPACK_IMPORTED_MODULE_3__.Router);
  const logger = (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.inject)(src_app_services_logger_service__WEBPACK_IMPORTED_MODULE_1__.LoggerService);
  const requiredRoles = route.data?.['roles']; // Get roles from route data
  const userRole = authService.getUserRole();
  if (requiredRoles.includes(userRole)) {
    logger.log('Role guard granted access' + userRole);
    return true; // Grant access if user role matches
  }

  logger.error('Role guard denied access' + userRole);
  router.navigate(['/']); // Redirect to home or another route
  return false; // Deny access
};

/***/ }),

/***/ 4113:
/*!**********************************************!*\
  !*** ./src/app/core/helpers/faker.helper.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   generateFakeRecipe: () => (/* binding */ generateFakeRecipe)
/* harmony export */ });
/* harmony import */ var _faker_js_faker__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @faker-js/faker */ 8660);
/* harmony import */ var src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/models/recipe.model */ 6464);


// export function generateFakeNutritionist(): NutritionistModel {
//   return {
//     id: faker.string.uuid(),
//     name: 'Dr. ' + faker.name.firstName(),
//     email: faker.internet.email(),
//     phone: faker.phone.number(),
//     profilePictureUrl: faker.image.avatar(),
//     patientsNumber: faker.number.int({ min: 10, max: 500 }),
//     experience: faker.number.int({ min: 1, max: 20 }),
//     certifications: Array.from(
//       { length: faker.number.int({ min: 1, max: 5 }) },
//       () => faker.company.buzzNoun()
//     ),
//     bio: faker.lorem.sentences(2),
//     location: faker.address.city(),
//     consultationFee: faker.number.int({ min: 50, max: 300 }),
//     ratings: faker.number.int({ min: 0, max: 5 }),
//     // New fields
//     address: faker.address.streetAddress(),
//     certificate: 'certif_' + faker.string.alpha(5) + '.pdf',
//     status: faker.helpers.arrayElement(['Approuvé', 'En attente', 'Rejeté']),
//     addedAt: faker.date.recent(), // Generates a recent date
//   };
// }
// export function generateFakeClient(): ClientModel {
//   return new ClientModel(
//     faker.string.uuid(),
//     faker.name.fullName(),
//     faker.internet.email(),
//     faker.phone.number(),
//     faker.image.avatar(),
//     faker.helpers.arrayElement(['Male', 'Female']),
//     faker.date.between({ from: '1950-01-01', to: '2003-01-01' }),
//     faker.number.int({ min: 150, max: 200 }),
//     faker.number.int({ min: 50, max: 100 }),
//     Array.from(
//       { length: faker.number.int({ min: 1, max: 3 }) },
//       generateFakeRecipe
//     ),
//     faker.helpers.arrayElement(
//       Object.values(ObjectifEnum).filter(
//         (objectif) => objectif != ObjectifEnum.ALL
//       )
//     ),
//     Array.from({ length: faker.number.int({ min: 1, max: 5 }) }, () =>
//       faker.date.future().toISOString()
//     )
//   );
// }
function generateFakeRecipe() {
  return {
    id: _faker_js_faker__WEBPACK_IMPORTED_MODULE_1__.a.string.uuid(),
    name: _faker_js_faker__WEBPACK_IMPORTED_MODULE_1__.a.lorem.words(_faker_js_faker__WEBPACK_IMPORTED_MODULE_1__.a.number.int({
      min: 1,
      max: 3
    })),
    description: _faker_js_faker__WEBPACK_IMPORTED_MODULE_1__.a.lorem.sentence(),
    category: _faker_js_faker__WEBPACK_IMPORTED_MODULE_1__.a.helpers.arrayElement(Object.values(src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_0__.CategoryEnum).filter(category => category !== src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_0__.CategoryEnum.ALL)),
    objectif: _faker_js_faker__WEBPACK_IMPORTED_MODULE_1__.a.helpers.arrayElement(Object.values(src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_0__.ObjectifEnum).filter(objectif => objectif !== src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_0__.ObjectifEnum.ALL)),
    preparationTime: _faker_js_faker__WEBPACK_IMPORTED_MODULE_1__.a.helpers.arrayElement(Object.values(src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_0__.PreparationTimeEnum).filter(time => time !== src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_0__.PreparationTimeEnum.ALL)),
    ingredients: Array.from({
      length: _faker_js_faker__WEBPACK_IMPORTED_MODULE_1__.a.number.int({
        min: 3,
        max: 5
      })
    }, () => _faker_js_faker__WEBPACK_IMPORTED_MODULE_1__.a.lorem.sentence()),
    imageUrl: `assets/images/recipe${_faker_js_faker__WEBPACK_IMPORTED_MODULE_1__.a.number.int({
      min: 1,
      max: 6
    })}.png`,
    calories: _faker_js_faker__WEBPACK_IMPORTED_MODULE_1__.a.number.int({
      min: 100,
      max: 2000
    }),
    protein: _faker_js_faker__WEBPACK_IMPORTED_MODULE_1__.a.number.int({
      min: 10,
      max: 50
    }),
    fat: _faker_js_faker__WEBPACK_IMPORTED_MODULE_1__.a.number.int({
      min: 5,
      max: 30
    }),
    carbohydrates: _faker_js_faker__WEBPACK_IMPORTED_MODULE_1__.a.number.int({
      min: 20,
      max: 100
    }),
    createdBy: _faker_js_faker__WEBPACK_IMPORTED_MODULE_1__.a.internet.userName(),
    createdAt: _faker_js_faker__WEBPACK_IMPORTED_MODULE_1__.a.date.past(),
    instructions: Array.from({
      length: _faker_js_faker__WEBPACK_IMPORTED_MODULE_1__.a.number.int({
        min: 3,
        max: 5
      })
    }, () => _faker_js_faker__WEBPACK_IMPORTED_MODULE_1__.a.lorem.sentence()),
    cookingNotes: Array.from(
    // New field for cooking notes as an array of strings
    {
      length: _faker_js_faker__WEBPACK_IMPORTED_MODULE_1__.a.number.int({
        min: 1,
        max: 3
      })
    }, () => _faker_js_faker__WEBPACK_IMPORTED_MODULE_1__.a.lorem.sentence())
  };
}
// export function generateFakeClient(): ClientModel {
//   return {
//     id: faker.string.uuid(),
//     name: faker.name.fullName(),
//     email: faker.internet.email(),
//     phone: faker.phone.number(),
//     profilePictureUrl: faker.image.avatar(),
//     address: faker.address.streetAddress(),
//     age: faker.number.int({ min: 18, max: 80 }),
//     height: faker.number.int({ min: 150, max: 200 }),
//     weight: faker.number.int({ min: 50, max: 100 }),
//     gender: faker.helpers.arrayElement(['Male', 'Female']),
//     favoriteRecipes: Array.from(
//       { length: faker.number.int({ min: 1, max: 3 }) },
//       generateFakeRecipe
//     ),
//     appointments: Array.from(
//       { length: faker.number.int({ min: 1, max: 5 }) },
//       () =>
//         new Date(faker.date.future()).toLocaleString('en-US', {
//           year: 'numeric',
//           month: 'long',
//           day: 'numeric',
//           hour: '2-digit',
//           minute: '2-digit'
//         })
//     ),
//   };
// }

/***/ }),

/***/ 909:
/*!********************************************************!*\
  !*** ./src/app/core/interceptors/token.interceptor.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TokenInterceptor: () => (/* binding */ TokenInterceptor)
/* harmony export */ });
/* harmony import */ var _constants_constants_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants/constants.config */ 8111);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7580);


class TokenInterceptor {
  constructor() {}
  intercept(request, next) {
    const token = localStorage.getItem(_constants_constants_config__WEBPACK_IMPORTED_MODULE_0__.APP_CONST.tokenLocalStorage);
    console.log('===================INTERCEPTED=================');
    // Clone the request and add the authorization header
    if (token) {
      request = request.clone({
        setHeaders: {
          Authorization: `Bearer ${token}`
        }
      });
    }
    return next.handle(request);
  }
  static {
    this.ɵfac = function TokenInterceptor_Factory(t) {
      return new (t || TokenInterceptor)();
    };
  }
  static {
    this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
      token: TokenInterceptor,
      factory: TokenInterceptor.ɵfac
    });
  }
}

/***/ }),

/***/ 4324:
/*!********************************************!*\
  !*** ./src/app/core/pipes/get-age.pipe.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GetAgePipe: () => (/* binding */ GetAgePipe)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 7580);

class GetAgePipe {
  transform(birthdate) {
    const today = new Date();
    const birthDate = new Date(birthdate);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || monthDiff === 0 && today.getDate() < birthDate.getDate()) {
      age--;
    }
    return age + ' Ans';
  }
  static {
    this.ɵfac = function GetAgePipe_Factory(t) {
      return new (t || GetAgePipe)();
    };
  }
  static {
    this.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefinePipe"]({
      name: "getAge",
      type: GetAgePipe,
      pure: true
    });
  }
  static {
    this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
      token: GetAgePipe,
      factory: GetAgePipe.ɵfac,
      providedIn: 'root'
    });
  }
}

/***/ }),

/***/ 7014:
/*!*************************************************!*\
  !*** ./src/app/core/pipes/get-initials.pipe.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GetInitialsPipe: () => (/* binding */ GetInitialsPipe)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 7580);

class GetInitialsPipe {
  transform(fullName) {
    return fullName.split(' ')[0][0] + (fullName.split(' ').length == 2 ? '.' + fullName.split(' ')[1][0] : '');
  }
  static {
    this.ɵfac = function GetInitialsPipe_Factory(t) {
      return new (t || GetInitialsPipe)();
    };
  }
  static {
    this.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefinePipe"]({
      name: "getInitials",
      type: GetInitialsPipe,
      pure: true
    });
  }
}

/***/ }),

/***/ 8818:
/*!*********************************************************!*\
  !*** ./src/app/core/pipes/nutritionists-filter.pipe.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   NutritionistsFilterPipe: () => (/* binding */ NutritionistsFilterPipe)
/* harmony export */ });
/* harmony import */ var src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/models/recipe.model */ 6464);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7580);


class NutritionistsFilterPipe {
  transform(nutritionists, searchText, experience) {
    let filteredNutritionists = nutritionists;
    // Apply search filter
    if (searchText) {
      filteredNutritionists = filteredNutritionists.filter(nutritionist => nutritionist.name.toLowerCase().includes(searchText.toLowerCase()));
    }
    // Apply experience filter
    switch (experience) {
      case src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_0__.ExperienceEnum.JUNIOR:
        filteredNutritionists = filteredNutritionists.filter(nutritionist => nutritionist.experienceYears >= 1 && nutritionist.experienceYears <= 3);
        break;
      case src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_0__.ExperienceEnum.MID_LEVEL:
        filteredNutritionists = filteredNutritionists.filter(nutritionist => nutritionist.experienceYears >= 4 && nutritionist.experienceYears <= 6);
        break;
      case src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_0__.ExperienceEnum.SENIOR:
        filteredNutritionists = filteredNutritionists.filter(nutritionist => nutritionist.experienceYears >= 7 && nutritionist.experienceYears <= 10);
        break;
      case src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_0__.ExperienceEnum.SENIOR_PLUS:
        filteredNutritionists = filteredNutritionists.filter(nutritionist => nutritionist.experienceYears > 10);
        break;
      default:
        break;
    }
    return filteredNutritionists;
  }
  static {
    this.ɵfac = function NutritionistsFilterPipe_Factory(t) {
      return new (t || NutritionistsFilterPipe)();
    };
  }
  static {
    this.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefinePipe"]({
      name: "nutritionistsFilter",
      type: NutritionistsFilterPipe,
      pure: true
    });
  }
}

/***/ }),

/***/ 4203:
/*!***************************************************************!*\
  !*** ./src/app/core/pipes/nutritionists-table-filter.pipe.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   NutritionistsTableFilterPipe: () => (/* binding */ NutritionistsTableFilterPipe)
/* harmony export */ });
/* harmony import */ var src_app_models_nutritionist_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/models/nutritionist.model */ 4942);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7580);


class NutritionistsTableFilterPipe {
  transform(nutritionists, searchQuery, statusFilter, dateFilter) {
    if (!nutritionists) {
      return [];
    }
    let filteredNutritionists = nutritionists;
    // Filter by search query
    if (searchQuery) {
      filteredNutritionists = filteredNutritionists.filter(nutritionist => {
        return nutritionist.name.toLowerCase().includes(searchQuery.toLowerCase()) || nutritionist.address.toLowerCase().includes(searchQuery.toLowerCase()) || nutritionist.phone.toLowerCase().includes(searchQuery.toLowerCase()) || nutritionist.email.toLowerCase().includes(searchQuery.toLowerCase()) || nutritionist.certificate.toLowerCase().includes(searchQuery.toLowerCase());
      });
    }
    // Filter by status
    if (statusFilter && statusFilter !== src_app_models_nutritionist_model__WEBPACK_IMPORTED_MODULE_0__.StatusEnumFilter.ALL) {
      filteredNutritionists = filteredNutritionists.filter(nutritionist => nutritionist.status.toLowerCase() === statusFilter.toLowerCase());
    }
    // Filter and sort by date (addedAt)
    if (dateFilter && dateFilter !== src_app_models_nutritionist_model__WEBPACK_IMPORTED_MODULE_0__.TrieEnum.ALL) {
      filteredNutritionists = filteredNutritionists.sort((a, b) => {
        const dateA = new Date(a.addedAt).getTime();
        const dateB = new Date(b.addedAt).getTime();
        if (dateFilter === src_app_models_nutritionist_model__WEBPACK_IMPORTED_MODULE_0__.TrieEnum.PlusRecents) {
          return dateB - dateA; // Sort descending
        } else if (dateFilter === src_app_models_nutritionist_model__WEBPACK_IMPORTED_MODULE_0__.TrieEnum.PlusAnciens) {
          return dateA - dateB; // Sort ascending
        }

        return 0; // No sorting for 'ALL'
      });
    }

    return filteredNutritionists;
  }
  static {
    this.ɵfac = function NutritionistsTableFilterPipe_Factory(t) {
      return new (t || NutritionistsTableFilterPipe)();
    };
  }
  static {
    this.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefinePipe"]({
      name: "nutritionistsTableFilter",
      type: NutritionistsTableFilterPipe,
      pure: true
    });
  }
}

/***/ }),

/***/ 9323:
/*!**************************************************!*\
  !*** ./src/app/core/pipes/recipe-filter.pipe.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RecipeFilterPipe: () => (/* binding */ RecipeFilterPipe)
/* harmony export */ });
/* harmony import */ var src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/models/recipe.model */ 6464);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7580);


class RecipeFilterPipe {
  transform(recipes, searchText, category, objectif) {
    let filteredRecipes = recipes;
    // Apply search filter
    if (searchText) {
      filteredRecipes = filteredRecipes.filter(recipe => recipe.name.toLowerCase().includes(searchText.toLowerCase()));
    }
    // Apply category filter
    if (category != src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_0__.CategoryEnum.ALL) {
      filteredRecipes = filteredRecipes.filter(recipe => recipe.category === category);
    }
    // Apply objectif filter
    if (objectif != src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_0__.ObjectifEnum.ALL) {
      filteredRecipes = filteredRecipes.filter(recipe => recipe.objectif === objectif);
    }
    return filteredRecipes;
  }
  static {
    this.ɵfac = function RecipeFilterPipe_Factory(t) {
      return new (t || RecipeFilterPipe)();
    };
  }
  static {
    this.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefinePipe"]({
      name: "recipeFilter",
      type: RecipeFilterPipe,
      pure: true
    });
  }
}

/***/ }),

/***/ 3584:
/*!***********************************************!*\
  !*** ./src/app/core/utils/functions.utils.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppUtils: () => (/* binding */ AppUtils)
/* harmony export */ });
class AppUtils {
  static getCssVariable(variableName) {
    // Fetch the root element's styles
    return getComputedStyle(document.documentElement).getPropertyValue(variableName).trim();
  }
  static getErrorMessage(error) {
    return error?.error?.message || 'An error occurred';
  }
  static convertToEnum(enumObj, value) {
    const enumValues = Object.values(enumObj);
    const matchedValue = enumValues.find(enumValue => enumValue.toLowerCase() === value.toLowerCase());
    return matchedValue;
  }
}

/***/ }),

/***/ 2692:
/*!******************************************************************!*\
  !*** ./src/app/features/home/admin-home/admin-home.component.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AdminHomeComponent: () => (/* binding */ AdminHomeComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _shared_components_page_background_page_background_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../shared/components/page-background/page-background.component */ 1469);
/* harmony import */ var _nutritionists_table_nutritionists_table_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../nutritionists-table/nutritionists-table.component */ 2944);



class AdminHomeComponent {
  static {
    this.ɵfac = function AdminHomeComponent_Factory(t) {
      return new (t || AdminHomeComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
      type: AdminHomeComponent,
      selectors: [["app-admin-home"]],
      decls: 2,
      vars: 0,
      template: function AdminHomeComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "app-page-background");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](1, "app-nutritionists-table");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        }
      },
      dependencies: [_shared_components_page_background_page_background_component__WEBPACK_IMPORTED_MODULE_0__.PageBackgroundComponent, _nutritionists_table_nutritionists_table_component__WEBPACK_IMPORTED_MODULE_1__.NutritionistsTableComponent],
      styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 5719:
/*!*****************************************************************************************!*\
  !*** ./src/app/features/home/components/appointment-card/appointment-card.component.ts ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppointmentCardComponent: () => (/* binding */ AppointmentCardComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 4456);
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ngx-toastr */ 4285);
/* harmony import */ var src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/models/recipe.model */ 6464);
/* harmony import */ var src_app_services_client_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/client.service */ 8281);
/* harmony import */ var src_app_services_planning_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/planning.service */ 6543);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../shared/components/button/button.component */ 8219);
/* harmony import */ var _shared_components_input_field_input_field_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../shared/components/input-field/input-field.component */ 1029);
/* harmony import */ var _shared_components_popup_popup_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../shared/components/popup/popup.component */ 4061);
/* harmony import */ var _upcoming_patient_upcoming_patient_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../upcoming-patient/upcoming-patient.component */ 6915);












function AppointmentCardComponent_img_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "img", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function AppointmentCardComponent_img_2_Template_img_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r7);
      const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵresetView"](ctx_r6.getPreviousAppointment());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
  }
}
function AppointmentCardComponent_img_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "img", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function AppointmentCardComponent_img_6_Template_img_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r9);
      const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵresetView"](ctx_r8.getNextAppointment());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
  }
}
function AppointmentCardComponent_app_upcoming_patient_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](0, "app-upcoming-patient", 16);
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("patient", ctx_r2.appointement.client)("appointmentTime", ctx_r2.appointement.time);
  }
}
function AppointmentCardComponent_img_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](0, "img", 17);
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("src", "assets/images/" + ctx_r3.getObjectifImg(ctx_r3.appointement.client.objectif) + ".svg", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵsanitizeUrl"]);
  }
}
function AppointmentCardComponent_p_21_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "p", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const note_r10 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" - ", note_r10, " ");
  }
}
function AppointmentCardComponent_app_popup_24_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "app-popup", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("popupClosed", function AppointmentCardComponent_app_popup_24_Template_app_popup_popupClosed_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r12);
      const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵresetView"](ctx_r11.closePopup());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](1, "app-input-field", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("enterPressed", function AppointmentCardComponent_app_popup_24_Template_app_input_field_enterPressed_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r12);
      const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵresetView"](ctx_r13.addNote($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("text", "Entrez une nouvelle note");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("placeholder", "Votre note...")("control", ctx_r5.newNoteControl);
  }
}
class AppointmentCardComponent {
  constructor() {
    this.isPopupVisible = false; // Initially hidden
    this.newNoteControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControl('');
    this.apppointementIndex = 0;
    this.clientService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.inject)(src_app_services_client_service__WEBPACK_IMPORTED_MODULE_1__.ClientService);
    this.slotService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.inject)(src_app_services_planning_service__WEBPACK_IMPORTED_MODULE_2__.PlanningService);
    this.onAppointmentChanged = new _angular_core__WEBPACK_IMPORTED_MODULE_7__.EventEmitter();
    this.toastr = (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.inject)(ngx_toastr__WEBPACK_IMPORTED_MODULE_9__.ToastrService);
    this.objectifImg = 'perdre-du-poids';
    this.showPopup = () => {
      this.isPopupVisible = true;
      console.log('pop shown');
    };
  }
  ngOnChanges(changes) {
    if (changes['appointmentsCount']) {
      // Logic triggered only when appointmentsCount changes
      this.apppointementIndex = this.appointmentsCount;
    }
  }
  ngOnInit() {
    this.apppointementIndex = this.appointmentsCount;
    console.log(this.appointement);
  }
  // Method to show the popup
  getObjectifImg(objectif) {
    switch (objectif) {
      case src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_0__.ObjectifEnum.PERDRE_POIDS:
        return this.objectifImg = 'perdre-du-poids';
      case src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_0__.ObjectifEnum.PRENDRE_POIDS:
        return this.objectifImg = 'prendre-du-poids';
      default:
        return this.objectifImg = 'se-muscler';
    }
  }
  getNextAppointment() {
    if (this.apppointementIndex < this.appointmentsCount) {
      this.apppointementIndex++;
      this.onAppointmentChanged.emit(this.apppointementIndex);
    }
  }
  getPreviousAppointment() {
    if (this.apppointementIndex > 1) {
      this.apppointementIndex--;
      this.onAppointmentChanged.emit(this.apppointementIndex);
    }
  }
  // Method to hide the popup
  closePopup() {
    this.isPopupVisible = false;
  }
  addNote(newNote) {
    this.slotService.addNote(this.appointement.id, [...(this.appointement?.notes ?? []), newNote]).subscribe({
      next: reservedSlot => {
        this.appointement = reservedSlot;
        this.toastr.success('Note Added Successfully!');
      },
      error: err => {
        this.toastr.error('Error');
      }
    });
  }
  static {
    this.ɵfac = function AppointmentCardComponent_Factory(t) {
      return new (t || AppointmentCardComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineComponent"]({
      type: AppointmentCardComponent,
      selectors: [["app-appointment-card"]],
      inputs: {
        appointement: "appointement",
        appointmentsCount: "appointmentsCount"
      },
      outputs: {
        onAppointmentChanged: "onAppointmentChanged"
      },
      features: [_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵNgOnChangesFeature"]],
      decls: 25,
      vars: 11,
      consts: [[1, "next-patient-meet"], [1, "arrows"], ["style", "cursor: pointer", "src", "assets/images/left-arrow.png", "width", "25px", "alt", "", 3, "click", 4, "ngIf"], ["style", "cursor: pointer", "src", "assets/images/right-arrow.png", "width", "25px", "alt", "", 3, "click", 4, "ngIf"], [1, "next-meet-card"], [3, "patient", "appointmentTime", 4, "ngIf"], [1, "detail"], ["alt", "", 3, "src", 4, "ngIf"], [1, "notes-wrapper"], [1, "notes-content"], ["class", "note", 4, "ngFor", "ngForOf"], [1, "buttons"], [3, "onClick", "text"], [3, "text", "popupClosed", 4, "ngIf"], ["src", "assets/images/left-arrow.png", "width", "25px", "alt", "", 2, "cursor", "pointer", 3, "click"], ["src", "assets/images/right-arrow.png", "width", "25px", "alt", "", 2, "cursor", "pointer", 3, "click"], [3, "patient", "appointmentTime"], ["alt", "", 3, "src"], [1, "note"], [3, "text", "popupClosed"], [3, "placeholder", "control", "enterPressed"]],
      template: function AppointmentCardComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "div", 0)(1, "div", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](2, AppointmentCardComponent_img_2_Template, 1, 0, "img", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](5, "date");
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](6, AppointmentCardComponent_img_6_Template, 1, 0, "img", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](7, "h2");
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](8, "Consultation");
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](9, "div", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](10, AppointmentCardComponent_app_upcoming_patient_10_Template, 1, 2, "app-upcoming-patient", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](11, "div", 6)(12, "h4");
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](13, "Objectif");
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](14, AppointmentCardComponent_img_14_Template, 1, 1, "img", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](15, "hr");
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](16, "div", 8)(17, "div", 6)(18, "h4");
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](19, "Notes");
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](20, "div", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](21, AppointmentCardComponent_p_21_Template, 2, 1, "p", 10);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](22, "div", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](23, "app-button", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](24, AppointmentCardComponent_app_popup_24_Template, 2, 3, "app-popup", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.apppointementIndex > 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](5, 9, ctx.appointement.date));
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.apppointementIndex < ctx.appointmentsCount);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.appointement);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.appointement);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](7);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngForOf", ctx.appointement.notes);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("onClick", ctx.showPopup)("text", "Ajouter Une Note");
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.isPopupVisible);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_10__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_10__.NgIf, _shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_3__.ButtonComponent, _shared_components_input_field_input_field_component__WEBPACK_IMPORTED_MODULE_4__.InputFieldComponent, _shared_components_popup_popup_component__WEBPACK_IMPORTED_MODULE_5__.PopupComponent, _upcoming_patient_upcoming_patient_component__WEBPACK_IMPORTED_MODULE_6__.UpcomingPatientComponent, _angular_common__WEBPACK_IMPORTED_MODULE_10__.DatePipe],
      styles: [".next-patient-meet[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 0 20px;\n  position: relative;\n  display: flex;\n  flex-direction: column;\n  gap: 20px;\n}\n.arrows[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 0;\n  top: 0;\n  display: flex;\n  gap: 10px;\n}\n\n.next-meet-card[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 20px;\n  border: 1px solid #a9d5e4;\n  border-radius: 3%;\n  padding: 10px 20px;\n}\n\n.next-meet-card[_ngcontent-%COMP%]   .detail[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 50px;\n}\n.next-meet-card[_ngcontent-%COMP%]   hr[_ngcontent-%COMP%] {\n  border: 0;\n  height: 1px;\n  background: #a9d5e4;\n  margin: 10px 10px;\n}\n\n.next-patient-meet[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  font-weight: 500;\n}\n\n.notes-wrapper[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: start;\n  gap: 20px;\n}\n.notes-content[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n}\n\np.note[_ngcontent-%COMP%] {\n  color: var(--hint-text);\n  font-size: 14px;\n}\n\n.buttons[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n  gap: 10px;\n  justify-content: center;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvZmVhdHVyZXMvaG9tZS9jb21wb25lbnRzL2FwcG9pbnRtZW50LWNhcmQvYXBwb2ludG1lbnQtY2FyZC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsV0FBVztFQUNYLGVBQWU7RUFDZixrQkFBa0I7RUFDbEIsYUFBYTtFQUNiLHNCQUFzQjtFQUN0QixTQUFTO0FBQ1g7QUFDQTtFQUNFLGtCQUFrQjtFQUNsQixRQUFRO0VBQ1IsTUFBTTtFQUNOLGFBQWE7RUFDYixTQUFTO0FBQ1g7O0FBRUE7RUFDRSxhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLFNBQVM7RUFDVCx5QkFBeUI7RUFDekIsaUJBQWlCO0VBQ2pCLGtCQUFrQjtBQUNwQjs7QUFFQTtFQUNFLGFBQWE7RUFDYixTQUFTO0FBQ1g7QUFDQTtFQUNFLFNBQVM7RUFDVCxXQUFXO0VBQ1gsbUJBQW1CO0VBQ25CLGlCQUFpQjtBQUNuQjs7QUFFQTtFQUNFLGdCQUFnQjtBQUNsQjs7QUFFQTtFQUNFLGFBQWE7RUFDYixzQkFBc0I7RUFDdEIsa0JBQWtCO0VBQ2xCLFNBQVM7QUFDWDtBQUNBO0VBQ0UsYUFBYTtFQUNiLHNCQUFzQjtFQUN0QixTQUFTO0FBQ1g7O0FBRUE7RUFDRSx1QkFBdUI7RUFDdkIsZUFBZTtBQUNqQjs7QUFFQTtFQUNFLFdBQVc7RUFDWCxhQUFhO0VBQ2IsU0FBUztFQUNULHVCQUF1QjtBQUN6QiIsInNvdXJjZXNDb250ZW50IjpbIi5uZXh0LXBhdGllbnQtbWVldCB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgcGFkZGluZzogMCAyMHB4O1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgZ2FwOiAyMHB4O1xyXG59XHJcbi5hcnJvd3Mge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICByaWdodDogMDtcclxuICB0b3A6IDA7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBnYXA6IDEwcHg7XHJcbn1cclxuXHJcbi5uZXh0LW1lZXQtY2FyZCB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gIGdhcDogMjBweDtcclxuICBib3JkZXI6IDFweCBzb2xpZCAjYTlkNWU0O1xyXG4gIGJvcmRlci1yYWRpdXM6IDMlO1xyXG4gIHBhZGRpbmc6IDEwcHggMjBweDtcclxufVxyXG5cclxuLm5leHQtbWVldC1jYXJkIC5kZXRhaWwge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZ2FwOiA1MHB4O1xyXG59XHJcbi5uZXh0LW1lZXQtY2FyZCBociB7XHJcbiAgYm9yZGVyOiAwO1xyXG4gIGhlaWdodDogMXB4O1xyXG4gIGJhY2tncm91bmQ6ICNhOWQ1ZTQ7XHJcbiAgbWFyZ2luOiAxMHB4IDEwcHg7XHJcbn1cclxuXHJcbi5uZXh0LXBhdGllbnQtbWVldCBoNCB7XHJcbiAgZm9udC13ZWlnaHQ6IDUwMDtcclxufVxyXG5cclxuLm5vdGVzLXdyYXBwZXIge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBhbGlnbi1pdGVtczogc3RhcnQ7XHJcbiAgZ2FwOiAyMHB4O1xyXG59XHJcbi5ub3Rlcy1jb250ZW50IHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgZ2FwOiAxMHB4O1xyXG59XHJcblxyXG5wLm5vdGUge1xyXG4gIGNvbG9yOiB2YXIoLS1oaW50LXRleHQpO1xyXG4gIGZvbnQtc2l6ZTogMTRweDtcclxufVxyXG5cclxuLmJ1dHRvbnMge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZ2FwOiAxMHB4O1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
    });
  }
}

/***/ }),

/***/ 8178:
/*!*******************************************************************!*\
  !*** ./src/app/features/home/components/stats/stats.component.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   StatsComponent: () => (/* binding */ StatsComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 316);


const _c0 = function () {
  return {
    backgroundColor: "#DFFDDD",
    color: "#008000"
  };
};
function StatsComponent_div_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 5)(1, "p", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "img", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("active", ctx_r0.hovered);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](5, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("", ctx_r0.evolutionPercent, "%");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("src", "assets/images/" + "increase" + ".svg", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
  }
}
class StatsComponent {
  constructor() {
    this.statObject = 'Nouveaux Patients';
    this.stat = 40;
    this.evolutionPercent = null;
    this.hovered = false;
  }
  static {
    this.ɵfac = function StatsComponent_Factory(t) {
      return new (t || StatsComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: StatsComponent,
      selectors: [["app-stats"]],
      inputs: {
        statObject: "statObject",
        stat: "stat",
        evolutionPercent: "evolutionPercent"
      },
      decls: 7,
      vars: 3,
      consts: [[1, "stats", 3, "mouseenter", "mouseleave"], [1, "stat-object"], [1, "numbers"], [1, "stat-number"], ["class", "evolution", 3, "active", "ngStyle", 4, "ngIf"], [1, "evolution", 3, "ngStyle"], [1, "evolution-number"], ["alt", "Evolution Image", 3, "src"]],
      template: function StatsComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("mouseenter", function StatsComponent_Template_div_mouseenter_0_listener() {
            return ctx.hovered = true;
          })("mouseleave", function StatsComponent_Template_div_mouseleave_0_listener() {
            return ctx.hovered = false;
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "p", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 2)(4, "p", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](6, StatsComponent_div_6_Template, 4, 6, "div", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.statObject);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.stat);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.evolutionPercent !== null);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgStyle],
      styles: [".stats[_ngcontent-%COMP%] {\n  border-radius: clamp(10px, 2vw, 14px);\n  background-color: white;\n  width: clamp(100px, 12vw, 180px);\n  padding: clamp(5px, 1vw, 10px) clamp(12px, 2vw, 17px);\n  transition: transform 0.5s ease-in-out, box-shadow 1s ease-in-out;\n  overflow: visible;\n  box-shadow: none;\n}\n.stats[_ngcontent-%COMP%]:hover {\n  transform: scale(1.2);\n  box-shadow: 0 clamp(10px, 2vw, 20px) clamp(5px, 1vw, 10px) var(--hint-text);\n}\n\n.numbers[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  width: 100%;\n  justify-content: space-between;\n}\n\np.stat-object[_ngcontent-%COMP%] {\n  font-weight: 500;\n  font-size: clamp(10px, 1.5vw, 14px);\n}\n\np.stat-number[_ngcontent-%COMP%] {\n  font-weight: 500;\n  font-size: clamp(20px, 3vw, 29px);\n}\n\np.evolution-number[_ngcontent-%COMP%] {\n  font-size: clamp(8px, 1vw, 11px);\n  font-weight: 400;\n}\n\n.evolution[_ngcontent-%COMP%] {\n  padding: clamp(0px, 1vw, 1px) clamp(5px, 1.5vw, 7px);\n  display: flex;\n  justify-content: space-around;\n  border-radius: 7px;\n  overflow: hidden;\n  transition: transform 0.5s ease-in-out;\n}\n\n.evolution.active[_ngcontent-%COMP%] {\n  animation: _ngcontent-%COMP%_translate 0.5s ease-in-out forwards;\n}\n\n@keyframes _ngcontent-%COMP%_translate {\n  0% {\n    transform: translate(0, 0);\n  }\n  100% {\n    transform: translate(clamp(10px, 3vw, 20px), clamp(-5px, 1.5vw, -10px));\n  }\n}\n\n.evolution[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: clamp(20%, 5vw, 30%);\n  object-fit: contain;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvZmVhdHVyZXMvaG9tZS9jb21wb25lbnRzL3N0YXRzL3N0YXRzLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxxQ0FBcUM7RUFDckMsdUJBQXVCO0VBQ3ZCLGdDQUFnQztFQUNoQyxxREFBcUQ7RUFDckQsaUVBQWlFO0VBQ2pFLGlCQUFpQjtFQUNqQixnQkFBZ0I7QUFDbEI7QUFDQTtFQUNFLHFCQUFxQjtFQUNyQiwyRUFBMkU7QUFDN0U7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLFdBQVc7RUFDWCw4QkFBOEI7QUFDaEM7O0FBRUE7RUFDRSxnQkFBZ0I7RUFDaEIsbUNBQW1DO0FBQ3JDOztBQUVBO0VBQ0UsZ0JBQWdCO0VBQ2hCLGlDQUFpQztBQUNuQzs7QUFFQTtFQUNFLGdDQUFnQztFQUNoQyxnQkFBZ0I7QUFDbEI7O0FBRUE7RUFDRSxvREFBb0Q7RUFDcEQsYUFBYTtFQUNiLDZCQUE2QjtFQUM3QixrQkFBa0I7RUFDbEIsZ0JBQWdCO0VBQ2hCLHNDQUFzQztBQUN4Qzs7QUFFQTtFQUNFLDhDQUE4QztBQUNoRDs7QUFFQTtFQUNFO0lBQ0UsMEJBQTBCO0VBQzVCO0VBQ0E7SUFDRSx1RUFBdUU7RUFDekU7QUFDRjs7QUFFQTtFQUNFLDJCQUEyQjtFQUMzQixtQkFBbUI7QUFDckIiLCJzb3VyY2VzQ29udGVudCI6WyIuc3RhdHMge1xyXG4gIGJvcmRlci1yYWRpdXM6IGNsYW1wKDEwcHgsIDJ2dywgMTRweCk7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgd2lkdGg6IGNsYW1wKDEwMHB4LCAxMnZ3LCAxODBweCk7XHJcbiAgcGFkZGluZzogY2xhbXAoNXB4LCAxdncsIDEwcHgpIGNsYW1wKDEycHgsIDJ2dywgMTdweCk7XHJcbiAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDAuNXMgZWFzZS1pbi1vdXQsIGJveC1zaGFkb3cgMXMgZWFzZS1pbi1vdXQ7XHJcbiAgb3ZlcmZsb3c6IHZpc2libGU7XHJcbiAgYm94LXNoYWRvdzogbm9uZTtcclxufVxyXG4uc3RhdHM6aG92ZXIge1xyXG4gIHRyYW5zZm9ybTogc2NhbGUoMS4yKTtcclxuICBib3gtc2hhZG93OiAwIGNsYW1wKDEwcHgsIDJ2dywgMjBweCkgY2xhbXAoNXB4LCAxdncsIDEwcHgpIHZhcigtLWhpbnQtdGV4dCk7XHJcbn1cclxuXHJcbi5udW1iZXJzIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG59XHJcblxyXG5wLnN0YXQtb2JqZWN0IHtcclxuICBmb250LXdlaWdodDogNTAwO1xyXG4gIGZvbnQtc2l6ZTogY2xhbXAoMTBweCwgMS41dncsIDE0cHgpO1xyXG59XHJcblxyXG5wLnN0YXQtbnVtYmVyIHtcclxuICBmb250LXdlaWdodDogNTAwO1xyXG4gIGZvbnQtc2l6ZTogY2xhbXAoMjBweCwgM3Z3LCAyOXB4KTtcclxufVxyXG5cclxucC5ldm9sdXRpb24tbnVtYmVyIHtcclxuICBmb250LXNpemU6IGNsYW1wKDhweCwgMXZ3LCAxMXB4KTtcclxuICBmb250LXdlaWdodDogNDAwO1xyXG59XHJcblxyXG4uZXZvbHV0aW9uIHtcclxuICBwYWRkaW5nOiBjbGFtcCgwcHgsIDF2dywgMXB4KSBjbGFtcCg1cHgsIDEuNXZ3LCA3cHgpO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1hcm91bmQ7XHJcbiAgYm9yZGVyLXJhZGl1czogN3B4O1xyXG4gIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDAuNXMgZWFzZS1pbi1vdXQ7XHJcbn1cclxuXHJcbi5ldm9sdXRpb24uYWN0aXZlIHtcclxuICBhbmltYXRpb246IHRyYW5zbGF0ZSAwLjVzIGVhc2UtaW4tb3V0IGZvcndhcmRzO1xyXG59XHJcblxyXG5Aa2V5ZnJhbWVzIHRyYW5zbGF0ZSB7XHJcbiAgMCUge1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoMCwgMCk7XHJcbiAgfVxyXG4gIDEwMCUge1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoY2xhbXAoMTBweCwgM3Z3LCAyMHB4KSwgY2xhbXAoLTVweCwgMS41dncsIC0xMHB4KSk7XHJcbiAgfVxyXG59XHJcblxyXG4uZXZvbHV0aW9uIGltZyB7XHJcbiAgd2lkdGg6IGNsYW1wKDIwJSwgNXZ3LCAzMCUpO1xyXG4gIG9iamVjdC1maXQ6IGNvbnRhaW47XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 6915:
/*!*****************************************************************************************!*\
  !*** ./src/app/features/home/components/upcoming-patient/upcoming-patient.component.ts ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   UpcomingPatientComponent: () => (/* binding */ UpcomingPatientComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var src_app_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/utils/functions.utils */ 3584);
/* harmony import */ var src_app_services_client_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/client.service */ 8281);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _core_pipes_get_initials_pipe__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../core/pipes/get-initials.pipe */ 7014);
/* harmony import */ var _core_pipes_get_age_pipe__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../core/pipes/get-age.pipe */ 4324);

// import { generateFakeClient } from 'src/app/core/helpers/faker.helper';






const _c0 = function (a0, a1) {
  return {
    backgroundColor: a0,
    color: a1
  };
};
function UpcomingPatientComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 5)(1, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction2"](2, _c0, ctx_r0.styleObject.backgroundColor, ctx_r0.styleObject.borderColor));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx_r0.appointmentTime);
  }
}
class UpcomingPatientComponent {
  constructor() {
    this.isSelected = false;
    this.index = 0;
    this.appointmentTime = null;
    this.styleObject = {
      backgroundColor: src_app_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_0__.AppUtils.getCssVariable('--light-green'),
      borderColor: src_app_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_0__.AppUtils.getCssVariable('--secondary-color')
    };
    this.clientService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.inject)(src_app_services_client_service__WEBPACK_IMPORTED_MODULE_1__.ClientService);
    this.onSelectPatient = new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter();
  }
  ngOnInit() {
    this.styleObject = this.getColor();
  }
  selectPatient(patient) {
    this.onSelectPatient.emit(patient);
  }
  getColor() {
    const colors = [{
      backgroundColor: src_app_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_0__.AppUtils.getCssVariable('--light-green'),
      borderColor: src_app_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_0__.AppUtils.getCssVariable('--secondary-color')
    }, {
      backgroundColor: '#FBD5DC',
      borderColor: '#F875B0'
    }, {
      backgroundColor: '#BCB8F0',
      borderColor: '#6462F7'
    }];
    return colors[this.index % 3];
  }
  static {
    this.ɵfac = function UpcomingPatientComponent_Factory(t) {
      return new (t || UpcomingPatientComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
      type: UpcomingPatientComponent,
      selectors: [["app-upcoming-patient"]],
      inputs: {
        isSelected: "isSelected",
        patient: "patient",
        index: "index",
        appointmentTime: "appointmentTime"
      },
      outputs: {
        onSelectPatient: "onSelectPatient"
      },
      decls: 12,
      vars: 15,
      consts: [[1, "upcoming-patient", 3, "click"], [1, "initials-wrapper"], [1, "initials-avatar"], [1, "profile"], ["class", "meet-time", 3, "ngStyle", 4, "ngIf"], [1, "meet-time", 3, "ngStyle"]],
      template: function UpcomingPatientComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function UpcomingPatientComponent_Template_div_click_0_listener() {
            return ctx.selectPatient(ctx.patient);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 1)(2, "div", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](4, "getInitials");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "div", 3)(6, "h2");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](10, "getAge");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](11, UpcomingPatientComponent_div_11_Template, 3, 5, "div", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵclassProp"]("active", ctx.isSelected);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleProp"]("border-color", ctx.styleObject.borderColor);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleProp"]("background-color", ctx.styleObject.backgroundColor);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](4, 11, ctx.patient.name), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx.patient.name);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate2"]("", ctx.patient.gender, " - ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](10, 13, ctx.patient.birthDate), "");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.appointmentTime);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgStyle, _core_pipes_get_initials_pipe__WEBPACK_IMPORTED_MODULE_2__.GetInitialsPipe, _core_pipes_get_age_pipe__WEBPACK_IMPORTED_MODULE_3__.GetAgePipe],
      styles: [".upcoming-patient[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 55px;\n  padding: 3px 10px;\n  border-radius: 15px;\n  display: flex;\n  align-items: center;\n  gap: 20px;\n  transition: box-shadow, scale 1.5s ease-in-out;\n\n  &.active {\n    background-color: #f0f9fd;\n    transform: scale(1.1);\n    animation: _ngcontent-%COMP%_ripple 2s ease-in-out infinite;\n  }\n}\n\n@keyframes _ngcontent-%COMP%_ripple {\n  0% {\n    box-shadow: 0 0 0 rgba(169, 213, 228, 1), 0 0 0 rgba(169, 213, 228, 1);\n  }\n  70% {\n    box-shadow: 0 0 20px rgba(169, 213, 228, 0.7),\n      0 0 40px rgba(169, 213, 228, 0.3);\n  }\n  100% {\n    box-shadow: 0 0 0 rgba(169, 213, 228, 0.2), 0 0 0 rgba(169, 213, 228, 0.2);\n  }\n}\n\n.initials-wrapper[_ngcontent-%COMP%] {\n  height: 100%;\n  aspect-ratio: 1/1;\n  border-radius: 50%;\n  padding: 3px;\n  border: 1px solid var(--secondary-color);\n}\n\n.initials-avatar[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  border-radius: 50%;\n  padding: 5px;\n  background-color: var(--light-green);\n  font-size: 100%;\n  text-align: center;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-weight: 400;\n}\n\n.profile[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  font-size: clamp(0.6rem, 2vw, 1rem);\n  font-weight: 500;\n}\n.profile[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  font-size: clamp(0.4rem, 1vw, 0.8rem);\n  color: var(--hint-text);\n}\n\n.meet-time[_ngcontent-%COMP%] {\n  margin-left: auto;\n  padding: 3px 7px;\n  border-radius: 7px;\n  text-align: center;\n}\n.meet-time[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  font-size: clamp(0.3rem, 1vw, 0.7rem);\n}\n\n.profile[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  justify-content: space-between;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvZmVhdHVyZXMvaG9tZS9jb21wb25lbnRzL3VwY29taW5nLXBhdGllbnQvdXBjb21pbmctcGF0aWVudC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsV0FBVztFQUNYLFlBQVk7RUFDWixpQkFBaUI7RUFDakIsbUJBQW1CO0VBQ25CLGFBQWE7RUFDYixtQkFBbUI7RUFDbkIsU0FBUztFQUNULDhDQUE4Qzs7RUFFOUM7SUFDRSx5QkFBeUI7SUFDekIscUJBQXFCO0lBQ3JCLHlDQUF5QztFQUMzQztBQUNGOztBQUVBO0VBQ0U7SUFDRSxzRUFBc0U7RUFDeEU7RUFDQTtJQUNFO3VDQUNtQztFQUNyQztFQUNBO0lBQ0UsMEVBQTBFO0VBQzVFO0FBQ0Y7O0FBRUE7RUFDRSxZQUFZO0VBQ1osaUJBQWlCO0VBQ2pCLGtCQUFrQjtFQUNsQixZQUFZO0VBQ1osd0NBQXdDO0FBQzFDOztBQUVBO0VBQ0UsV0FBVztFQUNYLFlBQVk7RUFDWixrQkFBa0I7RUFDbEIsWUFBWTtFQUNaLG9DQUFvQztFQUNwQyxlQUFlO0VBQ2Ysa0JBQWtCO0VBQ2xCLGFBQWE7RUFDYixtQkFBbUI7RUFDbkIsdUJBQXVCO0VBQ3ZCLGdCQUFnQjtBQUNsQjs7QUFFQTtFQUNFLG1DQUFtQztFQUNuQyxnQkFBZ0I7QUFDbEI7QUFDQTtFQUNFLHFDQUFxQztFQUNyQyx1QkFBdUI7QUFDekI7O0FBRUE7RUFDRSxpQkFBaUI7RUFDakIsZ0JBQWdCO0VBQ2hCLGtCQUFrQjtFQUNsQixrQkFBa0I7QUFDcEI7QUFDQTtFQUNFLHFDQUFxQztBQUN2Qzs7QUFFQTtFQUNFLGFBQWE7RUFDYixzQkFBc0I7RUFDdEIsOEJBQThCO0FBQ2hDIiwic291cmNlc0NvbnRlbnQiOlsiLnVwY29taW5nLXBhdGllbnQge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogNTVweDtcclxuICBwYWRkaW5nOiAzcHggMTBweDtcclxuICBib3JkZXItcmFkaXVzOiAxNXB4O1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBnYXA6IDIwcHg7XHJcbiAgdHJhbnNpdGlvbjogYm94LXNoYWRvdywgc2NhbGUgMS41cyBlYXNlLWluLW91dDtcclxuXHJcbiAgJi5hY3RpdmUge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2YwZjlmZDtcclxuICAgIHRyYW5zZm9ybTogc2NhbGUoMS4xKTtcclxuICAgIGFuaW1hdGlvbjogcmlwcGxlIDJzIGVhc2UtaW4tb3V0IGluZmluaXRlO1xyXG4gIH1cclxufVxyXG5cclxuQGtleWZyYW1lcyByaXBwbGUge1xyXG4gIDAlIHtcclxuICAgIGJveC1zaGFkb3c6IDAgMCAwIHJnYmEoMTY5LCAyMTMsIDIyOCwgMSksIDAgMCAwIHJnYmEoMTY5LCAyMTMsIDIyOCwgMSk7XHJcbiAgfVxyXG4gIDcwJSB7XHJcbiAgICBib3gtc2hhZG93OiAwIDAgMjBweCByZ2JhKDE2OSwgMjEzLCAyMjgsIDAuNyksXHJcbiAgICAgIDAgMCA0MHB4IHJnYmEoMTY5LCAyMTMsIDIyOCwgMC4zKTtcclxuICB9XHJcbiAgMTAwJSB7XHJcbiAgICBib3gtc2hhZG93OiAwIDAgMCByZ2JhKDE2OSwgMjEzLCAyMjgsIDAuMiksIDAgMCAwIHJnYmEoMTY5LCAyMTMsIDIyOCwgMC4yKTtcclxuICB9XHJcbn1cclxuXHJcbi5pbml0aWFscy13cmFwcGVyIHtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAgYXNwZWN0LXJhdGlvOiAxLzE7XHJcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gIHBhZGRpbmc6IDNweDtcclxuICBib3JkZXI6IDFweCBzb2xpZCB2YXIoLS1zZWNvbmRhcnktY29sb3IpO1xyXG59XHJcblxyXG4uaW5pdGlhbHMtYXZhdGFyIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gIHBhZGRpbmc6IDVweDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1saWdodC1ncmVlbik7XHJcbiAgZm9udC1zaXplOiAxMDAlO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgZm9udC13ZWlnaHQ6IDQwMDtcclxufVxyXG5cclxuLnByb2ZpbGUgaDIge1xyXG4gIGZvbnQtc2l6ZTogY2xhbXAoMC42cmVtLCAydncsIDFyZW0pO1xyXG4gIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbn1cclxuLnByb2ZpbGUgcCB7XHJcbiAgZm9udC1zaXplOiBjbGFtcCgwLjRyZW0sIDF2dywgMC44cmVtKTtcclxuICBjb2xvcjogdmFyKC0taGludC10ZXh0KTtcclxufVxyXG5cclxuLm1lZXQtdGltZSB7XHJcbiAgbWFyZ2luLWxlZnQ6IGF1dG87XHJcbiAgcGFkZGluZzogM3B4IDdweDtcclxuICBib3JkZXItcmFkaXVzOiA3cHg7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcbi5tZWV0LXRpbWUgcCB7XHJcbiAgZm9udC1zaXplOiBjbGFtcCgwLjNyZW0sIDF2dywgMC43cmVtKTtcclxufVxyXG5cclxuLnByb2ZpbGUge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 8213:
/*!*******************************************************************************************!*\
  !*** ./src/app/features/home/components/upcoming-patients/upcoming-patients.component.ts ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   UpcomingPatientsComponent: () => (/* binding */ UpcomingPatientsComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var src_app_services_client_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/services/client.service */ 8281);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _shared_components_svg_box_svg_box_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../shared/components/svg-box/svg-box.component */ 6145);
/* harmony import */ var _upcoming_patient_upcoming_patient_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../upcoming-patient/upcoming-patient.component */ 6915);
/* harmony import */ var _appointment_card_appointment_card_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../appointment-card/appointment-card.component */ 5719);







function UpcomingPatientsComponent_div_1_app_upcoming_patient_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "app-upcoming-patient", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("onSelectPatient", function UpcomingPatientsComponent_div_1_app_upcoming_patient_4_Template_app_upcoming_patient_onSelectPatient_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r5);
      const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r4.selectPatient($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const index_r3 = ctx.index;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("patient", ctx_r1.patients[index_r3])("index", index_r3)("isSelected", ctx_r1.patients[index_r3] == ctx_r1.selectedPatient);
  }
}
function UpcomingPatientsComponent_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 2)(1, "div", 3)(2, "h2");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "Liste des patients");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](4, UpcomingPatientsComponent_div_1_app_upcoming_patient_4_Template, 1, 3, "app-upcoming-patient", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "div", 5)(6, "app-appointment-card", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("onAppointmentChanged", function UpcomingPatientsComponent_div_1_Template_app_appointment_card_onAppointmentChanged_6_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r7);
      const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r6.onAppointementNumberChanged($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    let tmp_1_0;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx_r0.patients);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("appointmentsCount", (tmp_1_0 = ctx_r0.selectedPatient == null ? null : ctx_r0.selectedPatient.reservedSlotsCount) !== null && tmp_1_0 !== undefined ? tmp_1_0 : 0)("appointement", ctx_r0.appointment);
  }
}
class UpcomingPatientsComponent {
  constructor() {
    this.patients = [];
    this.nutritionistId = '';
    this.objectifImg = 'se-muscler';
    this.clientService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.inject)(src_app_services_client_service__WEBPACK_IMPORTED_MODULE_0__.ClientService);
    this.selectedPatient = null;
    this.appointmentsLength = 0;
    // appointmentIndex: number = 0;
    this.isLoading = false;
  }
  selectPatient(patient) {
    this.selectedPatient = patient;
    this.clientService.getAppointment(this.selectedPatient?.id ?? '', this.nutritionistId, this.selectedPatient.reservedSlotsCount).subscribe({
      next: appointment => {
        console.log('get appointemtn');
        this.appointment = appointment;
        this.isLoading = false;
      },
      error: err => {
        console.log('error');
      }
    });
  }
  ngOnInit() {
    this.selectedPatient = this.patients.length ? this.patients[0] : null;
    // this.appointmentsLength = this.selectedPatient.reservedSlots.length;
    console.log(this.selectedPatient);
    if (this.selectedPatient) {
      this.isLoading = true;
      this.clientService.getAppointment(this.selectedPatient?.id ?? '', this.nutritionistId, this.selectedPatient.reservedSlotsCount).subscribe({
        next: appointment => {
          console.log('get appointemtn');
          this.appointment = appointment;
          this.isLoading = false;
        },
        error: err => {
          console.log('error');
        }
      });
    }
  }
  onAppointementNumberChanged(appointementNumber) {
    this.clientService.getAppointment(this.selectedPatient?.id ?? '', this.nutritionistId, appointementNumber).subscribe({
      next: appointment => {
        this.appointment = appointment;
        console.log('New Appointement Set: ' + JSON.stringify(this.appointment) + 'After changing number to : ' + appointementNumber);
      }
    });
  }
  getAppointement(selectedPatientId) {}
  static {
    this.ɵfac = function UpcomingPatientsComponent_Factory(t) {
      return new (t || UpcomingPatientsComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
      type: UpcomingPatientsComponent,
      selectors: [["app-upcoming-patients"]],
      inputs: {
        patients: "patients",
        nutritionistId: "nutritionistId"
      },
      decls: 2,
      vars: 2,
      consts: [[3, "width"], ["class", "upcoming-patients-wrapper", 4, "ngIf"], [1, "upcoming-patients-wrapper"], [1, "patients-list"], [3, "patient", "index", "isSelected", "onSelectPatient", 4, "ngFor", "ngForOf"], [1, "next-meet-card"], [3, "appointmentsCount", "appointement", "onAppointmentChanged"], [3, "patient", "index", "isSelected", "onSelectPatient"]],
      template: function UpcomingPatientsComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "app-svg-box", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](1, UpcomingPatientsComponent_div_1_Template, 7, 3, "div", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("width", "95%");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx.isLoading);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgIf, _shared_components_svg_box_svg_box_component__WEBPACK_IMPORTED_MODULE_1__.SvgBoxComponent, _upcoming_patient_upcoming_patient_component__WEBPACK_IMPORTED_MODULE_2__.UpcomingPatientComponent, _appointment_card_appointment_card_component__WEBPACK_IMPORTED_MODULE_3__.AppointmentCardComponent],
      styles: [".modal[_ngcontent-%COMP%] {\n  position: relative;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n  z-index: 2000000;\n}\n\n\n\n.modal-content[_ngcontent-%COMP%] {\n  position: fixed;\n  top: 0;\n  left: 50%;\n  transform: translate(-50%, 0);\n  background-color: white;\n  padding: 20px 40px 20px 20px;\n  border-radius: 12px;\n  width: clamp(auto, 50vw, 90vw);\n  box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);\n  z-index: 10000;\n  display: flex;\n  flex-direction: column;\n  gap: 20px;\n}\n\n\n\n.close-btn[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 10px;\n  right: 10px;\n  background: none;\n  border: none;\n  font-size: 24px;\n  cursor: pointer;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hc3NldHMvY3NzL3BvcHVwLmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGtCQUFrQjtFQUNsQixNQUFNO0VBQ04sT0FBTztFQUNQLFdBQVc7RUFDWCxZQUFZO0VBQ1osZ0JBQWdCO0FBQ2xCOztBQUVBLGtCQUFrQjtBQUNsQjtFQUNFLGVBQWU7RUFDZixNQUFNO0VBQ04sU0FBUztFQUNULDZCQUE2QjtFQUM3Qix1QkFBdUI7RUFDdkIsNEJBQTRCO0VBQzVCLG1CQUFtQjtFQUNuQiw4QkFBOEI7RUFDOUIsMkNBQTJDO0VBQzNDLGNBQWM7RUFDZCxhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLFNBQVM7QUFDWDs7QUFFQSxpQkFBaUI7QUFDakI7RUFDRSxrQkFBa0I7RUFDbEIsU0FBUztFQUNULFdBQVc7RUFDWCxnQkFBZ0I7RUFDaEIsWUFBWTtFQUNaLGVBQWU7RUFDZixlQUFlO0FBQ2pCIiwic291cmNlc0NvbnRlbnQiOlsiLm1vZGFsIHtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgdG9wOiAwO1xyXG4gIGxlZnQ6IDA7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIHotaW5kZXg6IDIwMDAwMDA7XHJcbn1cclxuXHJcbi8qIFBvcHVwIGNvbnRlbnQgKi9cclxuLm1vZGFsLWNvbnRlbnQge1xyXG4gIHBvc2l0aW9uOiBmaXhlZDtcclxuICB0b3A6IDA7XHJcbiAgbGVmdDogNTAlO1xyXG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIDApO1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG4gIHBhZGRpbmc6IDIwcHggNDBweCAyMHB4IDIwcHg7XHJcbiAgYm9yZGVyLXJhZGl1czogMTJweDtcclxuICB3aWR0aDogY2xhbXAoYXV0bywgNTB2dywgOTB2dyk7XHJcbiAgYm94LXNoYWRvdzogMHB4IDRweCAxMHB4IHJnYmEoMCwgMCwgMCwgMC4yKTtcclxuICB6LWluZGV4OiAxMDAwMDtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgZ2FwOiAyMHB4O1xyXG59XHJcblxyXG4vKiBDbG9zZSBidXR0b24gKi9cclxuLmNsb3NlLWJ0biB7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHRvcDogMTBweDtcclxuICByaWdodDogMTBweDtcclxuICBiYWNrZ3JvdW5kOiBub25lO1xyXG4gIGJvcmRlcjogbm9uZTtcclxuICBmb250LXNpemU6IDI0cHg7XHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0= */", ".upcoming-patients-wrapper[_ngcontent-%COMP%] {\n  display: flex;\n  width: 100%;\n  justify-content: space-around;\n  gap: 10%;\n}\n.upcoming-patients-wrapper[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  font-size: clamp(0.9rem, 2.5vw, 1.3rem);\n  font-weight: 500;\n  padding-left: 40px;\n}\n\n.patients-list[_ngcontent-%COMP%] {\n  flex: 40%;\n  padding: 0 40px;\n  display: flex;\n  max-height: 400px;\n  overflow-y: scroll;\n  flex-direction: column;\n  gap: 20px;\n}\n.next-meet-card[_ngcontent-%COMP%] {\n  flex: 40%;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvZmVhdHVyZXMvaG9tZS9jb21wb25lbnRzL3VwY29taW5nLXBhdGllbnRzL3VwY29taW5nLXBhdGllbnRzLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxhQUFhO0VBQ2IsV0FBVztFQUNYLDZCQUE2QjtFQUM3QixRQUFRO0FBQ1Y7QUFDQTtFQUNFLHVDQUF1QztFQUN2QyxnQkFBZ0I7RUFDaEIsa0JBQWtCO0FBQ3BCOztBQUVBO0VBQ0UsU0FBUztFQUNULGVBQWU7RUFDZixhQUFhO0VBQ2IsaUJBQWlCO0VBQ2pCLGtCQUFrQjtFQUNsQixzQkFBc0I7RUFDdEIsU0FBUztBQUNYO0FBQ0E7RUFDRSxTQUFTO0FBQ1giLCJzb3VyY2VzQ29udGVudCI6WyIudXBjb21pbmctcGF0aWVudHMtd3JhcHBlciB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICB3aWR0aDogMTAwJTtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWFyb3VuZDtcclxuICBnYXA6IDEwJTtcclxufVxyXG4udXBjb21pbmctcGF0aWVudHMtd3JhcHBlciBoMiB7XHJcbiAgZm9udC1zaXplOiBjbGFtcCgwLjlyZW0sIDIuNXZ3LCAxLjNyZW0pO1xyXG4gIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgcGFkZGluZy1sZWZ0OiA0MHB4O1xyXG59XHJcblxyXG4ucGF0aWVudHMtbGlzdCB7XHJcbiAgZmxleDogNDAlO1xyXG4gIHBhZGRpbmc6IDAgNDBweDtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIG1heC1oZWlnaHQ6IDQwMHB4O1xyXG4gIG92ZXJmbG93LXk6IHNjcm9sbDtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gIGdhcDogMjBweDtcclxufVxyXG4ubmV4dC1tZWV0LWNhcmQge1xyXG4gIGZsZXg6IDQwJTtcclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
    });
  }
}

/***/ }),

/***/ 492:
/*!**********************************************************************************!*\
  !*** ./src/app/features/home/home-nutritioniste/home-nutritioniste.component.ts ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomeNutritionisteComponent: () => (/* binding */ HomeNutritionisteComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var src_app_models_client_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/models/client.model */ 4477);
/* harmony import */ var src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/models/recipe.model */ 6464);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/auth.service */ 4796);
/* harmony import */ var src_app_services_client_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/client.service */ 8281);
/* harmony import */ var src_app_services_nutritionists_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/nutritionists.service */ 1895);
/* harmony import */ var src_app_services_planning_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/planning.service */ 6543);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _shared_components_svg_box_svg_box_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../shared/components/svg-box/svg-box.component */ 6145);
/* harmony import */ var _shared_components_page_background_page_background_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../shared/components/page-background/page-background.component */ 1469);
/* harmony import */ var _shared_components_preloader_preloader_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../shared/components/preloader/preloader.component */ 9485);
/* harmony import */ var _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/material/datepicker */ 1977);
/* harmony import */ var _components_stats_stats_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../components/stats/stats.component */ 8178);
/* harmony import */ var _components_upcoming_patients_upcoming_patients_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../components/upcoming-patients/upcoming-patients.component */ 8213);

// import { generateFakeClient } from 'src/app/core/helpers/faker.helper';














function HomeNutritionisteComponent_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](1, "app-preloader");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
}
function HomeNutritionisteComponent_div_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 4)(1, "div", 5)(2, "app-svg-box")(3, "div", 6)(4, "h2");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](5, " Good Morning ");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](6, "span", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](8, "div", 8)(9, "h4");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](10, "Consultations Aujourd'hui");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](11, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](13, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](14, "app-stats", 10)(15, "app-stats", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](16, "img", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](17, "div", 13)(18, "mat-calendar", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("selectedChange", function HomeNutritionisteComponent_div_2_Template_mat_calendar_selectedChange_18_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r4);
      const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵresetView"](ctx_r3.currentDate = $event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"]("Dr.", ctx_r1.nutritionist == null ? null : ctx_r1.nutritionist.name, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r1.todayReservations.length);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("evolutionPercent", 51)("stat", ctx_r1.recentReservations.length)("statObject", "Nouveaux Patients");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("stat", ctx_r1.reservations.length)("statObject", "Total Patients");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("src", "assets/images/nutritionist-" + ctx_r1.getGenderImage() + ".png", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("selected", ctx_r1.currentDate);
  }
}
function HomeNutritionisteComponent_div_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 15)(1, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](2, "app-upcoming-patients", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("patients", ctx_r2.patientsList)("nutritionistId", ctx_r2.nutritionistId);
  }
}
class HomeNutritionisteComponent {
  constructor() {
    this.nutritionist = null;
    this.patientsList = [];
    this.objectif = src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_1__.ObjectifEnum.MUSCLER;
    this.clientService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.inject)(src_app_services_client_service__WEBPACK_IMPORTED_MODULE_3__.ClientService);
    this.nutritionistService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.inject)(src_app_services_nutritionists_service__WEBPACK_IMPORTED_MODULE_4__.NutritionistsService);
    this.planningService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.inject)(src_app_services_planning_service__WEBPACK_IMPORTED_MODULE_5__.PlanningService);
    this.authService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.inject)(src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService);
    this.nutritionistId = '';
    this.reservations = [];
    this.isLoading = false;
    this.todayReservations = [];
    this.recentReservations = [];
    this.currentDate = new Date();
  }
  getGenderImage() {
    return this.nutritionist?.gender == src_app_models_client_model__WEBPACK_IMPORTED_MODULE_0__.GenderEnum.MALE ? 'man' : 'women';
  }
  ngOnInit() {
    this.isLoading = true;
    this.nutritionistId = this.authService.getUserId();
    this.nutritionistService.getNutritionistById(this.nutritionistId).subscribe({
      next: response => {
        this.nutritionist = response;
      },
      error: err => {
        console.error('Upload Failed:', err);
      }
    });
    console.log('====================================');
    console.log('hello ' + this.currentDate);
    console.log('====================================');
    this.planningService.getUnavailableSlotsByNutritionist(this.nutritionistId).subscribe({
      next: reservations => {
        this.reservations = reservations;
        setTimeout(() => {
          this.isLoading = false;
        }, 500);
      },
      error: err => {
        console.error('Failed to fetch reservations:', err);
      }
    });
    this.todayReservations = this.reservations.filter(reservation => {
      // Parse reservation.date and compare it to the desired date
      const reservationDate = new Date(reservation.date).toDateString();
      return reservationDate === this.currentDate.toDateString();
    });
    this.recentReservations = this.reservations.filter(reservation => {
      const reservationDateMonth = new Date(reservation.date).getMonth();
      const reservationDateYear = new Date(reservation.date).getFullYear();
      return reservationDateMonth === this.currentDate.getMonth() && reservationDateYear === this.currentDate.getFullYear();
    });
    this.nutritionistService.getPatientsByNutritionist(this.nutritionistId).subscribe(clients => {
      this.patientsList = clients;
    });
  }
  static {
    this.ɵfac = function HomeNutritionisteComponent_Factory(t) {
      return new (t || HomeNutritionisteComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineComponent"]({
      type: HomeNutritionisteComponent,
      selectors: [["app-home-nutritioniste"]],
      decls: 4,
      vars: 3,
      consts: [["style", "display: flex; justify-content: center", 4, "ngIf"], ["class", "first-section", 4, "ngIf"], ["class", "second-section", 4, "ngIf"], [2, "display", "flex", "justify-content", "center"], [1, "first-section"], [1, "today-meets-section"], [1, "today-meets-content"], [1, "name"], [1, "infos"], [1, "stats"], [3, "evolutionPercent", "stat", "statObject"], [3, "stat", "statObject"], ["alt", "", 1, "nutritionist-img", 3, "src"], [1, "calendar"], [3, "selected", "selectedChange"], [1, "second-section"], [1, "patients-list"], [3, "patients", "nutritionistId"]],
      template: function HomeNutritionisteComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "app-page-background");
          _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](1, HomeNutritionisteComponent_div_1_Template, 2, 0, "div", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](2, HomeNutritionisteComponent_div_2_Template, 19, 9, "div", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](3, HomeNutritionisteComponent_div_3_Template, 3, 2, "div", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx.isLoading);
          _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", !ctx.isLoading);
          _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", !ctx.isLoading && ctx.patientsList.length > 0);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_12__.NgIf, _shared_components_svg_box_svg_box_component__WEBPACK_IMPORTED_MODULE_6__.SvgBoxComponent, _shared_components_page_background_page_background_component__WEBPACK_IMPORTED_MODULE_7__.PageBackgroundComponent, _shared_components_preloader_preloader_component__WEBPACK_IMPORTED_MODULE_8__.PreloaderComponent, _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_13__.MatCalendar, _components_stats_stats_component__WEBPACK_IMPORTED_MODULE_9__.StatsComponent, _components_upcoming_patients_upcoming_patients_component__WEBPACK_IMPORTED_MODULE_10__.UpcomingPatientsComponent],
      styles: [".first-section[_ngcontent-%COMP%] {\n  display: flex;\n  gap: clamp(10px, 2vw, 20px);\n  align-items: center;\n}\n\n.first-section[_ngcontent-%COMP%]   .today-meets-section[_ngcontent-%COMP%] {\n  flex: 65%;\n  flex-wrap: wrap;\n\n  border-radius: 7%;\n}\n\n.today-meets-content[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  position: relative;\n}\n\n.today-meets-content[_ngcontent-%COMP%]   .infos[_ngcontent-%COMP%] {\n  width: 65%;\n}\n\n.today-meets-content[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 0;\n  bottom: -7%;\n  width: clamp(200px, 20vw, 35%);\n  object-fit: cover;\n  overflow: hidden;\n}\n\n.today-meets-content[_ngcontent-%COMP%]    > h2[_ngcontent-%COMP%] {\n  font-weight: 400;\n  font-size: clamp(18px, 2vw, 27px);\n}\n\n.infos[_ngcontent-%COMP%] {\n  padding-top: clamp(10px, 2vw, 20px);\n  padding-left: clamp(10px, 2vw, 20px);\n}\n\n.infos[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  font-weight: 500;\n  font-size: clamp(12px, 2vw, 20px);\n}\n\n.infos[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  font-weight: 500;\n  font-size: clamp(30px, 5vw, 53px);\n}\n\nspan.name[_ngcontent-%COMP%] {\n  color: var(--primary-color);\n  font-weight: bold;\n  font-size: clamp(20px, 3vw, 35px);\n}\n\n.calendar[_ngcontent-%COMP%] {\n  flex: 35%;\n  height: 100%;\n  overflow: hidden;\n  border-radius: clamp(10px, 2vw, 15px);\n  --mat-datepicker-calendar-date-hover-state-background-color: #f8debd !important;\n}\n.calendar[_ngcontent-%COMP%]    >   * {\n  height: 100% !important;\n}\n\n  .mat-calendar {\n  background-color: white;\n  color: black !important;\n}\n  .mat-calendar-header {\n  color: black !important;\n}\n  .mat-calendar-controls {\n  color: black !important;\n}\n\n  .mat-mdc-button-touch-target {\n  color: black !important;\n}\n\n  .mat-calendar-header span {\n  color: black !important;\n}\n\n\n\n\n\n  .mat-calendar-body-cell-content {\n  color: black !important;\n}\n  .mat-calendar-body-label {\n  color: black !important;\n}\n\n  .mat-calendar-body-disabled .mat-calendar-body-cell-content {\n  color: rgba(0, 0, 0, 0.38); \n\n}\n  .mat-calendar-table-header tr th {\n  color: black;\n}\n  .mat-calendar-body-cell-selected:hover {\n  background-color: black !important; \n\n  color: white; \n\n}\n\n  .mat-calendar-body-selected {\n  background-color: var(\n    --primary-color\n  ) !important; \n\n  color: white !important; \n\n}\n\n\n\n  .mat-calendar-body-cell-content .mat-focus-indicator {\n  background-color: #f8debd !important;\n  cursor: pointer;\n}\n\n.stats[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: nowrap;\n  gap: clamp(5px, 2vw, 10px);\n  padding: clamp(3px, 1vw, 5px) clamp(5px, 2vw, 10px);\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvZmVhdHVyZXMvaG9tZS9ob21lLW51dHJpdGlvbmlzdGUvaG9tZS1udXRyaXRpb25pc3RlLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxhQUFhO0VBQ2IsMkJBQTJCO0VBQzNCLG1CQUFtQjtBQUNyQjs7QUFFQTtFQUNFLFNBQVM7RUFDVCxlQUFlOztFQUVmLGlCQUFpQjtBQUNuQjs7QUFFQTtFQUNFLFdBQVc7RUFDWCxZQUFZO0VBQ1osa0JBQWtCO0FBQ3BCOztBQUVBO0VBQ0UsVUFBVTtBQUNaOztBQUVBO0VBQ0Usa0JBQWtCO0VBQ2xCLFFBQVE7RUFDUixXQUFXO0VBQ1gsOEJBQThCO0VBQzlCLGlCQUFpQjtFQUNqQixnQkFBZ0I7QUFDbEI7O0FBRUE7RUFDRSxnQkFBZ0I7RUFDaEIsaUNBQWlDO0FBQ25DOztBQUVBO0VBQ0UsbUNBQW1DO0VBQ25DLG9DQUFvQztBQUN0Qzs7QUFFQTtFQUNFLGdCQUFnQjtFQUNoQixpQ0FBaUM7QUFDbkM7O0FBRUE7RUFDRSxnQkFBZ0I7RUFDaEIsaUNBQWlDO0FBQ25DOztBQUVBO0VBQ0UsMkJBQTJCO0VBQzNCLGlCQUFpQjtFQUNqQixpQ0FBaUM7QUFDbkM7O0FBRUE7RUFDRSxTQUFTO0VBQ1QsWUFBWTtFQUNaLGdCQUFnQjtFQUNoQixxQ0FBcUM7RUFDckMsK0VBQStFO0FBQ2pGO0FBQ0E7RUFDRSx1QkFBdUI7QUFDekI7O0FBRUE7RUFDRSx1QkFBdUI7RUFDdkIsdUJBQXVCO0FBQ3pCO0FBQ0E7RUFDRSx1QkFBdUI7QUFDekI7QUFDQTtFQUNFLHVCQUF1QjtBQUN6Qjs7QUFFQTtFQUNFLHVCQUF1QjtBQUN6Qjs7QUFFQTtFQUNFLHVCQUF1QjtBQUN6QjtBQUNBLDZDQUE2Qzs7QUFFN0MsOEJBQThCO0FBQzlCO0VBQ0UsdUJBQXVCO0FBQ3pCO0FBQ0E7RUFDRSx1QkFBdUI7QUFDekI7O0FBRUE7RUFDRSwwQkFBMEIsRUFBRSw4Q0FBOEM7QUFDNUU7QUFDQTtFQUNFLFlBQVk7QUFDZDtBQUNBO0VBQ0Usa0NBQWtDLEVBQUUsaUNBQWlDO0VBQ3JFLFlBQVksRUFBRSx5Q0FBeUM7QUFDekQ7O0FBRUE7RUFDRTs7Y0FFWSxFQUFFLGlDQUFpQztFQUMvQyx1QkFBdUIsRUFBRSx5Q0FBeUM7QUFDcEU7QUFDQSxvQ0FBb0M7O0FBRXBDO0VBQ0Usb0NBQW9DO0VBQ3BDLGVBQWU7QUFDakI7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsaUJBQWlCO0VBQ2pCLDBCQUEwQjtFQUMxQixtREFBbUQ7QUFDckQiLCJzb3VyY2VzQ29udGVudCI6WyIuZmlyc3Qtc2VjdGlvbiB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBnYXA6IGNsYW1wKDEwcHgsIDJ2dywgMjBweCk7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG5cclxuLmZpcnN0LXNlY3Rpb24gLnRvZGF5LW1lZXRzLXNlY3Rpb24ge1xyXG4gIGZsZXg6IDY1JTtcclxuICBmbGV4LXdyYXA6IHdyYXA7XHJcblxyXG4gIGJvcmRlci1yYWRpdXM6IDclO1xyXG59XHJcblxyXG4udG9kYXktbWVldHMtY29udGVudCB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxufVxyXG5cclxuLnRvZGF5LW1lZXRzLWNvbnRlbnQgLmluZm9zIHtcclxuICB3aWR0aDogNjUlO1xyXG59XHJcblxyXG4udG9kYXktbWVldHMtY29udGVudCBpbWcge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICByaWdodDogMDtcclxuICBib3R0b206IC03JTtcclxuICB3aWR0aDogY2xhbXAoMjAwcHgsIDIwdncsIDM1JSk7XHJcbiAgb2JqZWN0LWZpdDogY292ZXI7XHJcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcclxufVxyXG5cclxuLnRvZGF5LW1lZXRzLWNvbnRlbnQgPiBoMiB7XHJcbiAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICBmb250LXNpemU6IGNsYW1wKDE4cHgsIDJ2dywgMjdweCk7XHJcbn1cclxuXHJcbi5pbmZvcyB7XHJcbiAgcGFkZGluZy10b3A6IGNsYW1wKDEwcHgsIDJ2dywgMjBweCk7XHJcbiAgcGFkZGluZy1sZWZ0OiBjbGFtcCgxMHB4LCAydncsIDIwcHgpO1xyXG59XHJcblxyXG4uaW5mb3MgaDQge1xyXG4gIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgZm9udC1zaXplOiBjbGFtcCgxMnB4LCAydncsIDIwcHgpO1xyXG59XHJcblxyXG4uaW5mb3MgcCB7XHJcbiAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICBmb250LXNpemU6IGNsYW1wKDMwcHgsIDV2dywgNTNweCk7XHJcbn1cclxuXHJcbnNwYW4ubmFtZSB7XHJcbiAgY29sb3I6IHZhcigtLXByaW1hcnktY29sb3IpO1xyXG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gIGZvbnQtc2l6ZTogY2xhbXAoMjBweCwgM3Z3LCAzNXB4KTtcclxufVxyXG5cclxuLmNhbGVuZGFyIHtcclxuICBmbGV4OiAzNSU7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgYm9yZGVyLXJhZGl1czogY2xhbXAoMTBweCwgMnZ3LCAxNXB4KTtcclxuICAtLW1hdC1kYXRlcGlja2VyLWNhbGVuZGFyLWRhdGUtaG92ZXItc3RhdGUtYmFja2dyb3VuZC1jb2xvcjogI2Y4ZGViZCAhaW1wb3J0YW50O1xyXG59XHJcbi5jYWxlbmRhciA+IDo6bmctZGVlcCAqIHtcclxuICBoZWlnaHQ6IDEwMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuOjpuZy1kZWVwIC5tYXQtY2FsZW5kYXIge1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG4gIGNvbG9yOiBibGFjayAhaW1wb3J0YW50O1xyXG59XHJcbjo6bmctZGVlcCAubWF0LWNhbGVuZGFyLWhlYWRlciB7XHJcbiAgY29sb3I6IGJsYWNrICFpbXBvcnRhbnQ7XHJcbn1cclxuOjpuZy1kZWVwIC5tYXQtY2FsZW5kYXItY29udHJvbHMge1xyXG4gIGNvbG9yOiBibGFjayAhaW1wb3J0YW50O1xyXG59XHJcblxyXG46Om5nLWRlZXAgLm1hdC1tZGMtYnV0dG9uLXRvdWNoLXRhcmdldCB7XHJcbiAgY29sb3I6IGJsYWNrICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbjo6bmctZGVlcCAubWF0LWNhbGVuZGFyLWhlYWRlciBzcGFuIHtcclxuICBjb2xvcjogYmxhY2sgIWltcG9ydGFudDtcclxufVxyXG4vKiBDdXN0b21pemUgc2VsZWN0ZWQgZGF0ZSBiYWNrZ3JvdW5kIGNvbG9yICovXHJcblxyXG4vKiBDaGFuZ2UgZm9udCBzaXplIG9mIGRhdGVzICovXHJcbjo6bmctZGVlcCAubWF0LWNhbGVuZGFyLWJvZHktY2VsbC1jb250ZW50IHtcclxuICBjb2xvcjogYmxhY2sgIWltcG9ydGFudDtcclxufVxyXG46Om5nLWRlZXAgLm1hdC1jYWxlbmRhci1ib2R5LWxhYmVsIHtcclxuICBjb2xvcjogYmxhY2sgIWltcG9ydGFudDtcclxufVxyXG5cclxuOjpuZy1kZWVwIC5tYXQtY2FsZW5kYXItYm9keS1kaXNhYmxlZCAubWF0LWNhbGVuZGFyLWJvZHktY2VsbC1jb250ZW50IHtcclxuICBjb2xvcjogcmdiYSgwLCAwLCAwLCAwLjM4KTsgLyogU2xpZ2h0bHkgbGlnaHRlciBibGFjayBmb3IgZGlzYWJsZWQgZGF0ZXMgKi9cclxufVxyXG46Om5nLWRlZXAgLm1hdC1jYWxlbmRhci10YWJsZS1oZWFkZXIgdHIgdGgge1xyXG4gIGNvbG9yOiBibGFjaztcclxufVxyXG46Om5nLWRlZXAgLm1hdC1jYWxlbmRhci1ib2R5LWNlbGwtc2VsZWN0ZWQ6aG92ZXIge1xyXG4gIGJhY2tncm91bmQtY29sb3I6IGJsYWNrICFpbXBvcnRhbnQ7IC8qIENoYW5nZSB0byB5b3VyIGRlc2lyZWQgY29sb3IgKi9cclxuICBjb2xvcjogd2hpdGU7IC8qIE9wdGlvbmFsOiBDaGFuZ2UgdGV4dCBjb2xvciBvbiBob3ZlciAqL1xyXG59XHJcblxyXG46Om5nLWRlZXAgLm1hdC1jYWxlbmRhci1ib2R5LXNlbGVjdGVkIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoXHJcbiAgICAtLXByaW1hcnktY29sb3JcclxuICApICFpbXBvcnRhbnQ7IC8qIENoYW5nZSB0byB5b3VyIGRlc2lyZWQgY29sb3IgKi9cclxuICBjb2xvcjogd2hpdGUgIWltcG9ydGFudDsgLyogT3B0aW9uYWw6IENoYW5nZSB0ZXh0IGNvbG9yIG9uIGhvdmVyICovXHJcbn1cclxuLyogSG92ZXIgZWZmZWN0IGZvciBjYWxlbmRhciBjZWxscyAqL1xyXG5cclxuOjpuZy1kZWVwIC5tYXQtY2FsZW5kYXItYm9keS1jZWxsLWNvbnRlbnQgLm1hdC1mb2N1cy1pbmRpY2F0b3Ige1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmOGRlYmQgIWltcG9ydGFudDtcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbi5zdGF0cyB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LXdyYXA6IG5vd3JhcDtcclxuICBnYXA6IGNsYW1wKDVweCwgMnZ3LCAxMHB4KTtcclxuICBwYWRkaW5nOiBjbGFtcCgzcHgsIDF2dywgNXB4KSBjbGFtcCg1cHgsIDJ2dywgMTBweCk7XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 5724:
/*!****************************************************************!*\
  !*** ./src/app/features/home/home-page/home-page.component.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomePageComponent: () => (/* binding */ HomePageComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 5072);
/* harmony import */ var src_app_services_nutritionists_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/services/nutritionists.service */ 1895);
/* harmony import */ var src_app_services_recipe_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/recipe.service */ 4964);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _shared_components_page_background_page_background_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../shared/components/page-background/page-background.component */ 1469);
/* harmony import */ var _recipes_recette_item_recette_item_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../recipes/recette-item/recette-item.component */ 5404);
/* harmony import */ var _water_tracking_water_tracking_water_tracking_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../water-tracking/water-tracking/water-tracking.component */ 4104);
/* harmony import */ var _nutritionists_nutritionist_item_nutritionist_item_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../nutritionists/nutritionist-item/nutritionist-item.component */ 2124);
/* harmony import */ var _top_list_top_list_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../top-list/top-list.component */ 7606);











function HomePageComponent_app_recipe_item_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](0, "app-recipe-item", 3);
  }
  if (rf & 2) {
    const recipe_r2 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("recipe", recipe_r2);
  }
}
function HomePageComponent_app_nutritionist_item_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](0, "app-nutritionist-item", 4);
  }
  if (rf & 2) {
    const nutritionist_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("nutritionist", nutritionist_r3);
  }
}
class HomePageComponent {
  constructor() {
    this.recetRecipes = [];
    this.bestNutritionists = [];
    this.recipesService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.inject)(src_app_services_recipe_service__WEBPACK_IMPORTED_MODULE_1__.RecipesService);
    this.nutritionistsService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.inject)(src_app_services_nutritionists_service__WEBPACK_IMPORTED_MODULE_0__.NutritionistsService);
    this.router = (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.inject)(_angular_router__WEBPACK_IMPORTED_MODULE_8__.Router);
    this.recipesService.getAllRecipes(1, 4).subscribe(response => {
      this.recetRecipes = response.data;
    });
    this.nutritionistsService.getBestNutritionists().subscribe(nutritionists => {
      this.bestNutritionists = nutritionists;
    });
  }
  navigateToNutritionists() {
    this.router.navigate(['/nutritionists']);
  }
  navigateToRecipes() {
    this.router.navigate(['/recipes']);
  }
  static {
    this.ɵfac = function HomePageComponent_Factory(t) {
      return new (t || HomePageComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineComponent"]({
      type: HomePageComponent,
      selectors: [["app-home-page"]],
      decls: 6,
      vars: 6,
      consts: [[3, "title", "onVoirPlusClicked"], [3, "recipe", 4, "ngFor", "ngForOf"], [3, "nutritionist", 4, "ngFor", "ngForOf"], [3, "recipe"], [3, "nutritionist"]],
      template: function HomePageComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "app-page-background");
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](1, "app-water-tracking");
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](2, "app-top-list", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](3, HomePageComponent_app_recipe_item_3_Template, 1, 1, "app-recipe-item", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](4, "app-top-list", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](5, HomePageComponent_app_nutritionist_item_5_Template, 1, 1, "app-nutritionist-item", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("title", "Les recettes les plus r\u00E9centes")("onVoirPlusClicked", ctx.navigateToRecipes);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngForOf", ctx.recetRecipes);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("title", "Les meilleurs nutritionistes")("onVoirPlusClicked", ctx.navigateToNutritionists);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngForOf", ctx.bestNutritionists);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_9__.NgForOf, _shared_components_page_background_page_background_component__WEBPACK_IMPORTED_MODULE_2__.PageBackgroundComponent, _recipes_recette_item_recette_item_component__WEBPACK_IMPORTED_MODULE_3__.RecetteItemComponent, _water_tracking_water_tracking_water_tracking_component__WEBPACK_IMPORTED_MODULE_4__.WaterTrackingComponent, _nutritionists_nutritionist_item_nutritionist_item_component__WEBPACK_IMPORTED_MODULE_5__.NutritionistItemComponent, _top_list_top_list_component__WEBPACK_IMPORTED_MODULE_6__.TopListComponent],
      styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 2829:
/*!**********************************************!*\
  !*** ./src/app/features/home/home.module.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomeModule: () => (/* binding */ HomeModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _home_page_home_page_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home-page/home-page.component */ 5724);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/shared/shared.module */ 3887);
/* harmony import */ var _water_tracking_water_tracking_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../water-tracking/water-tracking.module */ 6229);
/* harmony import */ var _top_list_top_list_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./top-list/top-list.component */ 7606);
/* harmony import */ var _nutritionists_nutritionists_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../nutritionists/nutritionists.module */ 7629);
/* harmony import */ var _home_nutritioniste_home_nutritioniste_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./home-nutritioniste/home-nutritioniste.component */ 492);
/* harmony import */ var _components_stats_stats_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./components/stats/stats.component */ 8178);
/* harmony import */ var _components_upcoming_patients_upcoming_patients_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./components/upcoming-patients/upcoming-patients.component */ 8213);
/* harmony import */ var _components_upcoming_patient_upcoming_patient_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./components/upcoming-patient/upcoming-patient.component */ 6915);
/* harmony import */ var _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/material/datepicker */ 1977);
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/material/core */ 4646);
/* harmony import */ var _admin_home_admin_home_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./admin-home/admin-home.component */ 2692);
/* harmony import */ var _nutritionists_table_nutritionists_table_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./nutritionists-table/nutritionists-table.component */ 2944);
/* harmony import */ var src_app_core_core_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/core/core.module */ 8423);
/* harmony import */ var _components_appointment_card_appointment_card_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./components/appointment-card/appointment-card.component */ 5719);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 7580);

















class HomeModule {
  static {
    this.ɵfac = function HomeModule_Factory(t) {
      return new (t || HomeModule)();
    };
  }
  static {
    this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineNgModule"]({
      type: HomeModule
    });
  }
  static {
    this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_14__.CommonModule, src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule, _water_tracking_water_tracking_module__WEBPACK_IMPORTED_MODULE_2__.WaterTrackingModule, _nutritionists_nutritionists_module__WEBPACK_IMPORTED_MODULE_4__.NutritionistsModule, _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_15__.MatDatepickerModule, _angular_material_core__WEBPACK_IMPORTED_MODULE_16__.MatNativeDateModule, src_app_core_core_module__WEBPACK_IMPORTED_MODULE_11__.CoreModule]
    });
  }
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵsetNgModuleScope"](HomeModule, {
    declarations: [_home_page_home_page_component__WEBPACK_IMPORTED_MODULE_0__.HomePageComponent, _top_list_top_list_component__WEBPACK_IMPORTED_MODULE_3__.TopListComponent, _home_nutritioniste_home_nutritioniste_component__WEBPACK_IMPORTED_MODULE_5__.HomeNutritionisteComponent, _components_stats_stats_component__WEBPACK_IMPORTED_MODULE_6__.StatsComponent, _components_upcoming_patients_upcoming_patients_component__WEBPACK_IMPORTED_MODULE_7__.UpcomingPatientsComponent, _components_upcoming_patient_upcoming_patient_component__WEBPACK_IMPORTED_MODULE_8__.UpcomingPatientComponent, _admin_home_admin_home_component__WEBPACK_IMPORTED_MODULE_9__.AdminHomeComponent, _nutritionists_table_nutritionists_table_component__WEBPACK_IMPORTED_MODULE_10__.NutritionistsTableComponent, _components_appointment_card_appointment_card_component__WEBPACK_IMPORTED_MODULE_12__.AppointmentCardComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_14__.CommonModule, src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule, _water_tracking_water_tracking_module__WEBPACK_IMPORTED_MODULE_2__.WaterTrackingModule, _nutritionists_nutritionists_module__WEBPACK_IMPORTED_MODULE_4__.NutritionistsModule, _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_15__.MatDatepickerModule, _angular_material_core__WEBPACK_IMPORTED_MODULE_16__.MatNativeDateModule, src_app_core_core_module__WEBPACK_IMPORTED_MODULE_11__.CoreModule],
    exports: [_home_page_home_page_component__WEBPACK_IMPORTED_MODULE_0__.HomePageComponent, _admin_home_admin_home_component__WEBPACK_IMPORTED_MODULE_9__.AdminHomeComponent, _home_nutritioniste_home_nutritioniste_component__WEBPACK_IMPORTED_MODULE_5__.HomeNutritionisteComponent, _components_appointment_card_appointment_card_component__WEBPACK_IMPORTED_MODULE_12__.AppointmentCardComponent]
  });
})();

/***/ }),

/***/ 2944:
/*!************************************************************************************!*\
  !*** ./src/app/features/home/nutritionists-table/nutritionists-table.component.ts ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   NutritionistsTableComponent: () => (/* binding */ NutritionistsTableComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ 4456);
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ngx-toastr */ 4285);
/* harmony import */ var src_app_core_constants_constants_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/constants/constants.config */ 8111);
/* harmony import */ var src_app_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utils/functions.utils */ 3584);
/* harmony import */ var src_app_models_nutritionist_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/models/nutritionist.model */ 4942);
/* harmony import */ var src_app_services_file_upload_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/file-upload.service */ 8222);
/* harmony import */ var src_app_services_nutritionists_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/nutritionists.service */ 1895);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _shared_components_pagination_pagination_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../shared/components/pagination/pagination.component */ 4815);
/* harmony import */ var _shared_components_search_search_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../shared/components/search/search.component */ 1163);
/* harmony import */ var _shared_components_dropdown_dropdown_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../shared/components/dropdown/dropdown.component */ 4538);
/* harmony import */ var _core_pipes_nutritionists_table_filter_pipe__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../core/pipes/nutritionists-table-filter.pipe */ 4203);





// import { generateFakeNutritionist } from 'src/app/core/helpers/faker.helper';









function NutritionistsTableComponent_tr_23_span_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "span", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const nutritionist_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" ", nutritionist_r1.status, " ");
  }
}
function NutritionistsTableComponent_tr_23_span_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "span", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const nutritionist_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" ", nutritionist_r1.status, " ");
  }
}
function NutritionistsTableComponent_tr_23_span_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "span", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const nutritionist_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" ", nutritionist_r1.status, " ");
  }
}
function NutritionistsTableComponent_tr_23_span_18_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "span", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const nutritionist_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" ", nutritionist_r1.status, " ");
  }
}
function NutritionistsTableComponent_tr_23_div_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "div", 19)(1, "img", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function NutritionistsTableComponent_tr_23_div_19_Template_img_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r14);
      const nutritionist_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]().$implicit;
      const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵresetView"](ctx_r12.updateStatus(nutritionist_r1, ctx_r12.statusEnum.Approved));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](2, "img", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function NutritionistsTableComponent_tr_23_div_19_Template_img_click_2_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r14);
      const nutritionist_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]().$implicit;
      const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵresetView"](ctx_r15.updateStatus(nutritionist_r1, ctx_r15.statusEnum.Rejected));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
  }
}
function NutritionistsTableComponent_tr_23_span_20_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "span", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const nutritionist_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" ", nutritionist_r1.status, " ");
  }
}
function NutritionistsTableComponent_tr_23_Template(rf, ctx) {
  if (rf & 1) {
    const _r19 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](1, "td", 7)(2, "td", 7)(3, "td", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](4, "td", 7)(5, "span", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](7, "td")(8, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function NutritionistsTableComponent_tr_23_Template_div_click_8_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r19);
      const nutritionist_r1 = restoredCtx.$implicit;
      const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵresetView"](ctx_r18.downloadCertificate(nutritionist_r1.certificateUrl.split("/").pop()));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](9, "img", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](10, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](11);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](12, "img", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](13, "td")(14, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](15, NutritionistsTableComponent_tr_23_span_15_Template, 2, 1, "span", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](16, NutritionistsTableComponent_tr_23_span_16_Template, 2, 1, "span", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](17, NutritionistsTableComponent_tr_23_span_17_Template, 2, 1, "span", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](18, NutritionistsTableComponent_tr_23_span_18_Template, 2, 1, "span", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](19, NutritionistsTableComponent_tr_23_div_19_Template, 3, 0, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](20, NutritionistsTableComponent_tr_23_span_20_Template, 2, 1, "span", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const nutritionist_r1 = ctx.$implicit;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("innerHTML", ctx_r0.highlightText(nutritionist_r1.name, ctx_r0.searchControl.value), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵsanitizeHtml"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("innerHTML", ctx_r0.highlightText(nutritionist_r1.location, ctx_r0.searchControl.value), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵsanitizeHtml"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("innerHTML", ctx_r0.highlightText(nutritionist_r1.phoneNumber, ctx_r0.searchControl.value), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵsanitizeHtml"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("innerHTML", ctx_r0.highlightText(nutritionist_r1.email, ctx_r0.searchControl.value), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵsanitizeHtml"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](ctx_r0.searchControl.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](nutritionist_r1.certificate);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngSwitch", nutritionist_r1.status);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngSwitchCase", "Approuv\u00E9");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngSwitchCase", "Approuv\u00E9e");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngSwitchCase", "Rejet\u00E9");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngSwitchCase", "Rejet\u00E9e");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngSwitchCase", "En attente");
  }
}
class NutritionistsTableComponent {
  constructor() {
    this.base_url = src_app_core_constants_constants_config__WEBPACK_IMPORTED_MODULE_0__.APP_API.base_url;
    this.searchControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl('');
    this.trieControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(src_app_models_nutritionist_model__WEBPACK_IMPORTED_MODULE_2__.TrieEnum.ALL);
    this.statusControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(src_app_models_nutritionist_model__WEBPACK_IMPORTED_MODULE_2__.StatusEnumFilter.ALL);
    this.statusOptions = Object.values(src_app_models_nutritionist_model__WEBPACK_IMPORTED_MODULE_2__.StatusEnumFilter);
    this.trieOptions = Object.values(src_app_models_nutritionist_model__WEBPACK_IMPORTED_MODULE_2__.TrieEnum);
    this.statusEnum = src_app_models_nutritionist_model__WEBPACK_IMPORTED_MODULE_2__.StatusEnum;
    this.nutritionists = [];
    this.nutritionistService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.inject)(src_app_services_nutritionists_service__WEBPACK_IMPORTED_MODULE_4__.NutritionistsService);
    this.toastr = (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.inject)(ngx_toastr__WEBPACK_IMPORTED_MODULE_11__.ToastrService);
    this.totalNutritionistsCount = 0;
    this.currentPage = 0;
    this.limit = 12;
    this.isLoading = false;
    this.pageIndex = 0;
    this.uploadService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.inject)(src_app_services_file_upload_service__WEBPACK_IMPORTED_MODULE_3__.FileUploadService);
    this.nutritionistService.getAllNutritionists().subscribe(response => {
      this.nutritionists = response.data;
    });
  }
  updateStatus(nutritionist, newStatus) {
    this.nutritionistService.updateNutritionist(nutritionist.id, newStatus).subscribe({
      next: response => {
        // Success callback
        this.toastr.success('Status updated successfully!');
        nutritionist.status = newStatus;
      },
      error: error => {
        // Error callback
        this.toastr.error('Error updating status', 'Error');
      }
    });
  }
  highlightText(content, search) {
    if (!search) {
      return content;
    } // Return the original content if search is empty
    // Escape special characters in the search term
    const escapedSearch = search.replace(/[.*+?^=!:${}()|\[\]\/\\]/g, '\\$&');
    // Create a case-insensitive regex for the search term
    const regex = new RegExp(`(${escapedSearch})`, 'gi');
    // Wrap matches with a span
    return content.replace(regex, match => `<span class="highlight">${match}</span>`);
  }
  downloadCertificate(filename) {
    this.uploadService.downloadCertificate(filename).subscribe({
      next: blob => {
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = filename; // Use the original filename
        link.click();
        URL.revokeObjectURL(link.href); // Clean up
      },

      error: error => {
        console.error('Error downloading file:', error);
      }
    });
  }
  getTotalPageNumber() {
    return Math.ceil(this.totalNutritionistsCount / this.limit);
  }
  updatePage(index) {
    this.currentPage = index;
    this.isLoading = true;
    this.nutritionistService.getAllNutritionists(this.currentPage).subscribe({
      next: response => {
        this.nutritionists = response.data;
        this.totalNutritionistsCount = response.total;
        // H
        setTimeout(() => {
          this.isLoading = false;
        }, 1000);
      },
      error: error => {
        this.toastr.error(src_app_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_1__.AppUtils.getErrorMessage(error), 'Error');
        this.isLoading = false; // H
      }
    });
  }

  static {
    this.ɵfac = function NutritionistsTableComponent_Factory(t) {
      return new (t || NutritionistsTableComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineComponent"]({
      type: NutritionistsTableComponent,
      selectors: [["app-nutritionists-table"]],
      decls: 27,
      vars: 14,
      consts: [[1, "right-container"], [1, "filters"], [3, "formControlName"], [3, "name", "options", "formControlName"], [4, "ngFor", "ngForOf"], [1, "pagination"], [3, "totalPages", "pageChanged"], [3, "innerHTML"], [1, "highlight"], [1, "certificate-container", 3, "click"], ["src", "assets/images/pdf-file.png", "alt", "Download", 1, "icon"], ["src", "assets/images/download-icon.png", "alt", "Download", 1, "icon"], [3, "ngSwitch"], ["class", "status-approved", 4, "ngSwitchCase"], ["class", "status-rejected", 4, "ngSwitchCase"], ["class", "status-images", 4, "ngSwitchCase"], ["class", "status-default", 4, "ngSwitchDefault"], [1, "status-approved"], [1, "status-rejected"], [1, "status-images"], ["src", "assets/images/accept.png", "alt", "Accept", 1, "icon", 3, "click"], ["src", "assets/images/cancel.png", "alt", "Cancel", 1, "icon", 3, "click"], [1, "status-default"]],
      template: function NutritionistsTableComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "div", 0)(1, "h2");
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](2, "Nos Nutritionnistes:");
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](3, "div", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](4, "app-search", 2)(5, "app-dropdown", 3)(6, "app-dropdown", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](7, "table")(8, "thead")(9, "tr")(10, "th");
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](11, "Nutritioniste");
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](12, "th");
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](13, "Addresse");
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](14, "th");
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](15, "Num\u00E9ro de t\u00E9l\u00E9phone");
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](16, "th");
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](17, "Email");
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](18, "th");
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](19, "Certificat");
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](20, "th");
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](21, "Status");
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](22, "tbody");
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](23, NutritionistsTableComponent_tr_23_Template, 21, 12, "tr", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](24, "nutritionistsTableFilter");
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](25, "div", 5)(26, "app-pagination", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("pageChanged", function NutritionistsTableComponent_Template_app_pagination_pageChanged_26_listener($event) {
            return ctx.updatePage($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("formControlName", ctx.searchControl);
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("name", "Trier")("options", ctx.trieOptions)("formControlName", ctx.trieControl);
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("name", "Status")("options", ctx.statusOptions)("formControlName", ctx.statusControl);
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](17);
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind4"](24, 9, ctx.nutritionists, ctx.searchControl.value, ctx.statusControl.value, ctx.trieControl.value));
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("totalPages", ctx.getTotalPageNumber());
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_12__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_12__.NgSwitch, _angular_common__WEBPACK_IMPORTED_MODULE_12__.NgSwitchCase, _angular_common__WEBPACK_IMPORTED_MODULE_12__.NgSwitchDefault, _shared_components_pagination_pagination_component__WEBPACK_IMPORTED_MODULE_5__.PaginationComponent, _shared_components_search_search_component__WEBPACK_IMPORTED_MODULE_6__.SearchComponent, _shared_components_dropdown_dropdown_component__WEBPACK_IMPORTED_MODULE_7__.DropdownComponent, _core_pipes_nutritionists_table_filter_pipe__WEBPACK_IMPORTED_MODULE_8__.NutritionistsTableFilterPipe],
      styles: [".right-container[_ngcontent-%COMP%] {\n  background-color: white;\n  margin-top: 20px;\n  padding: 20px;\n  border-radius: 30px;\n  overflow-x: auto;\n  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);\n  width: 100%;\n  display: flex;\n  flex-direction: column;\n  align-items: start;\n  gap: 20px;\n}\n.right-container[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  color: var(--primary-color);\n}\n.right-container[_ngcontent-%COMP%]   table[_ngcontent-%COMP%] {\n  width: 100%;\n  font-size: 0.8rem;\n  border-collapse: collapse;\n  \n\n}\n\n.right-container[_ngcontent-%COMP%]   thead[_ngcontent-%COMP%] {\n  color: var(--hint-text);\n}\n\n.right-container[_ngcontent-%COMP%]   th[_ngcontent-%COMP%], td[_ngcontent-%COMP%] {\n  padding: 20px 15px;\n  text-align: left;\n  border-bottom: 1.3px solid #ddd;\n}\n\n.right-container[_ngcontent-%COMP%]   th[_ngcontent-%COMP%] {\n  font-weight: 500;\n}\n.certificate-container[_ngcontent-%COMP%] {\n  justify-content: space-between;\n  width: 100%;\n  display: flex;\n  align-items: center;\n}\n\n.certificate-container[_ngcontent-%COMP%]   .icon[_ngcontent-%COMP%] {\n  width: 20px;\n  height: 20px;\n  cursor: pointer;\n}\n\n.right-container[_ngcontent-%COMP%]   .status-approved[_ngcontent-%COMP%], .right-container[_ngcontent-%COMP%]   .status-rejected[_ngcontent-%COMP%] {\n  display: inline-block;\n  width: 100%;\n  padding: 0.5rem 1rem 0.5rem 1rem;\n  text-align: center;\n  border-radius: 4px;\n  font-weight: 500;\n}\n\n.right-container[_ngcontent-%COMP%]   .status-approved[_ngcontent-%COMP%] {\n  color: #5faa03;\n  background-color: var(--light-green);\n}\n\n.right-container[_ngcontent-%COMP%]   .status-rejected[_ngcontent-%COMP%] {\n  color: red;\n  background-color: #ffc5c5;\n}\n.right-container[_ngcontent-%COMP%]   .status-images[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 27px;\n  justify-content: center;\n  align-items: center;\n}\n.status-images[_ngcontent-%COMP%]   .icon[_ngcontent-%COMP%] {\n  width: 27px;\n  height: 27px;\n  cursor: pointer;\n}\n.right-container[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]:hover {\n  background-color: #f9f9f9;\n}\n.filters[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 20px;\n  width: 100%;\n}\n  .highlight {\n  background-color: var(--light-green);\n  font-weight: 600;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvZmVhdHVyZXMvaG9tZS9udXRyaXRpb25pc3RzLXRhYmxlL251dHJpdGlvbmlzdHMtdGFibGUuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHVCQUF1QjtFQUN2QixnQkFBZ0I7RUFDaEIsYUFBYTtFQUNiLG1CQUFtQjtFQUNuQixnQkFBZ0I7RUFDaEIsd0NBQXdDO0VBQ3hDLFdBQVc7RUFDWCxhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLGtCQUFrQjtFQUNsQixTQUFTO0FBQ1g7QUFDQTtFQUNFLDJCQUEyQjtBQUM3QjtBQUNBO0VBQ0UsV0FBVztFQUNYLGlCQUFpQjtFQUNqQix5QkFBeUI7RUFDekIseUJBQXlCO0FBQzNCOztBQUVBO0VBQ0UsdUJBQXVCO0FBQ3pCOztBQUVBOztFQUVFLGtCQUFrQjtFQUNsQixnQkFBZ0I7RUFDaEIsK0JBQStCO0FBQ2pDOztBQUVBO0VBQ0UsZ0JBQWdCO0FBQ2xCO0FBQ0E7RUFDRSw4QkFBOEI7RUFDOUIsV0FBVztFQUNYLGFBQWE7RUFDYixtQkFBbUI7QUFDckI7O0FBRUE7RUFDRSxXQUFXO0VBQ1gsWUFBWTtFQUNaLGVBQWU7QUFDakI7O0FBRUE7O0VBRUUscUJBQXFCO0VBQ3JCLFdBQVc7RUFDWCxnQ0FBZ0M7RUFDaEMsa0JBQWtCO0VBQ2xCLGtCQUFrQjtFQUNsQixnQkFBZ0I7QUFDbEI7O0FBRUE7RUFDRSxjQUFjO0VBQ2Qsb0NBQW9DO0FBQ3RDOztBQUVBO0VBQ0UsVUFBVTtFQUNWLHlCQUF5QjtBQUMzQjtBQUNBO0VBQ0UsYUFBYTtFQUNiLFNBQVM7RUFDVCx1QkFBdUI7RUFDdkIsbUJBQW1CO0FBQ3JCO0FBQ0E7RUFDRSxXQUFXO0VBQ1gsWUFBWTtFQUNaLGVBQWU7QUFDakI7QUFDQTtFQUNFLHlCQUF5QjtBQUMzQjtBQUNBO0VBQ0UsYUFBYTtFQUNiLFNBQVM7RUFDVCxXQUFXO0FBQ2I7QUFDQTtFQUNFLG9DQUFvQztFQUNwQyxnQkFBZ0I7QUFDbEIiLCJzb3VyY2VzQ29udGVudCI6WyIucmlnaHQtY29udGFpbmVyIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICBtYXJnaW4tdG9wOiAyMHB4O1xyXG4gIHBhZGRpbmc6IDIwcHg7XHJcbiAgYm9yZGVyLXJhZGl1czogMzBweDtcclxuICBvdmVyZmxvdy14OiBhdXRvO1xyXG4gIGJveC1zaGFkb3c6IDAgNHB4IDZweCByZ2JhKDAsIDAsIDAsIDAuMSk7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gIGFsaWduLWl0ZW1zOiBzdGFydDtcclxuICBnYXA6IDIwcHg7XHJcbn1cclxuLnJpZ2h0LWNvbnRhaW5lciBoMiB7XHJcbiAgY29sb3I6IHZhcigtLXByaW1hcnktY29sb3IpO1xyXG59XHJcbi5yaWdodC1jb250YWluZXIgdGFibGUge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGZvbnQtc2l6ZTogMC44cmVtO1xyXG4gIGJvcmRlci1jb2xsYXBzZTogY29sbGFwc2U7XHJcbiAgLyogdGFibGUtbGF5b3V0OiBmaXhlZDsgKi9cclxufVxyXG5cclxuLnJpZ2h0LWNvbnRhaW5lciB0aGVhZCB7XHJcbiAgY29sb3I6IHZhcigtLWhpbnQtdGV4dCk7XHJcbn1cclxuXHJcbi5yaWdodC1jb250YWluZXIgdGgsXHJcbnRkIHtcclxuICBwYWRkaW5nOiAyMHB4IDE1cHg7XHJcbiAgdGV4dC1hbGlnbjogbGVmdDtcclxuICBib3JkZXItYm90dG9tOiAxLjNweCBzb2xpZCAjZGRkO1xyXG59XHJcblxyXG4ucmlnaHQtY29udGFpbmVyIHRoIHtcclxuICBmb250LXdlaWdodDogNTAwO1xyXG59XHJcbi5jZXJ0aWZpY2F0ZS1jb250YWluZXIge1xyXG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICB3aWR0aDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5jZXJ0aWZpY2F0ZS1jb250YWluZXIgLmljb24ge1xyXG4gIHdpZHRoOiAyMHB4O1xyXG4gIGhlaWdodDogMjBweDtcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbi5yaWdodC1jb250YWluZXIgLnN0YXR1cy1hcHByb3ZlZCxcclxuLnJpZ2h0LWNvbnRhaW5lciAuc3RhdHVzLXJlamVjdGVkIHtcclxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgcGFkZGluZzogMC41cmVtIDFyZW0gMC41cmVtIDFyZW07XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICBmb250LXdlaWdodDogNTAwO1xyXG59XHJcblxyXG4ucmlnaHQtY29udGFpbmVyIC5zdGF0dXMtYXBwcm92ZWQge1xyXG4gIGNvbG9yOiAjNWZhYTAzO1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWxpZ2h0LWdyZWVuKTtcclxufVxyXG5cclxuLnJpZ2h0LWNvbnRhaW5lciAuc3RhdHVzLXJlamVjdGVkIHtcclxuICBjb2xvcjogcmVkO1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmM1YzU7XHJcbn1cclxuLnJpZ2h0LWNvbnRhaW5lciAuc3RhdHVzLWltYWdlcyB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBnYXA6IDI3cHg7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG4uc3RhdHVzLWltYWdlcyAuaWNvbiB7XHJcbiAgd2lkdGg6IDI3cHg7XHJcbiAgaGVpZ2h0OiAyN3B4O1xyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG4ucmlnaHQtY29udGFpbmVyIHRyOmhvdmVyIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjlmOWY5O1xyXG59XHJcbi5maWx0ZXJzIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGdhcDogMjBweDtcclxuICB3aWR0aDogMTAwJTtcclxufVxyXG46Om5nLWRlZXAgLmhpZ2hsaWdodCB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tbGlnaHQtZ3JlZW4pO1xyXG4gIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9 */", ".quote[_ngcontent-%COMP%] {\n  margin: auto;\n  width: 100%;\n  max-width: 21rem;\n  text-align: center;\n  white-space: normal;\n  line-height: 1.5;\n}\n.quote[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  font-family: \"Dancing Script\";\n  color: var(--primary-color);\n  font-size: 1.7rem;\n}\n\n.pagination[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n  justify-content: end;\n}\n.recipe-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  padding: 0 40px 40px 40px;\n  justify-content: start;\n  align-items: center;\n  gap: 20px;\n  width: 100%;\n}\n\n.first-section-recipe[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 30px;\n  align-items: center;\n  justify-content: center;\n  width: 100%;\n  margin-top: 15px;\n}\n.recipe-details[_ngcontent-%COMP%] {\n  height: 100%;\n  width: 65%;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  gap: 20px;\n  align-items: center;\n}\n.details-grid-container[_ngcontent-%COMP%] {\n  padding-top: 10px;\n  width: 100%;\n  display: grid;\n  grid-template-columns: repeat(auto-fit, 210px);\n  grid-template-rows: repeat(3, 50px);\n  justify-content: center;\n  row-gap: 10px;\n  column-gap: 20px;\n}\n.detail-item[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n}\n.detail-item[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 40px;\n  height: 40px;\n}\n.separation-line[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 0.5px;\n  background-color: var(--secondary-color);\n}\n.second-section-recipe[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n}\n.recipe-detail-item[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  gap: 15px;\n}\n.recipe-detail-item[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  color: var(--brown);\n  font-weight: 600;\n  font-size: 26px;\n}\n\n.detail-list[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  z-index: 1000;\n}\n.recipe-detail-item[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n  margin-bottom: 10px;\n}\n.detail-text[_ngcontent-%COMP%] {\n  font-weight: 500;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hc3NldHMvY3NzL2xpc3QtY29tbW9uLmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFlBQVk7RUFDWixXQUFXO0VBQ1gsZ0JBQWdCO0VBQ2hCLGtCQUFrQjtFQUNsQixtQkFBbUI7RUFDbkIsZ0JBQWdCO0FBQ2xCO0FBQ0E7RUFDRSw2QkFBNkI7RUFDN0IsMkJBQTJCO0VBQzNCLGlCQUFpQjtBQUNuQjs7QUFFQTtFQUNFLFdBQVc7RUFDWCxhQUFhO0VBQ2Isb0JBQW9CO0FBQ3RCO0FBQ0E7RUFDRSxhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLHlCQUF5QjtFQUN6QixzQkFBc0I7RUFDdEIsbUJBQW1CO0VBQ25CLFNBQVM7RUFDVCxXQUFXO0FBQ2I7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsU0FBUztFQUNULG1CQUFtQjtFQUNuQix1QkFBdUI7RUFDdkIsV0FBVztFQUNYLGdCQUFnQjtBQUNsQjtBQUNBO0VBQ0UsWUFBWTtFQUNaLFVBQVU7RUFDVixhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLHVCQUF1QjtFQUN2QixTQUFTO0VBQ1QsbUJBQW1CO0FBQ3JCO0FBQ0E7RUFDRSxpQkFBaUI7RUFDakIsV0FBVztFQUNYLGFBQWE7RUFDYiw4Q0FBOEM7RUFDOUMsbUNBQW1DO0VBQ25DLHVCQUF1QjtFQUN2QixhQUFhO0VBQ2IsZ0JBQWdCO0FBQ2xCO0FBQ0E7RUFDRSxhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLFNBQVM7QUFDWDtBQUNBO0VBQ0UsV0FBVztFQUNYLFlBQVk7QUFDZDtBQUNBO0VBQ0UsV0FBVztFQUNYLGFBQWE7RUFDYix3Q0FBd0M7QUFDMUM7QUFDQTtFQUNFLFdBQVc7RUFDWCxhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLFNBQVM7QUFDWDtBQUNBO0VBQ0UsYUFBYTtFQUNiLHNCQUFzQjtFQUN0Qix1QkFBdUI7RUFDdkIsU0FBUztBQUNYO0FBQ0E7RUFDRSxtQkFBbUI7RUFDbkIsZ0JBQWdCO0VBQ2hCLGVBQWU7QUFDakI7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLFNBQVM7RUFDVCxhQUFhO0FBQ2Y7QUFDQTtFQUNFLG1CQUFtQjtBQUNyQjtBQUNBO0VBQ0UsZ0JBQWdCO0FBQ2xCIiwic291cmNlc0NvbnRlbnQiOlsiLnF1b3RlIHtcclxuICBtYXJnaW46IGF1dG87XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgbWF4LXdpZHRoOiAyMXJlbTtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgd2hpdGUtc3BhY2U6IG5vcm1hbDtcclxuICBsaW5lLWhlaWdodDogMS41O1xyXG59XHJcbi5xdW90ZSBoMyB7XHJcbiAgZm9udC1mYW1pbHk6IFwiRGFuY2luZyBTY3JpcHRcIjtcclxuICBjb2xvcjogdmFyKC0tcHJpbWFyeS1jb2xvcik7XHJcbiAgZm9udC1zaXplOiAxLjdyZW07XHJcbn1cclxuXHJcbi5wYWdpbmF0aW9uIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogZW5kO1xyXG59XHJcbi5yZWNpcGUtY29udGFpbmVyIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgcGFkZGluZzogMCA0MHB4IDQwcHggNDBweDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHN0YXJ0O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgZ2FwOiAyMHB4O1xyXG4gIHdpZHRoOiAxMDAlO1xyXG59XHJcblxyXG4uZmlyc3Qtc2VjdGlvbi1yZWNpcGUge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZ2FwOiAzMHB4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgbWFyZ2luLXRvcDogMTVweDtcclxufVxyXG4ucmVjaXBlLWRldGFpbHMge1xyXG4gIGhlaWdodDogMTAwJTtcclxuICB3aWR0aDogNjUlO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBnYXA6IDIwcHg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG4uZGV0YWlscy1ncmlkLWNvbnRhaW5lciB7XHJcbiAgcGFkZGluZy10b3A6IDEwcHg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgZGlzcGxheTogZ3JpZDtcclxuICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IHJlcGVhdChhdXRvLWZpdCwgMjEwcHgpO1xyXG4gIGdyaWQtdGVtcGxhdGUtcm93czogcmVwZWF0KDMsIDUwcHgpO1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIHJvdy1nYXA6IDEwcHg7XHJcbiAgY29sdW1uLWdhcDogMjBweDtcclxufVxyXG4uZGV0YWlsLWl0ZW0ge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBnYXA6IDEwcHg7XHJcbn1cclxuLmRldGFpbC1pdGVtIGltZyB7XHJcbiAgd2lkdGg6IDQwcHg7XHJcbiAgaGVpZ2h0OiA0MHB4O1xyXG59XHJcbi5zZXBhcmF0aW9uLWxpbmUge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMC41cHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tc2Vjb25kYXJ5LWNvbG9yKTtcclxufVxyXG4uc2Vjb25kLXNlY3Rpb24tcmVjaXBlIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgZ2FwOiAxMHB4O1xyXG59XHJcbi5yZWNpcGUtZGV0YWlsLWl0ZW0ge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBnYXA6IDE1cHg7XHJcbn1cclxuLnJlY2lwZS1kZXRhaWwtaXRlbSBoMiB7XHJcbiAgY29sb3I6IHZhcigtLWJyb3duKTtcclxuICBmb250LXdlaWdodDogNjAwO1xyXG4gIGZvbnQtc2l6ZTogMjZweDtcclxufVxyXG5cclxuLmRldGFpbC1saXN0IHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgZ2FwOiAxMHB4O1xyXG4gIHotaW5kZXg6IDEwMDA7XHJcbn1cclxuLnJlY2lwZS1kZXRhaWwtaXRlbSBsaSB7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcclxufVxyXG4uZGV0YWlsLXRleHQge1xyXG4gIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 7606:
/*!**************************************************************!*\
  !*** ./src/app/features/home/top-list/top-list.component.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TopListComponent: () => (/* binding */ TopListComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../shared/components/button/button.component */ 8219);
/* harmony import */ var _shared_components_svg_box_svg_box_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../shared/components/svg-box/svg-box.component */ 6145);



const _c0 = ["*"];
class TopListComponent {
  constructor() {
    this.title = '';
    this.onVoirPlusClicked = () => {};
  }
  static {
    this.ɵfac = function TopListComponent_Factory(t) {
      return new (t || TopListComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
      type: TopListComponent,
      selectors: [["app-top-list"]],
      inputs: {
        title: "title",
        onVoirPlusClicked: "onVoirPlusClicked"
      },
      ngContentSelectors: _c0,
      decls: 8,
      vars: 4,
      consts: [[3, "width"], [1, "popular-items-container"], [1, "popular-items-header"], [3, "text", "onClick"], [1, "popular-items"]],
      template: function TopListComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵprojectionDef"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "app-svg-box", 0)(1, "div", 1)(2, "div", 2)(3, "h2");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](5, "app-button", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](6, "div", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵprojection"](7);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("width", "95%");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](ctx.title);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("text", "Voir plus")("onClick", ctx.onVoirPlusClicked);
        }
      },
      dependencies: [_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_0__.ButtonComponent, _shared_components_svg_box_svg_box_component__WEBPACK_IMPORTED_MODULE_1__.SvgBoxComponent],
      styles: [".popular-items-container[_ngcontent-%COMP%] {\n  width: 100%;\n}\n.popular-items[_ngcontent-%COMP%] {\n  padding: 90px 0 60px 0px;\n  display: flex;\n  gap: 30px;\n  width: 100%;\n  height: 100%;\n  flex-wrap: wrap;\n}\n.popular-items[_ngcontent-%COMP%]    >   * {\n  flex-basis: 20%;\n  height: 200px;\n  transition: transform 0.2s ease-in-out;\n  \n\n  &:hover {\n    transform: scale(1.2);\n  }\n}\n.popular-items-container[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  color: var(--primary-color);\n  font-weight: 600;\n}\n\n.popular-items-header[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvZmVhdHVyZXMvaG9tZS90b3AtbGlzdC90b3AtbGlzdC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsV0FBVztBQUNiO0FBQ0E7RUFDRSx3QkFBd0I7RUFDeEIsYUFBYTtFQUNiLFNBQVM7RUFDVCxXQUFXO0VBQ1gsWUFBWTtFQUNaLGVBQWU7QUFDakI7QUFDQTtFQUNFLGVBQWU7RUFDZixhQUFhO0VBQ2Isc0NBQXNDO0VBQ3RDLDRCQUE0QjtFQUM1QjtJQUNFLHFCQUFxQjtFQUN2QjtBQUNGO0FBQ0E7RUFDRSwyQkFBMkI7RUFDM0IsZ0JBQWdCO0FBQ2xCOztBQUVBO0VBQ0UsYUFBYTtFQUNiLDhCQUE4QjtBQUNoQyIsInNvdXJjZXNDb250ZW50IjpbIi5wb3B1bGFyLWl0ZW1zLWNvbnRhaW5lciB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbn1cclxuLnBvcHVsYXItaXRlbXMge1xyXG4gIHBhZGRpbmc6IDkwcHggMCA2MHB4IDBweDtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGdhcDogMzBweDtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAgZmxleC13cmFwOiB3cmFwO1xyXG59XHJcbi5wb3B1bGFyLWl0ZW1zID4gOjpuZy1kZWVwICoge1xyXG4gIGZsZXgtYmFzaXM6IDIwJTtcclxuICBoZWlnaHQ6IDIwMHB4O1xyXG4gIHRyYW5zaXRpb246IHRyYW5zZm9ybSAwLjJzIGVhc2UtaW4tb3V0O1xyXG4gIC8qIE9wdGlvbmFsIGZvciB2aXNpYmlsaXR5ICovXHJcbiAgJjpob3ZlciB7XHJcbiAgICB0cmFuc2Zvcm06IHNjYWxlKDEuMik7XHJcbiAgfVxyXG59XHJcbi5wb3B1bGFyLWl0ZW1zLWNvbnRhaW5lciBoMiB7XHJcbiAgY29sb3I6IHZhcigtLXByaW1hcnktY29sb3IpO1xyXG4gIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbn1cclxuXHJcbi5wb3B1bGFyLWl0ZW1zLWhlYWRlciB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 3527:
/*!******************************************************************!*\
  !*** ./src/app/features/landing/components/tip/tip.component.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TipComponent: () => (/* binding */ TipComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 7580);

class TipComponent {
  constructor() {
    this.imageUrl = 'assets/images/apple.png';
    this.text = 'Les pommes peuvent réduire le cholestérol élevé et la pression artérielle.';
    this.hovered = false;
  }
  static {
    this.ɵfac = function TipComponent_Factory(t) {
      return new (t || TipComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: TipComponent,
      selectors: [["app-tip"]],
      inputs: {
        imageUrl: "imageUrl",
        text: "text"
      },
      decls: 4,
      vars: 2,
      consts: [[1, "tip", 3, "mouseenter", "mouseleave"], ["alt", "", 3, "src"]],
      template: function TipComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("mouseenter", function TipComponent_Template_div_mouseenter_0_listener() {
            return ctx.hovered = true;
          })("mouseleave", function TipComponent_Template_div_mouseleave_0_listener() {
            return ctx.hovered = false;
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "img", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("src", "assets/images/" + ctx.imageUrl + (ctx.hovered ? "-white" : "") + ".png", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.text);
        }
      },
      styles: [".tip[_ngcontent-%COMP%] {\n  flex: 1 1 250px;\n  max-width: 300px;\n  padding: 9px 11px;\n  border-radius: 10px;\n  display: flex;\n  gap: 10px;\n  background-color: white;\n  color: black;\n  &:hover {\n    background-color: var(--primary-color);\n    color: white;\n  }\n}\n\n.tip[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  font-size: max(0.9vw, 12px);\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvZmVhdHVyZXMvbGFuZGluZy9jb21wb25lbnRzL3RpcC90aXAuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGVBQWU7RUFDZixnQkFBZ0I7RUFDaEIsaUJBQWlCO0VBQ2pCLG1CQUFtQjtFQUNuQixhQUFhO0VBQ2IsU0FBUztFQUNULHVCQUF1QjtFQUN2QixZQUFZO0VBQ1o7SUFDRSxzQ0FBc0M7SUFDdEMsWUFBWTtFQUNkO0FBQ0Y7O0FBRUE7RUFDRSwyQkFBMkI7QUFDN0IiLCJzb3VyY2VzQ29udGVudCI6WyIudGlwIHtcclxuICBmbGV4OiAxIDEgMjUwcHg7XHJcbiAgbWF4LXdpZHRoOiAzMDBweDtcclxuICBwYWRkaW5nOiA5cHggMTFweDtcclxuICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZ2FwOiAxMHB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG4gIGNvbG9yOiBibGFjaztcclxuICAmOmhvdmVyIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLXByaW1hcnktY29sb3IpO1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gIH1cclxufVxyXG5cclxuLnRpcCBwIHtcclxuICBmb250LXNpemU6IG1heCgwLjl2dywgMTJweCk7XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 9238:
/*!*************************************************************************!*\
  !*** ./src/app/features/landing/landing-page/landing-page.component.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LandingPageComponent: () => (/* binding */ LandingPageComponent)
/* harmony export */ });
/* harmony import */ var src_app_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/utils/functions.utils */ 3584);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../shared/components/button/button.component */ 8219);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 5072);
/* harmony import */ var _components_tip_tip_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/tip/tip.component */ 3527);





const _c0 = function () {
  return ["/login"];
};
class LandingPageComponent {
  getCssVariable(variableName) {
    return src_app_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_0__.AppUtils.getCssVariable(variableName);
  }
  static {
    this.ɵfac = function LandingPageComponent_Factory(t) {
      return new (t || LandingPageComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
      type: LandingPageComponent,
      selectors: [["app-landing-page"]],
      decls: 52,
      vars: 35,
      consts: [[1, "landing-page"], ["src", "assets/images/nutri-logo.png", "alt", "nutri-logo", 1, "logo"], [1, "first-section"], [1, "header"], [1, "signup"], [3, "width", "text", "borderRadius", "routerLink"], [1, "login"], [1, "opening"], [1, "left-section"], [1, "nutrition"], [1, "buttons"], [3, "routerLink", "width", "text", "borderRadius"], [3, "routerLink", "textColor", "width", "text", "borderRadius", "backgroundColor", "hasBorder"], [1, "numbers"], [1, "number"], [1, "right-section"], ["id", "main-img", "src", "assets/images/nutrition2.png", "alt", "nutrition2"], ["id", "small-flower", "src", "assets/images/flower-shape.svg", "alt", "nutrition2"], ["id", "big-flower", "src", "assets/images/big-flow.svg", "alt", "nutrition2"], ["id", "arrow", "src", "assets/images/arrow.svg", "alt", "nutrition2"], [1, "tips"], [3, "imageUrl", "text"]],
      template: function LandingPageComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](1, "img", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "div", 2)(3, "div", 3)(4, "div", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](5, "app-button", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](6, "div", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](7, "app-button", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](8, "div", 7)(9, "div", 8)(10, "h1");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](11, " Votre ");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](12, "span", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](13, "Nutrition");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](14, "br");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](15, "Au Coeur D");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](16, "br");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](17, " Votre Bien-\u00CAtre ");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](18, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](19, " D\u00E9couvrez NutriSolutions : nous offrons un suivi nutritionnel personnalis\u00E9 pour vous aider \u00E0 atteindre vos objectifs de bien-\u00EAtre, tout en respectant vos besoins uniques et vos pr\u00E9f\u00E9rences. ");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](20, "div", 10);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](21, "app-button", 11)(22, "app-button", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](23, "div", 13)(24, "div", 14)(25, "h2");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](26, "50+");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](27, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](28, "Nutritionnistes Certifi\u00E9s");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](29, "div", 14)(30, "h2");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](31, "200+");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](32, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](33, "Repas Personnalis\u00E9s");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](34, "div", 14)(35, "h2");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](36, "500+");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](37, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](38, "Clients Satisfaits");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](39, "div", 15);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](40, "img", 16)(41, "img", 17)(42, "img", 18)(43, "img", 19);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](44, "div", 20);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](45, "app-tip", 21)(46, "app-tip", 21)(47, "app-tip", 21)(48, "app-tip", 21)(49, "app-tip", 21)(50, "app-tip", 21)(51, "app-tip", 21);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("width", "100px")("text", "SignUp")("borderRadius", "20px 0px 20px 0px")("routerLink", "/signup");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("width", "100px")("text", "Login")("borderRadius", "20px 0px 20px 0px")("routerLink", "/login");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](14);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction0"](33, _c0))("width", "130px")("text", "Savoir Plus")("borderRadius", "20px 0px 20px 0px");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction0"](34, _c0))("textColor", ctx.getCssVariable("--secondary-color"))("width", "130px")("text", "Prendre RDV")("borderRadius", "20px 0px 20px 0px")("backgroundColor", "transparent")("hasBorder", true);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](23);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("imageUrl", "apple")("text", "Les pommes peuvent r\u00E9duire le cholest\u00E9rol \u00E9lev\u00E9 et la pression art\u00E9rielle.");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("imageUrl", "banana")("text", "Les pommes peuvent r\u00E9duire le cholest\u00E9rol \u00E9lev\u00E9 et la pression art\u00E9rielle.");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("imageUrl", "ananas")("text", "Les pommes peuvent r\u00E9duire le cholest\u00E9rol \u00E9lev\u00E9 et la pression art\u00E9rielle.");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("imageUrl", "rasain")("text", "Les pommes peuvent r\u00E9duire le cholest\u00E9rol \u00E9lev\u00E9 et la pression art\u00E9rielle.");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("imageUrl", "fraise")("text", "Les pommes peuvent r\u00E9duire le cholest\u00E9rol \u00E9lev\u00E9 et la pression art\u00E9rielle.");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("imageUrl", "pasteque")("text", "Les pommes peuvent r\u00E9duire le cholest\u00E9rol \u00E9lev\u00E9 et la pression art\u00E9rielle.");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("imageUrl", "mangue")("text", "Les pommes peuvent r\u00E9duire le cholest\u00E9rol \u00E9lev\u00E9 et la pression art\u00E9rielle.");
        }
      },
      dependencies: [_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_1__.ButtonComponent, _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterLink, _components_tip_tip_component__WEBPACK_IMPORTED_MODULE_2__.TipComponent],
      styles: [".landing-page[_ngcontent-%COMP%] {\n  position: relative;\n  padding: 0px 5%;\n}\nimg.logo[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  left: 0;\n  height: 120px;\n}\n\n.header[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 10vh;\n  display: flex;\n  justify-content: end;\n  padding-top: 30px;\n  margin-bottom: 50px;\n  gap: 15px;\n}\n.first-section[_ngcontent-%COMP%] {\n  height: 100vh;\n  display: flex;\n  flex-direction: column;\n}\n.buttons[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 90px;\n\n  display: flex;\n  gap: 20px;\n  justify-content: end;\n  align-items: start;\n}\n.left-section[_ngcontent-%COMP%]   .buttons[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n  gap: 20px;\n  justify-content: start;\n  align-items: center;\n}\n.numbers[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 15px;\n  flex-wrap: wrap;\n}\n.number[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  font-size: clamp(20px, 2vw, 30px);\n}\n.opening[_ngcontent-%COMP%] {\n  display: flex;\n}\n.left-section[_ngcontent-%COMP%] {\n  flex: 40%;\n}\n\n.left-section[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%] {\n  font-size: clamp(30px, 3.4vw, 60px);\n  font-weight: 400;\n  line-height: 1.2;\n}\n.left-section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  font-size: clamp(0.8rem, 1.5vw, 1rem);\n  font-weight: 400;\n  color: var(--text-color);\n}\nspan.nutrition[_ngcontent-%COMP%] {\n  background-color: var(--primary-color);\n  display: inline-block;\n  border-radius: 20px 0px 20px 0px;\n  color: white;\n  padding: 7px;\n  font-weight: bold;\n  animation: _ngcontent-%COMP%_bounce-4 1s ease forwards;\n}\n\n.right-section[_ngcontent-%COMP%] {\n  flex: 60%;\n  height: 100%;\n  position: relative;\n  display: flex;\n  justify-content: end;\n}\n\n#main-img[_ngcontent-%COMP%] {\n  border-radius: 50% 0 0 50%;\n  object-fit: contain;\n  width: clamp(300px, 40vw, 500px);\n  height: 100%;\n}\n\n#arrow[_ngcontent-%COMP%] {\n  position: absolute;\n  left: 0;\n  top: 50%;\n  width: clamp(60px, 7vw, 150px);\n\n  transform: translateY(-50%);\n}\n#small-flower[_ngcontent-%COMP%] {\n  position: absolute;\n  left: 20px;\n  bottom: 30%;\n  animation: _ngcontent-%COMP%_rotate 2s 2s infinite ease-in-out;\n}\n\n@keyframes _ngcontent-%COMP%_rotate {\n  0% {\n    transform: rotate(0deg);\n  }\n  100% {\n    transform: rotate(180deg);\n  }\n}\n\n#big-flower[_ngcontent-%COMP%] {\n  position: absolute;\n  top: -20px;\n  right: 0;\n  width: clamp(60px, 7vw, 150px);\n  object-fit: contain;\n  animation: _ngcontent-%COMP%_rotate 2s 2s infinite ease-in-out;\n}\n@keyframes _ngcontent-%COMP%_bounce-4 {\n  0%,\n  100% {\n    transform: translateY(0);\n    transform: rotate(0deg);\n  }\n  50% {\n    transform: translateY(-10);\n\n    transform: rotate(-5deg);\n  }\n}\n.tips[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: center;\n  flex-wrap: wrap;\n  width: 100%;\n  gap: 15px;\n  margin-top: 20px;\n}\n@keyframes _ngcontent-%COMP%_bounce-4 {\n  0%,\n  40%,\n  80% {\n    transform: rotate(0deg);\n  }\n\n  20%,\n  60% {\n    transform: rotate(-3deg);\n  }\n  100% {\n    transform: rotate(-4deg);\n  }\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvZmVhdHVyZXMvbGFuZGluZy9sYW5kaW5nLXBhZ2UvbGFuZGluZy1wYWdlLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxrQkFBa0I7RUFDbEIsZUFBZTtBQUNqQjtBQUNBO0VBQ0Usa0JBQWtCO0VBQ2xCLE1BQU07RUFDTixPQUFPO0VBQ1AsYUFBYTtBQUNmOztBQUVBO0VBQ0UsV0FBVztFQUNYLFlBQVk7RUFDWixhQUFhO0VBQ2Isb0JBQW9CO0VBQ3BCLGlCQUFpQjtFQUNqQixtQkFBbUI7RUFDbkIsU0FBUztBQUNYO0FBQ0E7RUFDRSxhQUFhO0VBQ2IsYUFBYTtFQUNiLHNCQUFzQjtBQUN4QjtBQUNBO0VBQ0UsV0FBVztFQUNYLFlBQVk7O0VBRVosYUFBYTtFQUNiLFNBQVM7RUFDVCxvQkFBb0I7RUFDcEIsa0JBQWtCO0FBQ3BCO0FBQ0E7RUFDRSxXQUFXO0VBQ1gsYUFBYTtFQUNiLFNBQVM7RUFDVCxzQkFBc0I7RUFDdEIsbUJBQW1CO0FBQ3JCO0FBQ0E7RUFDRSxhQUFhO0VBQ2IsU0FBUztFQUNULGVBQWU7QUFDakI7QUFDQTtFQUNFLGlDQUFpQztBQUNuQztBQUNBO0VBQ0UsYUFBYTtBQUNmO0FBQ0E7RUFDRSxTQUFTO0FBQ1g7O0FBRUE7RUFDRSxtQ0FBbUM7RUFDbkMsZ0JBQWdCO0VBQ2hCLGdCQUFnQjtBQUNsQjtBQUNBO0VBQ0UscUNBQXFDO0VBQ3JDLGdCQUFnQjtFQUNoQix3QkFBd0I7QUFDMUI7QUFDQTtFQUNFLHNDQUFzQztFQUN0QyxxQkFBcUI7RUFDckIsZ0NBQWdDO0VBQ2hDLFlBQVk7RUFDWixZQUFZO0VBQ1osaUJBQWlCO0VBQ2pCLG9DQUFvQztBQUN0Qzs7QUFFQTtFQUNFLFNBQVM7RUFDVCxZQUFZO0VBQ1osa0JBQWtCO0VBQ2xCLGFBQWE7RUFDYixvQkFBb0I7QUFDdEI7O0FBRUE7RUFDRSwwQkFBMEI7RUFDMUIsbUJBQW1CO0VBQ25CLGdDQUFnQztFQUNoQyxZQUFZO0FBQ2Q7O0FBRUE7RUFDRSxrQkFBa0I7RUFDbEIsT0FBTztFQUNQLFFBQVE7RUFDUiw4QkFBOEI7O0VBRTlCLDJCQUEyQjtBQUM3QjtBQUNBO0VBQ0Usa0JBQWtCO0VBQ2xCLFVBQVU7RUFDVixXQUFXO0VBQ1gsNENBQTRDO0FBQzlDOztBQUVBO0VBQ0U7SUFDRSx1QkFBdUI7RUFDekI7RUFDQTtJQUNFLHlCQUF5QjtFQUMzQjtBQUNGOztBQUVBO0VBQ0Usa0JBQWtCO0VBQ2xCLFVBQVU7RUFDVixRQUFRO0VBQ1IsOEJBQThCO0VBQzlCLG1CQUFtQjtFQUNuQiw0Q0FBNEM7QUFDOUM7QUFDQTtFQUNFOztJQUVFLHdCQUF3QjtJQUN4Qix1QkFBdUI7RUFDekI7RUFDQTtJQUNFLDBCQUEwQjs7SUFFMUIsd0JBQXdCO0VBQzFCO0FBQ0Y7QUFDQTtFQUNFLGFBQWE7RUFDYix1QkFBdUI7RUFDdkIsZUFBZTtFQUNmLFdBQVc7RUFDWCxTQUFTO0VBQ1QsZ0JBQWdCO0FBQ2xCO0FBQ0E7RUFDRTs7O0lBR0UsdUJBQXVCO0VBQ3pCOztFQUVBOztJQUVFLHdCQUF3QjtFQUMxQjtFQUNBO0lBQ0Usd0JBQXdCO0VBQzFCO0FBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyIubGFuZGluZy1wYWdlIHtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgcGFkZGluZzogMHB4IDUlO1xyXG59XHJcbmltZy5sb2dvIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiAwO1xyXG4gIGxlZnQ6IDA7XHJcbiAgaGVpZ2h0OiAxMjBweDtcclxufVxyXG5cclxuLmhlYWRlciB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAxMHZoO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBlbmQ7XHJcbiAgcGFkZGluZy10b3A6IDMwcHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogNTBweDtcclxuICBnYXA6IDE1cHg7XHJcbn1cclxuLmZpcnN0LXNlY3Rpb24ge1xyXG4gIGhlaWdodDogMTAwdmg7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG59XHJcbi5idXR0b25zIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDkwcHg7XHJcblxyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZ2FwOiAyMHB4O1xyXG4gIGp1c3RpZnktY29udGVudDogZW5kO1xyXG4gIGFsaWduLWl0ZW1zOiBzdGFydDtcclxufVxyXG4ubGVmdC1zZWN0aW9uIC5idXR0b25zIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGdhcDogMjBweDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHN0YXJ0O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuLm51bWJlcnMge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZ2FwOiAxNXB4O1xyXG4gIGZsZXgtd3JhcDogd3JhcDtcclxufVxyXG4ubnVtYmVyIGgyIHtcclxuICBmb250LXNpemU6IGNsYW1wKDIwcHgsIDJ2dywgMzBweCk7XHJcbn1cclxuLm9wZW5pbmcge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbn1cclxuLmxlZnQtc2VjdGlvbiB7XHJcbiAgZmxleDogNDAlO1xyXG59XHJcblxyXG4ubGVmdC1zZWN0aW9uIGgxIHtcclxuICBmb250LXNpemU6IGNsYW1wKDMwcHgsIDMuNHZ3LCA2MHB4KTtcclxuICBmb250LXdlaWdodDogNDAwO1xyXG4gIGxpbmUtaGVpZ2h0OiAxLjI7XHJcbn1cclxuLmxlZnQtc2VjdGlvbiBwIHtcclxuICBmb250LXNpemU6IGNsYW1wKDAuOHJlbSwgMS41dncsIDFyZW0pO1xyXG4gIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgY29sb3I6IHZhcigtLXRleHQtY29sb3IpO1xyXG59XHJcbnNwYW4ubnV0cml0aW9uIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1wcmltYXJ5LWNvbG9yKTtcclxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgYm9yZGVyLXJhZGl1czogMjBweCAwcHggMjBweCAwcHg7XHJcbiAgY29sb3I6IHdoaXRlO1xyXG4gIHBhZGRpbmc6IDdweDtcclxuICBmb250LXdlaWdodDogYm9sZDtcclxuICBhbmltYXRpb246IGJvdW5jZS00IDFzIGVhc2UgZm9yd2FyZHM7XHJcbn1cclxuXHJcbi5yaWdodC1zZWN0aW9uIHtcclxuICBmbGV4OiA2MCU7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogZW5kO1xyXG59XHJcblxyXG4jbWFpbi1pbWcge1xyXG4gIGJvcmRlci1yYWRpdXM6IDUwJSAwIDAgNTAlO1xyXG4gIG9iamVjdC1maXQ6IGNvbnRhaW47XHJcbiAgd2lkdGg6IGNsYW1wKDMwMHB4LCA0MHZ3LCA1MDBweCk7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG59XHJcblxyXG4jYXJyb3cge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICBsZWZ0OiAwO1xyXG4gIHRvcDogNTAlO1xyXG4gIHdpZHRoOiBjbGFtcCg2MHB4LCA3dncsIDE1MHB4KTtcclxuXHJcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC01MCUpO1xyXG59XHJcbiNzbWFsbC1mbG93ZXIge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICBsZWZ0OiAyMHB4O1xyXG4gIGJvdHRvbTogMzAlO1xyXG4gIGFuaW1hdGlvbjogcm90YXRlIDJzIDJzIGluZmluaXRlIGVhc2UtaW4tb3V0O1xyXG59XHJcblxyXG5Aa2V5ZnJhbWVzIHJvdGF0ZSB7XHJcbiAgMCUge1xyXG4gICAgdHJhbnNmb3JtOiByb3RhdGUoMGRlZyk7XHJcbiAgfVxyXG4gIDEwMCUge1xyXG4gICAgdHJhbnNmb3JtOiByb3RhdGUoMTgwZGVnKTtcclxuICB9XHJcbn1cclxuXHJcbiNiaWctZmxvd2VyIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiAtMjBweDtcclxuICByaWdodDogMDtcclxuICB3aWR0aDogY2xhbXAoNjBweCwgN3Z3LCAxNTBweCk7XHJcbiAgb2JqZWN0LWZpdDogY29udGFpbjtcclxuICBhbmltYXRpb246IHJvdGF0ZSAycyAycyBpbmZpbml0ZSBlYXNlLWluLW91dDtcclxufVxyXG5Aa2V5ZnJhbWVzIGJvdW5jZS00IHtcclxuICAwJSxcclxuICAxMDAlIHtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgwKTtcclxuICAgIHRyYW5zZm9ybTogcm90YXRlKDBkZWcpO1xyXG4gIH1cclxuICA1MCUge1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC0xMCk7XHJcblxyXG4gICAgdHJhbnNmb3JtOiByb3RhdGUoLTVkZWcpO1xyXG4gIH1cclxufVxyXG4udGlwcyB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBmbGV4LXdyYXA6IHdyYXA7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgZ2FwOiAxNXB4O1xyXG4gIG1hcmdpbi10b3A6IDIwcHg7XHJcbn1cclxuQGtleWZyYW1lcyBib3VuY2UtNCB7XHJcbiAgMCUsXHJcbiAgNDAlLFxyXG4gIDgwJSB7XHJcbiAgICB0cmFuc2Zvcm06IHJvdGF0ZSgwZGVnKTtcclxuICB9XHJcblxyXG4gIDIwJSxcclxuICA2MCUge1xyXG4gICAgdHJhbnNmb3JtOiByb3RhdGUoLTNkZWcpO1xyXG4gIH1cclxuICAxMDAlIHtcclxuICAgIHRyYW5zZm9ybTogcm90YXRlKC00ZGVnKTtcclxuICB9XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 797:
/*!****************************************************!*\
  !*** ./src/app/features/landing/landing.module.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LandingModule: () => (/* binding */ LandingModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _landing_page_landing_page_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./landing-page/landing-page.component */ 9238);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../shared/shared.module */ 3887);
/* harmony import */ var _components_tip_tip_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/tip/tip.component */ 3527);
/* harmony import */ var _water_tracking_water_tracking_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../water-tracking/water-tracking.module */ 6229);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 5072);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7580);







class LandingModule {
  static {
    this.ɵfac = function LandingModule_Factory(t) {
      return new (t || LandingModule)();
    };
  }
  static {
    this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineNgModule"]({
      type: LandingModule
    });
  }
  static {
    this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule, _water_tracking_water_tracking_module__WEBPACK_IMPORTED_MODULE_3__.WaterTrackingModule, _angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule]
    });
  }
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsetNgModuleScope"](LandingModule, {
    declarations: [_landing_page_landing_page_component__WEBPACK_IMPORTED_MODULE_0__.LandingPageComponent, _components_tip_tip_component__WEBPACK_IMPORTED_MODULE_2__.TipComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule, _water_tracking_water_tracking_module__WEBPACK_IMPORTED_MODULE_3__.WaterTrackingModule, _angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule],
    exports: [_landing_page_landing_page_component__WEBPACK_IMPORTED_MODULE_0__.LandingPageComponent]
  });
})();

/***/ }),

/***/ 2124:
/*!*****************************************************************************************!*\
  !*** ./src/app/features/nutritionists/nutritionist-item/nutritionist-item.component.ts ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   NutritionistItemComponent: () => (/* binding */ NutritionistItemComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 5072);
/* harmony import */ var src_app_core_constants_constants_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/constants/constants.config */ 8111);
/* harmony import */ var _shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../shared/components/button/button.component */ 8219);
/* harmony import */ var _shared_components_svg_box_svg_box_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../shared/components/svg-box/svg-box.component */ 6145);
/* harmony import */ var _shared_components_star_star_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../shared/components/star/star.component */ 9023);







class NutritionistItemComponent {
  constructor() {
    this.base_url = src_app_core_constants_constants_config__WEBPACK_IMPORTED_MODULE_0__.APP_API.base_url;
    this.router = (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.inject)(_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router);
    this.openPlanning = () => {
      this.router.navigate([`/nutritionnists/${this.nutritionist.id}/planning`]);
    };
  }
  static {
    this.ɵfac = function NutritionistItemComponent_Factory(t) {
      return new (t || NutritionistItemComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
      type: NutritionistItemComponent,
      selectors: [["app-nutritionist-item"]],
      inputs: {
        nutritionist: "nutritionist"
      },
      decls: 15,
      vars: 11,
      consts: [[3, "height", "width"], [1, "nutritionist-item"], [1, "nutritionist-img"], ["alt", "", 3, "src"], [1, "nutritionist-content"], [1, "stars-container"], [3, "selectedStars"], [1, "button"], [3, "text", "fontWeight", "width", "onClick"]],
      template: function NutritionistItemComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "app-svg-box", 0)(1, "div", 1)(2, "div", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](3, "img", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "div", 4)(5, "div", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](6, "app-star", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "h2");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](8);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](10);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](12);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](13, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](14, "app-button", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
        }
        if (rf & 2) {
          let tmp_3_0;
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("height", "100%")("width", "100%");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("src", ctx.base_url + ctx.nutritionist.profilePictureUrl, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeUrl"]);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("selectedStars", (tmp_3_0 = ctx.nutritionist.stars) !== null && tmp_3_0 !== undefined ? tmp_3_0 : 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx.nutritionist.name);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"]("", ctx.nutritionist.patientsNumber, "+ Patients");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"]("", ctx.nutritionist.experienceYears, "+ Ann\u00E9es d'exp\u00E9rience");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("text", "Prendre RDV")("fontWeight", "400")("width", "100%")("onClick", ctx.openPlanning);
        }
      },
      dependencies: [_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_1__.ButtonComponent, _shared_components_svg_box_svg_box_component__WEBPACK_IMPORTED_MODULE_2__.SvgBoxComponent, _shared_components_star_star_component__WEBPACK_IMPORTED_MODULE_3__.StarComponent],
      styles: [".nutritionist-item[_ngcontent-%COMP%] {\n  position: relative;\n  width: auto;\n  height: 100%;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n}\n\n.nutritionist-img[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 50%;\n  display: flex;\n  justify-content: center;\n  position: absolute;\n  top: -30%;\n}\n.nutritionist-img[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  border-radius: 50%;\n  width: 50%;\n}\n.stars-container[_ngcontent-%COMP%] {\n  width: 70%;\n}\n.nutritionist-item[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  text-align: center;\n  color: black;\n  font-size: 16px;\n  font-weight: 500;\n  text-overflow: ellipsis;\n}\n.nutritionist-item[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  text-overflow: ellipsis;\n  color: black;\n  font-size: 12px;\n  font-weight: 400;\n  text-align: center;\n}\n\n.nutritionist-content[_ngcontent-%COMP%] {\n  height: 90%;\n  padding: 15px;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: end;\n}\n\n.button[_ngcontent-%COMP%] {\n  position: absolute;\n  bottom: -15px;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvZmVhdHVyZXMvbnV0cml0aW9uaXN0cy9udXRyaXRpb25pc3QtaXRlbS9udXRyaXRpb25pc3QtaXRlbS5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usa0JBQWtCO0VBQ2xCLFdBQVc7RUFDWCxZQUFZO0VBQ1osYUFBYTtFQUNiLHNCQUFzQjtFQUN0QixtQkFBbUI7QUFDckI7O0FBRUE7RUFDRSxXQUFXO0VBQ1gsV0FBVztFQUNYLGFBQWE7RUFDYix1QkFBdUI7RUFDdkIsa0JBQWtCO0VBQ2xCLFNBQVM7QUFDWDtBQUNBO0VBQ0Usa0JBQWtCO0VBQ2xCLFVBQVU7QUFDWjtBQUNBO0VBQ0UsVUFBVTtBQUNaO0FBQ0E7RUFDRSxrQkFBa0I7RUFDbEIsWUFBWTtFQUNaLGVBQWU7RUFDZixnQkFBZ0I7RUFDaEIsdUJBQXVCO0FBQ3pCO0FBQ0E7RUFDRSx1QkFBdUI7RUFDdkIsWUFBWTtFQUNaLGVBQWU7RUFDZixnQkFBZ0I7RUFDaEIsa0JBQWtCO0FBQ3BCOztBQUVBO0VBQ0UsV0FBVztFQUNYLGFBQWE7RUFDYixhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLG1CQUFtQjtFQUNuQixvQkFBb0I7QUFDdEI7O0FBRUE7RUFDRSxrQkFBa0I7RUFDbEIsYUFBYTtBQUNmIiwic291cmNlc0NvbnRlbnQiOlsiLm51dHJpdGlvbmlzdC1pdGVtIHtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgd2lkdGg6IGF1dG87XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcblxyXG4ubnV0cml0aW9uaXN0LWltZyB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiA1MCU7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiAtMzAlO1xyXG59XHJcbi5udXRyaXRpb25pc3QtaW1nIGltZyB7XHJcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gIHdpZHRoOiA1MCU7XHJcbn1cclxuLnN0YXJzLWNvbnRhaW5lciB7XHJcbiAgd2lkdGg6IDcwJTtcclxufVxyXG4ubnV0cml0aW9uaXN0LWl0ZW0gaDIge1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBjb2xvcjogYmxhY2s7XHJcbiAgZm9udC1zaXplOiAxNnB4O1xyXG4gIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XHJcbn1cclxuLm51dHJpdGlvbmlzdC1pdGVtIHAge1xyXG4gIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xyXG4gIGNvbG9yOiBibGFjaztcclxuICBmb250LXNpemU6IDEycHg7XHJcbiAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5udXRyaXRpb25pc3QtY29udGVudCB7XHJcbiAgaGVpZ2h0OiA5MCU7XHJcbiAgcGFkZGluZzogMTVweDtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGVuZDtcclxufVxyXG5cclxuLmJ1dHRvbiB7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIGJvdHRvbTogLTE1cHg7XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 3990:
/*!*******************************************************************************************!*\
  !*** ./src/app/features/nutritionists/nutritionists-list/nutritionists-list.component.ts ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   NutritionistsListComponent: () => (/* binding */ NutritionistsListComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/forms */ 4456);
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ngx-toastr */ 4285);
/* harmony import */ var src_app_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/utils/functions.utils */ 3584);
/* harmony import */ var src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/models/recipe.model */ 6464);
/* harmony import */ var src_app_services_nutritionists_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/nutritionists.service */ 1895);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _shared_components_svg_box_svg_box_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../shared/components/svg-box/svg-box.component */ 6145);
/* harmony import */ var _shared_components_page_background_page_background_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../shared/components/page-background/page-background.component */ 1469);
/* harmony import */ var _shared_components_pagination_pagination_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../shared/components/pagination/pagination.component */ 4815);
/* harmony import */ var _shared_components_search_search_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../shared/components/search/search.component */ 1163);
/* harmony import */ var _shared_components_dropdown_dropdown_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../shared/components/dropdown/dropdown.component */ 4538);
/* harmony import */ var _nutritionist_item_nutritionist_item_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../nutritionist-item/nutritionist-item.component */ 2124);
/* harmony import */ var _core_pipes_nutritionists_filter_pipe__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../core/pipes/nutritionists-filter.pipe */ 8818);















function NutritionistsListComponent_app_nutritionist_item_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "app-nutritionist-item", 10);
  }
  if (rf & 2) {
    const nutritionist_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("nutritionist", nutritionist_r1);
  }
}
class NutritionistsListComponent {
  constructor() {
    this.nutritionists = [];
    this.nutritionistsService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.inject)(src_app_services_nutritionists_service__WEBPACK_IMPORTED_MODULE_2__.NutritionistsService);
    this.searchControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormControl('');
    this.experienceOptions = Object.values(src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_1__.ExperienceEnum);
    this.totalNutritionistsCount = 0;
    this.currentPage = 0;
    this.limit = 12;
    this.isLoading = false;
    this.pageIndex = 0;
    this.toastr = (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.inject)(ngx_toastr__WEBPACK_IMPORTED_MODULE_12__.ToastrService);
    this.nutritionistsService.getAllNutritionists(1, this.limit).subscribe(response => {
      this.nutritionists = response.data;
    });
    this.experienceControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormControl(src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_1__.ExperienceEnum.ALL);
  }
  getTotalPageNumber() {
    return Math.ceil(this.totalNutritionistsCount / this.limit);
  }
  updatePage(index) {
    this.currentPage = index;
    this.isLoading = true;
    this.nutritionistsService.getAllNutritionists(this.currentPage).subscribe({
      next: response => {
        this.nutritionists = response.data;
        this.totalNutritionistsCount = response.total;
        // H
        setTimeout(() => {
          this.isLoading = false;
        }, 1000);
      },
      error: error => {
        this.toastr.error(src_app_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_0__.AppUtils.getErrorMessage(error), 'Error');
        this.isLoading = false; // H
      }
    });
  }

  static {
    this.ɵfac = function NutritionistsListComponent_Factory(t) {
      return new (t || NutritionistsListComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineComponent"]({
      type: NutritionistsListComponent,
      selectors: [["app-nutritionists-list"]],
      decls: 15,
      vars: 12,
      consts: [[1, "quote"], [3, "height", "width"], [1, "title"], [1, "filters"], [3, "formControlName"], [3, "name", "options", "formControlName"], [1, "grid-container"], [3, "nutritionist", 4, "ngFor", "ngForOf"], [1, "pagination"], [3, "totalPages", "pageChanged"], [3, "nutritionist"]],
      template: function NutritionistsListComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "app-page-background")(1, "div", 0)(2, "h3");
          _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](3, "Un nutritionniste, votre alli\u00E9 pour une sant\u00E9 \u00E9quilibr\u00E9e et durable");
          _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](4, "app-svg-box", 1)(5, "h2", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](6, "Nos Nutritionnistes:");
          _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](7, "div", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](8, "app-search", 4)(9, "app-dropdown", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](10, "div", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](11, NutritionistsListComponent_app_nutritionist_item_11_Template, 1, 1, "app-nutritionist-item", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](12, "nutritionistsFilter");
          _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](13, "div", 8)(14, "app-pagination", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("pageChanged", function NutritionistsListComponent_Template_app_pagination_pageChanged_14_listener($event) {
            return ctx.updatePage($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("height", "100%")("width", "95%");
          _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("formControlName", ctx.searchControl);
          _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("name", "Experience")("options", ctx.experienceOptions)("formControlName", ctx.experienceControl);
          _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind3"](12, 8, ctx.nutritionists, ctx.searchControl.value, ctx.experienceControl.value));
          _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("totalPages", ctx.getTotalPageNumber());
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_13__.NgForOf, _shared_components_svg_box_svg_box_component__WEBPACK_IMPORTED_MODULE_3__.SvgBoxComponent, _shared_components_page_background_page_background_component__WEBPACK_IMPORTED_MODULE_4__.PageBackgroundComponent, _shared_components_pagination_pagination_component__WEBPACK_IMPORTED_MODULE_5__.PaginationComponent, _shared_components_search_search_component__WEBPACK_IMPORTED_MODULE_6__.SearchComponent, _shared_components_dropdown_dropdown_component__WEBPACK_IMPORTED_MODULE_7__.DropdownComponent, _nutritionist_item_nutritionist_item_component__WEBPACK_IMPORTED_MODULE_8__.NutritionistItemComponent, _core_pipes_nutritionists_filter_pipe__WEBPACK_IMPORTED_MODULE_9__.NutritionistsFilterPipe],
      styles: [".grid-container[_ngcontent-%COMP%] {\n  width: 100%;\n  display: grid;\n  grid-template-columns: repeat(auto-fit, 160px);\n  grid-template-rows: repeat(3, 180px);\n  justify-content: start;\n  row-gap: 70px;\n  column-gap: 35px;\n}\n.filters[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 20px;\n  width: 100%;\n  margin-bottom: 50px;\n}\nh2.title[_ngcontent-%COMP%] {\n  align-self: start;\n  font-weight: 600;\n  color: var(--primary-color);\n  font-size: 25px;\n  margin-bottom: 20px;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvZmVhdHVyZXMvbnV0cml0aW9uaXN0cy9udXRyaXRpb25pc3RzLWxpc3QvbnV0cml0aW9uaXN0cy1saXN0LmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxXQUFXO0VBQ1gsYUFBYTtFQUNiLDhDQUE4QztFQUM5QyxvQ0FBb0M7RUFDcEMsc0JBQXNCO0VBQ3RCLGFBQWE7RUFDYixnQkFBZ0I7QUFDbEI7QUFDQTtFQUNFLGFBQWE7RUFDYixTQUFTO0VBQ1QsV0FBVztFQUNYLG1CQUFtQjtBQUNyQjtBQUNBO0VBQ0UsaUJBQWlCO0VBQ2pCLGdCQUFnQjtFQUNoQiwyQkFBMkI7RUFDM0IsZUFBZTtFQUNmLG1CQUFtQjtBQUNyQiIsInNvdXJjZXNDb250ZW50IjpbIi5ncmlkLWNvbnRhaW5lciB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgZGlzcGxheTogZ3JpZDtcclxuICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IHJlcGVhdChhdXRvLWZpdCwgMTYwcHgpO1xyXG4gIGdyaWQtdGVtcGxhdGUtcm93czogcmVwZWF0KDMsIDE4MHB4KTtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHN0YXJ0O1xyXG4gIHJvdy1nYXA6IDcwcHg7XHJcbiAgY29sdW1uLWdhcDogMzVweDtcclxufVxyXG4uZmlsdGVycyB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBnYXA6IDIwcHg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgbWFyZ2luLWJvdHRvbTogNTBweDtcclxufVxyXG5oMi50aXRsZSB7XHJcbiAgYWxpZ24tc2VsZjogc3RhcnQ7XHJcbiAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICBjb2xvcjogdmFyKC0tcHJpbWFyeS1jb2xvcik7XHJcbiAgZm9udC1zaXplOiAyNXB4O1xyXG4gIG1hcmdpbi1ib3R0b206IDIwcHg7XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */", ".quote[_ngcontent-%COMP%] {\n  margin: auto;\n  width: 100%;\n  max-width: 21rem;\n  text-align: center;\n  white-space: normal;\n  line-height: 1.5;\n}\n.quote[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  font-family: \"Dancing Script\";\n  color: var(--primary-color);\n  font-size: 1.7rem;\n}\n\n.pagination[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n  justify-content: end;\n}\n.recipe-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  padding: 0 40px 40px 40px;\n  justify-content: start;\n  align-items: center;\n  gap: 20px;\n  width: 100%;\n}\n\n.first-section-recipe[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 30px;\n  align-items: center;\n  justify-content: center;\n  width: 100%;\n  margin-top: 15px;\n}\n.recipe-details[_ngcontent-%COMP%] {\n  height: 100%;\n  width: 65%;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  gap: 20px;\n  align-items: center;\n}\n.details-grid-container[_ngcontent-%COMP%] {\n  padding-top: 10px;\n  width: 100%;\n  display: grid;\n  grid-template-columns: repeat(auto-fit, 210px);\n  grid-template-rows: repeat(3, 50px);\n  justify-content: center;\n  row-gap: 10px;\n  column-gap: 20px;\n}\n.detail-item[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n}\n.detail-item[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 40px;\n  height: 40px;\n}\n.separation-line[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 0.5px;\n  background-color: var(--secondary-color);\n}\n.second-section-recipe[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n}\n.recipe-detail-item[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  gap: 15px;\n}\n.recipe-detail-item[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  color: var(--brown);\n  font-weight: 600;\n  font-size: 26px;\n}\n\n.detail-list[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  z-index: 1000;\n}\n.recipe-detail-item[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n  margin-bottom: 10px;\n}\n.detail-text[_ngcontent-%COMP%] {\n  font-weight: 500;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hc3NldHMvY3NzL2xpc3QtY29tbW9uLmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFlBQVk7RUFDWixXQUFXO0VBQ1gsZ0JBQWdCO0VBQ2hCLGtCQUFrQjtFQUNsQixtQkFBbUI7RUFDbkIsZ0JBQWdCO0FBQ2xCO0FBQ0E7RUFDRSw2QkFBNkI7RUFDN0IsMkJBQTJCO0VBQzNCLGlCQUFpQjtBQUNuQjs7QUFFQTtFQUNFLFdBQVc7RUFDWCxhQUFhO0VBQ2Isb0JBQW9CO0FBQ3RCO0FBQ0E7RUFDRSxhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLHlCQUF5QjtFQUN6QixzQkFBc0I7RUFDdEIsbUJBQW1CO0VBQ25CLFNBQVM7RUFDVCxXQUFXO0FBQ2I7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsU0FBUztFQUNULG1CQUFtQjtFQUNuQix1QkFBdUI7RUFDdkIsV0FBVztFQUNYLGdCQUFnQjtBQUNsQjtBQUNBO0VBQ0UsWUFBWTtFQUNaLFVBQVU7RUFDVixhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLHVCQUF1QjtFQUN2QixTQUFTO0VBQ1QsbUJBQW1CO0FBQ3JCO0FBQ0E7RUFDRSxpQkFBaUI7RUFDakIsV0FBVztFQUNYLGFBQWE7RUFDYiw4Q0FBOEM7RUFDOUMsbUNBQW1DO0VBQ25DLHVCQUF1QjtFQUN2QixhQUFhO0VBQ2IsZ0JBQWdCO0FBQ2xCO0FBQ0E7RUFDRSxhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLFNBQVM7QUFDWDtBQUNBO0VBQ0UsV0FBVztFQUNYLFlBQVk7QUFDZDtBQUNBO0VBQ0UsV0FBVztFQUNYLGFBQWE7RUFDYix3Q0FBd0M7QUFDMUM7QUFDQTtFQUNFLFdBQVc7RUFDWCxhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLFNBQVM7QUFDWDtBQUNBO0VBQ0UsYUFBYTtFQUNiLHNCQUFzQjtFQUN0Qix1QkFBdUI7RUFDdkIsU0FBUztBQUNYO0FBQ0E7RUFDRSxtQkFBbUI7RUFDbkIsZ0JBQWdCO0VBQ2hCLGVBQWU7QUFDakI7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLFNBQVM7RUFDVCxhQUFhO0FBQ2Y7QUFDQTtFQUNFLG1CQUFtQjtBQUNyQjtBQUNBO0VBQ0UsZ0JBQWdCO0FBQ2xCIiwic291cmNlc0NvbnRlbnQiOlsiLnF1b3RlIHtcclxuICBtYXJnaW46IGF1dG87XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgbWF4LXdpZHRoOiAyMXJlbTtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgd2hpdGUtc3BhY2U6IG5vcm1hbDtcclxuICBsaW5lLWhlaWdodDogMS41O1xyXG59XHJcbi5xdW90ZSBoMyB7XHJcbiAgZm9udC1mYW1pbHk6IFwiRGFuY2luZyBTY3JpcHRcIjtcclxuICBjb2xvcjogdmFyKC0tcHJpbWFyeS1jb2xvcik7XHJcbiAgZm9udC1zaXplOiAxLjdyZW07XHJcbn1cclxuXHJcbi5wYWdpbmF0aW9uIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogZW5kO1xyXG59XHJcbi5yZWNpcGUtY29udGFpbmVyIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgcGFkZGluZzogMCA0MHB4IDQwcHggNDBweDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHN0YXJ0O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgZ2FwOiAyMHB4O1xyXG4gIHdpZHRoOiAxMDAlO1xyXG59XHJcblxyXG4uZmlyc3Qtc2VjdGlvbi1yZWNpcGUge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZ2FwOiAzMHB4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgbWFyZ2luLXRvcDogMTVweDtcclxufVxyXG4ucmVjaXBlLWRldGFpbHMge1xyXG4gIGhlaWdodDogMTAwJTtcclxuICB3aWR0aDogNjUlO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBnYXA6IDIwcHg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG4uZGV0YWlscy1ncmlkLWNvbnRhaW5lciB7XHJcbiAgcGFkZGluZy10b3A6IDEwcHg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgZGlzcGxheTogZ3JpZDtcclxuICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IHJlcGVhdChhdXRvLWZpdCwgMjEwcHgpO1xyXG4gIGdyaWQtdGVtcGxhdGUtcm93czogcmVwZWF0KDMsIDUwcHgpO1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIHJvdy1nYXA6IDEwcHg7XHJcbiAgY29sdW1uLWdhcDogMjBweDtcclxufVxyXG4uZGV0YWlsLWl0ZW0ge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBnYXA6IDEwcHg7XHJcbn1cclxuLmRldGFpbC1pdGVtIGltZyB7XHJcbiAgd2lkdGg6IDQwcHg7XHJcbiAgaGVpZ2h0OiA0MHB4O1xyXG59XHJcbi5zZXBhcmF0aW9uLWxpbmUge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMC41cHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tc2Vjb25kYXJ5LWNvbG9yKTtcclxufVxyXG4uc2Vjb25kLXNlY3Rpb24tcmVjaXBlIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgZ2FwOiAxMHB4O1xyXG59XHJcbi5yZWNpcGUtZGV0YWlsLWl0ZW0ge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBnYXA6IDE1cHg7XHJcbn1cclxuLnJlY2lwZS1kZXRhaWwtaXRlbSBoMiB7XHJcbiAgY29sb3I6IHZhcigtLWJyb3duKTtcclxuICBmb250LXdlaWdodDogNjAwO1xyXG4gIGZvbnQtc2l6ZTogMjZweDtcclxufVxyXG5cclxuLmRldGFpbC1saXN0IHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgZ2FwOiAxMHB4O1xyXG4gIHotaW5kZXg6IDEwMDA7XHJcbn1cclxuLnJlY2lwZS1kZXRhaWwtaXRlbSBsaSB7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcclxufVxyXG4uZGV0YWlsLXRleHQge1xyXG4gIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 7629:
/*!****************************************************************!*\
  !*** ./src/app/features/nutritionists/nutritionists.module.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   NutritionistsModule: () => (/* binding */ NutritionistsModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../shared/shared.module */ 3887);
/* harmony import */ var _nutritionists_list_nutritionists_list_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./nutritionists-list/nutritionists-list.component */ 3990);
/* harmony import */ var _nutritionist_item_nutritionist_item_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./nutritionist-item/nutritionist-item.component */ 2124);
/* harmony import */ var _core_core_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../core/core.module */ 8423);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7580);






class NutritionistsModule {
  static {
    this.ɵfac = function NutritionistsModule_Factory(t) {
      return new (t || NutritionistsModule)();
    };
  }
  static {
    this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineNgModule"]({
      type: NutritionistsModule
    });
  }
  static {
    this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule, _core_core_module__WEBPACK_IMPORTED_MODULE_3__.CoreModule]
    });
  }
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsetNgModuleScope"](NutritionistsModule, {
    declarations: [_nutritionists_list_nutritionists_list_component__WEBPACK_IMPORTED_MODULE_1__.NutritionistsListComponent, _nutritionist_item_nutritionist_item_component__WEBPACK_IMPORTED_MODULE_2__.NutritionistItemComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule, _core_core_module__WEBPACK_IMPORTED_MODULE_3__.CoreModule],
    exports: [_nutritionists_list_nutritionists_list_component__WEBPACK_IMPORTED_MODULE_1__.NutritionistsListComponent, _nutritionist_item_nutritionist_item_component__WEBPACK_IMPORTED_MODULE_2__.NutritionistItemComponent]
  });
})();

/***/ }),

/***/ 5490:
/*!*********************************************************!*\
  !*** ./src/app/features/planning/planning.component.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PlanningComponent: () => (/* binding */ PlanningComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 5072);
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ngx-toastr */ 4285);
/* harmony import */ var src_app_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/utils/functions.utils */ 3584);
/* harmony import */ var src_app_models_client_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/models/client.model */ 4477);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/auth.service */ 4796);
/* harmony import */ var src_app_services_planning_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/planning.service */ 6543);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/forms */ 4456);
/* harmony import */ var _shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../shared/components/button/button.component */ 8219);
/* harmony import */ var _shared_components_page_background_page_background_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../shared/components/page-background/page-background.component */ 1469);
/* harmony import */ var _shared_components_popup_popup_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../shared/components/popup/popup.component */ 4061);
/* harmony import */ var _core_pipes_get_initials_pipe__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../core/pipes/get-initials.pipe */ 7014);



// import { generateFakeNutritionist } from 'src/app/core/helpers/faker.helper';











function PlanningComponent_div_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const time_r6 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", time_r6, " ");
  }
}
function PlanningComponent_div_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const day_r7 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", day_r7, " ");
  }
}
function PlanningComponent_div_17_div_1_p_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](2, "getInitials");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const slot_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](2).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](2, 1, slot_r8.reservedBy), " ");
  }
}
function PlanningComponent_div_17_div_1_img_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](0, "img", 20);
  }
}
function PlanningComponent_div_17_div_1_img_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r20 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "img", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function PlanningComponent_div_17_div_1_img_3_Template_img_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r20);
      const index_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](2).index;
      const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵresetView"](ctx_r18.showReservationPopup(index_r9));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }
}
function PlanningComponent_div_17_div_1_img_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r23 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "img", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function PlanningComponent_div_17_div_1_img_4_Template_img_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r23);
      const index_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](2).index;
      const ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵresetView"](ctx_r21.showAddUnavailableSlotPopup(index_r9));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }
}
function PlanningComponent_div_17_div_1_img_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r26 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "img", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function PlanningComponent_div_17_div_1_img_5_Template_img_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r26);
      const index_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](2).index;
      const ctx_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵresetView"](ctx_r24.showCancelPopup(index_r9));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }
}
function PlanningComponent_div_17_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](1, PlanningComponent_div_17_div_1_p_1_Template, 3, 3, "p", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](2, PlanningComponent_div_17_div_1_img_2_Template, 1, 0, "img", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](3, PlanningComponent_div_17_div_1_img_3_Template, 1, 0, "img", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](4, PlanningComponent_div_17_div_1_img_4_Template, 1, 0, "img", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](5, PlanningComponent_div_17_div_1_img_5_Template, 1, 0, "img", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const slot_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]().$implicit;
    const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", slot_r8.isReservation);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", !slot_r8.isReservation && slot_r8.isReserved && ctx_r10.userRole == "Client");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", !slot_r8.isReserved && ctx_r10.userRole == "Client");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", !slot_r8.isReserved && ctx_r10.userRole == "Nutritionist");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", slot_r8.isReserved && (slot_r8.reservedBy == ctx_r10.clientUserName || ctx_r10.userRole == "Nutritionist"));
  }
}
function PlanningComponent_div_17_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](1, "img", 24)(2, "img", 25)(3, "img", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }
}
function PlanningComponent_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](1, PlanningComponent_div_17_div_1_Template, 6, 5, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](2, PlanningComponent_div_17_div_2_Template, 4, 0, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const slot_r8 = ctx.$implicit;
    const index_r9 = ctx.index;
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵstyleProp"]("background-color", slot_r8.color);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵclassProp"]("break-slot", index_r9 % 9 == 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", index_r9 % 9 != 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", index_r9 % 9 == 4);
  }
}
function PlanningComponent_app_popup_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r29 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "app-popup", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("popupClosed", function PlanningComponent_app_popup_19_Template_app_popup_popupClosed_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r29);
      const ctx_r28 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵresetView"](ctx_r28.isReservationPopupVisible = false);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](1, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](2, "app-button", 29)(3, "app-button", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("text", "Confirmer la prise de rendez-vous");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("text", "Confirmer")("onClick", ctx_r3.pickSlot);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("boxShadow", "0 4px 8px 2px #ffc5c5")("backgroundColor", "#df0404")("onClick", ctx_r3.closeReservationPopup)("text", "Annuler");
  }
}
function PlanningComponent_app_popup_20_Template(rf, ctx) {
  if (rf & 1) {
    const _r31 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "app-popup", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("popupClosed", function PlanningComponent_app_popup_20_Template_app_popup_popupClosed_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r31);
      const ctx_r30 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵresetView"](ctx_r30.isCancelPopupVisible = false);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](1, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](2, "app-button", 29)(3, "app-button", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("text", "Confirmer l'annulation");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("text", "Confirmer")("onClick", ctx_r4.cancelReservation);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("boxShadow", "0 4px 8px 2px #ffc5c5")("backgroundColor", "#df0404")("onClick", ctx_r4.closeCancelnPopup)("text", "Annuler");
  }
}
function PlanningComponent_app_popup_21_Template(rf, ctx) {
  if (rf & 1) {
    const _r33 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "app-popup", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("popupClosed", function PlanningComponent_app_popup_21_Template_app_popup_popupClosed_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r33);
      const ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵresetView"](ctx_r32.isUnavailablePopupVisible = false);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](1, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](2, "app-button", 29)(3, "app-button", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("text", "Confirmer la non disponibilit\u00E9");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("text", "Confirmer")("onClick", ctx_r5.pickSlot);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("boxShadow", "0 4px 8px 2px #ffc5c5")("backgroundColor", "#df0404")("onClick", ctx_r5.closeUnavailablePopup)("text", "Annuler");
  }
}
class PlanningComponent {
  constructor() {
    this.actRoute = (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.inject)(_angular_router__WEBPACK_IMPORTED_MODULE_9__.ActivatedRoute);
    this.nutritionistId = this.actRoute.snapshot.params['nutritionistId'];
    this.clientUserName = '';
    this.userRole = '';
    this.timeSlots = ['8:00', '9:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00'];
    this.reservedSlots = [];
    this.allSlots = [];
    this.morningTimeSlots = ['8:00', '9:00', '10:00', '11:00'];
    this.afternoonTimeSlots = ['13:00', '14:00', '15:00', '16:00'];
    this.workDaysOfWeek = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi'];
    // morningSlots: Slot[] = [];
    // afternoonSlots: Slot[] = [];
    this.toastr = (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.inject)(ngx_toastr__WEBPACK_IMPORTED_MODULE_10__.ToastrService);
    this.allDaysOfWeek = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];
    this.isReservationPopupVisible = false;
    this.isCancelPopupVisible = false;
    this.isUnavailablePopupVisible = false;
    this.selectedIndex = 0;
    this.isMorning = true;
    this.planningService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.inject)(src_app_services_planning_service__WEBPACK_IMPORTED_MODULE_3__.PlanningService);
    this.authService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.inject)(src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService);
    this.pickSlot = () => {
      let slot = this.allSlots[this.selectedIndex];
      let slotModelDto;
      if (slot && !slot.isReserved) {
        if (this.userRole == src_app_models_client_model__WEBPACK_IMPORTED_MODULE_1__.UserRoleEnum.CLIENT.toString()) {
          slotModelDto = {
            date: slot.date,
            day: slot.day,
            time: slot.time,
            isReservation: true,
            clientId: this.authService.getUserId(),
            nutritionistId: this.nutritionistId
          };
        } else {
          slotModelDto = {
            date: slot.date,
            day: slot.day,
            time: slot.time,
            isReservation: false,
            nutritionistId: this.nutritionistId
          };
        }
        this.planningService.addSlot(slotModelDto).subscribe({
          next: reservedSlot => {
            slot.reservedBy = reservedSlot.isReservation ? this.clientUserName : '';
            console.log(slot.reservedBy);
            slot.isReserved = true;
            slot.isReservation = true;
            const color = reservedSlot.isReservation ? this.getRandomCoolColor() : '#ff6b6b';
            slot.color = color;
            this.toastr.success('Slot Reserved Successfully');
            if (slotModelDto.isReservation) {
              this.closeReservationPopup();
            } else {
              this.closeUnavailablePopup();
            }
          },
          error: error => {
            this.toastr.error(src_app_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_0__.AppUtils.getErrorMessage(error), 'Error');
          }
        });
      }
    };
    this.cancelReservation = () => {
      // const slots = this.isMorning ? this.morningSlots : this.afternoonSlots;
      const slot = this.allSlots[this.selectedIndex];
      if (slot && slot.isReserved) {
        this.planningService.cancelSlotReservation(slot.id).subscribe({
          next: reservedSlot => {
            slot.isReserved = false;
            slot.isReservation = false;
            slot.reservedBy = '';
            slot.color = '#ebebeb';
            this.toastr.success('Slot Reservation Cancelled Successfully');
          },
          error: error => {
            this.toastr.error(src_app_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_0__.AppUtils.getErrorMessage(error), 'Error');
          }
        });
        this.closeCancelnPopup();
      }
    };
    // Method to show the popup
    this.showReservationPopup = index => {
      this.isReservationPopupVisible = true;
      this.selectedIndex = index;
    };
    // Method to show the popup
    this.showAddUnavailableSlotPopup = index => {
      this.isUnavailablePopupVisible = true;
      this.selectedIndex = index;
    };
    // Method to hide the popup
    this.closeReservationPopup = () => {
      this.isReservationPopupVisible = false;
    };
    // Method to show the popup
    this.showCancelPopup = index => {
      this.isCancelPopupVisible = true;
      this.selectedIndex = index;
    };
    // Method to hide the popup
    this.closeCancelnPopup = () => {
      this.isCancelPopupVisible = false;
    };
    this.closeUnavailablePopup = () => {
      this.isUnavailablePopupVisible = false;
    };
  }
  ngOnInit() {
    this.selectedDate = new Date();
    this.clientUserName = this.authService.getUserName();
    this.userRole = this.authService.getUserRole();
    this.planningService.getUnavailableSlotsByNutritionist(this.nutritionistId).subscribe({
      next: slots => {
        console.log('Raw slots:', slots);
        this.reservedSlots = slots.map(slot => {
          console.log('Mapping slot:', slot);
          return {
            id: slot.id ?? '',
            date: new Date(slot.date),
            day: slot.day,
            time: slot.time,
            isReservation: slot.isReservation,
            isReserved: true,
            reservedBy: slot.client ? slot.client?.name : '',
            color: '#FFAD80'
          };
        });
        console.log('Reserved slots:', this.reservedSlots);
        this.updateSlots(this.selectedDate.toISOString());
      },
      error: err => {
        console.error('Error fetching unavailable slots:', err);
      }
    });
  }
  updateSlots(selectedDate) {
    this.selectedDate = new Date(selectedDate);
    const currentDayIndex = this.selectedDate.getDay();
    console.log(currentDayIndex);
    const selectedDay = this.allDaysOfWeek[currentDayIndex];
    console.log(selectedDay);
    if (this.workDaysOfWeek.includes(selectedDay)) {
      const indexOfSelectedDay = this.workDaysOfWeek.indexOf(selectedDay);
      // this.afternoonSlots = this.generateSlots(
      //   this.afternoonTimeSlots,
      //   indexOfSelectedDay
      // );
      // this.morningSlots = this.generateSlots(
      //   this.morningTimeSlots,
      //   indexOfSelectedDay
      // );
      this.allSlots = this.generateSlots([...this.morningTimeSlots, '12:00', ...this.afternoonTimeSlots], indexOfSelectedDay);
    } else {
      console.log('jawna ahah');
      this.toastr.error('Weekends Are Off');
    }
  }
  generateSlots(timeSlots, indexOfSelectedDay) {
    return new Array(timeSlots.length * this.workDaysOfWeek.length).fill(null).map((_, index) => {
      const dayIndex = Math.floor(index / timeSlots.length);
      const difference = dayIndex - indexOfSelectedDay;
      const selectedDate = new Date(this.selectedDate);
      const date = new Date(selectedDate.setDate(selectedDate.getDate() + difference));
      const reservedSlot = this.reservedSlots.find(slot => slot.date?.toDateString() === date.toDateString() && slot.time === timeSlots[index % timeSlots.length]);
      const reservedBy = reservedSlot?.reservedBy ?? '';
      const id = reservedSlot?.id ?? '';
      console.log('Reserved Slots', this.reservedSlots);
      console.log('hola', reservedSlot?.isReserved);
      return {
        id: id,
        date: date,
        day: this.workDaysOfWeek[dayIndex],
        time: timeSlots[index % timeSlots.length],
        isReservation: reservedSlot?.isReservation ?? false,
        isReserved: reservedSlot?.isReserved ?? false,
        reservedBy: reservedBy,
        color: reservedSlot?.isReservation ? this.getRandomCoolColor() : reservedSlot?.isReserved ? '#ff6b6b' : '#ebebeb'
      };
    });
  }
  getRandomCoolColor() {
    // index: number, isMorning: boolean
    const pickedSlotColors = ['#FFAD80', '#6FF9AA', '#F7EE6E', '#FEE8AD', '#94C6FC'];
    // const neighboursColors = this.getNeighbourColors();
    var randomIndex = 0;
    // while (neighboursColors.includes(pickedSlotColors[randomIndex])) {
    randomIndex = Math.floor(Math.random() * pickedSlotColors.length);
    // }
    // Return the color in rgb format
    return pickedSlotColors[randomIndex];
  }
  getNeighbourColors() {
    var neighboursColors = [];
    if (this.allSlots[this.selectedIndex - 1].color !== '#ebebeb' && this.selectedIndex % 9 != 5 && this.selectedIndex % 5 != 0) {
      neighboursColors.push(this.allSlots[this.selectedIndex - 1].color);
    }
    if (this.allSlots[this.selectedIndex + 1].color !== '#ebebeb' && (this.selectedIndex + 1) % 9 != 4 && this.selectedIndex % 9 != 8) {
      neighboursColors.push(this.allSlots[this.selectedIndex + 1].color);
    }
    if (this.allSlots[this.selectedIndex + 9].color !== '#ebebeb' && this.selectedIndex + 9 < this.allSlots.length) neighboursColors.push(this.allSlots[this.selectedIndex + 9].color);
    if (this.allSlots[this.selectedIndex - 9].color !== '#ebebeb' && this.selectedIndex - 9 >= 0) neighboursColors.push(this.allSlots[this.selectedIndex - 9].color);
    return neighboursColors;
  }
  static {
    this.ɵfac = function PlanningComponent_Factory(t) {
      return new (t || PlanningComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineComponent"]({
      type: PlanningComponent,
      selectors: [["app-planning"]],
      decls: 22,
      vars: 7,
      consts: [[1, "quote"], ["id", "date-input", "type", "date", "ngModel", "", 1, "date-input", 3, "ngModel", "ngModelChange"], [1, "planning"], [1, "times-days-slot"], [1, "slot"], ["id", "days"], ["id", "slots"], [1, "horiz-header"], ["class", "slot header-slot", 4, "ngFor", "ngForOf"], [1, "vert-header"], [1, "content"], ["class", "slot", 3, "break-slot", "backgroundColor", 4, "ngFor", "ngForOf"], [1, "modal"], [3, "text", "popupClosed", 4, "ngIf"], [1, "slot", "header-slot"], [4, "ngIf"], ["src", "assets/images/unavailable.png", "width", "30px", "height", "30px", "alt", "appointment", 4, "ngIf"], ["src", "assets/images/medical-appointment.svg", "width", "30px", "height", "30px", "alt", "appointment", 3, "click", 4, "ngIf"], ["src", "assets/images/unavailable.png", "width", "30px", "height", "30px", "alt", "appointment", 3, "click", 4, "ngIf"], ["src", "assets/images/cancel.png", "width", "30px", "height", "30px", "alt", "appointment", 3, "click", 4, "ngIf"], ["src", "assets/images/unavailable.png", "width", "30px", "height", "30px", "alt", "appointment"], ["src", "assets/images/medical-appointment.svg", "width", "30px", "height", "30px", "alt", "appointment", 3, "click"], ["src", "assets/images/unavailable.png", "width", "30px", "height", "30px", "alt", "appointment", 3, "click"], ["src", "assets/images/cancel.png", "width", "30px", "height", "30px", "alt", "appointment", 3, "click"], ["src", "assets/images/break-time-man.svg", "height", "100px", "alt", ""], ["src", "assets/images/break-time.svg", "alt", ""], ["src", "assets/images/break-time-man.svg", "alt", ""], [3, "text", "popupClosed"], [2, "display", "flex", "gap", "10px"], [3, "text", "onClick"], [3, "boxShadow", "backgroundColor", "onClick", "text"]],
      template: function PlanningComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "app-page-background")(1, "div", 0)(2, "h3");
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](3, "Un nutritionniste, votre alli\u00E9 pour une sant\u00E9 \u00E9quilibr\u00E9e et durable");
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](4, "input", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("ngModelChange", function PlanningComponent_Template_input_ngModelChange_4_listener($event) {
            return ctx.selectedDate.toISOString().split("T")[0] = $event;
          })("ngModelChange", function PlanningComponent_Template_input_ngModelChange_4_listener($event) {
            return ctx.updateSlots($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](5, "div", 2)(6, "div", 3)(7, "div", 4)(8, "p", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](9, "Days");
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](10, "p", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](11, "Slots");
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](12, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](13, PlanningComponent_div_13_Template, 2, 1, "div", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](14, "div", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](15, PlanningComponent_div_15_Template, 2, 1, "div", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](16, "div", 10);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](17, PlanningComponent_div_17_Template, 3, 6, "div", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](18, "div", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](19, PlanningComponent_app_popup_19_Template, 4, 7, "app-popup", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](20, PlanningComponent_app_popup_20_Template, 4, 7, "app-popup", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](21, PlanningComponent_app_popup_21_Template, 4, 7, "app-popup", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngModel", ctx.selectedDate.toISOString().split("T")[0]);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](9);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngForOf", ctx.timeSlots);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngForOf", ctx.workDaysOfWeek);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngForOf", ctx.allSlots);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.isReservationPopupVisible);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.isCancelPopupVisible);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.isUnavailablePopupVisible);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_11__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_11__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.NgModel, _shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_4__.ButtonComponent, _shared_components_page_background_page_background_component__WEBPACK_IMPORTED_MODULE_5__.PageBackgroundComponent, _shared_components_popup_popup_component__WEBPACK_IMPORTED_MODULE_6__.PopupComponent, _core_pipes_get_initials_pipe__WEBPACK_IMPORTED_MODULE_7__.GetInitialsPipe],
      styles: [".modal[_ngcontent-%COMP%] {\n  position: relative;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n  z-index: 2000000;\n}\n\n\n\n.modal-content[_ngcontent-%COMP%] {\n  position: fixed;\n  top: 0;\n  left: 50%;\n  transform: translate(-50%, 0);\n  background-color: white;\n  padding: 20px 40px 20px 20px;\n  border-radius: 12px;\n  width: clamp(auto, 50vw, 90vw);\n  box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);\n  z-index: 10000;\n  display: flex;\n  flex-direction: column;\n  gap: 20px;\n}\n\n\n\n.close-btn[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 10px;\n  right: 10px;\n  background: none;\n  border: none;\n  font-size: 24px;\n  cursor: pointer;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hc3NldHMvY3NzL3BvcHVwLmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGtCQUFrQjtFQUNsQixNQUFNO0VBQ04sT0FBTztFQUNQLFdBQVc7RUFDWCxZQUFZO0VBQ1osZ0JBQWdCO0FBQ2xCOztBQUVBLGtCQUFrQjtBQUNsQjtFQUNFLGVBQWU7RUFDZixNQUFNO0VBQ04sU0FBUztFQUNULDZCQUE2QjtFQUM3Qix1QkFBdUI7RUFDdkIsNEJBQTRCO0VBQzVCLG1CQUFtQjtFQUNuQiw4QkFBOEI7RUFDOUIsMkNBQTJDO0VBQzNDLGNBQWM7RUFDZCxhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLFNBQVM7QUFDWDs7QUFFQSxpQkFBaUI7QUFDakI7RUFDRSxrQkFBa0I7RUFDbEIsU0FBUztFQUNULFdBQVc7RUFDWCxnQkFBZ0I7RUFDaEIsWUFBWTtFQUNaLGVBQWU7RUFDZixlQUFlO0FBQ2pCIiwic291cmNlc0NvbnRlbnQiOlsiLm1vZGFsIHtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgdG9wOiAwO1xyXG4gIGxlZnQ6IDA7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIHotaW5kZXg6IDIwMDAwMDA7XHJcbn1cclxuXHJcbi8qIFBvcHVwIGNvbnRlbnQgKi9cclxuLm1vZGFsLWNvbnRlbnQge1xyXG4gIHBvc2l0aW9uOiBmaXhlZDtcclxuICB0b3A6IDA7XHJcbiAgbGVmdDogNTAlO1xyXG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIDApO1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG4gIHBhZGRpbmc6IDIwcHggNDBweCAyMHB4IDIwcHg7XHJcbiAgYm9yZGVyLXJhZGl1czogMTJweDtcclxuICB3aWR0aDogY2xhbXAoYXV0bywgNTB2dywgOTB2dyk7XHJcbiAgYm94LXNoYWRvdzogMHB4IDRweCAxMHB4IHJnYmEoMCwgMCwgMCwgMC4yKTtcclxuICB6LWluZGV4OiAxMDAwMDtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgZ2FwOiAyMHB4O1xyXG59XHJcblxyXG4vKiBDbG9zZSBidXR0b24gKi9cclxuLmNsb3NlLWJ0biB7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHRvcDogMTBweDtcclxuICByaWdodDogMTBweDtcclxuICBiYWNrZ3JvdW5kOiBub25lO1xyXG4gIGJvcmRlcjogbm9uZTtcclxuICBmb250LXNpemU6IDI0cHg7XHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0= */", ".planning[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  position: relative;\n  display: grid;\n  grid-template-columns: repeat(10, minmax(50px, 1fr));\n  grid-template-rows: repeat(6, minmax(70px, 1fr));\n  grid-template-areas:\n    \"times-days horiz-header horiz-header horiz-header horiz-header horiz-header horiz-header horiz-header horiz-header horiz-header \"\n    \"vert-header slot slot slot slot slot slot slot slot slot\"\n    \"vert-header slot slot slot slot slot slot slot slot slot\"\n    \"vert-header slot slot slot slot slot slot slot slot slot\"\n    \"vert-header slot slot slot slot slot slot slot slot slot\"\n    \"vert-header slot slot slot slot slot slot slot slot slot\";\n\n  justify-content: center;\n  gap: 7px;\n}\n.slot.break-slot[_ngcontent-%COMP%] {\n  grid-column: 5 / 6; \n\n  grid-row: 1 / 6; \n\n  display: flex;\n  flex-direction: column;\n}\n.slot[_ngcontent-%COMP%] {\n  background-color: #ebebeb;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  font-size: clamp(10px, 1.5vw, 16px);\n}\n\n.horiz-header[_ngcontent-%COMP%] {\n  display: flex;\n  grid-area: horiz-header;\n  gap: 7px;\n}\n.horiz-header[_ngcontent-%COMP%]    > *[_ngcontent-%COMP%] {\n  flex: 1 1 70px;\n}\n\n.morning-content[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(4, minmax(50px, 1fr));\n  grid-template-rows: repeat(5, minmax(70px, 1fr));\n  gap: 7px;\n  grid-area: mslot;\n}\n.content[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(9, minmax(50px, 1fr));\n  grid-template-rows: repeat(5, minmax(70px, 1fr));\n  gap: 7px;\n  grid-area: slot;\n}\n.afternoon-content[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(4, minmax(50px, 1fr));\n  grid-template-rows: repeat(5, minmax(70px, 1fr));\n  gap: 7px;\n  grid-area: aslot;\n}\n\n.vert-header[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  grid-area: vert-header;\n  gap: 7px;\n}\n\n.vert-header[_ngcontent-%COMP%]    > *[_ngcontent-%COMP%] {\n  flex: 1 1 70px;\n}\n.times-days-slot[_ngcontent-%COMP%] {\n  background-color: #cbea7b;\n\n  grid-area: times-days;\n  position: relative;\n}\n.times-days-slot[_ngcontent-%COMP%]   #days[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 10%;\n  top: 10%;\n}\n.times-days-slot[_ngcontent-%COMP%]   #slots[_ngcontent-%COMP%] {\n  position: absolute;\n  left: 5%;\n  bottom: 10%;\n}\n.times-days-slot[_ngcontent-%COMP%]:after {\n  content: \"\";\n  width: 100%;\n  height: 100%;\n  position: absolute;\n  top: 0;\n  left: 0;\n\n  background: linear-gradient(\n    to right top,\n    transparent calc(50% - 1px),\n    black calc(50% - 1px) 50%,\n    transparent 50%\n  );\n}\n.break-slot[_ngcontent-%COMP%]   div[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  display: flex;\n  flex-direction: column;\n}\n.break-slot[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  height: 100%;\n  object-fit: cover;\n}\n.header-slot[_ngcontent-%COMP%] {\n  background-color: #cbea7b;\n}\n\n.slot[_ngcontent-%COMP%]:not(.break-slot)   img[_ngcontent-%COMP%] {\n  opacity: 0;\n  display: none;\n  transition: opacity, display 0.3s ease; \n\n}\n\n\n\n.slot[_ngcontent-%COMP%]:hover:not(.header-slot):not(.break-slot)   img[_ngcontent-%COMP%] {\n  display: block;\n  opacity: 1;\n}\n\n\n.slot[_ngcontent-%COMP%]:hover:not(.header-slot):not(.break):not(.break-slot)   p[_ngcontent-%COMP%] {\n  display: none;\n}\n\n.date-input[_ngcontent-%COMP%] {\n  width: 200px;\n  padding: 8px 40px 8px 12px;\n  font-size: clamp(9px, 14px, 1.4vw);\n  color: var(--primary-color);\n  border: 1px solid transparent;\n  border-radius: 25px;\n  background: linear-gradient(white, white) padding-box,\n    linear-gradient(90deg, var(--primary-color), var(--secondary-color))\n      border-box;\n  outline: none;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvZmVhdHVyZXMvcGxhbm5pbmcvcGxhbm5pbmcuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFdBQVc7RUFDWCxZQUFZO0VBQ1osa0JBQWtCO0VBQ2xCLGFBQWE7RUFDYixvREFBb0Q7RUFDcEQsZ0RBQWdEO0VBQ2hEOzs7Ozs7OERBTTREOztFQUU1RCx1QkFBdUI7RUFDdkIsUUFBUTtBQUNWO0FBQ0E7RUFDRSxrQkFBa0IsRUFBRSw4Q0FBOEM7RUFDbEUsZUFBZSxFQUFFLDhDQUE4QztFQUMvRCxhQUFhO0VBQ2Isc0JBQXNCO0FBQ3hCO0FBQ0E7RUFDRSx5QkFBeUI7RUFDekIsYUFBYTtFQUNiLHVCQUF1QjtFQUN2QixtQkFBbUI7RUFDbkIsbUNBQW1DO0FBQ3JDOztBQUVBO0VBQ0UsYUFBYTtFQUNiLHVCQUF1QjtFQUN2QixRQUFRO0FBQ1Y7QUFDQTtFQUNFLGNBQWM7QUFDaEI7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsbURBQW1EO0VBQ25ELGdEQUFnRDtFQUNoRCxRQUFRO0VBQ1IsZ0JBQWdCO0FBQ2xCO0FBQ0E7RUFDRSxhQUFhO0VBQ2IsbURBQW1EO0VBQ25ELGdEQUFnRDtFQUNoRCxRQUFRO0VBQ1IsZUFBZTtBQUNqQjtBQUNBO0VBQ0UsYUFBYTtFQUNiLG1EQUFtRDtFQUNuRCxnREFBZ0Q7RUFDaEQsUUFBUTtFQUNSLGdCQUFnQjtBQUNsQjs7QUFFQTtFQUNFLGFBQWE7RUFDYixzQkFBc0I7RUFDdEIsc0JBQXNCO0VBQ3RCLFFBQVE7QUFDVjs7QUFFQTtFQUNFLGNBQWM7QUFDaEI7QUFDQTtFQUNFLHlCQUF5Qjs7RUFFekIscUJBQXFCO0VBQ3JCLGtCQUFrQjtBQUNwQjtBQUNBO0VBQ0Usa0JBQWtCO0VBQ2xCLFVBQVU7RUFDVixRQUFRO0FBQ1Y7QUFDQTtFQUNFLGtCQUFrQjtFQUNsQixRQUFRO0VBQ1IsV0FBVztBQUNiO0FBQ0E7RUFDRSxXQUFXO0VBQ1gsV0FBVztFQUNYLFlBQVk7RUFDWixrQkFBa0I7RUFDbEIsTUFBTTtFQUNOLE9BQU87O0VBRVA7Ozs7O0dBS0M7QUFDSDtBQUNBO0VBQ0UsV0FBVztFQUNYLFlBQVk7RUFDWixhQUFhO0VBQ2Isc0JBQXNCO0FBQ3hCO0FBQ0E7RUFDRSxZQUFZO0VBQ1osaUJBQWlCO0FBQ25CO0FBQ0E7RUFDRSx5QkFBeUI7QUFDM0I7O0FBRUE7RUFDRSxVQUFVO0VBQ1YsYUFBYTtFQUNiLHNDQUFzQyxFQUFFLDBCQUEwQjtBQUNwRTs7QUFFQSw0QkFBNEI7QUFDNUI7RUFDRSxjQUFjO0VBQ2QsVUFBVTtBQUNaO0FBQ0EsNEJBQTRCO0FBQzVCO0VBQ0UsYUFBYTtBQUNmOztBQUVBO0VBQ0UsWUFBWTtFQUNaLDBCQUEwQjtFQUMxQixrQ0FBa0M7RUFDbEMsMkJBQTJCO0VBQzNCLDZCQUE2QjtFQUM3QixtQkFBbUI7RUFDbkI7O2dCQUVjO0VBQ2QsYUFBYTtBQUNmIiwic291cmNlc0NvbnRlbnQiOlsiLnBsYW5uaW5nIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIGRpc3BsYXk6IGdyaWQ7XHJcbiAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiByZXBlYXQoMTAsIG1pbm1heCg1MHB4LCAxZnIpKTtcclxuICBncmlkLXRlbXBsYXRlLXJvd3M6IHJlcGVhdCg2LCBtaW5tYXgoNzBweCwgMWZyKSk7XHJcbiAgZ3JpZC10ZW1wbGF0ZS1hcmVhczpcclxuICAgIFwidGltZXMtZGF5cyBob3Jpei1oZWFkZXIgaG9yaXotaGVhZGVyIGhvcml6LWhlYWRlciBob3Jpei1oZWFkZXIgaG9yaXotaGVhZGVyIGhvcml6LWhlYWRlciBob3Jpei1oZWFkZXIgaG9yaXotaGVhZGVyIGhvcml6LWhlYWRlciBcIlxyXG4gICAgXCJ2ZXJ0LWhlYWRlciBzbG90IHNsb3Qgc2xvdCBzbG90IHNsb3Qgc2xvdCBzbG90IHNsb3Qgc2xvdFwiXHJcbiAgICBcInZlcnQtaGVhZGVyIHNsb3Qgc2xvdCBzbG90IHNsb3Qgc2xvdCBzbG90IHNsb3Qgc2xvdCBzbG90XCJcclxuICAgIFwidmVydC1oZWFkZXIgc2xvdCBzbG90IHNsb3Qgc2xvdCBzbG90IHNsb3Qgc2xvdCBzbG90IHNsb3RcIlxyXG4gICAgXCJ2ZXJ0LWhlYWRlciBzbG90IHNsb3Qgc2xvdCBzbG90IHNsb3Qgc2xvdCBzbG90IHNsb3Qgc2xvdFwiXHJcbiAgICBcInZlcnQtaGVhZGVyIHNsb3Qgc2xvdCBzbG90IHNsb3Qgc2xvdCBzbG90IHNsb3Qgc2xvdCBzbG90XCI7XHJcblxyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGdhcDogN3B4O1xyXG59XHJcbi5zbG90LmJyZWFrLXNsb3Qge1xyXG4gIGdyaWQtY29sdW1uOiA1IC8gNjsgLyogRXhwYW5kIHRoZSBmaWZ0aCBzbG90IHRvIHNwYW4gdHdvIGNvbHVtbnMgKi9cclxuICBncmlkLXJvdzogMSAvIDY7IC8qIEV4cGFuZCB0aGUgZmlmdGggc2xvdCB0byBzcGFuIHR3byBjb2x1bW5zICovXHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG59XHJcbi5zbG90IHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZWJlYmViO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBmb250LXNpemU6IGNsYW1wKDEwcHgsIDEuNXZ3LCAxNnB4KTtcclxufVxyXG5cclxuLmhvcml6LWhlYWRlciB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBncmlkLWFyZWE6IGhvcml6LWhlYWRlcjtcclxuICBnYXA6IDdweDtcclxufVxyXG4uaG9yaXotaGVhZGVyID4gKiB7XHJcbiAgZmxleDogMSAxIDcwcHg7XHJcbn1cclxuXHJcbi5tb3JuaW5nLWNvbnRlbnQge1xyXG4gIGRpc3BsYXk6IGdyaWQ7XHJcbiAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiByZXBlYXQoNCwgbWlubWF4KDUwcHgsIDFmcikpO1xyXG4gIGdyaWQtdGVtcGxhdGUtcm93czogcmVwZWF0KDUsIG1pbm1heCg3MHB4LCAxZnIpKTtcclxuICBnYXA6IDdweDtcclxuICBncmlkLWFyZWE6IG1zbG90O1xyXG59XHJcbi5jb250ZW50IHtcclxuICBkaXNwbGF5OiBncmlkO1xyXG4gIGdyaWQtdGVtcGxhdGUtY29sdW1uczogcmVwZWF0KDksIG1pbm1heCg1MHB4LCAxZnIpKTtcclxuICBncmlkLXRlbXBsYXRlLXJvd3M6IHJlcGVhdCg1LCBtaW5tYXgoNzBweCwgMWZyKSk7XHJcbiAgZ2FwOiA3cHg7XHJcbiAgZ3JpZC1hcmVhOiBzbG90O1xyXG59XHJcbi5hZnRlcm5vb24tY29udGVudCB7XHJcbiAgZGlzcGxheTogZ3JpZDtcclxuICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IHJlcGVhdCg0LCBtaW5tYXgoNTBweCwgMWZyKSk7XHJcbiAgZ3JpZC10ZW1wbGF0ZS1yb3dzOiByZXBlYXQoNSwgbWlubWF4KDcwcHgsIDFmcikpO1xyXG4gIGdhcDogN3B4O1xyXG4gIGdyaWQtYXJlYTogYXNsb3Q7XHJcbn1cclxuXHJcbi52ZXJ0LWhlYWRlciB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gIGdyaWQtYXJlYTogdmVydC1oZWFkZXI7XHJcbiAgZ2FwOiA3cHg7XHJcbn1cclxuXHJcbi52ZXJ0LWhlYWRlciA+ICoge1xyXG4gIGZsZXg6IDEgMSA3MHB4O1xyXG59XHJcbi50aW1lcy1kYXlzLXNsb3Qge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNjYmVhN2I7XHJcblxyXG4gIGdyaWQtYXJlYTogdGltZXMtZGF5cztcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbn1cclxuLnRpbWVzLWRheXMtc2xvdCAjZGF5cyB7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHJpZ2h0OiAxMCU7XHJcbiAgdG9wOiAxMCU7XHJcbn1cclxuLnRpbWVzLWRheXMtc2xvdCAjc2xvdHMge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICBsZWZ0OiA1JTtcclxuICBib3R0b206IDEwJTtcclxufVxyXG4udGltZXMtZGF5cy1zbG90OmFmdGVyIHtcclxuICBjb250ZW50OiBcIlwiO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMTAwJTtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiAwO1xyXG4gIGxlZnQ6IDA7XHJcblxyXG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudChcclxuICAgIHRvIHJpZ2h0IHRvcCxcclxuICAgIHRyYW5zcGFyZW50IGNhbGMoNTAlIC0gMXB4KSxcclxuICAgIGJsYWNrIGNhbGMoNTAlIC0gMXB4KSA1MCUsXHJcbiAgICB0cmFuc3BhcmVudCA1MCVcclxuICApO1xyXG59XHJcbi5icmVhay1zbG90IGRpdiB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxufVxyXG4uYnJlYWstc2xvdCBpbWcge1xyXG4gIGhlaWdodDogMTAwJTtcclxuICBvYmplY3QtZml0OiBjb3ZlcjtcclxufVxyXG4uaGVhZGVyLXNsb3Qge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNjYmVhN2I7XHJcbn1cclxuXHJcbi5zbG90Om5vdCguYnJlYWstc2xvdCkgaW1nIHtcclxuICBvcGFjaXR5OiAwO1xyXG4gIGRpc3BsYXk6IG5vbmU7XHJcbiAgdHJhbnNpdGlvbjogb3BhY2l0eSwgZGlzcGxheSAwLjNzIGVhc2U7IC8qIFNtb290aCBmYWRlLWluIGVmZmVjdCAqL1xyXG59XHJcblxyXG4vKiBTaG93IHRoZSBpbWFnZSBvbiBob3ZlciAqL1xyXG4uc2xvdDpob3Zlcjpub3QoLmhlYWRlci1zbG90KTpub3QoLmJyZWFrLXNsb3QpIGltZyB7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgb3BhY2l0eTogMTtcclxufVxyXG4vKiBTaG93IHRoZSBpbWFnZSBvbiBob3ZlciAqL1xyXG4uc2xvdDpob3Zlcjpub3QoLmhlYWRlci1zbG90KTpub3QoLmJyZWFrKTpub3QoLmJyZWFrLXNsb3QpIHAge1xyXG4gIGRpc3BsYXk6IG5vbmU7XHJcbn1cclxuXHJcbi5kYXRlLWlucHV0IHtcclxuICB3aWR0aDogMjAwcHg7XHJcbiAgcGFkZGluZzogOHB4IDQwcHggOHB4IDEycHg7XHJcbiAgZm9udC1zaXplOiBjbGFtcCg5cHgsIDE0cHgsIDEuNHZ3KTtcclxuICBjb2xvcjogdmFyKC0tcHJpbWFyeS1jb2xvcik7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgdHJhbnNwYXJlbnQ7XHJcbiAgYm9yZGVyLXJhZGl1czogMjVweDtcclxuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQod2hpdGUsIHdoaXRlKSBwYWRkaW5nLWJveCxcclxuICAgIGxpbmVhci1ncmFkaWVudCg5MGRlZywgdmFyKC0tcHJpbWFyeS1jb2xvciksIHZhcigtLXNlY29uZGFyeS1jb2xvcikpXHJcbiAgICAgIGJvcmRlci1ib3g7XHJcbiAgb3V0bGluZTogbm9uZTtcclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */", ".quote[_ngcontent-%COMP%] {\n  margin: auto;\n  width: 100%;\n  max-width: 21rem;\n  text-align: center;\n  white-space: normal;\n  line-height: 1.5;\n}\n.quote[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  font-family: \"Dancing Script\";\n  color: var(--primary-color);\n  font-size: 1.7rem;\n}\n\n.pagination[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n  justify-content: end;\n}\n.recipe-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  padding: 0 40px 40px 40px;\n  justify-content: start;\n  align-items: center;\n  gap: 20px;\n  width: 100%;\n}\n\n.first-section-recipe[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 30px;\n  align-items: center;\n  justify-content: center;\n  width: 100%;\n  margin-top: 15px;\n}\n.recipe-details[_ngcontent-%COMP%] {\n  height: 100%;\n  width: 65%;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  gap: 20px;\n  align-items: center;\n}\n.details-grid-container[_ngcontent-%COMP%] {\n  padding-top: 10px;\n  width: 100%;\n  display: grid;\n  grid-template-columns: repeat(auto-fit, 210px);\n  grid-template-rows: repeat(3, 50px);\n  justify-content: center;\n  row-gap: 10px;\n  column-gap: 20px;\n}\n.detail-item[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n}\n.detail-item[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 40px;\n  height: 40px;\n}\n.separation-line[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 0.5px;\n  background-color: var(--secondary-color);\n}\n.second-section-recipe[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n}\n.recipe-detail-item[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  gap: 15px;\n}\n.recipe-detail-item[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  color: var(--brown);\n  font-weight: 600;\n  font-size: 26px;\n}\n\n.detail-list[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  z-index: 1000;\n}\n.recipe-detail-item[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n  margin-bottom: 10px;\n}\n.detail-text[_ngcontent-%COMP%] {\n  font-weight: 500;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hc3NldHMvY3NzL2xpc3QtY29tbW9uLmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFlBQVk7RUFDWixXQUFXO0VBQ1gsZ0JBQWdCO0VBQ2hCLGtCQUFrQjtFQUNsQixtQkFBbUI7RUFDbkIsZ0JBQWdCO0FBQ2xCO0FBQ0E7RUFDRSw2QkFBNkI7RUFDN0IsMkJBQTJCO0VBQzNCLGlCQUFpQjtBQUNuQjs7QUFFQTtFQUNFLFdBQVc7RUFDWCxhQUFhO0VBQ2Isb0JBQW9CO0FBQ3RCO0FBQ0E7RUFDRSxhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLHlCQUF5QjtFQUN6QixzQkFBc0I7RUFDdEIsbUJBQW1CO0VBQ25CLFNBQVM7RUFDVCxXQUFXO0FBQ2I7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsU0FBUztFQUNULG1CQUFtQjtFQUNuQix1QkFBdUI7RUFDdkIsV0FBVztFQUNYLGdCQUFnQjtBQUNsQjtBQUNBO0VBQ0UsWUFBWTtFQUNaLFVBQVU7RUFDVixhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLHVCQUF1QjtFQUN2QixTQUFTO0VBQ1QsbUJBQW1CO0FBQ3JCO0FBQ0E7RUFDRSxpQkFBaUI7RUFDakIsV0FBVztFQUNYLGFBQWE7RUFDYiw4Q0FBOEM7RUFDOUMsbUNBQW1DO0VBQ25DLHVCQUF1QjtFQUN2QixhQUFhO0VBQ2IsZ0JBQWdCO0FBQ2xCO0FBQ0E7RUFDRSxhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLFNBQVM7QUFDWDtBQUNBO0VBQ0UsV0FBVztFQUNYLFlBQVk7QUFDZDtBQUNBO0VBQ0UsV0FBVztFQUNYLGFBQWE7RUFDYix3Q0FBd0M7QUFDMUM7QUFDQTtFQUNFLFdBQVc7RUFDWCxhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLFNBQVM7QUFDWDtBQUNBO0VBQ0UsYUFBYTtFQUNiLHNCQUFzQjtFQUN0Qix1QkFBdUI7RUFDdkIsU0FBUztBQUNYO0FBQ0E7RUFDRSxtQkFBbUI7RUFDbkIsZ0JBQWdCO0VBQ2hCLGVBQWU7QUFDakI7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLFNBQVM7RUFDVCxhQUFhO0FBQ2Y7QUFDQTtFQUNFLG1CQUFtQjtBQUNyQjtBQUNBO0VBQ0UsZ0JBQWdCO0FBQ2xCIiwic291cmNlc0NvbnRlbnQiOlsiLnF1b3RlIHtcclxuICBtYXJnaW46IGF1dG87XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgbWF4LXdpZHRoOiAyMXJlbTtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgd2hpdGUtc3BhY2U6IG5vcm1hbDtcclxuICBsaW5lLWhlaWdodDogMS41O1xyXG59XHJcbi5xdW90ZSBoMyB7XHJcbiAgZm9udC1mYW1pbHk6IFwiRGFuY2luZyBTY3JpcHRcIjtcclxuICBjb2xvcjogdmFyKC0tcHJpbWFyeS1jb2xvcik7XHJcbiAgZm9udC1zaXplOiAxLjdyZW07XHJcbn1cclxuXHJcbi5wYWdpbmF0aW9uIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogZW5kO1xyXG59XHJcbi5yZWNpcGUtY29udGFpbmVyIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgcGFkZGluZzogMCA0MHB4IDQwcHggNDBweDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHN0YXJ0O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgZ2FwOiAyMHB4O1xyXG4gIHdpZHRoOiAxMDAlO1xyXG59XHJcblxyXG4uZmlyc3Qtc2VjdGlvbi1yZWNpcGUge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZ2FwOiAzMHB4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgbWFyZ2luLXRvcDogMTVweDtcclxufVxyXG4ucmVjaXBlLWRldGFpbHMge1xyXG4gIGhlaWdodDogMTAwJTtcclxuICB3aWR0aDogNjUlO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBnYXA6IDIwcHg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG4uZGV0YWlscy1ncmlkLWNvbnRhaW5lciB7XHJcbiAgcGFkZGluZy10b3A6IDEwcHg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgZGlzcGxheTogZ3JpZDtcclxuICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IHJlcGVhdChhdXRvLWZpdCwgMjEwcHgpO1xyXG4gIGdyaWQtdGVtcGxhdGUtcm93czogcmVwZWF0KDMsIDUwcHgpO1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIHJvdy1nYXA6IDEwcHg7XHJcbiAgY29sdW1uLWdhcDogMjBweDtcclxufVxyXG4uZGV0YWlsLWl0ZW0ge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBnYXA6IDEwcHg7XHJcbn1cclxuLmRldGFpbC1pdGVtIGltZyB7XHJcbiAgd2lkdGg6IDQwcHg7XHJcbiAgaGVpZ2h0OiA0MHB4O1xyXG59XHJcbi5zZXBhcmF0aW9uLWxpbmUge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMC41cHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tc2Vjb25kYXJ5LWNvbG9yKTtcclxufVxyXG4uc2Vjb25kLXNlY3Rpb24tcmVjaXBlIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgZ2FwOiAxMHB4O1xyXG59XHJcbi5yZWNpcGUtZGV0YWlsLWl0ZW0ge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBnYXA6IDE1cHg7XHJcbn1cclxuLnJlY2lwZS1kZXRhaWwtaXRlbSBoMiB7XHJcbiAgY29sb3I6IHZhcigtLWJyb3duKTtcclxuICBmb250LXdlaWdodDogNjAwO1xyXG4gIGZvbnQtc2l6ZTogMjZweDtcclxufVxyXG5cclxuLmRldGFpbC1saXN0IHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgZ2FwOiAxMHB4O1xyXG4gIHotaW5kZXg6IDEwMDA7XHJcbn1cclxuLnJlY2lwZS1kZXRhaWwtaXRlbSBsaSB7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcclxufVxyXG4uZGV0YWlsLXRleHQge1xyXG4gIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 4190:
/*!*************************************************************************!*\
  !*** ./src/app/features/profile/health-infos/health-infos.component.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HealthInfosComponent: () => (/* binding */ HealthInfosComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 316);


function HealthInfosComponent_button_52_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " You're Healthy ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
}
function HealthInfosComponent_button_53_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " You're Not Healthy ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
}
function HealthInfosComponent_button_54_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " You're Underweight ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
}
class HealthInfosComponent {
  calculateBMI() {
    const weightKg = this.client.weight;
    const heightM = this.client.height / 100; // Convert height to meters
    if (!weightKg || !heightM) {
      throw new Error('Invalid weight or height values');
    }
    return +(weightKg / (heightM * heightM)).toFixed(2); // BMI formula with 2 decimal precision
  }

  getBMIStatus() {
    const bmi = this.calculateBMI();
    if (bmi < 18.5) {
      return 'Underweight';
    } else if (bmi >= 18.5 && bmi < 24.9) {
      return 'Healthy';
    } else {
      return 'Not Healthy';
    }
  }
  static {
    this.ɵfac = function HealthInfosComponent_Factory(t) {
      return new (t || HealthInfosComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: HealthInfosComponent,
      selectors: [["app-health-infos"]],
      inputs: {
        client: "client"
      },
      decls: 55,
      vars: 6,
      consts: [[1, "health-infos-container"], [1, "infos"], ["width", "139", "height", "61", "viewBox", "0 0 139 61", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["y", "0.391357", "width", "138.217", "height", "60.6087", "rx", "8.86957", "fill", "#CBEA7B"], ["x", "60.6094", "y", "12.2174", "width", "1.47826", "height", "7.3913", "rx", "0.73913", "fill", "var(--text-color)", "fill-opacity", "0.28"], ["x", "69.4785", "y", "12.2174", "width", "1.47826", "height", "7.3913", "rx", "0.73913", "fill", "var(--text-color)", "fill-opacity", "0.4"], ["x", "78.3486", "y", "12.2174", "width", "1.47826", "height", "7.3913", "rx", "0.73913", "fill", "#282828", "fill-opacity", "0.7"], ["x", "87.2178", "y", "12.2174", "width", "1.47826", "height", "16.2609", "rx", "0.73913", "fill", "#D16564"], ["x", "96.0879", "y", "12.2174", "width", "1.47826", "height", "7.3913", "rx", "0.73913", "fill", "#282828"], ["x", "104.957", "y", "12.2174", "width", "1.47826", "height", "7.3913", "rx", "0.73913", "fill", "#282828"], ["x", "113.827", "y", "12.2174", "width", "1.47826", "height", "7.3913", "rx", "0.73913", "fill", "#282828"], ["x", "122.696", "y", "12.2174", "width", "1.47826", "height", "7.3913", "rx", "0.73913", "fill", "#282828", "fill-opacity", "0.6"], ["x", "131.565", "y", "12.2174", "width", "1.47826", "height", "7.3913", "rx", "0.73913", "fill", "#282828", "fill-opacity", "0.3"], ["x", "55", "y", "50", "font-size", "13.5", "fill", "var(--text-color)", "text-anchor", "end"], ["x", "110", "y", "50", "font-size", "13.5", "fill", "var(--text-color)", "text-anchor", "end"], ["width", "138.217", "height", "60.6087", "rx", "8.86957", "fill", "#F8DEBD"], ["x", "60.6094", "y", "11.8261", "width", "1.47826", "height", "7.3913", "rx", "0.73913", "fill", "#282828", "fill-opacity", "0.28"], ["x", "69.4785", "y", "11.8261", "width", "1.47826", "height", "7.3913", "rx", "0.73913", "fill", "#282828", "fill-opacity", "0.4"], ["x", "78.3486", "y", "11.8261", "width", "1.47826", "height", "7.3913", "rx", "0.73913", "fill", "#282828", "fill-opacity", "0.7"], ["x", "87.2178", "y", "11.8261", "width", "1.47826", "height", "16.2609", "rx", "0.73913", "fill", "#D16564"], ["x", "96.0879", "y", "11.8261", "width", "1.47826", "height", "7.3913", "rx", "0.73913", "fill", "#282828"], ["x", "104.957", "y", "11.8261", "width", "1.47826", "height", "7.3913", "rx", "0.73913", "fill", "#282828"], ["x", "113.827", "y", "11.8261", "width", "1.47826", "height", "7.3913", "rx", "0.73913", "fill", "#282828"], ["x", "122.696", "y", "11.8261", "width", "1.47826", "height", "7.3913", "rx", "0.73913", "fill", "#282828", "fill-opacity", "0.6"], ["x", "131.565", "y", "11.8261", "width", "1.47826", "height", "7.3913", "rx", "0.73913", "fill", "#282828", "fill-opacity", "0.3"], [1, "bmi"], ["width", "210", "height", "136", "viewBox", "0 0 210 136", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["width", "209.174", "height", "136", "rx", "8.86957", "fill", "#CC5500"], ["d", "M15.7677 121.348V120.399H17.2046V116.053H17.7545L15.9096 117.153V116.07L17.5328 115.095H18.3488V120.399H19.6969V121.348H15.7677ZM22.8067 121.437C22.5347 121.437 22.2627 121.407 21.9907 121.348C21.7246 121.289 21.4733 121.206 21.2368 121.099C21.0062 120.993 20.8081 120.866 20.6425 120.718L21.015 119.858C21.293 120.065 21.5768 120.221 21.8665 120.328C22.1622 120.428 22.4697 120.479 22.789 120.479C23.1733 120.479 23.4719 120.384 23.6848 120.195C23.9036 120 24.013 119.739 24.013 119.414C24.013 119.083 23.9095 118.817 23.7025 118.616C23.4956 118.409 23.2117 118.306 22.851 118.306C22.5968 118.306 22.3632 118.356 22.1503 118.456C21.9434 118.551 21.7571 118.699 21.5916 118.9H20.8377V115.095H24.7225V116.035H21.9197V118.022H21.6448C21.7985 117.815 22.0025 117.655 22.2568 117.543C22.517 117.43 22.8067 117.374 23.126 117.374C23.5281 117.374 23.877 117.457 24.1726 117.623C24.4683 117.788 24.6989 118.022 24.8644 118.323C25.03 118.619 25.1128 118.968 25.1128 119.37C25.1128 119.778 25.0182 120.139 24.829 120.452C24.6457 120.759 24.3796 121.002 24.0307 121.179C23.6877 121.351 23.2797 121.437 22.8067 121.437Z", "fill", "white"], ["d", "M56.4201 121.348V120.399H57.8569V116.053H58.4069L56.562 117.153V116.07L58.1851 115.095H59.0011V120.399H60.3493V121.348H56.4201ZM63.4147 121.437C62.6815 121.437 62.1079 121.28 61.694 120.966C61.286 120.653 61.082 120.218 61.082 119.663C61.082 119.225 61.215 118.861 61.4811 118.572C61.7472 118.282 62.0931 118.11 62.5189 118.057V118.243C62.1345 118.161 61.8241 117.98 61.5876 117.702C61.357 117.425 61.2416 117.087 61.2416 116.691C61.2416 116.165 61.4338 115.754 61.8182 115.458C62.2084 115.157 62.7406 115.006 63.4147 115.006C64.0947 115.006 64.6269 115.157 65.0112 115.458C65.4015 115.754 65.5966 116.165 65.5966 116.691C65.5966 117.087 65.4843 117.427 65.2596 117.711C65.0408 117.995 64.7422 118.17 64.3637 118.235V118.057C64.7836 118.116 65.1206 118.291 65.3749 118.581C65.6291 118.864 65.7563 119.225 65.7563 119.663C65.7563 120.218 65.5493 120.653 65.1354 120.966C64.7274 121.28 64.1538 121.437 63.4147 121.437ZM63.4147 120.55C63.8463 120.55 64.1686 120.47 64.3815 120.31C64.5943 120.145 64.7008 119.902 64.7008 119.583C64.7008 119.263 64.5943 119.024 64.3815 118.864C64.1686 118.705 63.8463 118.625 63.4147 118.625C62.989 118.625 62.6667 118.705 62.4479 118.864C62.235 119.024 62.1286 119.263 62.1286 119.583C62.1286 119.902 62.235 120.145 62.4479 120.31C62.6667 120.47 62.989 120.55 63.4147 120.55ZM63.4147 117.738C63.7813 117.738 64.0592 117.655 64.2484 117.49C64.4436 117.324 64.5411 117.096 64.5411 116.807C64.5411 116.523 64.4436 116.301 64.2484 116.141C64.0592 115.976 63.7813 115.893 63.4147 115.893C63.054 115.893 62.7761 115.976 62.581 116.141C62.3917 116.301 62.2971 116.523 62.2971 116.807C62.2971 117.096 62.3917 117.324 62.581 117.49C62.7761 117.655 63.054 117.738 63.4147 117.738ZM66.5511 121.348V120.115H67.7928V121.348H66.5511ZM70.9774 121.437C70.7054 121.437 70.4334 121.407 70.1614 121.348C69.8953 121.289 69.644 121.206 69.4075 121.099C69.1769 120.993 68.9788 120.866 68.8132 120.718L69.1857 119.858C69.4636 120.065 69.7475 120.221 70.0372 120.328C70.3329 120.428 70.6403 120.479 70.9596 120.479C71.344 120.479 71.6426 120.384 71.8555 120.195C72.0743 120 72.1836 119.739 72.1836 119.414C72.1836 119.083 72.0802 118.817 71.8732 118.616C71.6663 118.409 71.3824 118.306 71.0217 118.306C70.7675 118.306 70.5339 118.356 70.321 118.456C70.1141 118.551 69.9278 118.699 69.7623 118.9H69.0083V115.095H72.8932V116.035H70.0904V118.022H69.8155C69.9692 117.815 70.1732 117.655 70.4275 117.543C70.6876 117.43 70.9774 117.374 71.2967 117.374C71.6988 117.374 72.0476 117.457 72.3433 117.623C72.6389 117.788 72.8696 118.022 73.0351 118.323C73.2007 118.619 73.2835 118.968 73.2835 119.37C73.2835 119.778 73.1889 120.139 72.9996 120.452C72.8163 120.759 72.5503 121.002 72.2014 121.179C71.8584 121.351 71.4504 121.437 70.9774 121.437Z", "fill", "white"], ["d", "M101.954 121.348V120.505L104.029 118.341C104.289 118.069 104.481 117.818 104.606 117.587C104.73 117.357 104.792 117.12 104.792 116.878C104.792 116.576 104.697 116.348 104.508 116.195C104.319 116.041 104.044 115.964 103.683 115.964C103.393 115.964 103.115 116.017 102.849 116.124C102.583 116.224 102.323 116.384 102.069 116.603L101.696 115.751C101.951 115.526 102.264 115.346 102.637 115.21C103.015 115.074 103.411 115.006 103.825 115.006C104.499 115.006 105.017 115.157 105.377 115.458C105.738 115.76 105.918 116.192 105.918 116.753C105.918 117.144 105.827 117.516 105.643 117.871C105.46 118.22 105.176 118.586 104.792 118.971L103.062 120.7V120.399H106.167V121.348H101.954ZM109.285 121.437C109.013 121.437 108.741 121.407 108.469 121.348C108.203 121.289 107.952 121.206 107.715 121.099C107.485 120.993 107.287 120.866 107.121 120.718L107.494 119.858C107.771 120.065 108.055 120.221 108.345 120.328C108.641 120.428 108.948 120.479 109.267 120.479C109.652 120.479 109.95 120.384 110.163 120.195C110.382 120 110.491 119.739 110.491 119.414C110.491 119.083 110.388 118.817 110.181 118.616C109.974 118.409 109.69 118.306 109.33 118.306C109.075 118.306 108.842 118.356 108.629 118.456C108.422 118.551 108.236 118.699 108.07 118.9H107.316V115.095H111.201V116.035H108.398V118.022H108.123C108.277 117.815 108.481 117.655 108.735 117.543C108.995 117.43 109.285 117.374 109.605 117.374C110.007 117.374 110.355 117.457 110.651 117.623C110.947 117.788 111.177 118.022 111.343 118.323C111.509 118.619 111.591 118.968 111.591 119.37C111.591 119.778 111.497 120.139 111.307 120.452C111.124 120.759 110.858 121.002 110.509 121.179C110.166 121.351 109.758 121.437 109.285 121.437Z", "fill", "white"], ["d", "M142.999 121.437C142.567 121.437 142.153 121.374 141.757 121.25C141.361 121.12 141.036 120.943 140.781 120.718L141.154 119.858C141.432 120.071 141.719 120.227 142.014 120.328C142.316 120.428 142.632 120.479 142.963 120.479C143.365 120.479 143.67 120.399 143.877 120.239C144.084 120.079 144.187 119.846 144.187 119.538C144.187 119.243 144.084 119.021 143.877 118.873C143.676 118.719 143.38 118.643 142.99 118.643H141.979V117.729H142.892C143.229 117.729 143.499 117.646 143.7 117.481C143.901 117.315 144.001 117.087 144.001 116.798C144.001 116.526 143.907 116.319 143.717 116.177C143.534 116.035 143.268 115.964 142.919 115.964C142.292 115.964 141.739 116.177 141.26 116.603L140.888 115.751C141.142 115.515 141.456 115.331 141.828 115.201C142.207 115.071 142.603 115.006 143.017 115.006C143.667 115.006 144.176 115.154 144.542 115.45C144.915 115.739 145.101 116.144 145.101 116.665C145.101 117.037 144.995 117.359 144.782 117.631C144.575 117.898 144.288 118.075 143.921 118.164V118.057C144.353 118.128 144.687 118.306 144.924 118.589C145.166 118.867 145.287 119.216 145.287 119.636C145.287 120.192 145.083 120.632 144.675 120.958C144.267 121.277 143.708 121.437 142.999 121.437ZM148.415 121.437C147.681 121.437 147.117 121.159 146.721 120.603C146.324 120.041 146.126 119.243 146.126 118.208C146.126 117.161 146.324 116.366 146.721 115.822C147.117 115.278 147.681 115.006 148.415 115.006C149.154 115.006 149.719 115.278 150.109 115.822C150.505 116.366 150.703 117.158 150.703 118.199C150.703 119.24 150.505 120.041 150.109 120.603C149.719 121.159 149.154 121.437 148.415 121.437ZM148.415 120.496C148.817 120.496 149.115 120.313 149.311 119.946C149.506 119.574 149.603 118.991 149.603 118.199C149.603 117.407 149.506 116.833 149.311 116.478C149.115 116.118 148.817 115.937 148.415 115.937C148.019 115.937 147.72 116.118 147.519 116.478C147.324 116.833 147.226 117.407 147.226 118.199C147.226 118.991 147.324 119.574 147.519 119.946C147.72 120.313 148.019 120.496 148.415 120.496Z", "fill", "white"], ["d", "M188.68 121.348V120.124H185.886V119.326L188.857 115.095H189.78V119.255H190.676V120.124H189.78V121.348H188.68ZM188.68 119.255V116.443H188.893L186.738 119.521V119.255H188.68ZM193.502 121.437C192.768 121.437 192.204 121.159 191.808 120.603C191.411 120.041 191.213 119.243 191.213 118.208C191.213 117.161 191.411 116.366 191.808 115.822C192.204 115.278 192.768 115.006 193.502 115.006C194.241 115.006 194.805 115.278 195.196 115.822C195.592 116.366 195.79 117.158 195.79 118.199C195.79 119.24 195.592 120.041 195.196 120.603C194.805 121.159 194.241 121.437 193.502 121.437ZM193.502 120.496C193.904 120.496 194.202 120.313 194.397 119.946C194.593 119.574 194.69 118.991 194.69 118.199C194.69 117.407 194.593 116.833 194.397 116.478C194.202 116.118 193.904 115.937 193.502 115.937C193.105 115.937 192.807 116.118 192.606 116.478C192.411 116.833 192.313 117.407 192.313 118.199C192.313 118.991 192.411 119.574 192.606 119.946C192.807 120.313 193.105 120.496 193.502 120.496Z", "fill", "white"], ["x", "14.7832", "y", "96.0869", "width", "179.609", "height", "10.3478", "rx", "5.17391", "fill", "url(#paint0_linear_696_197)"], ["id", "paint0_linear_696_197", "x1", "14.7832", "y1", "101.261", "x2", "194.392", "y2", "101.261", "gradientUnits", "userSpaceOnUse"], ["stop-color", "#B5D4F1"], ["offset", "0.377705", "stop-color", "#81E6DB"], ["offset", "0.704019", "stop-color", "#E8D284"], ["offset", "1", "stop-color", "#E2798E"], ["x", "155", "y", "30", "font-size", "13.5", "fill", "white", "text-anchor", "end"], ["x", "55", "y", "65", "font-size", "16", "fill", "white", "text-anchor", "end"], [1, "buttons"], ["class", "healthy-button", 4, "ngIf"], ["class", "not-healthy-button", 4, "ngIf"], ["class", "underweight-button", 4, "ngIf"], [1, "healthy-button"], [1, "not-healthy-button"], [1, "underweight-button"]],
      template: function HealthInfosComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "div", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnamespaceSVG"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "svg", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "rect", 3)(4, "rect", 4)(5, "rect", 5)(6, "rect", 6)(7, "rect", 7)(8, "rect", 8)(9, "rect", 9)(10, "rect", 10)(11, "rect", 11)(12, "rect", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "text", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](14, " Weight ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "text", 14);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "svg", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](18, "rect", 15)(19, "rect", 16)(20, "rect", 17)(21, "rect", 18)(22, "rect", 19)(23, "rect", 20)(24, "rect", 21)(25, "rect", 22)(26, "rect", 23)(27, "rect", 24);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "text", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](29, " Height ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](30, "text", 14);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](31);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnamespaceHTML"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](32, "div", 25);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnamespaceSVG"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](33, "svg", 26);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](34, "rect", 27)(35, "path", 28)(36, "path", 29)(37, "path", 30)(38, "path", 31)(39, "path", 32)(40, "rect", 33);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](41, "defs")(42, "linearGradient", 34);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](43, "stop", 35)(44, "stop", 36)(45, "stop", 37)(46, "stop", 38);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](47, "text", 39);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](48, " Body Mass Index (BMI) ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](49, "text", 40);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](50);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnamespaceHTML"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](51, "div", 41);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](52, HealthInfosComponent_button_52_Template, 2, 0, "button", 42);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](53, HealthInfosComponent_button_53_Template, 2, 0, "button", 43);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](54, HealthInfosComponent_button_54_Template, 2, 0, "button", 44);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](16);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx.client.weight, " kg ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](15);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx.client.height, " cm ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](19);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx.calculateBMI(), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.getBMIStatus() === "Healthy");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.getBMIStatus() === "Not Healthy");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.getBMIStatus() === "Underweight");
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgIf],
      styles: [".infos[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n\n  padding: 5px;\n  gap: 10px;\n}\n.infos[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 160px;\n  height: 70.16px;\n}\n.health-infos-container[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 10px;\n  justify-content: center;\n  align-items: center;\n}\n.bmi[_ngcontent-%COMP%] {\n  position: relative;\n}\n.bmi[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 250px;\n  height: 162.54px;\n}\n.healthy-button[_ngcontent-%COMP%] {\n  background-color: #d6ffdd;\n  color: var(--brown);\n  border: none;\n  padding: 7px 10px;\n  font-size: 14px;\n  border-radius: 6px;\n}\n\n.not-healthy-button[_ngcontent-%COMP%] {\n  background-color: var(--light-red);\n  color: red;\n  border: none;\n  padding: 7px 10px;\n  font-size: 14px;\n  border-radius: 6px;\n}\n\n.underweight-button[_ngcontent-%COMP%] {\n  background-color: #f8debd;\n  color: var(--brown);\n  border: none;\n  padding: 7px 10px;\n  font-size: 14px;\n  border-radius: 6px;\n}\n.buttons[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 8%;\n  top: 33%;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvZmVhdHVyZXMvcHJvZmlsZS9oZWFsdGgtaW5mb3MvaGVhbHRoLWluZm9zLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxhQUFhO0VBQ2Isc0JBQXNCOztFQUV0QixZQUFZO0VBQ1osU0FBUztBQUNYO0FBQ0E7RUFDRSxZQUFZO0VBQ1osZUFBZTtBQUNqQjtBQUNBO0VBQ0UsYUFBYTtFQUNiLFNBQVM7RUFDVCx1QkFBdUI7RUFDdkIsbUJBQW1CO0FBQ3JCO0FBQ0E7RUFDRSxrQkFBa0I7QUFDcEI7QUFDQTtFQUNFLFlBQVk7RUFDWixnQkFBZ0I7QUFDbEI7QUFDQTtFQUNFLHlCQUF5QjtFQUN6QixtQkFBbUI7RUFDbkIsWUFBWTtFQUNaLGlCQUFpQjtFQUNqQixlQUFlO0VBQ2Ysa0JBQWtCO0FBQ3BCOztBQUVBO0VBQ0Usa0NBQWtDO0VBQ2xDLFVBQVU7RUFDVixZQUFZO0VBQ1osaUJBQWlCO0VBQ2pCLGVBQWU7RUFDZixrQkFBa0I7QUFDcEI7O0FBRUE7RUFDRSx5QkFBeUI7RUFDekIsbUJBQW1CO0VBQ25CLFlBQVk7RUFDWixpQkFBaUI7RUFDakIsZUFBZTtFQUNmLGtCQUFrQjtBQUNwQjtBQUNBO0VBQ0Usa0JBQWtCO0VBQ2xCLFNBQVM7RUFDVCxRQUFRO0FBQ1YiLCJzb3VyY2VzQ29udGVudCI6WyIuaW5mb3Mge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuXHJcbiAgcGFkZGluZzogNXB4O1xyXG4gIGdhcDogMTBweDtcclxufVxyXG4uaW5mb3Mgc3ZnIHtcclxuICB3aWR0aDogMTYwcHg7XHJcbiAgaGVpZ2h0OiA3MC4xNnB4O1xyXG59XHJcbi5oZWFsdGgtaW5mb3MtY29udGFpbmVyIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGdhcDogMTBweDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcbi5ibWkge1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxufVxyXG4uYm1pIHN2ZyB7XHJcbiAgd2lkdGg6IDI1MHB4O1xyXG4gIGhlaWdodDogMTYyLjU0cHg7XHJcbn1cclxuLmhlYWx0aHktYnV0dG9uIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZDZmZmRkO1xyXG4gIGNvbG9yOiB2YXIoLS1icm93bik7XHJcbiAgYm9yZGVyOiBub25lO1xyXG4gIHBhZGRpbmc6IDdweCAxMHB4O1xyXG4gIGZvbnQtc2l6ZTogMTRweDtcclxuICBib3JkZXItcmFkaXVzOiA2cHg7XHJcbn1cclxuXHJcbi5ub3QtaGVhbHRoeS1idXR0b24ge1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWxpZ2h0LXJlZCk7XHJcbiAgY29sb3I6IHJlZDtcclxuICBib3JkZXI6IG5vbmU7XHJcbiAgcGFkZGluZzogN3B4IDEwcHg7XHJcbiAgZm9udC1zaXplOiAxNHB4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDZweDtcclxufVxyXG5cclxuLnVuZGVyd2VpZ2h0LWJ1dHRvbiB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2Y4ZGViZDtcclxuICBjb2xvcjogdmFyKC0tYnJvd24pO1xyXG4gIGJvcmRlcjogbm9uZTtcclxuICBwYWRkaW5nOiA3cHggMTBweDtcclxuICBmb250LXNpemU6IDE0cHg7XHJcbiAgYm9yZGVyLXJhZGl1czogNnB4O1xyXG59XHJcbi5idXR0b25zIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgcmlnaHQ6IDglO1xyXG4gIHRvcDogMzMlO1xyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
    });
  }
}

/***/ }),

/***/ 1620:
/*!*************************************************************************!*\
  !*** ./src/app/features/profile/profile-page/profile-page.component.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ProfilePageComponent: () => (/* binding */ ProfilePageComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ngx-toastr */ 4285);
/* harmony import */ var src_app_core_constants_constants_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/constants/constants.config */ 8111);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/auth.service */ 4796);
/* harmony import */ var src_app_services_client_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/client.service */ 8281);
/* harmony import */ var src_app_services_recipe_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/recipe.service */ 4964);
/* harmony import */ var src_app_core_pipes_get_age_pipe__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/pipes/get-age.pipe */ 4324);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _shared_components_page_background_page_background_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../shared/components/page-background/page-background.component */ 1469);
/* harmony import */ var _shared_components_upload_image_upload_image_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../shared/components/upload-image/upload-image.component */ 6881);
/* harmony import */ var _health_infos_health_infos_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../health-infos/health-infos.component */ 4190);












function ProfilePageComponent_div_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 16)(1, "span", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](2, "i");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](3, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const item_r2 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵclassMap"](item_r2.icon);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate"](item_r2.param);
  }
}
function ProfilePageComponent_div_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](1, "img", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](2, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const recette_r3 = ctx.$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("src", ctx_r1.base_url + recette_r3.imageUrl, _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate"](recette_r3.name);
  }
}
class ProfilePageComponent {
  constructor(getAgePipe) {
    this.getAgePipe = getAgePipe;
    this.recipesService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.inject)(src_app_services_recipe_service__WEBPACK_IMPORTED_MODULE_3__.RecipesService);
    this.client = null;
    this.clientInfoItems = [];
    this.authService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.inject)(src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_1__.AuthService);
    this.clientService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.inject)(src_app_services_client_service__WEBPACK_IMPORTED_MODULE_2__.ClientService);
    this.toastr = (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.inject)(ngx_toastr__WEBPACK_IMPORTED_MODULE_9__.ToastrService);
    this.base_url = src_app_core_constants_constants_config__WEBPACK_IMPORTED_MODULE_0__.APP_API.base_url;
    this.clientService.getClientById(this.authService.getUserId()).subscribe({
      next: response => {
        this.client = response;
        this.updateClientInfoItems();
      },
      error: err => {
        console.error('Upload Failed:', err);
      }
    });
  }
  ngOnInit() {
    this.recettes = this.recipesService.generateFakeRecipesList(4);
  }
  updateClientInfoItems() {
    if (this.client) {
      this.clientInfoItems = [{
        icon: 'fa-solid fa-user',
        param: this.client.gender ?? 'N/A'
      }, {
        icon: 'fa-solid fa-cake-candles',
        param: this.getAgePipe.transform(this.client.birthDate)
      }, {
        icon: 'fa-solid fa-envelope',
        param: this.client.email ?? 'N/A'
      }, {
        icon: 'fa-solid fa-phone',
        param: this.client.phoneNumber ?? 'N/A'
      }];
    }
  }
  static {
    this.ɵfac = function ProfilePageComponent_Factory(t) {
      return new (t || ProfilePageComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_pipes_get_age_pipe__WEBPACK_IMPORTED_MODULE_4__.GetAgePipe));
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineComponent"]({
      type: ProfilePageComponent,
      selectors: [["app-profile-page"]],
      decls: 31,
      vars: 7,
      consts: [[1, "first-section"], ["src", "assets/images/profile-bg.png", "alt", ""], [1, "under-img"], [1, "profile-pic"], [3, "acceptedFileTypes", "uploadedImage"], [1, "small-details"], [1, "second-section"], [1, "propos"], ["class", "propos-item", 4, "ngFor", "ngForOf"], [1, "right-section"], [1, "upper-right"], [1, "health-infos"], [3, "client"], [1, "favorites"], [1, "lower-right"], [2, "color", "var(--brown)"], [1, "propos-item"], [1, "icon-propos"], ["alt", "", 3, "src"]],
      template: function ProfilePageComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "app-page-background")(1, "div", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](2, "img", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](3, "div", 2)(4, "div", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](5, "app-upload-image", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](6, "div", 5)(7, "h3");
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](8);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](9, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](10);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](11, "div", 6)(12, "div", 7)(13, "h3");
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](14, "A Propos");
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](15, ProfilePageComponent_div_15_Template, 5, 3, "div", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](16, "div", 9)(17, "div", 10)(18, "div", 11)(19, "h3");
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](20, "Donn\u00E9es de sant\u00E9");
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](21, "app-health-infos", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](22, "div", 13)(23, "h3");
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](24, "Recettes pr\u00E9f\u00E9r\u00E9es");
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](25, ProfilePageComponent_div_25_Template, 4, 2, "div", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](26, "div", 14)(27, "h3");
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](28, "Upcoming appointment");
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](29, "p", 15);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](30, "Consultation with Dr. Khiari");
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()()()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("acceptedFileTypes", "image/*")("uploadedImage", "assets/images/avatar.png");
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate"](ctx.client == null ? null : ctx.client.name);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate"](ctx.client == null ? null : ctx.client.role);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngForOf", ctx.clientInfoItems);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("client", ctx.client);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngForOf", ctx.client == null ? null : ctx.client.favoriteRecipes);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_10__.NgForOf, _shared_components_page_background_page_background_component__WEBPACK_IMPORTED_MODULE_5__.PageBackgroundComponent, _shared_components_upload_image_upload_image_component__WEBPACK_IMPORTED_MODULE_6__.UploadImageComponent, _health_infos_health_infos_component__WEBPACK_IMPORTED_MODULE_7__.HealthInfosComponent],
      styles: [".first-section[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n}\n.first-section[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  color: white;\n}\nh3[_ngcontent-%COMP%] {\n  font-weight: 500;\n  color: var(--brown);\n}\n.first-section[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 65%;\n}\n.under-img[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 25%;\n  background-color: var(--primary-color);\n  color: white;\n  display: flex;\n  align-items: center;\n  padding: 20px;\n  position: relative;\n}\n\n.profile-pic[_ngcontent-%COMP%] {\n  width: 30%;\n  height: 100%;\n  position: absolute;\n  top: -80%;\n  left: 0;\n}\n\n.small-details[_ngcontent-%COMP%] {\n  margin-left: 23%; \n\n  display: flex;\n  flex-direction: column;\n}\n.second-section[_ngcontent-%COMP%] {\n  display: flex;\n  width: 100%;\n  height: 100%;\n  gap: 20px;\n  word-break: break-word;\n  margin-bottom: 10px;\n  \n\n}\n.propos[_ngcontent-%COMP%] {\n  padding: 15px;\n  border-radius: 10px;\n  background-color: white;\n  display: flex;\n  flex-direction: column;\n  width: 30%;\n  gap: 25px;\n}\n\n.icon-propos[_ngcontent-%COMP%] {\n  color: var(--primary-color);\n}\n\n.propos-item[_ngcontent-%COMP%] {\n  color: var(--primary-color);\n  display: flex;\n  gap: 15px;\n  align-items: center;\n  padding-bottom: 10px;\n  border-bottom: 0.1px solid #eeeded;\n}\n.right-section[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n  flex-direction: column;\n  gap: 20px;\n}\n.health-infos[_ngcontent-%COMP%] {\n  flex: 65%;\n  padding: 15px;\n  display: flex;\n  flex-direction: column;\n  padding: 10px;\n  border-radius: 10px;\n  background-color: white;\n  gap: 20px;\n}\n.favorites[_ngcontent-%COMP%] {\n  flex: 35%;\n  display: flex;\n  flex-direction: column;\n  padding: 10px;\n  border-radius: 10px;\n  background-color: white;\n  gap: 5px;\n}\n\n.propos-item[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  height: 40px;\n  width: 40px;\n}\n.upper-right[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 15px;\n  width: 100%;\n  max-height: 75%;\n}\n.lower-right[_ngcontent-%COMP%] {\n  background-color: white;\n  border-radius: 10px;\n  min-height: 25%;\n  width: 100%;\n  display: flex;\n  justify-content: space-around;\n  padding: 15px;\n  align-items: center;\n}\n\n.lower-right[_ngcontent-%COMP%]   button[_ngcontent-%COMP%] {\n  background-color: var(--light-green);\n  border-radius: 10px;\n  color: var(--brown);\n  padding: 0.7rem 1rem 0.7rem 1rem;\n  border: none;\n  cursor: \"pointer\";\n  transition: \"border-color 0.3s ease\";\n  overflow: hidden;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvZmVhdHVyZXMvcHJvZmlsZS9wcm9maWxlLXBhZ2UvcHJvZmlsZS1wYWdlLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxXQUFXO0VBQ1gsYUFBYTtFQUNiLHNCQUFzQjtFQUN0Qix1QkFBdUI7RUFDdkIsbUJBQW1CO0FBQ3JCO0FBQ0E7RUFDRSxZQUFZO0FBQ2Q7QUFDQTtFQUNFLGdCQUFnQjtFQUNoQixtQkFBbUI7QUFDckI7QUFDQTtFQUNFLFdBQVc7RUFDWCxXQUFXO0FBQ2I7QUFDQTtFQUNFLFdBQVc7RUFDWCxXQUFXO0VBQ1gsc0NBQXNDO0VBQ3RDLFlBQVk7RUFDWixhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLGFBQWE7RUFDYixrQkFBa0I7QUFDcEI7O0FBRUE7RUFDRSxVQUFVO0VBQ1YsWUFBWTtFQUNaLGtCQUFrQjtFQUNsQixTQUFTO0VBQ1QsT0FBTztBQUNUOztBQUVBO0VBQ0UsZ0JBQWdCLEVBQUUsbURBQW1EO0VBQ3JFLGFBQWE7RUFDYixzQkFBc0I7QUFDeEI7QUFDQTtFQUNFLGFBQWE7RUFDYixXQUFXO0VBQ1gsWUFBWTtFQUNaLFNBQVM7RUFDVCxzQkFBc0I7RUFDdEIsbUJBQW1CO0VBQ25CLDZCQUE2QjtBQUMvQjtBQUNBO0VBQ0UsYUFBYTtFQUNiLG1CQUFtQjtFQUNuQix1QkFBdUI7RUFDdkIsYUFBYTtFQUNiLHNCQUFzQjtFQUN0QixVQUFVO0VBQ1YsU0FBUztBQUNYOztBQUVBO0VBQ0UsMkJBQTJCO0FBQzdCOztBQUVBO0VBQ0UsMkJBQTJCO0VBQzNCLGFBQWE7RUFDYixTQUFTO0VBQ1QsbUJBQW1CO0VBQ25CLG9CQUFvQjtFQUNwQixrQ0FBa0M7QUFDcEM7QUFDQTtFQUNFLFdBQVc7RUFDWCxhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLFNBQVM7QUFDWDtBQUNBO0VBQ0UsU0FBUztFQUNULGFBQWE7RUFDYixhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLGFBQWE7RUFDYixtQkFBbUI7RUFDbkIsdUJBQXVCO0VBQ3ZCLFNBQVM7QUFDWDtBQUNBO0VBQ0UsU0FBUztFQUNULGFBQWE7RUFDYixzQkFBc0I7RUFDdEIsYUFBYTtFQUNiLG1CQUFtQjtFQUNuQix1QkFBdUI7RUFDdkIsUUFBUTtBQUNWOztBQUVBO0VBQ0UsWUFBWTtFQUNaLFdBQVc7QUFDYjtBQUNBO0VBQ0UsYUFBYTtFQUNiLFNBQVM7RUFDVCxXQUFXO0VBQ1gsZUFBZTtBQUNqQjtBQUNBO0VBQ0UsdUJBQXVCO0VBQ3ZCLG1CQUFtQjtFQUNuQixlQUFlO0VBQ2YsV0FBVztFQUNYLGFBQWE7RUFDYiw2QkFBNkI7RUFDN0IsYUFBYTtFQUNiLG1CQUFtQjtBQUNyQjs7QUFFQTtFQUNFLG9DQUFvQztFQUNwQyxtQkFBbUI7RUFDbkIsbUJBQW1CO0VBQ25CLGdDQUFnQztFQUNoQyxZQUFZO0VBQ1osaUJBQWlCO0VBQ2pCLG9DQUFvQztFQUNwQyxnQkFBZ0I7QUFDbEIiLCJzb3VyY2VzQ29udGVudCI6WyIuZmlyc3Qtc2VjdGlvbiB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuLmZpcnN0LXNlY3Rpb24gaDMge1xyXG4gIGNvbG9yOiB3aGl0ZTtcclxufVxyXG5oMyB7XHJcbiAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICBjb2xvcjogdmFyKC0tYnJvd24pO1xyXG59XHJcbi5maXJzdC1zZWN0aW9uIGltZyB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiA2NSU7XHJcbn1cclxuLnVuZGVyLWltZyB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAyNSU7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tcHJpbWFyeS1jb2xvcik7XHJcbiAgY29sb3I6IHdoaXRlO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBwYWRkaW5nOiAyMHB4O1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxufVxyXG5cclxuLnByb2ZpbGUtcGljIHtcclxuICB3aWR0aDogMzAlO1xyXG4gIGhlaWdodDogMTAwJTtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiAtODAlO1xyXG4gIGxlZnQ6IDA7XHJcbn1cclxuXHJcbi5zbWFsbC1kZXRhaWxzIHtcclxuICBtYXJnaW4tbGVmdDogMjMlOyAvKiBBZGRzIHNwYWNlIHRvIHRoZSByaWdodCBvZiB0aGUgcHJvZmlsZSBwaWN0dXJlICovXHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG59XHJcbi5zZWNvbmQtc2VjdGlvbiB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAgZ2FwOiAyMHB4O1xyXG4gIHdvcmQtYnJlYWs6IGJyZWFrLXdvcmQ7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcclxuICAvKiB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpczsgKi9cclxufVxyXG4ucHJvcG9zIHtcclxuICBwYWRkaW5nOiAxNXB4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gIHdpZHRoOiAzMCU7XHJcbiAgZ2FwOiAyNXB4O1xyXG59XHJcblxyXG4uaWNvbi1wcm9wb3Mge1xyXG4gIGNvbG9yOiB2YXIoLS1wcmltYXJ5LWNvbG9yKTtcclxufVxyXG5cclxuLnByb3Bvcy1pdGVtIHtcclxuICBjb2xvcjogdmFyKC0tcHJpbWFyeS1jb2xvcik7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBnYXA6IDE1cHg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBwYWRkaW5nLWJvdHRvbTogMTBweDtcclxuICBib3JkZXItYm90dG9tOiAwLjFweCBzb2xpZCAjZWVlZGVkO1xyXG59XHJcbi5yaWdodC1zZWN0aW9uIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgZ2FwOiAyMHB4O1xyXG59XHJcbi5oZWFsdGgtaW5mb3Mge1xyXG4gIGZsZXg6IDY1JTtcclxuICBwYWRkaW5nOiAxNXB4O1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBwYWRkaW5nOiAxMHB4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgZ2FwOiAyMHB4O1xyXG59XHJcbi5mYXZvcml0ZXMge1xyXG4gIGZsZXg6IDM1JTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgcGFkZGluZzogMTBweDtcclxuICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG4gIGdhcDogNXB4O1xyXG59XHJcblxyXG4ucHJvcG9zLWl0ZW0gaW1nIHtcclxuICBoZWlnaHQ6IDQwcHg7XHJcbiAgd2lkdGg6IDQwcHg7XHJcbn1cclxuLnVwcGVyLXJpZ2h0IHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGdhcDogMTVweDtcclxuICB3aWR0aDogMTAwJTtcclxuICBtYXgtaGVpZ2h0OiA3NSU7XHJcbn1cclxuLmxvd2VyLXJpZ2h0IHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gIG1pbi1oZWlnaHQ6IDI1JTtcclxuICB3aWR0aDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYXJvdW5kO1xyXG4gIHBhZGRpbmc6IDE1cHg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG5cclxuLmxvd2VyLXJpZ2h0IGJ1dHRvbiB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tbGlnaHQtZ3JlZW4pO1xyXG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgY29sb3I6IHZhcigtLWJyb3duKTtcclxuICBwYWRkaW5nOiAwLjdyZW0gMXJlbSAwLjdyZW0gMXJlbTtcclxuICBib3JkZXI6IG5vbmU7XHJcbiAgY3Vyc29yOiBcInBvaW50ZXJcIjtcclxuICB0cmFuc2l0aW9uOiBcImJvcmRlci1jb2xvciAwLjNzIGVhc2VcIjtcclxuICBvdmVyZmxvdzogaGlkZGVuO1xyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
    });
  }
}

/***/ }),

/***/ 337:
/*!****************************************************!*\
  !*** ./src/app/features/profile/profile.module.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ProfileModule: () => (/* binding */ ProfileModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _profile_page_profile_page_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./profile-page/profile-page.component */ 1620);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/shared/shared.module */ 3887);
/* harmony import */ var _angular_material_slider__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/slider */ 4992);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 4456);
/* harmony import */ var _health_infos_health_infos_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./health-infos/health-infos.component */ 4190);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7580);







class ProfileModule {
  static {
    this.ɵfac = function ProfileModule_Factory(t) {
      return new (t || ProfileModule)();
    };
  }
  static {
    this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
      type: ProfileModule
    });
  }
  static {
    this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule, src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule, _angular_material_slider__WEBPACK_IMPORTED_MODULE_5__.MatSliderModule, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule]
    });
  }
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](ProfileModule, {
    declarations: [_profile_page_profile_page_component__WEBPACK_IMPORTED_MODULE_0__.ProfilePageComponent, _health_infos_health_infos_component__WEBPACK_IMPORTED_MODULE_2__.HealthInfosComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule, src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule, _angular_material_slider__WEBPACK_IMPORTED_MODULE_5__.MatSliderModule, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule],
    exports: [_profile_page_profile_page_component__WEBPACK_IMPORTED_MODULE_0__.ProfilePageComponent, _health_infos_health_infos_component__WEBPACK_IMPORTED_MODULE_2__.HealthInfosComponent]
  });
})();

/***/ }),

/***/ 3852:
/*!*********************************************************************!*\
  !*** ./src/app/features/recipes/add-recipe/add-recipe.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AddRecipeComponent: () => (/* binding */ AddRecipeComponent)
/* harmony export */ });
/* harmony import */ var D_Code_angular_nutri_solution_Nutrisolutions_FRONT_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 9204);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/forms */ 4456);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/router */ 5072);
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ngx-toastr */ 4285);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! rxjs */ 6196);
/* harmony import */ var src_app_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utils/functions.utils */ 3584);
/* harmony import */ var src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/models/recipe.model */ 6464);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/auth.service */ 4796);
/* harmony import */ var src_app_services_file_upload_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/file-upload.service */ 8222);
/* harmony import */ var src_app_services_logger_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/logger.service */ 4798);
/* harmony import */ var src_app_services_recipe_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/recipe.service */ 4964);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../shared/components/button/button.component */ 8219);
/* harmony import */ var _shared_components_svg_box_svg_box_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../shared/components/svg-box/svg-box.component */ 6145);
/* harmony import */ var _shared_components_page_background_page_background_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../shared/components/page-background/page-background.component */ 1469);
/* harmony import */ var _shared_components_upload_image_upload_image_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../shared/components/upload-image/upload-image.component */ 6881);
/* harmony import */ var _shared_components_dropdown_dropdown_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../shared/components/dropdown/dropdown.component */ 4538);
/* harmony import */ var _shared_components_input_field_input_field_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../shared/components/input-field/input-field.component */ 1029);
/* harmony import */ var _shared_components_recipe_description_recipe_description_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../shared/components/recipe-description/recipe-description.component */ 6981);





















function AddRecipeComponent_div_18_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](1, "img", 20)(2, "app-input-field", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("src", item_r3.image, _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("control", item_r3.formControlName)("placeholder", item_r3.placeholder);
  }
}
function AddRecipeComponent_app_button_30_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](0, "app-button", 21);
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("disabled", ctx_r1.isButtonDisabled())("text", "Ajouter Recette")("onClick", ctx_r1.saveRecipe);
  }
}
function AddRecipeComponent_app_button_31_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](0, "app-button", 21);
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("disabled", ctx_r2.isButtonDisabled())("text", "Modifier Recette")("onClick", ctx_r2.saveRecipe);
  }
}
const _c0 = function () {
  return [];
};
class AddRecipeComponent {
  constructor() {
    this.recipe = null;
    this.items = [];
    this.isEditMode = false;
    this.titleControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_15__.FormControl('');
    this.descriptionControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_15__.FormControl('');
    this.categoryControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_15__.FormControl(src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_2__.CategoryEnum.DINER);
    this.objectifControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_15__.FormControl(src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_2__.ObjectifEnum.PERDRE_POIDS);
    this.preptimeControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_15__.FormControl(src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_2__.PreparationTimeEnum.VERY_SHORT);
    this.recipesService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.inject)(src_app_services_recipe_service__WEBPACK_IMPORTED_MODULE_6__.RecipesService);
    this.toastr = (0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.inject)(ngx_toastr__WEBPACK_IMPORTED_MODULE_16__.ToastrService);
    this.logger = (0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.inject)(src_app_services_logger_service__WEBPACK_IMPORTED_MODULE_5__.LoggerService);
    this.router = (0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.inject)(_angular_router__WEBPACK_IMPORTED_MODULE_17__.Router);
    this.ingredients = [];
    this.instructions = [];
    this.notes = [];
    this.imageUrl = '';
    this.uploadImageService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.inject)(src_app_services_file_upload_service__WEBPACK_IMPORTED_MODULE_4__.FileUploadService);
    this.nutritionstName = '';
    this.categoryOptions = Object.values(src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_2__.CategoryEnum).filter(category => category !== src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_2__.CategoryEnum.ALL);
    this.objectifOptions = Object.values(src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_2__.ObjectifEnum).filter(objectif => objectif !== src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_2__.ObjectifEnum.ALL);
    this.preptimeOptions = Object.values(src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_2__.PreparationTimeEnum).filter(preptime => preptime !== src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_2__.PreparationTimeEnum.ALL);
    this.authService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.inject)(src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService);
    this.isFormInvalid = true;
    this.saveRecipe = () => {
      if (this.isFormInvalid) {
        this.toastr.error('Please fill all the required fields');
      } else {
        if (this.imageFile) {
          // Upload the image first
          this.uploadImageService.uploadImage(this.imageFile).subscribe({
            next: response => {
              console.log('Upload Success:', response);
              this.imageUrl = response.path;
              this.processRecipe(); // Handle the recipe after uploading the image
            },

            error: err => {
              console.error('Upload Failed:', err);
              this.toastr.error('Image upload failed. Please try again.');
            }
          });
        } else {
          this.processRecipe();
        }
      }
    };
  }
  ngOnInit() {
    this.items = [{
      image: 'assets/images/proteins.png',
      placeholder: 'Proteins (g)',
      formControlName: new _angular_forms__WEBPACK_IMPORTED_MODULE_15__.FormControl('')
    }, {
      image: 'assets/images/lipid.png',
      placeholder: 'Lipides (g)',
      formControlName: new _angular_forms__WEBPACK_IMPORTED_MODULE_15__.FormControl('')
    }, {
      image: 'assets/images/carbohydrate.png',
      placeholder: 'Glucides (g)',
      formControlName: new _angular_forms__WEBPACK_IMPORTED_MODULE_15__.FormControl('')
    }, {
      image: 'assets/images/calories.png',
      placeholder: 'Calorie (Kcal)',
      formControlName: new _angular_forms__WEBPACK_IMPORTED_MODULE_15__.FormControl('')
    }];
    this.recipe = history.state.recipe;
    this.logger.info('Recipe:', this.recipe);
    if (this.recipe) {
      this.isEditMode = true;
      this.initializeForm(this.recipe);
    }
  }
  initializeForm(recipe) {
    this.imageUrl = recipe.imageUrl;
    this.titleControl.setValue(recipe.name);
    this.descriptionControl.setValue(recipe.description);
    this.nutritionstName = recipe.createdBy;
    this.categoryControl.setValue(recipe.category);
    this.objectifControl.setValue(recipe.objectif);
    this.preptimeControl.setValue(recipe.preparationTime);
    this.updateDetails(this.ingredients, recipe.ingredients);
    this.updateDetails(this.instructions, recipe.instructions);
    this.updateDetails(this.notes, recipe.cookingNotes);
    this.logger.info('hola form with recipe:', this.ingredients);
    const nutrients = [recipe.protein, recipe.fat, recipe.carbohydrates, recipe.calories];
    this.items.forEach((item, index) => {
      item.formControlName.setValue(nutrients[index]?.toString() || '0');
    });
  }
  updateDetails(listToUpdate, newList) {
    listToUpdate.splice(0, listToUpdate.length, ...newList);
  }
  selectImage(selectedImage) {
    this.imageFile = selectedImage;
    console.log('Selected image:', selectedImage.name);
  }
  createRecipeModel() {
    var _this = this;
    return (0,D_Code_angular_nutri_solution_Nutrisolutions_FRONT_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (!_this.isEditMode) {
        try {
          const response = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_18__.firstValueFrom)(_this.authService.getUserInfos());
          _this.nutritionstName = response?.name || '';
          console.log('Nutritionist:', _this.nutritionstName);
        } catch (error) {
          _this.toastr.error(src_app_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_1__.AppUtils.getErrorMessage(error), 'Error');
          throw error; // Or handle error as needed
        }
      }

      return {
        name: _this.titleControl.value || '',
        description: _this.descriptionControl.value || '',
        ingredients: _this.ingredients,
        imageUrl: _this.imageUrl,
        calories: parseInt(_this.items[3].formControlName.value || '0'),
        category: _this.categoryControl.value || src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_2__.CategoryEnum.DINER,
        objectif: _this.objectifControl.value || src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_2__.ObjectifEnum.ALL,
        preparationTime: _this.preptimeControl.value || src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_2__.PreparationTimeEnum.ALL,
        createdBy: _this.nutritionstName,
        createdAt: _this.isEditMode ? _this.recipe.createdAt : new Date(),
        protein: parseInt(_this.items[0].formControlName.value || '0'),
        fat: parseInt(_this.items[1].formControlName.value || '0'),
        carbohydrates: parseInt(_this.items[2].formControlName.value || '0'),
        instructions: _this.instructions,
        cookingNotes: _this.notes
      };
    })();
  }
  isButtonDisabled() {
    this.isFormInvalid = !this.titleControl.value || !this.objectifControl.value || !this.categoryControl.value || !this.descriptionControl.value || !this.imageUrl && !this.imageFile || !this.ingredients.length || !this.instructions.length || this.items.some(item => !item.formControlName.value);
    return this.isFormInvalid;
  }
  processRecipe() {
    var _this2 = this;
    return (0,D_Code_angular_nutri_solution_Nutrisolutions_FRONT_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const newRecipe = yield _this2.createRecipeModel();
      if (_this2.isEditMode) {
        newRecipe.id = _this2.recipe?.id; // Ensure the ID is set for updating
        _this2.logger.info('Edit Recipe:', newRecipe);
        _this2.recipesService.updateRecipe(newRecipe.id, newRecipe).subscribe({
          next: () => {
            _this2.toastr.success('Recipe updated successfully');
            _this2.router.navigate(['/recipes/recipe-details', newRecipe.id]);
          },
          error: err => {
            console.error('Update Failed:', err);
            _this2.toastr.error('Failed to update recipe');
          }
        });
      } else {
        _this2.logger.info('Add Recipe:', newRecipe);
        _this2.recipesService.addRecipe(newRecipe).subscribe({
          next: addedRecipe => {
            _this2.toastr.success('Recipe added successfully');
            _this2.router.navigate(['/recipes']);
          },
          error: err => {
            console.error('Add Failed:', err);
            _this2.toastr.error('Failed to add recipe');
          }
        });
      }
    })();
  }
  static {
    this.ɵfac = function AddRecipeComponent_Factory(t) {
      return new (t || AddRecipeComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdefineComponent"]({
      type: AddRecipeComponent,
      selectors: [["app-add-recipe"]],
      decls: 32,
      vars: 35,
      consts: [[1, "quote"], [3, "height", "width"], [1, "recipe-container"], [1, "first-section-recipe"], [1, "upload"], [3, "uploadedImage", "acceptedFileTypes", "fileSelected"], [1, "recipe-details"], [3, "placeholderColor", "fontWeight", "fontSize", "color", "control"], [1, "details-grid-container"], [1, "detail-item"], ["src", "assets/images/chef.png", "alt", "category"], [3, "name", "options", "formControlName"], ["src", "assets/images/goal.png", "alt", "goal"], ["class", "detail-item", 4, "ngFor", "ngForOf"], ["src", "assets/images/meal.png", "alt", "preptime"], [1, "separation-line"], [1, "second-section-recipe"], [3, "control", "placeholder"], [3, "details", "placeholder", "title", "enterPressed"], [3, "disabled", "text", "onClick", 4, "ngIf"], ["alt", "goal", 3, "src"], [3, "disabled", "text", "onClick"]],
      template: function AddRecipeComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "app-page-background")(1, "div", 0)(2, "h3");
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](3, "Manger sain, c'est prendre soin de soi avec chaque bouch\u00E9e");
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](4, "app-svg-box", 1)(5, "div", 2)(6, "div", 3)(7, "div", 4)(8, "app-upload-image", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("fileSelected", function AddRecipeComponent_Template_app_upload_image_fileSelected_8_listener($event) {
            return ctx.selectImage($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](9, "div", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](10, "app-input-field", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](11, "div", 8)(12, "div", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](13, "img", 10)(14, "app-dropdown", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](15, "div", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](16, "img", 12)(17, "app-dropdown", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](18, AddRecipeComponent_div_18_Template, 3, 3, "div", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](19, "div", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](20, "img", 14)(21, "app-dropdown", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](22, "div", 15);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](23, "div", 16)(24, "h2");
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](25, "Description:");
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](26, "app-input-field", 17);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](27, "app-recipe-description", 18);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("enterPressed", function AddRecipeComponent_Template_app_recipe_description_enterPressed_27_listener($event) {
            return ctx.updateDetails(ctx.ingredients, $event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](28, "app-recipe-description", 18);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("enterPressed", function AddRecipeComponent_Template_app_recipe_description_enterPressed_28_listener($event) {
            return ctx.updateDetails(ctx.instructions, $event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](29, "app-recipe-description", 18);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("enterPressed", function AddRecipeComponent_Template_app_recipe_description_enterPressed_29_listener($event) {
            return ctx.updateDetails(ctx.notes, $event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](30, AddRecipeComponent_app_button_30_Template, 1, 3, "app-button", 19);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](31, AddRecipeComponent_app_button_31_Template, 1, 3, "app-button", 19);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()()();
        }
        if (rf & 2) {
          let tmp_2_0;
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("height", "100%")("width", "95%");
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("uploadedImage", (tmp_2_0 = ctx.recipe == null ? null : ctx.recipe.imageUrl) !== null && tmp_2_0 !== undefined ? tmp_2_0 : "")("acceptedFileTypes", "image/*");
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("placeholderColor", "var(--brown)")("fontWeight", "bold")("fontSize", "26px")("color", "var(--brown)")("control", ctx.titleControl);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("name", "Cat\u00E9gorie")("options", ctx.categoryOptions)("formControlName", ctx.categoryControl);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("name", "Objectif")("options", ctx.objectifOptions)("formControlName", ctx.objectifControl);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngForOf", ctx.items);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("name", "Temps de pr\u00E9paration")("options", ctx.preptimeOptions)("formControlName", ctx.preptimeControl);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("control", ctx.descriptionControl)("placeholder", "Entrez une bri\u00E8ve description");
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("details", (ctx.recipe == null ? null : ctx.recipe.ingredients) || _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction0"](32, _c0))("placeholder", "Ajouter un ingr\u00E9dient")("title", "Ingr\u00E9dients :");
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("details", (ctx.recipe == null ? null : ctx.recipe.instructions) || _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction0"](33, _c0))("placeholder", "Ajouter une instruction")("title", "Instructions :");
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("details", (ctx.recipe == null ? null : ctx.recipe.cookingNotes) || _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction0"](34, _c0))("placeholder", "Ajouter une cooking Note")("title", "Cooking Note :");
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", !ctx.isEditMode);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", ctx.isEditMode);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_19__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_19__.NgIf, _shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_7__.ButtonComponent, _shared_components_svg_box_svg_box_component__WEBPACK_IMPORTED_MODULE_8__.SvgBoxComponent, _shared_components_page_background_page_background_component__WEBPACK_IMPORTED_MODULE_9__.PageBackgroundComponent, _shared_components_upload_image_upload_image_component__WEBPACK_IMPORTED_MODULE_10__.UploadImageComponent, _shared_components_dropdown_dropdown_component__WEBPACK_IMPORTED_MODULE_11__.DropdownComponent, _shared_components_input_field_input_field_component__WEBPACK_IMPORTED_MODULE_12__.InputFieldComponent, _shared_components_recipe_description_recipe_description_component__WEBPACK_IMPORTED_MODULE_13__.RecipeDescriptionComponent],
      styles: [".upload[_ngcontent-%COMP%] {\n  width: 35%;\n}\n.second-section-recipe[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  color: var(--brown);\n  font-weight: 600;\n  font-size: 26px;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvZmVhdHVyZXMvcmVjaXBlcy9hZGQtcmVjaXBlL2FkZC1yZWNpcGUuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFVBQVU7QUFDWjtBQUNBO0VBQ0UsbUJBQW1CO0VBQ25CLGdCQUFnQjtFQUNoQixlQUFlO0FBQ2pCIiwic291cmNlc0NvbnRlbnQiOlsiLnVwbG9hZCB7XHJcbiAgd2lkdGg6IDM1JTtcclxufVxyXG4uc2Vjb25kLXNlY3Rpb24tcmVjaXBlIGgyIHtcclxuICBjb2xvcjogdmFyKC0tYnJvd24pO1xyXG4gIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgZm9udC1zaXplOiAyNnB4O1xyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0= */", ".quote[_ngcontent-%COMP%] {\n  margin: auto;\n  width: 100%;\n  max-width: 21rem;\n  text-align: center;\n  white-space: normal;\n  line-height: 1.5;\n}\n.quote[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  font-family: \"Dancing Script\";\n  color: var(--primary-color);\n  font-size: 1.7rem;\n}\n\n.pagination[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n  justify-content: end;\n}\n.recipe-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  padding: 0 40px 40px 40px;\n  justify-content: start;\n  align-items: center;\n  gap: 20px;\n  width: 100%;\n}\n\n.first-section-recipe[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 30px;\n  align-items: center;\n  justify-content: center;\n  width: 100%;\n  margin-top: 15px;\n}\n.recipe-details[_ngcontent-%COMP%] {\n  height: 100%;\n  width: 65%;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  gap: 20px;\n  align-items: center;\n}\n.details-grid-container[_ngcontent-%COMP%] {\n  padding-top: 10px;\n  width: 100%;\n  display: grid;\n  grid-template-columns: repeat(auto-fit, 210px);\n  grid-template-rows: repeat(3, 50px);\n  justify-content: center;\n  row-gap: 10px;\n  column-gap: 20px;\n}\n.detail-item[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n}\n.detail-item[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 40px;\n  height: 40px;\n}\n.separation-line[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 0.5px;\n  background-color: var(--secondary-color);\n}\n.second-section-recipe[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n}\n.recipe-detail-item[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  gap: 15px;\n}\n.recipe-detail-item[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  color: var(--brown);\n  font-weight: 600;\n  font-size: 26px;\n}\n\n.detail-list[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  z-index: 1000;\n}\n.recipe-detail-item[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n  margin-bottom: 10px;\n}\n.detail-text[_ngcontent-%COMP%] {\n  font-weight: 500;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hc3NldHMvY3NzL2xpc3QtY29tbW9uLmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFlBQVk7RUFDWixXQUFXO0VBQ1gsZ0JBQWdCO0VBQ2hCLGtCQUFrQjtFQUNsQixtQkFBbUI7RUFDbkIsZ0JBQWdCO0FBQ2xCO0FBQ0E7RUFDRSw2QkFBNkI7RUFDN0IsMkJBQTJCO0VBQzNCLGlCQUFpQjtBQUNuQjs7QUFFQTtFQUNFLFdBQVc7RUFDWCxhQUFhO0VBQ2Isb0JBQW9CO0FBQ3RCO0FBQ0E7RUFDRSxhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLHlCQUF5QjtFQUN6QixzQkFBc0I7RUFDdEIsbUJBQW1CO0VBQ25CLFNBQVM7RUFDVCxXQUFXO0FBQ2I7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsU0FBUztFQUNULG1CQUFtQjtFQUNuQix1QkFBdUI7RUFDdkIsV0FBVztFQUNYLGdCQUFnQjtBQUNsQjtBQUNBO0VBQ0UsWUFBWTtFQUNaLFVBQVU7RUFDVixhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLHVCQUF1QjtFQUN2QixTQUFTO0VBQ1QsbUJBQW1CO0FBQ3JCO0FBQ0E7RUFDRSxpQkFBaUI7RUFDakIsV0FBVztFQUNYLGFBQWE7RUFDYiw4Q0FBOEM7RUFDOUMsbUNBQW1DO0VBQ25DLHVCQUF1QjtFQUN2QixhQUFhO0VBQ2IsZ0JBQWdCO0FBQ2xCO0FBQ0E7RUFDRSxhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLFNBQVM7QUFDWDtBQUNBO0VBQ0UsV0FBVztFQUNYLFlBQVk7QUFDZDtBQUNBO0VBQ0UsV0FBVztFQUNYLGFBQWE7RUFDYix3Q0FBd0M7QUFDMUM7QUFDQTtFQUNFLFdBQVc7RUFDWCxhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLFNBQVM7QUFDWDtBQUNBO0VBQ0UsYUFBYTtFQUNiLHNCQUFzQjtFQUN0Qix1QkFBdUI7RUFDdkIsU0FBUztBQUNYO0FBQ0E7RUFDRSxtQkFBbUI7RUFDbkIsZ0JBQWdCO0VBQ2hCLGVBQWU7QUFDakI7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLFNBQVM7RUFDVCxhQUFhO0FBQ2Y7QUFDQTtFQUNFLG1CQUFtQjtBQUNyQjtBQUNBO0VBQ0UsZ0JBQWdCO0FBQ2xCIiwic291cmNlc0NvbnRlbnQiOlsiLnF1b3RlIHtcclxuICBtYXJnaW46IGF1dG87XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgbWF4LXdpZHRoOiAyMXJlbTtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgd2hpdGUtc3BhY2U6IG5vcm1hbDtcclxuICBsaW5lLWhlaWdodDogMS41O1xyXG59XHJcbi5xdW90ZSBoMyB7XHJcbiAgZm9udC1mYW1pbHk6IFwiRGFuY2luZyBTY3JpcHRcIjtcclxuICBjb2xvcjogdmFyKC0tcHJpbWFyeS1jb2xvcik7XHJcbiAgZm9udC1zaXplOiAxLjdyZW07XHJcbn1cclxuXHJcbi5wYWdpbmF0aW9uIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogZW5kO1xyXG59XHJcbi5yZWNpcGUtY29udGFpbmVyIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgcGFkZGluZzogMCA0MHB4IDQwcHggNDBweDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHN0YXJ0O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgZ2FwOiAyMHB4O1xyXG4gIHdpZHRoOiAxMDAlO1xyXG59XHJcblxyXG4uZmlyc3Qtc2VjdGlvbi1yZWNpcGUge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZ2FwOiAzMHB4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgbWFyZ2luLXRvcDogMTVweDtcclxufVxyXG4ucmVjaXBlLWRldGFpbHMge1xyXG4gIGhlaWdodDogMTAwJTtcclxuICB3aWR0aDogNjUlO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBnYXA6IDIwcHg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG4uZGV0YWlscy1ncmlkLWNvbnRhaW5lciB7XHJcbiAgcGFkZGluZy10b3A6IDEwcHg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgZGlzcGxheTogZ3JpZDtcclxuICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IHJlcGVhdChhdXRvLWZpdCwgMjEwcHgpO1xyXG4gIGdyaWQtdGVtcGxhdGUtcm93czogcmVwZWF0KDMsIDUwcHgpO1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIHJvdy1nYXA6IDEwcHg7XHJcbiAgY29sdW1uLWdhcDogMjBweDtcclxufVxyXG4uZGV0YWlsLWl0ZW0ge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBnYXA6IDEwcHg7XHJcbn1cclxuLmRldGFpbC1pdGVtIGltZyB7XHJcbiAgd2lkdGg6IDQwcHg7XHJcbiAgaGVpZ2h0OiA0MHB4O1xyXG59XHJcbi5zZXBhcmF0aW9uLWxpbmUge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMC41cHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tc2Vjb25kYXJ5LWNvbG9yKTtcclxufVxyXG4uc2Vjb25kLXNlY3Rpb24tcmVjaXBlIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgZ2FwOiAxMHB4O1xyXG59XHJcbi5yZWNpcGUtZGV0YWlsLWl0ZW0ge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBnYXA6IDE1cHg7XHJcbn1cclxuLnJlY2lwZS1kZXRhaWwtaXRlbSBoMiB7XHJcbiAgY29sb3I6IHZhcigtLWJyb3duKTtcclxuICBmb250LXdlaWdodDogNjAwO1xyXG4gIGZvbnQtc2l6ZTogMjZweDtcclxufVxyXG5cclxuLmRldGFpbC1saXN0IHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgZ2FwOiAxMHB4O1xyXG4gIHotaW5kZXg6IDEwMDA7XHJcbn1cclxuLnJlY2lwZS1kZXRhaWwtaXRlbSBsaSB7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcclxufVxyXG4uZGV0YWlsLXRleHQge1xyXG4gIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 5404:
/*!*************************************************************************!*\
  !*** ./src/app/features/recipes/recette-item/recette-item.component.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RecetteItemComponent: () => (/* binding */ RecetteItemComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 5072);
/* harmony import */ var src_app_core_constants_constants_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/constants/constants.config */ 8111);
/* harmony import */ var src_app_services_logger_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/logger.service */ 4798);
/* harmony import */ var _shared_components_svg_box_svg_box_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../shared/components/svg-box/svg-box.component */ 6145);







const _c0 = function (a1) {
  return ["/recipes/recipe-details", a1];
};
class RecetteItemComponent {
  constructor() {
    this.base_url = src_app_core_constants_constants_config__WEBPACK_IMPORTED_MODULE_0__.APP_API.base_url;
    this.logger = (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.inject)(src_app_services_logger_service__WEBPACK_IMPORTED_MODULE_1__.LoggerService);
    this.router = (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.inject)(_angular_router__WEBPACK_IMPORTED_MODULE_4__.Router);
  }
  ngOnInit() {
    this.router.events.subscribe(event => {
      if (event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_4__.NavigationStart) {
        // Log when navigation starts
        this.logger.log(`Navigation started to: ${event.url}`);
      } else if (event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_4__.NavigationEnd) {
        // Log when navigation ends
        this.logger.log(`Navigation ended at: ${event.url}`);
      } else if (event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_4__.NavigationError) {
        // Log if there's an error in navigation
        this.logger.log(`Navigation error: ${event.error}`);
      }
    });
  }
  static {
    this.ɵfac = function RecetteItemComponent_Factory(t) {
      return new (t || RecetteItemComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
      type: RecetteItemComponent,
      selectors: [["app-recipe-item"]],
      inputs: {
        recipe: "recipe"
      },
      decls: 11,
      vars: 9,
      consts: [[3, "height", "width"], [1, "recette-item", 3, "routerLink"], [1, "recette-img"], ["alt", "", 3, "src"], [1, "recette-content"]],
      template: function RecetteItemComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "app-svg-box", 0)(1, "div", 1)(2, "div", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](3, "img", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "div", 4)(5, "h2");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](7, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](8);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](9, "h4");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](10);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("height", "100%")("width", "100%");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction1"](7, _c0, ctx.recipe.id));
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("src", ctx.base_url + ctx.recipe.imageUrl, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsanitizeUrl"]);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](ctx.recipe.name);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", ctx.recipe.description, " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"]("", ctx.recipe.calories, " Calories");
        }
      },
      dependencies: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterLink, _shared_components_svg_box_svg_box_component__WEBPACK_IMPORTED_MODULE_2__.SvgBoxComponent],
      styles: [".recette-item[_ngcontent-%COMP%] {\n  position: relative;\n  width: 100%;\n  height: 100%;\n  display: flex;\n  flex-direction: column;\n}\n.recette-item[_ngcontent-%COMP%]:hover    > .recette-img[_ngcontent-%COMP%] {\n  animation: _ngcontent-%COMP%_popOut 1s ease-out forwards;\n}\n\n@keyframes _ngcontent-%COMP%_popOut {\n  0% {\n    transform: perspective(500px) rotate3d(1, 0, 0, 0deg) scale(1);\n  }\n\n  100% {\n    transform: perspective(500px) rotate3d(1, 0, 0, 40deg) scale(1.3);\n  }\n}\n\n.recette-img[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 70%;\n  display: flex;\n  justify-content: center;\n  position: absolute;\n  top: -35%;\n}\n.recette-img[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  filter: drop-shadow(var(--drop-shadow));\n  width: 80%;\n}\n\n.recette-item[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  color: var(--primary-color);\n  font-size: clamp(16px, 4vw, 18px);\n  font-weight: 400;\n}\n.recette-item[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  display: -webkit-box; \n\n  -webkit-line-clamp: 2; \n\n  -webkit-box-orient: vertical;\n  text-overflow: ellipsis;\n  color: var(--brown);\n  font-size: clamp(9px, 12px, 1.4vw);\n  overflow: hidden;\n  font-weight: 400;\n}\n.recette-item[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  color: var(--secondary-color);\n  font-size: 0.8rem;\n  font-weight: 400;\n  text-overflow: ellipsis;\n}\n\n.recette-content[_ngcontent-%COMP%] {\n  margin-top: auto;\n  height: 100%;\n  width: 100%;\n  padding: 15px;\n  display: flex;\n  flex-direction: column;\n  justify-content: end;\n  overflow: hidden;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvZmVhdHVyZXMvcmVjaXBlcy9yZWNldHRlLWl0ZW0vcmVjZXR0ZS1pdGVtLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxrQkFBa0I7RUFDbEIsV0FBVztFQUNYLFlBQVk7RUFDWixhQUFhO0VBQ2Isc0JBQXNCO0FBQ3hCO0FBQ0E7RUFDRSxzQ0FBc0M7QUFDeEM7O0FBRUE7RUFDRTtJQUNFLDhEQUE4RDtFQUNoRTs7RUFFQTtJQUNFLGlFQUFpRTtFQUNuRTtBQUNGOztBQUVBO0VBQ0UsV0FBVztFQUNYLFdBQVc7RUFDWCxhQUFhO0VBQ2IsdUJBQXVCO0VBQ3ZCLGtCQUFrQjtFQUNsQixTQUFTO0FBQ1g7QUFDQTtFQUNFLHVDQUF1QztFQUN2QyxVQUFVO0FBQ1o7O0FBRUE7RUFDRSwyQkFBMkI7RUFDM0IsaUNBQWlDO0VBQ2pDLGdCQUFnQjtBQUNsQjtBQUNBO0VBQ0Usb0JBQW9CLEVBQUUsaURBQWlEO0VBQ3ZFLHFCQUFxQixFQUFFLHFCQUFxQjtFQUM1Qyw0QkFBNEI7RUFDNUIsdUJBQXVCO0VBQ3ZCLG1CQUFtQjtFQUNuQixrQ0FBa0M7RUFDbEMsZ0JBQWdCO0VBQ2hCLGdCQUFnQjtBQUNsQjtBQUNBO0VBQ0UsNkJBQTZCO0VBQzdCLGlCQUFpQjtFQUNqQixnQkFBZ0I7RUFDaEIsdUJBQXVCO0FBQ3pCOztBQUVBO0VBQ0UsZ0JBQWdCO0VBQ2hCLFlBQVk7RUFDWixXQUFXO0VBQ1gsYUFBYTtFQUNiLGFBQWE7RUFDYixzQkFBc0I7RUFDdEIsb0JBQW9CO0VBQ3BCLGdCQUFnQjtBQUNsQiIsInNvdXJjZXNDb250ZW50IjpbIi5yZWNldHRlLWl0ZW0ge1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG59XHJcbi5yZWNldHRlLWl0ZW06aG92ZXIgPiAucmVjZXR0ZS1pbWcge1xyXG4gIGFuaW1hdGlvbjogcG9wT3V0IDFzIGVhc2Utb3V0IGZvcndhcmRzO1xyXG59XHJcblxyXG5Aa2V5ZnJhbWVzIHBvcE91dCB7XHJcbiAgMCUge1xyXG4gICAgdHJhbnNmb3JtOiBwZXJzcGVjdGl2ZSg1MDBweCkgcm90YXRlM2QoMSwgMCwgMCwgMGRlZykgc2NhbGUoMSk7XHJcbiAgfVxyXG5cclxuICAxMDAlIHtcclxuICAgIHRyYW5zZm9ybTogcGVyc3BlY3RpdmUoNTAwcHgpIHJvdGF0ZTNkKDEsIDAsIDAsIDQwZGVnKSBzY2FsZSgxLjMpO1xyXG4gIH1cclxufVxyXG5cclxuLnJlY2V0dGUtaW1nIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDcwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB0b3A6IC0zNSU7XHJcbn1cclxuLnJlY2V0dGUtaW1nIGltZyB7XHJcbiAgZmlsdGVyOiBkcm9wLXNoYWRvdyh2YXIoLS1kcm9wLXNoYWRvdykpO1xyXG4gIHdpZHRoOiA4MCU7XHJcbn1cclxuXHJcbi5yZWNldHRlLWl0ZW0gaDIge1xyXG4gIGNvbG9yOiB2YXIoLS1wcmltYXJ5LWNvbG9yKTtcclxuICBmb250LXNpemU6IGNsYW1wKDE2cHgsIDR2dywgMThweCk7XHJcbiAgZm9udC13ZWlnaHQ6IDQwMDtcclxufVxyXG4ucmVjZXR0ZS1pdGVtIHAge1xyXG4gIGRpc3BsYXk6IC13ZWJraXQtYm94OyAvKiBGbGV4Ym94LWxpa2UgYmVoYXZpb3IgZm9yIG11bHRpbGluZSBlbGxpcHNpcyAqL1xyXG4gIC13ZWJraXQtbGluZS1jbGFtcDogMjsgLyogTGltaXQgdG8gMiBsaW5lcyAqL1xyXG4gIC13ZWJraXQtYm94LW9yaWVudDogdmVydGljYWw7XHJcbiAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XHJcbiAgY29sb3I6IHZhcigtLWJyb3duKTtcclxuICBmb250LXNpemU6IGNsYW1wKDlweCwgMTJweCwgMS40dncpO1xyXG4gIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgZm9udC13ZWlnaHQ6IDQwMDtcclxufVxyXG4ucmVjZXR0ZS1pdGVtIGg0IHtcclxuICBjb2xvcjogdmFyKC0tc2Vjb25kYXJ5LWNvbG9yKTtcclxuICBmb250LXNpemU6IDAuOHJlbTtcclxuICBmb250LXdlaWdodDogNDAwO1xyXG4gIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xyXG59XHJcblxyXG4ucmVjZXR0ZS1jb250ZW50IHtcclxuICBtYXJnaW4tdG9wOiBhdXRvO1xyXG4gIGhlaWdodDogMTAwJTtcclxuICB3aWR0aDogMTAwJTtcclxuICBwYWRkaW5nOiAxNXB4O1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGVuZDtcclxuICBvdmVyZmxvdzogaGlkZGVuO1xyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
    });
  }
}

/***/ }),

/***/ 2561:
/*!***************************************************************************************!*\
  !*** ./src/app/features/recipes/recipe-details-item/recipe-details-item.component.ts ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RecipeDetailsItemComponent: () => (/* binding */ RecipeDetailsItemComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 316);


const _c0 = function (a0) {
  return {
    "active": a0
  };
};
function RecipeDetailsItemComponent_li_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "li")(1, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function RecipeDetailsItemComponent_li_4_Template_div_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r4);
      const i_r2 = restoredCtx.index;
      const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r3.toggleDetail(i_r2));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "span", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const detail_r1 = ctx.$implicit;
    const i_r2 = ctx.index;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](5, _c0, ctx_r0.isDetailChecked(i_r2)));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", i_r2 + 1, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("strikethrough", ctx_r0.isDetailChecked(i_r2));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", detail_r1, " ");
  }
}
class RecipeDetailsItemComponent {
  constructor() {
    this.title = '';
    this.details = [];
    this.checkedDetails = new Set();
  }
  toggleDetail(index) {
    if (this.checkedDetails.has(index)) {
      this.checkedDetails.delete(index);
    } else {
      this.checkedDetails.add(index);
    }
  }
  // Method to check if the instruction is checked
  isDetailChecked(index) {
    return this.checkedDetails.has(index);
  }
  static {
    this.ɵfac = function RecipeDetailsItemComponent_Factory(t) {
      return new (t || RecipeDetailsItemComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: RecipeDetailsItemComponent,
      selectors: [["app-recipe-details-item"]],
      inputs: {
        title: "title",
        details: "details"
      },
      decls: 5,
      vars: 2,
      consts: [[1, "recipe-detail-item"], [4, "ngFor", "ngForOf"], [1, "detail-list", 3, "click"], [1, "number-box", 3, "ngClass"], [1, "detail-text"]],
      template: function RecipeDetailsItemComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "h2");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "ul");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, RecipeDetailsItemComponent_li_4_Template, 6, 7, "li", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.title);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.details);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgForOf],
      styles: [".number-box[_ngcontent-%COMP%] {\n  width: 30px;\n  height: 30px;\n  background-color: white;\n  color: var(--secondary-color);\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  border-radius: 4px;\n  margin-right: 10px;\n  font-weight: bold;\n  font-size: 18px;\n}\n\n.number-box.active[_ngcontent-%COMP%] {\n  background-color: var(--secondary-color);\n  color: white;\n}\n\n.detail-text.strikethrough[_ngcontent-%COMP%] {\n  text-decoration: line-through;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvZmVhdHVyZXMvcmVjaXBlcy9yZWNpcGUtZGV0YWlscy1pdGVtL3JlY2lwZS1kZXRhaWxzLWl0ZW0uY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFdBQVc7RUFDWCxZQUFZO0VBQ1osdUJBQXVCO0VBQ3ZCLDZCQUE2QjtFQUM3QixhQUFhO0VBQ2IsdUJBQXVCO0VBQ3ZCLG1CQUFtQjtFQUNuQixrQkFBa0I7RUFDbEIsa0JBQWtCO0VBQ2xCLGlCQUFpQjtFQUNqQixlQUFlO0FBQ2pCOztBQUVBO0VBQ0Usd0NBQXdDO0VBQ3hDLFlBQVk7QUFDZDs7QUFFQTtFQUNFLDZCQUE2QjtBQUMvQiIsInNvdXJjZXNDb250ZW50IjpbIi5udW1iZXItYm94IHtcclxuICB3aWR0aDogMzBweDtcclxuICBoZWlnaHQ6IDMwcHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgY29sb3I6IHZhcigtLXNlY29uZGFyeS1jb2xvcik7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgZm9udC1zaXplOiAxOHB4O1xyXG59XHJcblxyXG4ubnVtYmVyLWJveC5hY3RpdmUge1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLXNlY29uZGFyeS1jb2xvcik7XHJcbiAgY29sb3I6IHdoaXRlO1xyXG59XHJcblxyXG4uZGV0YWlsLXRleHQuc3RyaWtldGhyb3VnaCB7XHJcbiAgdGV4dC1kZWNvcmF0aW9uOiBsaW5lLXRocm91Z2g7XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */", ".quote[_ngcontent-%COMP%] {\n  margin: auto;\n  width: 100%;\n  max-width: 21rem;\n  text-align: center;\n  white-space: normal;\n  line-height: 1.5;\n}\n.quote[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  font-family: \"Dancing Script\";\n  color: var(--primary-color);\n  font-size: 1.7rem;\n}\n\n.pagination[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n  justify-content: end;\n}\n.recipe-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  padding: 0 40px 40px 40px;\n  justify-content: start;\n  align-items: center;\n  gap: 20px;\n  width: 100%;\n}\n\n.first-section-recipe[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 30px;\n  align-items: center;\n  justify-content: center;\n  width: 100%;\n  margin-top: 15px;\n}\n.recipe-details[_ngcontent-%COMP%] {\n  height: 100%;\n  width: 65%;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  gap: 20px;\n  align-items: center;\n}\n.details-grid-container[_ngcontent-%COMP%] {\n  padding-top: 10px;\n  width: 100%;\n  display: grid;\n  grid-template-columns: repeat(auto-fit, 210px);\n  grid-template-rows: repeat(3, 50px);\n  justify-content: center;\n  row-gap: 10px;\n  column-gap: 20px;\n}\n.detail-item[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n}\n.detail-item[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 40px;\n  height: 40px;\n}\n.separation-line[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 0.5px;\n  background-color: var(--secondary-color);\n}\n.second-section-recipe[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n}\n.recipe-detail-item[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  gap: 15px;\n}\n.recipe-detail-item[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  color: var(--brown);\n  font-weight: 600;\n  font-size: 26px;\n}\n\n.detail-list[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  z-index: 1000;\n}\n.recipe-detail-item[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n  margin-bottom: 10px;\n}\n.detail-text[_ngcontent-%COMP%] {\n  font-weight: 500;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hc3NldHMvY3NzL2xpc3QtY29tbW9uLmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFlBQVk7RUFDWixXQUFXO0VBQ1gsZ0JBQWdCO0VBQ2hCLGtCQUFrQjtFQUNsQixtQkFBbUI7RUFDbkIsZ0JBQWdCO0FBQ2xCO0FBQ0E7RUFDRSw2QkFBNkI7RUFDN0IsMkJBQTJCO0VBQzNCLGlCQUFpQjtBQUNuQjs7QUFFQTtFQUNFLFdBQVc7RUFDWCxhQUFhO0VBQ2Isb0JBQW9CO0FBQ3RCO0FBQ0E7RUFDRSxhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLHlCQUF5QjtFQUN6QixzQkFBc0I7RUFDdEIsbUJBQW1CO0VBQ25CLFNBQVM7RUFDVCxXQUFXO0FBQ2I7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsU0FBUztFQUNULG1CQUFtQjtFQUNuQix1QkFBdUI7RUFDdkIsV0FBVztFQUNYLGdCQUFnQjtBQUNsQjtBQUNBO0VBQ0UsWUFBWTtFQUNaLFVBQVU7RUFDVixhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLHVCQUF1QjtFQUN2QixTQUFTO0VBQ1QsbUJBQW1CO0FBQ3JCO0FBQ0E7RUFDRSxpQkFBaUI7RUFDakIsV0FBVztFQUNYLGFBQWE7RUFDYiw4Q0FBOEM7RUFDOUMsbUNBQW1DO0VBQ25DLHVCQUF1QjtFQUN2QixhQUFhO0VBQ2IsZ0JBQWdCO0FBQ2xCO0FBQ0E7RUFDRSxhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLFNBQVM7QUFDWDtBQUNBO0VBQ0UsV0FBVztFQUNYLFlBQVk7QUFDZDtBQUNBO0VBQ0UsV0FBVztFQUNYLGFBQWE7RUFDYix3Q0FBd0M7QUFDMUM7QUFDQTtFQUNFLFdBQVc7RUFDWCxhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLFNBQVM7QUFDWDtBQUNBO0VBQ0UsYUFBYTtFQUNiLHNCQUFzQjtFQUN0Qix1QkFBdUI7RUFDdkIsU0FBUztBQUNYO0FBQ0E7RUFDRSxtQkFBbUI7RUFDbkIsZ0JBQWdCO0VBQ2hCLGVBQWU7QUFDakI7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLFNBQVM7RUFDVCxhQUFhO0FBQ2Y7QUFDQTtFQUNFLG1CQUFtQjtBQUNyQjtBQUNBO0VBQ0UsZ0JBQWdCO0FBQ2xCIiwic291cmNlc0NvbnRlbnQiOlsiLnF1b3RlIHtcclxuICBtYXJnaW46IGF1dG87XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgbWF4LXdpZHRoOiAyMXJlbTtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgd2hpdGUtc3BhY2U6IG5vcm1hbDtcclxuICBsaW5lLWhlaWdodDogMS41O1xyXG59XHJcbi5xdW90ZSBoMyB7XHJcbiAgZm9udC1mYW1pbHk6IFwiRGFuY2luZyBTY3JpcHRcIjtcclxuICBjb2xvcjogdmFyKC0tcHJpbWFyeS1jb2xvcik7XHJcbiAgZm9udC1zaXplOiAxLjdyZW07XHJcbn1cclxuXHJcbi5wYWdpbmF0aW9uIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogZW5kO1xyXG59XHJcbi5yZWNpcGUtY29udGFpbmVyIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgcGFkZGluZzogMCA0MHB4IDQwcHggNDBweDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHN0YXJ0O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgZ2FwOiAyMHB4O1xyXG4gIHdpZHRoOiAxMDAlO1xyXG59XHJcblxyXG4uZmlyc3Qtc2VjdGlvbi1yZWNpcGUge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZ2FwOiAzMHB4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgbWFyZ2luLXRvcDogMTVweDtcclxufVxyXG4ucmVjaXBlLWRldGFpbHMge1xyXG4gIGhlaWdodDogMTAwJTtcclxuICB3aWR0aDogNjUlO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBnYXA6IDIwcHg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG4uZGV0YWlscy1ncmlkLWNvbnRhaW5lciB7XHJcbiAgcGFkZGluZy10b3A6IDEwcHg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgZGlzcGxheTogZ3JpZDtcclxuICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IHJlcGVhdChhdXRvLWZpdCwgMjEwcHgpO1xyXG4gIGdyaWQtdGVtcGxhdGUtcm93czogcmVwZWF0KDMsIDUwcHgpO1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIHJvdy1nYXA6IDEwcHg7XHJcbiAgY29sdW1uLWdhcDogMjBweDtcclxufVxyXG4uZGV0YWlsLWl0ZW0ge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBnYXA6IDEwcHg7XHJcbn1cclxuLmRldGFpbC1pdGVtIGltZyB7XHJcbiAgd2lkdGg6IDQwcHg7XHJcbiAgaGVpZ2h0OiA0MHB4O1xyXG59XHJcbi5zZXBhcmF0aW9uLWxpbmUge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMC41cHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tc2Vjb25kYXJ5LWNvbG9yKTtcclxufVxyXG4uc2Vjb25kLXNlY3Rpb24tcmVjaXBlIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgZ2FwOiAxMHB4O1xyXG59XHJcbi5yZWNpcGUtZGV0YWlsLWl0ZW0ge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBnYXA6IDE1cHg7XHJcbn1cclxuLnJlY2lwZS1kZXRhaWwtaXRlbSBoMiB7XHJcbiAgY29sb3I6IHZhcigtLWJyb3duKTtcclxuICBmb250LXdlaWdodDogNjAwO1xyXG4gIGZvbnQtc2l6ZTogMjZweDtcclxufVxyXG5cclxuLmRldGFpbC1saXN0IHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgZ2FwOiAxMHB4O1xyXG4gIHotaW5kZXg6IDEwMDA7XHJcbn1cclxuLnJlY2lwZS1kZXRhaWwtaXRlbSBsaSB7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcclxufVxyXG4uZGV0YWlsLXRleHQge1xyXG4gIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 7798:
/*!*****************************************************************************!*\
  !*** ./src/app/features/recipes/recipe-details/recipe-details.component.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RecipeDetailsComponent: () => (/* binding */ RecipeDetailsComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 5072);
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ngx-toastr */ 4285);
/* harmony import */ var src_app_core_constants_constants_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/constants/constants.config */ 8111);
/* harmony import */ var src_app_models_client_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/models/client.model */ 4477);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/auth.service */ 4796);
/* harmony import */ var src_app_services_client_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/client.service */ 8281);
/* harmony import */ var src_app_services_recipe_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/recipe.service */ 4964);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _shared_components_svg_box_svg_box_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../shared/components/svg-box/svg-box.component */ 6145);
/* harmony import */ var _shared_components_page_background_page_background_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../shared/components/page-background/page-background.component */ 1469);
/* harmony import */ var _recipe_details_item_recipe_details_item_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../recipe-details-item/recipe-details-item.component */ 2561);














function RecipeDetailsComponent_div_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](1, "img", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](2, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const item_r5 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("src", item_r5.image, _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate"](item_r5.content);
  }
}
function RecipeDetailsComponent_button_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "button", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function RecipeDetailsComponent_button_15_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r7);
      const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵresetView"](ctx_r6.deleteRecipe());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](1, "img", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](2, " Delete recipe ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }
}
function RecipeDetailsComponent_button_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "button", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function RecipeDetailsComponent_button_16_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r9);
      const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵresetView"](ctx_r8.addToFavourite());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](1, "img", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](2, " Add to favorite ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }
}
const _c0 = function (a0) {
  return {
    recipe: a0
  };
};
function RecipeDetailsComponent_button_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "button", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](1, "img", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](2, " Edit Recipe ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("routerLink", "../../edit-recipe")("state", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction1"](2, _c0, ctx_r3.recipe));
  }
}
function RecipeDetailsComponent_li_24_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "li")(1, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](2, "input", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](3, "span", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ingredient_r10 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate"](ingredient_r10);
  }
}
const _c1 = function () {
  return [];
};
class RecipeDetailsComponent {
  constructor() {
    this.base_url = src_app_core_constants_constants_config__WEBPACK_IMPORTED_MODULE_0__.APP_API.base_url;
    this.items = []; // Additional recipe details
    this.recipeId = '';
    this.route = (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.inject)(_angular_router__WEBPACK_IMPORTED_MODULE_9__.ActivatedRoute);
    this.router = (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.inject)(_angular_router__WEBPACK_IMPORTED_MODULE_9__.Router);
    this.toastr = (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.inject)(ngx_toastr__WEBPACK_IMPORTED_MODULE_10__.ToastrService);
    this.clientService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.inject)(src_app_services_client_service__WEBPACK_IMPORTED_MODULE_3__.ClientService);
    this.authService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.inject)(src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService);
    this.buttons = [{
      image: 'assets/images/downloads.png',
      text: 'Download recipe'
    }, {
      image: 'assets/images/favourite.png',
      text: 'Add to favorite'
    },
    // { image: 'assets/images/question.png', text: 'Ask question' },
    {
      image: 'assets/images/question.png',
      text: 'Edit Recipe'
    }];
    this.recipesService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.inject)(src_app_services_recipe_service__WEBPACK_IMPORTED_MODULE_4__.RecipesService);
    this.checkedInstructions = new Set(); // Set to track checked instructions
    this.role = src_app_models_client_model__WEBPACK_IMPORTED_MODULE_1__.UserRoleEnum.CLIENT;
  }
  // Method to toggle the instruction state (checked or unchecked)
  toggleInstruction(index) {
    if (this.checkedInstructions.has(index)) {
      this.checkedInstructions.delete(index); // Uncheck if already checked
    } else {
      this.checkedInstructions.add(index); // Check the instruction
    }
  }
  // Method to check if the instruction is checked
  isInstructionChecked(index) {
    return this.checkedInstructions.has(index);
  }
  ngOnInit() {
    this.recipeId = this.route.snapshot.paramMap.get('id');
    console.log('Recipe ID:', this.recipeId);
    this.loadRecipe(this.recipeId || '');
    this.role = this.authService.getUserRole();
  }
  loadRecipe(id) {
    this.recipesService.getRecipeById(id).subscribe(recipe => {
      this.recipe = recipe;
      this.populateItems();
    });
  }
  populateItems() {
    if (!this.recipe) return;
    this.items = [{
      image: 'assets/images/doctor.png',
      content: 'Dr. ' + this.recipe.createdBy || 0
    }, {
      image: 'assets/images/goal.png',
      content: this.recipe.objectif || 'No objective provided'
    }, {
      image: 'assets/images/chef.png',
      content: this.recipe.category || 'Uncategorized'
    }, {
      image: 'assets/images/meal.png',
      content: this.recipe.preparationTime || 'N/A'
    }, {
      image: 'assets/images/proteins.png',
      content: `${this.recipe.protein || 0} grammes`
    }, {
      image: 'assets/images/lipid.png',
      content: `${this.recipe.fat || 0} grammes`
    }, {
      image: 'assets/images/carbohydrate.png',
      content: `${this.recipe.carbohydrates || 0} grammes`
    }, {
      image: 'assets/images/calories.png',
      content: `${this.recipe.calories || 0} calories`
    }];
  }
  deleteRecipe() {
    if (this.recipeId) {
      this.recipesService.deleteRecipe(this.recipeId).subscribe(response => {
        this.toastr.success('Recipe deleted successfully');
        this.router.navigate(['/recipes']);
      }, error => {
        this.toastr.error('Error deleting recipe');
        console.error('Error deleting recipe:', error);
      });
    }
  }
  addToFavourite() {
    this.clientService.addRecipeToFavourite(this.recipeId, this.authService.getUserId()).subscribe({
      next: client => {
        this.toastr.success('Recipe added to favourite');
      },
      error: error => {
        this.toastr.error('Error adding recipe to favourite');
        console.error('Error adding recipe to favourite:', error);
      }
    });
  }
  showFavoriteButton() {
    if (this.recipe) return this.role === src_app_models_client_model__WEBPACK_IMPORTED_MODULE_1__.UserRoleEnum.CLIENT && !this.recipe.favoritedByClient?.some(client => client.id === this.authService.getUserId());
    return true;
  }
  static {
    this.ɵfac = function RecipeDetailsComponent_Factory(t) {
      return new (t || RecipeDetailsComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineComponent"]({
      type: RecipeDetailsComponent,
      selectors: [["app-recipe-details"]],
      decls: 27,
      vars: 15,
      consts: [[1, "quote"], [3, "height", "width"], [1, "recipe-container"], [1, "first-section-recipe"], [1, "img-container"], ["alt", "recipe_image", 3, "src"], [1, "recipe-details"], [1, "details-grid-container"], ["class", "detail-item", 4, "ngFor", "ngForOf"], [1, "button-container"], ["class", "recipe-button", 3, "click", 4, "ngIf"], ["class", "recipe-button", 3, "routerLink", "state", 4, "ngIf"], [1, "separation-line"], [1, "second-section-recipe"], [1, "recipe-detail-item"], [4, "ngFor", "ngForOf"], [3, "title", "details"], [1, "detail-item"], ["alt", "goal", 3, "src"], [1, "recipe-button", 3, "click"], ["src", "assets/images/delete.png", "alt", "Button Icon"], ["src", "assets/images/favourite.png", "alt", "Button Icon"], [1, "recipe-button", 3, "routerLink", "state"], ["src", "assets/images/question.png", "alt", "Button Icon"], [1, "detail-list"], ["type", "checkbox"], [1, "detail-text"]],
      template: function RecipeDetailsComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "app-page-background")(1, "div", 0)(2, "h3");
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](3, "Manger sain, c'est prendre soin de soi avec chaque bouch\u00E9e");
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](4, "app-svg-box", 1)(5, "div", 2)(6, "div", 3)(7, "div", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](8, "img", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](9, "div", 6)(10, "h2");
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](11);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](12, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](13, RecipeDetailsComponent_div_13_Template, 4, 2, "div", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](14, "div", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](15, RecipeDetailsComponent_button_15_Template, 3, 0, "button", 10);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](16, RecipeDetailsComponent_button_16_Template, 3, 0, "button", 10);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](17, RecipeDetailsComponent_button_17_Template, 3, 4, "button", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](18, "div", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](19, "div", 13)(20, "div", 14)(21, "h2");
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](22, "Ingr\u00E9dients :");
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](23, "ul");
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](24, RecipeDetailsComponent_li_24_Template, 5, 1, "li", 15);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](25, "app-recipe-details-item", 16)(26, "app-recipe-details-item", 16);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("height", "100%")("width", "95%");
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("src", ctx.base_url + (ctx.recipe == null ? null : ctx.recipe.imageUrl), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵsanitizeUrl"]);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate"](ctx.recipe == null ? null : ctx.recipe.name);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngForOf", ctx.items);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.role == "Nutritionist");
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.showFavoriteButton());
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.role == "Nutritionist");
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](7);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngForOf", ctx.recipe == null ? null : ctx.recipe.ingredients);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("title", "Instructions :")("details", (ctx.recipe == null ? null : ctx.recipe.instructions) || _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction0"](13, _c1));
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("title", "Cooking Notes :")("details", (ctx.recipe == null ? null : ctx.recipe.cookingNotes) || _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction0"](14, _c1));
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_11__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_11__.NgIf, _shared_components_svg_box_svg_box_component__WEBPACK_IMPORTED_MODULE_5__.SvgBoxComponent, _shared_components_page_background_page_background_component__WEBPACK_IMPORTED_MODULE_6__.PageBackgroundComponent, _angular_router__WEBPACK_IMPORTED_MODULE_9__.RouterLink, _recipe_details_item_recipe_details_item_component__WEBPACK_IMPORTED_MODULE_7__.RecipeDetailsItemComponent],
      styles: [".img-container[_ngcontent-%COMP%] {\n  width: 35%;\n  display: flex;\n  justify-content: center;\n}\n\n.img-container[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  height: 250px;\n  width: 250px;\n}\n\n.recipe-details[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  align-self: flex-start;\n  color: var(--brown);\n  font-size: 26px;\n}\n\n.detail-item[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  font-weight: 500;\n  font-size: 18px;\n}\n.button-container[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 35px;\n}\n.recipe-button[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 10px;\n  background-color: var(--secondary-color);\n  border-radius: 10px;\n  color: white;\n  padding: 0.7rem 1rem 0.7rem 1rem;\n  align-items: center;\n  border: none;\n  cursor: \"pointer\";\n  transition: \"border-color 0.3s ease\";\n  position: relative;\n  overflow: hidden;\n  &::before {\n    content: \"\";\n    position: absolute;\n    top: 0;\n    left: -100%;\n    width: 100%;\n    height: 100%;\n    background: linear-gradient(\n      120deg,\n      transparent,\n      rgba(255, 255, 255, 0.2),\n      transparent\n    );\n\n    transition: all 0.65s ease-in-out;\n  }\n  &:hover::before {\n    left: 100%;\n  }\n}\n\n.recipe-button[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  height: 20px;\n  width: 20px;\n}\n\n.checkbox[_ngcontent-%COMP%] {\n  display: flex;\n}\n.checkbox[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  margin-left: 5px;\n  color: var(--hint-text);\n}\ninput[type=\"checkbox\"][_ngcontent-%COMP%] {\n  appearance: none;\n  width: 30px;\n  height: 30px;\n  border: 2px solid var(--hint-text);\n  border-radius: 4px;\n  background-color: white;\n  cursor: pointer;\n}\n\ninput[type=\"checkbox\"][_ngcontent-%COMP%]:checked {\n  background-color: var(--secondary-color);\n  border-color: var(--secondary-color);\n  background-image: url('data:image/svg+xml;utf8,<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><path d=\"M20 6L9 17l-5-5\" fill=\"none\" stroke=\"white\" stroke-width=\"2\"/></svg>');\n  background-position: center;\n  background-repeat: no-repeat;\n  background-size: 25px;\n}\n\n.detail-list[_ngcontent-%COMP%]   input[type=\"checkbox\"][_ngcontent-%COMP%]:checked    + .detail-text[_ngcontent-%COMP%] {\n  text-decoration: line-through;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvZmVhdHVyZXMvcmVjaXBlcy9yZWNpcGUtZGV0YWlscy9yZWNpcGUtZGV0YWlscy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsVUFBVTtFQUNWLGFBQWE7RUFDYix1QkFBdUI7QUFDekI7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsWUFBWTtBQUNkOztBQUVBO0VBQ0Usc0JBQXNCO0VBQ3RCLG1CQUFtQjtFQUNuQixlQUFlO0FBQ2pCOztBQUVBO0VBQ0UsZ0JBQWdCO0VBQ2hCLGVBQWU7QUFDakI7QUFDQTtFQUNFLGFBQWE7RUFDYixTQUFTO0FBQ1g7QUFDQTtFQUNFLGFBQWE7RUFDYixTQUFTO0VBQ1Qsd0NBQXdDO0VBQ3hDLG1CQUFtQjtFQUNuQixZQUFZO0VBQ1osZ0NBQWdDO0VBQ2hDLG1CQUFtQjtFQUNuQixZQUFZO0VBQ1osaUJBQWlCO0VBQ2pCLG9DQUFvQztFQUNwQyxrQkFBa0I7RUFDbEIsZ0JBQWdCO0VBQ2hCO0lBQ0UsV0FBVztJQUNYLGtCQUFrQjtJQUNsQixNQUFNO0lBQ04sV0FBVztJQUNYLFdBQVc7SUFDWCxZQUFZO0lBQ1o7Ozs7O0tBS0M7O0lBRUQsaUNBQWlDO0VBQ25DO0VBQ0E7SUFDRSxVQUFVO0VBQ1o7QUFDRjs7QUFFQTtFQUNFLFlBQVk7RUFDWixXQUFXO0FBQ2I7O0FBRUE7RUFDRSxhQUFhO0FBQ2Y7QUFDQTtFQUNFLGdCQUFnQjtFQUNoQix1QkFBdUI7QUFDekI7QUFDQTtFQUdFLGdCQUFnQjtFQUNoQixXQUFXO0VBQ1gsWUFBWTtFQUNaLGtDQUFrQztFQUNsQyxrQkFBa0I7RUFDbEIsdUJBQXVCO0VBQ3ZCLGVBQWU7QUFDakI7O0FBRUE7RUFDRSx3Q0FBd0M7RUFDeEMsb0NBQW9DO0VBQ3BDLDBMQUEwTDtFQUMxTCwyQkFBMkI7RUFDM0IsNEJBQTRCO0VBQzVCLHFCQUFxQjtBQUN2Qjs7QUFFQTtFQUNFLDZCQUE2QjtBQUMvQiIsInNvdXJjZXNDb250ZW50IjpbIi5pbWctY29udGFpbmVyIHtcclxuICB3aWR0aDogMzUlO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbn1cclxuXHJcbi5pbWctY29udGFpbmVyIGltZyB7XHJcbiAgaGVpZ2h0OiAyNTBweDtcclxuICB3aWR0aDogMjUwcHg7XHJcbn1cclxuXHJcbi5yZWNpcGUtZGV0YWlscyBoMiB7XHJcbiAgYWxpZ24tc2VsZjogZmxleC1zdGFydDtcclxuICBjb2xvcjogdmFyKC0tYnJvd24pO1xyXG4gIGZvbnQtc2l6ZTogMjZweDtcclxufVxyXG5cclxuLmRldGFpbC1pdGVtIGgzIHtcclxuICBmb250LXdlaWdodDogNTAwO1xyXG4gIGZvbnQtc2l6ZTogMThweDtcclxufVxyXG4uYnV0dG9uLWNvbnRhaW5lciB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBnYXA6IDM1cHg7XHJcbn1cclxuLnJlY2lwZS1idXR0b24ge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZ2FwOiAxMHB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLXNlY29uZGFyeS1jb2xvcik7XHJcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICBjb2xvcjogd2hpdGU7XHJcbiAgcGFkZGluZzogMC43cmVtIDFyZW0gMC43cmVtIDFyZW07XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBib3JkZXI6IG5vbmU7XHJcbiAgY3Vyc29yOiBcInBvaW50ZXJcIjtcclxuICB0cmFuc2l0aW9uOiBcImJvcmRlci1jb2xvciAwLjNzIGVhc2VcIjtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICAmOjpiZWZvcmUge1xyXG4gICAgY29udGVudDogXCJcIjtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRvcDogMDtcclxuICAgIGxlZnQ6IC0xMDAlO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoXHJcbiAgICAgIDEyMGRlZyxcclxuICAgICAgdHJhbnNwYXJlbnQsXHJcbiAgICAgIHJnYmEoMjU1LCAyNTUsIDI1NSwgMC4yKSxcclxuICAgICAgdHJhbnNwYXJlbnRcclxuICAgICk7XHJcblxyXG4gICAgdHJhbnNpdGlvbjogYWxsIDAuNjVzIGVhc2UtaW4tb3V0O1xyXG4gIH1cclxuICAmOmhvdmVyOjpiZWZvcmUge1xyXG4gICAgbGVmdDogMTAwJTtcclxuICB9XHJcbn1cclxuXHJcbi5yZWNpcGUtYnV0dG9uIGltZyB7XHJcbiAgaGVpZ2h0OiAyMHB4O1xyXG4gIHdpZHRoOiAyMHB4O1xyXG59XHJcblxyXG4uY2hlY2tib3gge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbn1cclxuLmNoZWNrYm94IGxhYmVsIHtcclxuICBtYXJnaW4tbGVmdDogNXB4O1xyXG4gIGNvbG9yOiB2YXIoLS1oaW50LXRleHQpO1xyXG59XHJcbmlucHV0W3R5cGU9XCJjaGVja2JveFwiXSB7XHJcbiAgLXdlYmtpdC1hcHBlYXJhbmNlOiBub25lO1xyXG4gIC1tb3otYXBwZWFyYW5jZTogbm9uZTtcclxuICBhcHBlYXJhbmNlOiBub25lO1xyXG4gIHdpZHRoOiAzMHB4O1xyXG4gIGhlaWdodDogMzBweDtcclxuICBib3JkZXI6IDJweCBzb2xpZCB2YXIoLS1oaW50LXRleHQpO1xyXG4gIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbmlucHV0W3R5cGU9XCJjaGVja2JveFwiXTpjaGVja2VkIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1zZWNvbmRhcnktY29sb3IpO1xyXG4gIGJvcmRlci1jb2xvcjogdmFyKC0tc2Vjb25kYXJ5LWNvbG9yKTtcclxuICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJ2RhdGE6aW1hZ2Uvc3ZnK3htbDt1dGY4LDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj48cGF0aCBkPVwiTTIwIDZMOSAxN2wtNS01XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJ3aGl0ZVwiIHN0cm9rZS13aWR0aD1cIjJcIi8+PC9zdmc+Jyk7XHJcbiAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xyXG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgYmFja2dyb3VuZC1zaXplOiAyNXB4O1xyXG59XHJcblxyXG4uZGV0YWlsLWxpc3QgaW5wdXRbdHlwZT1cImNoZWNrYm94XCJdOmNoZWNrZWQgKyAuZGV0YWlsLXRleHQge1xyXG4gIHRleHQtZGVjb3JhdGlvbjogbGluZS10aHJvdWdoO1xyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0= */", ".quote[_ngcontent-%COMP%] {\n  margin: auto;\n  width: 100%;\n  max-width: 21rem;\n  text-align: center;\n  white-space: normal;\n  line-height: 1.5;\n}\n.quote[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  font-family: \"Dancing Script\";\n  color: var(--primary-color);\n  font-size: 1.7rem;\n}\n\n.pagination[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n  justify-content: end;\n}\n.recipe-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  padding: 0 40px 40px 40px;\n  justify-content: start;\n  align-items: center;\n  gap: 20px;\n  width: 100%;\n}\n\n.first-section-recipe[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 30px;\n  align-items: center;\n  justify-content: center;\n  width: 100%;\n  margin-top: 15px;\n}\n.recipe-details[_ngcontent-%COMP%] {\n  height: 100%;\n  width: 65%;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  gap: 20px;\n  align-items: center;\n}\n.details-grid-container[_ngcontent-%COMP%] {\n  padding-top: 10px;\n  width: 100%;\n  display: grid;\n  grid-template-columns: repeat(auto-fit, 210px);\n  grid-template-rows: repeat(3, 50px);\n  justify-content: center;\n  row-gap: 10px;\n  column-gap: 20px;\n}\n.detail-item[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n}\n.detail-item[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 40px;\n  height: 40px;\n}\n.separation-line[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 0.5px;\n  background-color: var(--secondary-color);\n}\n.second-section-recipe[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n}\n.recipe-detail-item[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  gap: 15px;\n}\n.recipe-detail-item[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  color: var(--brown);\n  font-weight: 600;\n  font-size: 26px;\n}\n\n.detail-list[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  z-index: 1000;\n}\n.recipe-detail-item[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n  margin-bottom: 10px;\n}\n.detail-text[_ngcontent-%COMP%] {\n  font-weight: 500;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hc3NldHMvY3NzL2xpc3QtY29tbW9uLmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFlBQVk7RUFDWixXQUFXO0VBQ1gsZ0JBQWdCO0VBQ2hCLGtCQUFrQjtFQUNsQixtQkFBbUI7RUFDbkIsZ0JBQWdCO0FBQ2xCO0FBQ0E7RUFDRSw2QkFBNkI7RUFDN0IsMkJBQTJCO0VBQzNCLGlCQUFpQjtBQUNuQjs7QUFFQTtFQUNFLFdBQVc7RUFDWCxhQUFhO0VBQ2Isb0JBQW9CO0FBQ3RCO0FBQ0E7RUFDRSxhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLHlCQUF5QjtFQUN6QixzQkFBc0I7RUFDdEIsbUJBQW1CO0VBQ25CLFNBQVM7RUFDVCxXQUFXO0FBQ2I7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsU0FBUztFQUNULG1CQUFtQjtFQUNuQix1QkFBdUI7RUFDdkIsV0FBVztFQUNYLGdCQUFnQjtBQUNsQjtBQUNBO0VBQ0UsWUFBWTtFQUNaLFVBQVU7RUFDVixhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLHVCQUF1QjtFQUN2QixTQUFTO0VBQ1QsbUJBQW1CO0FBQ3JCO0FBQ0E7RUFDRSxpQkFBaUI7RUFDakIsV0FBVztFQUNYLGFBQWE7RUFDYiw4Q0FBOEM7RUFDOUMsbUNBQW1DO0VBQ25DLHVCQUF1QjtFQUN2QixhQUFhO0VBQ2IsZ0JBQWdCO0FBQ2xCO0FBQ0E7RUFDRSxhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLFNBQVM7QUFDWDtBQUNBO0VBQ0UsV0FBVztFQUNYLFlBQVk7QUFDZDtBQUNBO0VBQ0UsV0FBVztFQUNYLGFBQWE7RUFDYix3Q0FBd0M7QUFDMUM7QUFDQTtFQUNFLFdBQVc7RUFDWCxhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLFNBQVM7QUFDWDtBQUNBO0VBQ0UsYUFBYTtFQUNiLHNCQUFzQjtFQUN0Qix1QkFBdUI7RUFDdkIsU0FBUztBQUNYO0FBQ0E7RUFDRSxtQkFBbUI7RUFDbkIsZ0JBQWdCO0VBQ2hCLGVBQWU7QUFDakI7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLFNBQVM7RUFDVCxhQUFhO0FBQ2Y7QUFDQTtFQUNFLG1CQUFtQjtBQUNyQjtBQUNBO0VBQ0UsZ0JBQWdCO0FBQ2xCIiwic291cmNlc0NvbnRlbnQiOlsiLnF1b3RlIHtcclxuICBtYXJnaW46IGF1dG87XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgbWF4LXdpZHRoOiAyMXJlbTtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgd2hpdGUtc3BhY2U6IG5vcm1hbDtcclxuICBsaW5lLWhlaWdodDogMS41O1xyXG59XHJcbi5xdW90ZSBoMyB7XHJcbiAgZm9udC1mYW1pbHk6IFwiRGFuY2luZyBTY3JpcHRcIjtcclxuICBjb2xvcjogdmFyKC0tcHJpbWFyeS1jb2xvcik7XHJcbiAgZm9udC1zaXplOiAxLjdyZW07XHJcbn1cclxuXHJcbi5wYWdpbmF0aW9uIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogZW5kO1xyXG59XHJcbi5yZWNpcGUtY29udGFpbmVyIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgcGFkZGluZzogMCA0MHB4IDQwcHggNDBweDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHN0YXJ0O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgZ2FwOiAyMHB4O1xyXG4gIHdpZHRoOiAxMDAlO1xyXG59XHJcblxyXG4uZmlyc3Qtc2VjdGlvbi1yZWNpcGUge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZ2FwOiAzMHB4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgbWFyZ2luLXRvcDogMTVweDtcclxufVxyXG4ucmVjaXBlLWRldGFpbHMge1xyXG4gIGhlaWdodDogMTAwJTtcclxuICB3aWR0aDogNjUlO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBnYXA6IDIwcHg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG4uZGV0YWlscy1ncmlkLWNvbnRhaW5lciB7XHJcbiAgcGFkZGluZy10b3A6IDEwcHg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgZGlzcGxheTogZ3JpZDtcclxuICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IHJlcGVhdChhdXRvLWZpdCwgMjEwcHgpO1xyXG4gIGdyaWQtdGVtcGxhdGUtcm93czogcmVwZWF0KDMsIDUwcHgpO1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIHJvdy1nYXA6IDEwcHg7XHJcbiAgY29sdW1uLWdhcDogMjBweDtcclxufVxyXG4uZGV0YWlsLWl0ZW0ge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBnYXA6IDEwcHg7XHJcbn1cclxuLmRldGFpbC1pdGVtIGltZyB7XHJcbiAgd2lkdGg6IDQwcHg7XHJcbiAgaGVpZ2h0OiA0MHB4O1xyXG59XHJcbi5zZXBhcmF0aW9uLWxpbmUge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMC41cHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tc2Vjb25kYXJ5LWNvbG9yKTtcclxufVxyXG4uc2Vjb25kLXNlY3Rpb24tcmVjaXBlIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgZ2FwOiAxMHB4O1xyXG59XHJcbi5yZWNpcGUtZGV0YWlsLWl0ZW0ge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBnYXA6IDE1cHg7XHJcbn1cclxuLnJlY2lwZS1kZXRhaWwtaXRlbSBoMiB7XHJcbiAgY29sb3I6IHZhcigtLWJyb3duKTtcclxuICBmb250LXdlaWdodDogNjAwO1xyXG4gIGZvbnQtc2l6ZTogMjZweDtcclxufVxyXG5cclxuLmRldGFpbC1saXN0IHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgZ2FwOiAxMHB4O1xyXG4gIHotaW5kZXg6IDEwMDA7XHJcbn1cclxuLnJlY2lwZS1kZXRhaWwtaXRlbSBsaSB7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcclxufVxyXG4uZGV0YWlsLXRleHQge1xyXG4gIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 3996:
/*!*************************************************************************!*\
  !*** ./src/app/features/recipes/recipes-list/recipes-list.component.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RecipesListComponent: () => (/* binding */ RecipesListComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/forms */ 4456);
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ngx-toastr */ 4285);
/* harmony import */ var src_app_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/utils/functions.utils */ 3584);
/* harmony import */ var src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/models/recipe.model */ 6464);
/* harmony import */ var src_app_services_recipe_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/recipe.service */ 4964);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../shared/components/button/button.component */ 8219);
/* harmony import */ var _shared_components_svg_box_svg_box_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../shared/components/svg-box/svg-box.component */ 6145);
/* harmony import */ var _shared_components_page_background_page_background_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../shared/components/page-background/page-background.component */ 1469);
/* harmony import */ var _recette_item_recette_item_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../recette-item/recette-item.component */ 5404);
/* harmony import */ var _shared_components_pagination_pagination_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../shared/components/pagination/pagination.component */ 4815);
/* harmony import */ var _shared_components_search_search_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../shared/components/search/search.component */ 1163);
/* harmony import */ var _shared_components_dropdown_dropdown_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../shared/components/dropdown/dropdown.component */ 4538);
/* harmony import */ var _shared_components_preloader_preloader_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../shared/components/preloader/preloader.component */ 9485);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/router */ 5072);
/* harmony import */ var _core_pipes_recipe_filter_pipe__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../core/pipes/recipe-filter.pipe */ 9323);


















function RecipesListComponent_div_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](1, "app-preloader");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
  }
}
function RecipesListComponent_div_14_app_recipe_item_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](0, "app-recipe-item", 15);
  }
  if (rf & 2) {
    const recipe_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("recipe", recipe_r3);
  }
}
function RecipesListComponent_div_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](1, RecipesListComponent_div_14_app_recipe_item_1_Template, 1, 1, "app-recipe-item", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipe"](2, "recipeFilter");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipeBind4"](2, 1, ctx_r1.recipes, ctx_r1.searchControl.value, ctx_r1.categoryControl.value, ctx_r1.objectifControl.value));
  }
}
class RecipesListComponent {
  updatePage(index) {
    this.currentPage = index;
    this.isLoading = true;
    this.recipesService.getAllRecipes(this.currentPage).subscribe({
      next: response => {
        this.recipes = response.data;
        this.totalRecipesCount = response.total;
        // H
        setTimeout(() => {
          this.isLoading = false;
        }, 1000);
      },
      error: error => {
        this.toastr.error(src_app_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_0__.AppUtils.getErrorMessage(error), 'Error');
        this.isLoading = false; // H
      }
    });
  }

  getTotalPageNumber() {
    return Math.ceil(this.totalRecipesCount / this.limit);
  }
  ngOnInit() {
    this.categoryControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_13__.FormControl(src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_1__.CategoryEnum.ALL);
    this.objectifControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_13__.FormControl(src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_1__.ObjectifEnum.ALL);
  }
  constructor() {
    this.recipes = [];
    this.totalRecipesCount = 0;
    this.currentPage = 0;
    this.limit = 12;
    this.isLoading = true;
    this.searchControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_13__.FormControl('');
    this.toastr = (0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.inject)(ngx_toastr__WEBPACK_IMPORTED_MODULE_14__.ToastrService);
    this.recipesService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.inject)(src_app_services_recipe_service__WEBPACK_IMPORTED_MODULE_2__.RecipesService);
    this.objectifOptions = Object.values(src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_1__.ObjectifEnum);
    this.selectedObjectif = '';
    this.categoryOptions = Object.values(src_app_models_recipe_model__WEBPACK_IMPORTED_MODULE_1__.CategoryEnum);
    this.selectedCategory = '';
    this.recipesService.getAllRecipes(this.currentPage).subscribe({
      next: response => {
        this.recipes = response.data;
        this.totalRecipesCount = response.total;
        // H
        setTimeout(() => {
          this.isLoading = false;
        }, 1000);
      },
      error: error => {
        this.toastr.error(src_app_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_0__.AppUtils.getErrorMessage(error), 'Error');
        this.isLoading = false; // H
      }
    });
  }

  selectObjectif(objectif) {
    this.selectedObjectif = objectif;
  }
  selectCategory(category) {
    this.selectedCategory = category;
  }
  static {
    this.ɵfac = function RecipesListComponent_Factory(t) {
      return new (t || RecipesListComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdefineComponent"]({
      type: RecipesListComponent,
      selectors: [["app-recipes-list"]],
      decls: 17,
      vars: 14,
      consts: [[1, "quote"], [3, "height", "width"], [1, "title"], [1, "filters"], [3, "formControlName"], [3, "name", "options", "formControlName"], [2, "margin-left", "auto"], [3, "text", "routerLink"], ["class", "grid-container loading", 4, "ngIf"], ["class", "grid-container", 4, "ngIf"], [1, "pagination"], [3, "totalPages", "pageChanged"], [1, "grid-container", "loading"], [1, "grid-container"], [3, "recipe", 4, "ngFor", "ngForOf"], [3, "recipe"]],
      template: function RecipesListComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "app-page-background")(1, "div", 0)(2, "h3");
          _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](3, "Manger sain, c'est prendre soin de soi avec chaque bouch\u00E9e");
          _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](4, "app-svg-box", 1)(5, "h2", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](6, "Nos Recettes:");
          _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](7, "div", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](8, "app-search", 4)(9, "app-dropdown", 5)(10, "app-dropdown", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](11, "div", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](12, "app-button", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](13, RecipesListComponent_div_13_Template, 2, 0, "div", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](14, RecipesListComponent_div_14_Template, 3, 6, "div", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](15, "div", 10)(16, "app-pagination", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("pageChanged", function RecipesListComponent_Template_app_pagination_pageChanged_16_listener($event) {
            return ctx.updatePage($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()()()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("height", "100%")("width", "95%");
          _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("formControlName", ctx.searchControl);
          _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("name", "Objectif")("options", ctx.objectifOptions)("formControlName", ctx.objectifControl);
          _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("name", "Cat\u00E9gorie")("options", ctx.categoryOptions)("formControlName", ctx.categoryControl);
          _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("text", "Ajouter Recette")("routerLink", "add-recipe");
          _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", ctx.isLoading);
          _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", !ctx.isLoading);
          _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("totalPages", ctx.getTotalPageNumber());
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_15__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgIf, _shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_3__.ButtonComponent, _shared_components_svg_box_svg_box_component__WEBPACK_IMPORTED_MODULE_4__.SvgBoxComponent, _shared_components_page_background_page_background_component__WEBPACK_IMPORTED_MODULE_5__.PageBackgroundComponent, _recette_item_recette_item_component__WEBPACK_IMPORTED_MODULE_6__.RecetteItemComponent, _shared_components_pagination_pagination_component__WEBPACK_IMPORTED_MODULE_7__.PaginationComponent, _shared_components_search_search_component__WEBPACK_IMPORTED_MODULE_8__.SearchComponent, _shared_components_dropdown_dropdown_component__WEBPACK_IMPORTED_MODULE_9__.DropdownComponent, _shared_components_preloader_preloader_component__WEBPACK_IMPORTED_MODULE_10__.PreloaderComponent, _angular_router__WEBPACK_IMPORTED_MODULE_16__.RouterLink, _core_pipes_recipe_filter_pipe__WEBPACK_IMPORTED_MODULE_11__.RecipeFilterPipe],
      styles: [".grid-container[_ngcontent-%COMP%] {\n  padding: 20px;\n  padding-top: 30px;\n  width: 100%;\n  display: grid;\n  grid-template-columns: repeat(auto-fit, 150px);\n  grid-template-rows: repeat(3, 180px);\n  justify-content: start;\n  row-gap: 90px;\n  column-gap: 35px;\n  &.loading {\n    justify-content: center;\n  }\n}\n.filters[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 20px;\n  width: 100%;\n  margin-bottom: 35px;\n}\nh2.title[_ngcontent-%COMP%] {\n  align-self: start;\n  font-weight: 600;\n  color: var(--primary-color);\n  font-size: 25px;\n  margin-bottom: 20px;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvZmVhdHVyZXMvcmVjaXBlcy9yZWNpcGVzLWxpc3QvcmVjaXBlcy1saXN0LmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxhQUFhO0VBQ2IsaUJBQWlCO0VBQ2pCLFdBQVc7RUFDWCxhQUFhO0VBQ2IsOENBQThDO0VBQzlDLG9DQUFvQztFQUNwQyxzQkFBc0I7RUFDdEIsYUFBYTtFQUNiLGdCQUFnQjtFQUNoQjtJQUNFLHVCQUF1QjtFQUN6QjtBQUNGO0FBQ0E7RUFDRSxhQUFhO0VBQ2IsU0FBUztFQUNULFdBQVc7RUFDWCxtQkFBbUI7QUFDckI7QUFDQTtFQUNFLGlCQUFpQjtFQUNqQixnQkFBZ0I7RUFDaEIsMkJBQTJCO0VBQzNCLGVBQWU7RUFDZixtQkFBbUI7QUFDckIiLCJzb3VyY2VzQ29udGVudCI6WyIuZ3JpZC1jb250YWluZXIge1xyXG4gIHBhZGRpbmc6IDIwcHg7XHJcbiAgcGFkZGluZy10b3A6IDMwcHg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgZGlzcGxheTogZ3JpZDtcclxuICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IHJlcGVhdChhdXRvLWZpdCwgMTUwcHgpO1xyXG4gIGdyaWQtdGVtcGxhdGUtcm93czogcmVwZWF0KDMsIDE4MHB4KTtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHN0YXJ0O1xyXG4gIHJvdy1nYXA6IDkwcHg7XHJcbiAgY29sdW1uLWdhcDogMzVweDtcclxuICAmLmxvYWRpbmcge1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgfVxyXG59XHJcbi5maWx0ZXJzIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGdhcDogMjBweDtcclxuICB3aWR0aDogMTAwJTtcclxuICBtYXJnaW4tYm90dG9tOiAzNXB4O1xyXG59XHJcbmgyLnRpdGxlIHtcclxuICBhbGlnbi1zZWxmOiBzdGFydDtcclxuICBmb250LXdlaWdodDogNjAwO1xyXG4gIGNvbG9yOiB2YXIoLS1wcmltYXJ5LWNvbG9yKTtcclxuICBmb250LXNpemU6IDI1cHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogMjBweDtcclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */", ".quote[_ngcontent-%COMP%] {\n  margin: auto;\n  width: 100%;\n  max-width: 21rem;\n  text-align: center;\n  white-space: normal;\n  line-height: 1.5;\n}\n.quote[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  font-family: \"Dancing Script\";\n  color: var(--primary-color);\n  font-size: 1.7rem;\n}\n\n.pagination[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n  justify-content: end;\n}\n.recipe-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  padding: 0 40px 40px 40px;\n  justify-content: start;\n  align-items: center;\n  gap: 20px;\n  width: 100%;\n}\n\n.first-section-recipe[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 30px;\n  align-items: center;\n  justify-content: center;\n  width: 100%;\n  margin-top: 15px;\n}\n.recipe-details[_ngcontent-%COMP%] {\n  height: 100%;\n  width: 65%;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  gap: 20px;\n  align-items: center;\n}\n.details-grid-container[_ngcontent-%COMP%] {\n  padding-top: 10px;\n  width: 100%;\n  display: grid;\n  grid-template-columns: repeat(auto-fit, 210px);\n  grid-template-rows: repeat(3, 50px);\n  justify-content: center;\n  row-gap: 10px;\n  column-gap: 20px;\n}\n.detail-item[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n}\n.detail-item[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 40px;\n  height: 40px;\n}\n.separation-line[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 0.5px;\n  background-color: var(--secondary-color);\n}\n.second-section-recipe[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n}\n.recipe-detail-item[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  gap: 15px;\n}\n.recipe-detail-item[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  color: var(--brown);\n  font-weight: 600;\n  font-size: 26px;\n}\n\n.detail-list[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  z-index: 1000;\n}\n.recipe-detail-item[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n  margin-bottom: 10px;\n}\n.detail-text[_ngcontent-%COMP%] {\n  font-weight: 500;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hc3NldHMvY3NzL2xpc3QtY29tbW9uLmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFlBQVk7RUFDWixXQUFXO0VBQ1gsZ0JBQWdCO0VBQ2hCLGtCQUFrQjtFQUNsQixtQkFBbUI7RUFDbkIsZ0JBQWdCO0FBQ2xCO0FBQ0E7RUFDRSw2QkFBNkI7RUFDN0IsMkJBQTJCO0VBQzNCLGlCQUFpQjtBQUNuQjs7QUFFQTtFQUNFLFdBQVc7RUFDWCxhQUFhO0VBQ2Isb0JBQW9CO0FBQ3RCO0FBQ0E7RUFDRSxhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLHlCQUF5QjtFQUN6QixzQkFBc0I7RUFDdEIsbUJBQW1CO0VBQ25CLFNBQVM7RUFDVCxXQUFXO0FBQ2I7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsU0FBUztFQUNULG1CQUFtQjtFQUNuQix1QkFBdUI7RUFDdkIsV0FBVztFQUNYLGdCQUFnQjtBQUNsQjtBQUNBO0VBQ0UsWUFBWTtFQUNaLFVBQVU7RUFDVixhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLHVCQUF1QjtFQUN2QixTQUFTO0VBQ1QsbUJBQW1CO0FBQ3JCO0FBQ0E7RUFDRSxpQkFBaUI7RUFDakIsV0FBVztFQUNYLGFBQWE7RUFDYiw4Q0FBOEM7RUFDOUMsbUNBQW1DO0VBQ25DLHVCQUF1QjtFQUN2QixhQUFhO0VBQ2IsZ0JBQWdCO0FBQ2xCO0FBQ0E7RUFDRSxhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLFNBQVM7QUFDWDtBQUNBO0VBQ0UsV0FBVztFQUNYLFlBQVk7QUFDZDtBQUNBO0VBQ0UsV0FBVztFQUNYLGFBQWE7RUFDYix3Q0FBd0M7QUFDMUM7QUFDQTtFQUNFLFdBQVc7RUFDWCxhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLFNBQVM7QUFDWDtBQUNBO0VBQ0UsYUFBYTtFQUNiLHNCQUFzQjtFQUN0Qix1QkFBdUI7RUFDdkIsU0FBUztBQUNYO0FBQ0E7RUFDRSxtQkFBbUI7RUFDbkIsZ0JBQWdCO0VBQ2hCLGVBQWU7QUFDakI7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLFNBQVM7RUFDVCxhQUFhO0FBQ2Y7QUFDQTtFQUNFLG1CQUFtQjtBQUNyQjtBQUNBO0VBQ0UsZ0JBQWdCO0FBQ2xCIiwic291cmNlc0NvbnRlbnQiOlsiLnF1b3RlIHtcclxuICBtYXJnaW46IGF1dG87XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgbWF4LXdpZHRoOiAyMXJlbTtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgd2hpdGUtc3BhY2U6IG5vcm1hbDtcclxuICBsaW5lLWhlaWdodDogMS41O1xyXG59XHJcbi5xdW90ZSBoMyB7XHJcbiAgZm9udC1mYW1pbHk6IFwiRGFuY2luZyBTY3JpcHRcIjtcclxuICBjb2xvcjogdmFyKC0tcHJpbWFyeS1jb2xvcik7XHJcbiAgZm9udC1zaXplOiAxLjdyZW07XHJcbn1cclxuXHJcbi5wYWdpbmF0aW9uIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogZW5kO1xyXG59XHJcbi5yZWNpcGUtY29udGFpbmVyIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgcGFkZGluZzogMCA0MHB4IDQwcHggNDBweDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHN0YXJ0O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgZ2FwOiAyMHB4O1xyXG4gIHdpZHRoOiAxMDAlO1xyXG59XHJcblxyXG4uZmlyc3Qtc2VjdGlvbi1yZWNpcGUge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZ2FwOiAzMHB4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgbWFyZ2luLXRvcDogMTVweDtcclxufVxyXG4ucmVjaXBlLWRldGFpbHMge1xyXG4gIGhlaWdodDogMTAwJTtcclxuICB3aWR0aDogNjUlO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBnYXA6IDIwcHg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG4uZGV0YWlscy1ncmlkLWNvbnRhaW5lciB7XHJcbiAgcGFkZGluZy10b3A6IDEwcHg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgZGlzcGxheTogZ3JpZDtcclxuICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IHJlcGVhdChhdXRvLWZpdCwgMjEwcHgpO1xyXG4gIGdyaWQtdGVtcGxhdGUtcm93czogcmVwZWF0KDMsIDUwcHgpO1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIHJvdy1nYXA6IDEwcHg7XHJcbiAgY29sdW1uLWdhcDogMjBweDtcclxufVxyXG4uZGV0YWlsLWl0ZW0ge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBnYXA6IDEwcHg7XHJcbn1cclxuLmRldGFpbC1pdGVtIGltZyB7XHJcbiAgd2lkdGg6IDQwcHg7XHJcbiAgaGVpZ2h0OiA0MHB4O1xyXG59XHJcbi5zZXBhcmF0aW9uLWxpbmUge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMC41cHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tc2Vjb25kYXJ5LWNvbG9yKTtcclxufVxyXG4uc2Vjb25kLXNlY3Rpb24tcmVjaXBlIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgZ2FwOiAxMHB4O1xyXG59XHJcbi5yZWNpcGUtZGV0YWlsLWl0ZW0ge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBnYXA6IDE1cHg7XHJcbn1cclxuLnJlY2lwZS1kZXRhaWwtaXRlbSBoMiB7XHJcbiAgY29sb3I6IHZhcigtLWJyb3duKTtcclxuICBmb250LXdlaWdodDogNjAwO1xyXG4gIGZvbnQtc2l6ZTogMjZweDtcclxufVxyXG5cclxuLmRldGFpbC1saXN0IHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgZ2FwOiAxMHB4O1xyXG4gIHotaW5kZXg6IDEwMDA7XHJcbn1cclxuLnJlY2lwZS1kZXRhaWwtaXRlbSBsaSB7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcclxufVxyXG4uZGV0YWlsLXRleHQge1xyXG4gIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 5237:
/*!****************************************************!*\
  !*** ./src/app/features/recipes/recipes.module.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RecipesModule: () => (/* binding */ RecipesModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _recipes_list_recipes_list_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./recipes-list/recipes-list.component */ 3996);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/shared/shared.module */ 3887);
/* harmony import */ var _core_core_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../core/core.module */ 8423);
/* harmony import */ var _landing_landing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../landing/landing.module */ 797);
/* harmony import */ var _add_recipe_add_recipe_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./add-recipe/add-recipe.component */ 3852);
/* harmony import */ var _recette_item_recette_item_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./recette-item/recette-item.component */ 5404);
/* harmony import */ var _recipe_details_recipe_details_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./recipe-details/recipe-details.component */ 7798);
/* harmony import */ var _recipe_details_item_recipe_details_item_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./recipe-details-item/recipe-details-item.component */ 2561);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/router */ 5072);
/* harmony import */ var src_app_core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/guards/auth.guard */ 4978);
/* harmony import */ var src_app_models_client_model__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/models/client.model */ 4477);
/* harmony import */ var src_app_core_guards_role_guard__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/core/guards/role.guard */ 400);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 7580);















const routes = [{
  path: '',
  component: _recipes_list_recipes_list_component__WEBPACK_IMPORTED_MODULE_0__.RecipesListComponent,
  canActivate: [src_app_core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_8__.authGuard]
}, {
  path: 'add-recipe',
  component: _add_recipe_add_recipe_component__WEBPACK_IMPORTED_MODULE_4__.AddRecipeComponent,
  canActivate: [src_app_core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_8__.authGuard, src_app_core_guards_role_guard__WEBPACK_IMPORTED_MODULE_10__.roleGuard],
  data: {
    roles: [src_app_models_client_model__WEBPACK_IMPORTED_MODULE_9__.UserRoleEnum.NUTRITIONIST]
  }
}, {
  path: 'edit-recipe',
  component: _add_recipe_add_recipe_component__WEBPACK_IMPORTED_MODULE_4__.AddRecipeComponent,
  canActivate: [src_app_core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_8__.authGuard, src_app_core_guards_role_guard__WEBPACK_IMPORTED_MODULE_10__.roleGuard],
  data: {
    roles: [src_app_models_client_model__WEBPACK_IMPORTED_MODULE_9__.UserRoleEnum.NUTRITIONIST]
  }
}, {
  path: 'recipe-details/:id',
  component: _recipe_details_recipe_details_component__WEBPACK_IMPORTED_MODULE_6__.RecipeDetailsComponent,
  canActivate: [src_app_core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_8__.authGuard]
}];
class RecipesModule {
  static {
    this.ɵfac = function RecipesModule_Factory(t) {
      return new (t || RecipesModule)();
    };
  }
  static {
    this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineNgModule"]({
      type: RecipesModule
    });
  }
  static {
    this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_12__.CommonModule, src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule, _core_core_module__WEBPACK_IMPORTED_MODULE_2__.CoreModule, _angular_router__WEBPACK_IMPORTED_MODULE_13__.RouterModule.forChild(routes), _landing_landing_module__WEBPACK_IMPORTED_MODULE_3__.LandingModule]
    });
  }
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵsetNgModuleScope"](RecipesModule, {
    declarations: [_recipes_list_recipes_list_component__WEBPACK_IMPORTED_MODULE_0__.RecipesListComponent, _add_recipe_add_recipe_component__WEBPACK_IMPORTED_MODULE_4__.AddRecipeComponent, _recipe_details_recipe_details_component__WEBPACK_IMPORTED_MODULE_6__.RecipeDetailsComponent, _recipe_details_item_recipe_details_item_component__WEBPACK_IMPORTED_MODULE_7__.RecipeDetailsItemComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_12__.CommonModule, src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule, _core_core_module__WEBPACK_IMPORTED_MODULE_2__.CoreModule, _angular_router__WEBPACK_IMPORTED_MODULE_13__.RouterModule],
    exports: [_recipes_list_recipes_list_component__WEBPACK_IMPORTED_MODULE_0__.RecipesListComponent, _landing_landing_module__WEBPACK_IMPORTED_MODULE_3__.LandingModule, _add_recipe_add_recipe_component__WEBPACK_IMPORTED_MODULE_4__.AddRecipeComponent, _recette_item_recette_item_component__WEBPACK_IMPORTED_MODULE_5__.RecetteItemComponent, _recipe_details_recipe_details_component__WEBPACK_IMPORTED_MODULE_6__.RecipeDetailsComponent]
  });
})();

/***/ }),

/***/ 6229:
/*!******************************************************************!*\
  !*** ./src/app/features/water-tracking/water-tracking.module.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   WaterTrackingModule: () => (/* binding */ WaterTrackingModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _water_tracking_water_tracking_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./water-tracking/water-tracking.component */ 4104);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/shared/shared.module */ 3887);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7580);




class WaterTrackingModule {
  static {
    this.ɵfac = function WaterTrackingModule_Factory(t) {
      return new (t || WaterTrackingModule)();
    };
  }
  static {
    this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({
      type: WaterTrackingModule
    });
  }
  static {
    this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule, src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule]
    });
  }
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](WaterTrackingModule, {
    declarations: [_water_tracking_water_tracking_component__WEBPACK_IMPORTED_MODULE_0__.WaterTrackingComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule, src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule],
    exports: [_water_tracking_water_tracking_component__WEBPACK_IMPORTED_MODULE_0__.WaterTrackingComponent]
  });
})();

/***/ }),

/***/ 4104:
/*!************************************************************************************!*\
  !*** ./src/app/features/water-tracking/water-tracking/water-tracking.component.ts ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   WaterTrackingComponent: () => (/* binding */ WaterTrackingComponent),
/* harmony export */   WaterTrackingStatus: () => (/* binding */ WaterTrackingStatus)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ngx-toastr */ 4285);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _shared_components_svg_box_svg_box_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../shared/components/svg-box/svg-box.component */ 6145);




function WaterTrackingComponent_div_21_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 16)(1, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnamespaceSVG"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "svg", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](3, "path", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "g", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](5, "path", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](6, "path", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "g", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](8, "path", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](9, "g", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "path", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](11, "g", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](12, "path", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](13, "g", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](14, "path", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const index_r2 = ctx.index;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵclassProp"]("active", index_r2 <= ctx_r0.filledCups);
  }
}
const _c0 = function () {
  return [];
};
class WaterTrackingComponent {
  constructor(toastr) {
    this.toastr = toastr;
    this.filledCups = -1;
    this.recommendedDrunCups = 0;
    this.waterTrackingStatus = WaterTrackingStatus.NEUTRAL;
    this.currentTime = '';
  }
  ngOnInit() {
    this.updateStatus();
    this.currentTime = this.getCurrentTime();
    this.timeIntervalId = setInterval(() => {
      this.currentTime = this.getCurrentTime();
    }, 30000);
    // Set the interval to run every 30 seconds (30000 milliseconds)
    this.intervalId = setInterval(() => {
      this.recommendedDrunCups++;
      this.toastr.info("Don't forget to Hydrate yourself!", 'Water Tracker');
      this.updateStatus();
      console.log('CHECKING');
    }, 15000);
  }
  getCurrentHour() {
    const currentDate = new Date(); // Get the current date and time
    return currentDate.getHours().toString().padStart(2, '0'); // Extract the current hour (0-23)
  }

  getCurrentMinutes() {
    const currentDate = new Date(); // Get the current date and time
    return currentDate.getMinutes().toString().padStart(2, '0'); // Extract the current hour (0-23)
  }

  getCurrentTime() {
    return this.getCurrentHour() + ':' + this.getCurrentMinutes();
  }
  ngOnDestroy() {
    // Clear the interval when the component is destroyed
    if (this.intervalId) {
      clearInterval(this.intervalId);
    }
    if (this.timeIntervalId) {
      clearInterval(this.timeIntervalId);
    }
  }
  showWarning() {
    this.toastr.warning('Warning message', "Don't Forget To Hydrate Your Self !");
  }
  fillNextCup() {
    if (this.filledCups < 7) this.filledCups++;
    this.updateStatus();
  }
  updateStatus() {
    const difference = this.recommendedDrunCups - this.filledCups;
    switch (difference) {
      case 0:
        this.waterTrackingStatus = WaterTrackingStatus.VERY_HAPPY;
        break;
      case 1:
        this.waterTrackingStatus = WaterTrackingStatus.HAPPY;
        break;
      case 2:
        this.waterTrackingStatus = WaterTrackingStatus.NEUTRAL;
        break;
      case 3:
        this.waterTrackingStatus = WaterTrackingStatus.SAD;
        break;
      case 4:
        this.waterTrackingStatus = WaterTrackingStatus.VERY_SAD;
        this.showWarning();
        break;
      default:
        break;
    }
  }
  static {
    this.ɵfac = function WaterTrackingComponent_Factory(t) {
      return new (t || WaterTrackingComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](ngx_toastr__WEBPACK_IMPORTED_MODULE_2__.ToastrService));
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: WaterTrackingComponent,
      selectors: [["app-water-tracking"]],
      decls: 23,
      vars: 5,
      consts: [[3, "width"], [1, "water-tracker-container"], [1, "water-tracker-box-background"], [1, "wave-animation"], ["viewBox", "0 0 500 150", "preserveAspectRatio", "none"], ["d", "M-8.74,71.55 C289.78,255.11 349.60,4.47 505.36,34.05 L500.00,150.00 L0.00,150.00 Z", 1, "w1"], ["d", "M-23.42,125.83 C187.63,45.89 299.38,57.73 526.80,123.86 L500.00,150.00 L0.00,150.00 Z", 1, "w2"], ["d", "M-23.42,125.83 C172.96,-152.44 217.55,183.06 504.22,55.77 L500.00,150.00 L0.00,150.00 Z", 1, "w3"], ["id", "small-water-drop", "src", "assets/images/water-drop.svg", "alt", ""], ["id", "big-water-drop", "src", "assets/images/water-drop.svg", "alt", ""], [1, "water-tracker-box"], [3, "click"], [1, "progress"], [1, "cups"], ["class", "cup", 4, "ngFor", "ngForOf"], ["alt", "", 1, "emoji", 3, "src"], [1, "cup"], [1, "wave"], ["preserveAspectRatio", "none", "width", "100%", "height", "95%", "viewBox", "0 0 50 60", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M49.2039 4.82459C49.0356 5.58432 48.4465 6.07561 47.8574 6.59729C46.5741 7.72676 45.0488 8.57259 43.4972 9.32726C32.6308 14.6099 19.3134 15.6128 8.21556 10.7961C6.30632 9.96543 4.45493 8.95752 2.8823 7.61027C2.26166 7.07846 0.68377 5.85276 0.525981 5.01199C0.331375 4.02435 2.49834 4.25226 3.20313 4.09019C3.28203 4.06993 3.36618 4.05474 3.44508 4.03448C4.67583 3.76097 5.93814 3.59383 7.19519 3.48241C15.6474 2.71255 24.268 4.27759 32.615 2.76319C36.6649 2.02879 40.6728 0.565043 44.7753 0.924648C45.885 1.02088 47.0159 1.26399 47.91 1.90217C47.9784 1.95282 48.0415 1.9984 48.1046 2.05918C48.8936 2.72774 49.4143 3.85214 49.1986 4.81953L49.2039 4.82459Z", "fill", "#3291D9"], ["opacity", "0.5", 2, "mix-blend-mode", "multiply"], ["d", "M49.2039 4.82462C49.0356 5.58435 48.4465 6.07564 47.8574 6.59732C46.5741 7.72678 45.0488 8.57262 43.4972 9.32728C32.6308 14.6099 19.3134 15.6128 8.21556 10.7961C6.30632 9.96545 4.45493 8.95755 2.8823 7.61029C2.26166 7.07848 0.68377 5.85279 0.525981 5.01202C0.331375 4.02437 2.49834 4.25229 3.20313 4.09021C3.28203 4.06995 3.36618 4.05476 3.44508 4.0345C3.83955 4.10034 4.23402 4.16112 4.60746 4.20164C6.53248 4.41943 8.45225 4.62709 10.372 4.82462C12.5337 5.04747 14.6954 5.25513 16.8624 5.43747C27.3448 6.31875 38.3585 6.54667 47.8521 2.17569C47.9363 2.14024 48.0205 2.09972 48.1099 2.05414C48.8988 2.7227 49.4195 3.8471 49.2039 4.81449V4.82462Z", "fill", "#3291D9"], ["d", "M49.2323 4.57642L48.3539 16.5346L45.6715 52.9661C45.5242 54.9819 44.1147 56.704 42.1213 57.3371C27.2365 62.0829 14.2715 59.3985 7.52867 57.2105C5.5563 56.5672 4.18354 54.8502 4.04153 52.8547L0.843675 9.40323L0.517578 5.01706C1.70625 5.14875 2.90019 5.44757 4.07835 5.56913C6.29791 5.78692 8.53326 5.88822 10.7476 6.06042C14.9237 6.38457 19.0841 6.88599 23.2655 7.0582C30.9498 7.37222 38.7393 7.02781 46.2553 5.32602C47.2547 5.0981 48.2435 4.84992 49.227 4.57642H49.2323Z", "fill", "#68CEFF"], ["d", "M48.352 16.5345L45.6696 52.9661C45.5224 54.9819 44.1128 56.704 42.1194 57.3371C27.2346 62.0828 14.2696 59.3985 7.52679 57.2104C5.55443 56.5672 4.18166 54.8502 4.03965 52.8547L0.841797 9.4032C2.21456 14.5542 3.30856 19.776 4.10803 25.0384C4.75496 29.2879 5.22307 33.5727 6.37493 37.7209C7.53205 41.8639 9.43077 45.9209 12.5708 48.9699C15.7055 52.019 20.213 53.9436 24.6311 53.3814C28.0499 52.9458 31.1425 51.082 33.5251 48.6812C35.9078 46.2805 37.6592 43.3682 39.2318 40.4154C43.266 32.8535 46.3323 24.8156 48.352 16.5396V16.5345Z", "fill", "#68CEFF"], ["opacity", "0.5", 2, "mix-blend-mode", "screen"], ["d", "M28.8091 8.61312C23.2759 8.64351 17.7586 8.14209 12.2623 7.51911C10.3688 7.30639 8.44379 7.07341 6.5661 7.39756C5.65619 7.55457 4.71997 7.86859 4.11511 8.54222C3.48396 9.24117 3.29987 10.2339 3.4261 11.1506C3.55759 12.0674 3.96785 12.9233 4.42543 13.7388C6.28208 17.0563 9.01183 20.0192 12.541 21.6551C15.3234 22.9467 18.4529 23.3569 21.5403 23.5089C24.2122 23.6355 26.9419 23.5697 29.4928 22.7998C32.6381 21.8476 35.3415 19.8672 37.7557 17.6995C40.1699 15.5317 42.3579 13.136 44.8878 11.0949C45.5821 10.5378 46.3131 9.99077 46.7812 9.24623C47.1442 8.67897 47.6859 6.68848 46.4709 6.68848C45.8135 6.68848 45.0561 6.97211 44.4091 7.09873C43.7096 7.23042 43.0048 7.35704 42.3 7.47353C39.4283 7.94456 36.5355 8.27378 33.6322 8.45611C32.028 8.55741 30.4238 8.60806 28.8143 8.61819L28.8091 8.61312Z", "fill", "#9CF1FF"], ["d", "M13.796 8.64858C12.1497 8.47131 10.4351 8.28898 8.86769 8.8056C8.4627 8.94235 8.01563 9.19559 7.98408 9.60585C7.95252 10.0313 8.37855 10.3504 8.7625 10.5631C11.8183 12.27 15.337 13.1209 18.861 13.3386C22.3849 13.5564 25.9299 13.1563 29.3908 12.4827C31.2369 12.1231 33.0988 11.6723 34.7556 10.791C35.1711 10.5682 36.0916 10.0566 35.3394 9.66662C34.7188 9.34754 33.8509 9.48429 33.1882 9.52481C29.0279 9.77299 24.857 9.6261 20.7071 9.30702C18.3981 9.12975 16.0944 8.89676 13.796 8.64352V8.64858Z", "fill", "#9CF1FF"], ["d", "M37.9718 9.29184C37.7456 9.38301 37.5195 9.49444 37.3617 9.67677C37.2039 9.85911 37.1302 10.1275 37.246 10.3352C37.3932 10.5986 37.7561 10.6594 38.0665 10.6746C38.5135 10.6948 38.9659 10.6948 39.4182 10.6695C40.1808 10.6239 40.9435 10.5074 41.6588 10.2542C42.0796 10.1073 43.1841 9.72742 43.2893 9.23107C43.4576 8.39536 41.1223 8.59796 40.691 8.64861C39.7653 8.76003 38.8344 8.94237 37.9718 9.29691V9.29184Z", "fill", "#9CF1FF"]],
      template: function WaterTrackingComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "app-svg-box", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnamespaceSVG"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "svg", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](5, "path", 5)(6, "path", 6)(7, "path", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnamespaceHTML"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](8, "img", 8)(9, "img", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "div", 10)(11, "h3");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](12);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](13, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](14, "200ml water ( 1 Verre )");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](15, "button", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function WaterTrackingComponent_Template_button_click_15_listener() {
            return ctx.fillNextCup();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](16, " J'ai bu un verre ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "div", 12)(18, "h2");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](19, "Today's Progress");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](20, "div", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](21, WaterTrackingComponent_div_21_Template, 15, 2, "div", 14);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](22, "img", 15);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("width", "95%");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](12);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx.currentTime);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](9);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](4, _c0).constructor(8));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("src", "assets/images/" + ctx.waterTrackingStatus + ".svg", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsanitizeUrl"]);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgForOf, _shared_components_svg_box_svg_box_component__WEBPACK_IMPORTED_MODULE_0__.SvgBoxComponent],
      styles: [".water-tracker-container[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n  gap: 20px;\n  align-items: center;\n  position: relative;\n}\n.water-tracker-box-background[_ngcontent-%COMP%] {\n  width: clamp(200px, 30vw, 300px);\n  min-width: 200px;\n  height: 162px;\n  display: flex;\n  flex-direction: column;\n  justify-content: end;\n  background-color: white;\n  border-radius: 15px;\n  overflow: hidden;\n  position: relative;\n  z-index: 1000;\n}\n.water-tracker-box[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  display: flex;\n  flex-direction: column;\n  padding: 20px;\n  position: absolute;\n  top: 0;\n  left: 0;\n}\n\n.water-tracker-box[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  color: var(--primary-color);\n  font-size: 20px;\n  font-weight: 600;\n}\n.water-tracker-box[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  color: #90a5b4;\n  font-size: clamp(12px, 2vw, 14px);\n  font-weight: 400;\n}\n.water-tracker-box[_ngcontent-%COMP%]   button[_ngcontent-%COMP%] {\n  margin-top: auto;\n  font-size: clamp(8px, 2vw, 12px);\n  border-radius: 20px;\n  background-color: white;\n  border: none;\n  width: auto;\n  padding: 7px 10px;\n  cursor: pointer;\n  white-space: nowrap;\n  align-self: flex-start;\n}\n\n.wave-animation[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 90px;\n  display: flex;\n  flex-direction: column;\n  justify-content: end;\n  padding: 0;\n}\n#small-water-drop[_ngcontent-%COMP%] {\n  width: clamp(30px, 7vw, 70px);\n  height: clamp(30px, 7vw, 70px);\n  top: 0px;\n  right: 0px;\n  position: absolute;\n  animation: _ngcontent-%COMP%_drop 10s ease-in-out forwards;\n}\n#big-water-drop[_ngcontent-%COMP%] {\n  width: clamp(80px, 14vw, 150px);\n  height: clamp(80px, 14vw, 150px);\n  position: absolute;\n  right: 0px;\n  bottom: 0px;\n  animation: _ngcontent-%COMP%_drop 10s ease-in-out forwards;\n}\n\n.w1[_ngcontent-%COMP%] {\n  stroke: none;\n  fill: #5dccfc;\n  opacity: 55%;\n  animation: _ngcontent-%COMP%_move1 2s ease-in-out infinite;\n}\n.w2[_ngcontent-%COMP%] {\n  stroke: none;\n  fill: #5dccfc;\n  opacity: 35%;\n  transform: translate3d(0, 0, 0);\n  animation: _ngcontent-%COMP%_move2 10s ease-in-out infinite;\n}\n.w3[_ngcontent-%COMP%] {\n  stroke: none;\n  fill: #5dccfc;\n  opacity: 30%;\n  transform: translate3d(0, 0, 0);\n  animation: _ngcontent-%COMP%_move3 15s ease-in-out infinite;\n}\n@keyframes _ngcontent-%COMP%_move1 {\n  0% {\n    transform: translateX(-400px) scaleX(2.5);\n  }\n  25% {\n    transform: translateX(-100px) scaleX(2.5);\n  }\n  50% {\n    transform: translateX(0) scaleX(2.5);\n  }\n  75% {\n    transform: translateX(-100px) scaleX(2.5);\n  }\n  100% {\n    transform: translateX(-400px) scaleX(2.5);\n  }\n}\n@keyframes _ngcontent-%COMP%_move2 {\n  0% {\n    transform: translateX(-600px) scaleX(3);\n  }\n  25% {\n    transform: translateX(-100px) scaleX(2);\n  }\n  50% {\n    transform: translateX(0) scaleX(3);\n  }\n  75% {\n    transform: translateX(-100px) scaleX(2.5);\n  }\n  100% {\n    transform: translateX(-600px) scaleX(3);\n  }\n}\n@keyframes _ngcontent-%COMP%_move3 {\n  0% {\n    transform: translateX(-800px) scaleX(3);\n  }\n  25% {\n    transform: translateX(-100px) scaleX(2.5);\n  }\n  50% {\n    transform: translateX(0) scaleX(3);\n  }\n  75% {\n    transform: translateX(-100px) scaleX(2.5);\n  }\n  100% {\n    transform: translateX(-800px) scaleX(3);\n  }\n}\n.progress[_ngcontent-%COMP%] {\n  height: 100%;\n  flex: 1;\n  display: flex;\n  flex-wrap: wrap;\n  flex-direction: column;\n}\n\n.progress[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  color: var(--primary-color);\n  font-size: 22px;\n  font-weight: 600;\n  margin-bottom: 10px;\n}\n\n.cups[_ngcontent-%COMP%] {\n  flex: 1;\n  width: 100%;\n  min-width: 250px;\n  display: flex;\n  flex-wrap: wrap;\n  gap: 20px;\n}\n\n.cup[_ngcontent-%COMP%] {\n  height: clamp(50px, 5.5vw, 80px);\n  width: clamp(40px, 3vw, 50px);\n  background-image: url('cup.svg');\n  background-position: center;\n  background-repeat: no-repeat;\n  position: relative;\n  border-radius: 0 0 15px 15px;\n  overflow: hidden;\n  clip-path: polygon(0 0, 100% 0, 90% 100%, 10% 100%);\n}\n.wave[_ngcontent-%COMP%] {\n  position: absolute;\n  bottom: 0;\n  width: 100%;\n  height: 100%;\n  overflow: hidden;\n  display: flex;\n  flex-direction: column;\n  justify-content: end;\n  transform: translateY(100%);\n}\n\n.wave.active[_ngcontent-%COMP%] {\n  animation: _ngcontent-%COMP%_fill 2s -0.5s forwards ease-in-out;\n}\n\n@keyframes _ngcontent-%COMP%_fill {\n  0% {\n    transform: translateY(100%); \n\n  }\n\n  100% {\n    transform: translateY(0); \n\n  }\n}\n\n.emoji[_ngcontent-%COMP%] {\n  position: absolute;\n  width: clamp(30px, 4vw, 100px);\n  top: 0px;\n  right: 0px;\n}\n\n@keyframes _ngcontent-%COMP%_drop {\n  0% {\n    transform: translateY(-20%); \n\n  }\n\n  100% {\n    transform: translateY(0); \n\n  }\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvZmVhdHVyZXMvd2F0ZXItdHJhY2tpbmcvd2F0ZXItdHJhY2tpbmcvd2F0ZXItdHJhY2tpbmcuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFdBQVc7RUFDWCxhQUFhO0VBQ2IsU0FBUztFQUNULG1CQUFtQjtFQUNuQixrQkFBa0I7QUFDcEI7QUFDQTtFQUNFLGdDQUFnQztFQUNoQyxnQkFBZ0I7RUFDaEIsYUFBYTtFQUNiLGFBQWE7RUFDYixzQkFBc0I7RUFDdEIsb0JBQW9CO0VBQ3BCLHVCQUF1QjtFQUN2QixtQkFBbUI7RUFDbkIsZ0JBQWdCO0VBQ2hCLGtCQUFrQjtFQUNsQixhQUFhO0FBQ2Y7QUFDQTtFQUNFLFdBQVc7RUFDWCxZQUFZO0VBQ1osYUFBYTtFQUNiLHNCQUFzQjtFQUN0QixhQUFhO0VBQ2Isa0JBQWtCO0VBQ2xCLE1BQU07RUFDTixPQUFPO0FBQ1Q7O0FBRUE7RUFDRSwyQkFBMkI7RUFDM0IsZUFBZTtFQUNmLGdCQUFnQjtBQUNsQjtBQUNBO0VBQ0UsY0FBYztFQUNkLGlDQUFpQztFQUNqQyxnQkFBZ0I7QUFDbEI7QUFDQTtFQUNFLGdCQUFnQjtFQUNoQixnQ0FBZ0M7RUFDaEMsbUJBQW1CO0VBQ25CLHVCQUF1QjtFQUN2QixZQUFZO0VBQ1osV0FBVztFQUNYLGlCQUFpQjtFQUNqQixlQUFlO0VBQ2YsbUJBQW1CO0VBQ25CLHNCQUFzQjtBQUN4Qjs7QUFFQTtFQUNFLFdBQVc7RUFDWCxZQUFZO0VBQ1osYUFBYTtFQUNiLHNCQUFzQjtFQUN0QixvQkFBb0I7RUFDcEIsVUFBVTtBQUNaO0FBQ0E7RUFDRSw2QkFBNkI7RUFDN0IsOEJBQThCO0VBQzlCLFFBQVE7RUFDUixVQUFVO0VBQ1Ysa0JBQWtCO0VBQ2xCLHdDQUF3QztBQUMxQztBQUNBO0VBQ0UsK0JBQStCO0VBQy9CLGdDQUFnQztFQUNoQyxrQkFBa0I7RUFDbEIsVUFBVTtFQUNWLFdBQVc7RUFDWCx3Q0FBd0M7QUFDMUM7O0FBRUE7RUFDRSxZQUFZO0VBQ1osYUFBYTtFQUNiLFlBQVk7RUFDWix3Q0FBd0M7QUFDMUM7QUFDQTtFQUNFLFlBQVk7RUFDWixhQUFhO0VBQ2IsWUFBWTtFQUNaLCtCQUErQjtFQUMvQix5Q0FBeUM7QUFDM0M7QUFDQTtFQUNFLFlBQVk7RUFDWixhQUFhO0VBQ2IsWUFBWTtFQUNaLCtCQUErQjtFQUMvQix5Q0FBeUM7QUFDM0M7QUFDQTtFQUNFO0lBQ0UseUNBQXlDO0VBQzNDO0VBQ0E7SUFDRSx5Q0FBeUM7RUFDM0M7RUFDQTtJQUNFLG9DQUFvQztFQUN0QztFQUNBO0lBQ0UseUNBQXlDO0VBQzNDO0VBQ0E7SUFDRSx5Q0FBeUM7RUFDM0M7QUFDRjtBQUNBO0VBQ0U7SUFDRSx1Q0FBdUM7RUFDekM7RUFDQTtJQUNFLHVDQUF1QztFQUN6QztFQUNBO0lBQ0Usa0NBQWtDO0VBQ3BDO0VBQ0E7SUFDRSx5Q0FBeUM7RUFDM0M7RUFDQTtJQUNFLHVDQUF1QztFQUN6QztBQUNGO0FBQ0E7RUFDRTtJQUNFLHVDQUF1QztFQUN6QztFQUNBO0lBQ0UseUNBQXlDO0VBQzNDO0VBQ0E7SUFDRSxrQ0FBa0M7RUFDcEM7RUFDQTtJQUNFLHlDQUF5QztFQUMzQztFQUNBO0lBQ0UsdUNBQXVDO0VBQ3pDO0FBQ0Y7QUFDQTtFQUNFLFlBQVk7RUFDWixPQUFPO0VBQ1AsYUFBYTtFQUNiLGVBQWU7RUFDZixzQkFBc0I7QUFDeEI7O0FBRUE7RUFDRSwyQkFBMkI7RUFDM0IsZUFBZTtFQUNmLGdCQUFnQjtFQUNoQixtQkFBbUI7QUFDckI7O0FBRUE7RUFDRSxPQUFPO0VBQ1AsV0FBVztFQUNYLGdCQUFnQjtFQUNoQixhQUFhO0VBQ2IsZUFBZTtFQUNmLFNBQVM7QUFDWDs7QUFFQTtFQUNFLGdDQUFnQztFQUNoQyw2QkFBNkI7RUFDN0IsZ0NBQWtEO0VBQ2xELDJCQUEyQjtFQUMzQiw0QkFBNEI7RUFDNUIsa0JBQWtCO0VBQ2xCLDRCQUE0QjtFQUM1QixnQkFBZ0I7RUFDaEIsbURBQW1EO0FBQ3JEO0FBQ0E7RUFDRSxrQkFBa0I7RUFDbEIsU0FBUztFQUNULFdBQVc7RUFDWCxZQUFZO0VBQ1osZ0JBQWdCO0VBQ2hCLGFBQWE7RUFDYixzQkFBc0I7RUFDdEIsb0JBQW9CO0VBQ3BCLDJCQUEyQjtBQUM3Qjs7QUFFQTtFQUNFLDZDQUE2QztBQUMvQzs7QUFFQTtFQUNFO0lBQ0UsMkJBQTJCLEVBQUUsOEJBQThCO0VBQzdEOztFQUVBO0lBQ0Usd0JBQXdCLEVBQUUsdUJBQXVCO0VBQ25EO0FBQ0Y7O0FBRUE7RUFDRSxrQkFBa0I7RUFDbEIsOEJBQThCO0VBQzlCLFFBQVE7RUFDUixVQUFVO0FBQ1o7O0FBRUE7RUFDRTtJQUNFLDJCQUEyQixFQUFFLDhCQUE4QjtFQUM3RDs7RUFFQTtJQUNFLHdCQUF3QixFQUFFLHVCQUF1QjtFQUNuRDtBQUNGIiwic291cmNlc0NvbnRlbnQiOlsiLndhdGVyLXRyYWNrZXItY29udGFpbmVyIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGdhcDogMjBweDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxufVxyXG4ud2F0ZXItdHJhY2tlci1ib3gtYmFja2dyb3VuZCB7XHJcbiAgd2lkdGg6IGNsYW1wKDIwMHB4LCAzMHZ3LCAzMDBweCk7XHJcbiAgbWluLXdpZHRoOiAyMDBweDtcclxuICBoZWlnaHQ6IDE2MnB4O1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGVuZDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICBib3JkZXItcmFkaXVzOiAxNXB4O1xyXG4gIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIHotaW5kZXg6IDEwMDA7XHJcbn1cclxuLndhdGVyLXRyYWNrZXItYm94IHtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gIHBhZGRpbmc6IDIwcHg7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHRvcDogMDtcclxuICBsZWZ0OiAwO1xyXG59XHJcblxyXG4ud2F0ZXItdHJhY2tlci1ib3ggaDMge1xyXG4gIGNvbG9yOiB2YXIoLS1wcmltYXJ5LWNvbG9yKTtcclxuICBmb250LXNpemU6IDIwcHg7XHJcbiAgZm9udC13ZWlnaHQ6IDYwMDtcclxufVxyXG4ud2F0ZXItdHJhY2tlci1ib3ggcCB7XHJcbiAgY29sb3I6ICM5MGE1YjQ7XHJcbiAgZm9udC1zaXplOiBjbGFtcCgxMnB4LCAydncsIDE0cHgpO1xyXG4gIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbn1cclxuLndhdGVyLXRyYWNrZXItYm94IGJ1dHRvbiB7XHJcbiAgbWFyZ2luLXRvcDogYXV0bztcclxuICBmb250LXNpemU6IGNsYW1wKDhweCwgMnZ3LCAxMnB4KTtcclxuICBib3JkZXItcmFkaXVzOiAyMHB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG4gIGJvcmRlcjogbm9uZTtcclxuICB3aWR0aDogYXV0bztcclxuICBwYWRkaW5nOiA3cHggMTBweDtcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcclxuICBhbGlnbi1zZWxmOiBmbGV4LXN0YXJ0O1xyXG59XHJcblxyXG4ud2F2ZS1hbmltYXRpb24ge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogOTBweDtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAganVzdGlmeS1jb250ZW50OiBlbmQ7XHJcbiAgcGFkZGluZzogMDtcclxufVxyXG4jc21hbGwtd2F0ZXItZHJvcCB7XHJcbiAgd2lkdGg6IGNsYW1wKDMwcHgsIDd2dywgNzBweCk7XHJcbiAgaGVpZ2h0OiBjbGFtcCgzMHB4LCA3dncsIDcwcHgpO1xyXG4gIHRvcDogMHB4O1xyXG4gIHJpZ2h0OiAwcHg7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIGFuaW1hdGlvbjogZHJvcCAxMHMgZWFzZS1pbi1vdXQgZm9yd2FyZHM7XHJcbn1cclxuI2JpZy13YXRlci1kcm9wIHtcclxuICB3aWR0aDogY2xhbXAoODBweCwgMTR2dywgMTUwcHgpO1xyXG4gIGhlaWdodDogY2xhbXAoODBweCwgMTR2dywgMTUwcHgpO1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICByaWdodDogMHB4O1xyXG4gIGJvdHRvbTogMHB4O1xyXG4gIGFuaW1hdGlvbjogZHJvcCAxMHMgZWFzZS1pbi1vdXQgZm9yd2FyZHM7XHJcbn1cclxuXHJcbi53MSB7XHJcbiAgc3Ryb2tlOiBub25lO1xyXG4gIGZpbGw6ICM1ZGNjZmM7XHJcbiAgb3BhY2l0eTogNTUlO1xyXG4gIGFuaW1hdGlvbjogbW92ZTEgMnMgZWFzZS1pbi1vdXQgaW5maW5pdGU7XHJcbn1cclxuLncyIHtcclxuICBzdHJva2U6IG5vbmU7XHJcbiAgZmlsbDogIzVkY2NmYztcclxuICBvcGFjaXR5OiAzNSU7XHJcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAwLCAwKTtcclxuICBhbmltYXRpb246IG1vdmUyIDEwcyBlYXNlLWluLW91dCBpbmZpbml0ZTtcclxufVxyXG4udzMge1xyXG4gIHN0cm9rZTogbm9uZTtcclxuICBmaWxsOiAjNWRjY2ZjO1xyXG4gIG9wYWNpdHk6IDMwJTtcclxuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDAsIDApO1xyXG4gIGFuaW1hdGlvbjogbW92ZTMgMTVzIGVhc2UtaW4tb3V0IGluZmluaXRlO1xyXG59XHJcbkBrZXlmcmFtZXMgbW92ZTEge1xyXG4gIDAlIHtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWCgtNDAwcHgpIHNjYWxlWCgyLjUpO1xyXG4gIH1cclxuICAyNSUge1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKC0xMDBweCkgc2NhbGVYKDIuNSk7XHJcbiAgfVxyXG4gIDUwJSB7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoMCkgc2NhbGVYKDIuNSk7XHJcbiAgfVxyXG4gIDc1JSB7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoLTEwMHB4KSBzY2FsZVgoMi41KTtcclxuICB9XHJcbiAgMTAwJSB7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoLTQwMHB4KSBzY2FsZVgoMi41KTtcclxuICB9XHJcbn1cclxuQGtleWZyYW1lcyBtb3ZlMiB7XHJcbiAgMCUge1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKC02MDBweCkgc2NhbGVYKDMpO1xyXG4gIH1cclxuICAyNSUge1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKC0xMDBweCkgc2NhbGVYKDIpO1xyXG4gIH1cclxuICA1MCUge1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKDApIHNjYWxlWCgzKTtcclxuICB9XHJcbiAgNzUlIHtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWCgtMTAwcHgpIHNjYWxlWCgyLjUpO1xyXG4gIH1cclxuICAxMDAlIHtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWCgtNjAwcHgpIHNjYWxlWCgzKTtcclxuICB9XHJcbn1cclxuQGtleWZyYW1lcyBtb3ZlMyB7XHJcbiAgMCUge1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKC04MDBweCkgc2NhbGVYKDMpO1xyXG4gIH1cclxuICAyNSUge1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKC0xMDBweCkgc2NhbGVYKDIuNSk7XHJcbiAgfVxyXG4gIDUwJSB7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoMCkgc2NhbGVYKDMpO1xyXG4gIH1cclxuICA3NSUge1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKC0xMDBweCkgc2NhbGVYKDIuNSk7XHJcbiAgfVxyXG4gIDEwMCUge1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKC04MDBweCkgc2NhbGVYKDMpO1xyXG4gIH1cclxufVxyXG4ucHJvZ3Jlc3Mge1xyXG4gIGhlaWdodDogMTAwJTtcclxuICBmbGV4OiAxO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC13cmFwOiB3cmFwO1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbn1cclxuXHJcbi5wcm9ncmVzcyBoMiB7XHJcbiAgY29sb3I6IHZhcigtLXByaW1hcnktY29sb3IpO1xyXG4gIGZvbnQtc2l6ZTogMjJweDtcclxuICBmb250LXdlaWdodDogNjAwO1xyXG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XHJcbn1cclxuXHJcbi5jdXBzIHtcclxuICBmbGV4OiAxO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIG1pbi13aWR0aDogMjUwcHg7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LXdyYXA6IHdyYXA7XHJcbiAgZ2FwOiAyMHB4O1xyXG59XHJcblxyXG4uY3VwIHtcclxuICBoZWlnaHQ6IGNsYW1wKDUwcHgsIDUuNXZ3LCA4MHB4KTtcclxuICB3aWR0aDogY2xhbXAoNDBweCwgM3Z3LCA1MHB4KTtcclxuICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCJzcmMvYXNzZXRzL2ltYWdlcy9jdXAuc3ZnXCIpO1xyXG4gIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcclxuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICBib3JkZXItcmFkaXVzOiAwIDAgMTVweCAxNXB4O1xyXG4gIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgY2xpcC1wYXRoOiBwb2x5Z29uKDAgMCwgMTAwJSAwLCA5MCUgMTAwJSwgMTAlIDEwMCUpO1xyXG59XHJcbi53YXZlIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgYm90dG9tOiAwO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMTAwJTtcclxuICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGVuZDtcclxuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMTAwJSk7XHJcbn1cclxuXHJcbi53YXZlLmFjdGl2ZSB7XHJcbiAgYW5pbWF0aW9uOiBmaWxsIDJzIC0wLjVzIGZvcndhcmRzIGVhc2UtaW4tb3V0O1xyXG59XHJcblxyXG5Aa2V5ZnJhbWVzIGZpbGwge1xyXG4gIDAlIHtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgxMDAlKTsgLyogV2F2ZSBzdGFydHMgYmVsb3cgdGhlIGN1cCAqL1xyXG4gIH1cclxuXHJcbiAgMTAwJSB7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7IC8qIFdhdmUgZmlsbHMgdGhlIGN1cCAqL1xyXG4gIH1cclxufVxyXG5cclxuLmVtb2ppIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgd2lkdGg6IGNsYW1wKDMwcHgsIDR2dywgMTAwcHgpO1xyXG4gIHRvcDogMHB4O1xyXG4gIHJpZ2h0OiAwcHg7XHJcbn1cclxuXHJcbkBrZXlmcmFtZXMgZHJvcCB7XHJcbiAgMCUge1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC0yMCUpOyAvKiBXYXZlIHN0YXJ0cyBiZWxvdyB0aGUgY3VwICovXHJcbiAgfVxyXG5cclxuICAxMDAlIHtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgwKTsgLyogV2F2ZSBmaWxscyB0aGUgY3VwICovXHJcbiAgfVxyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
    });
  }
}
var WaterTrackingStatus;
(function (WaterTrackingStatus) {
  WaterTrackingStatus["VERY_HAPPY"] = "very-happy";
  WaterTrackingStatus["HAPPY"] = "happy";
  WaterTrackingStatus["NEUTRAL"] = "neutral";
  WaterTrackingStatus["SAD"] = "sad";
  WaterTrackingStatus["VERY_SAD"] = "very-sad";
})(WaterTrackingStatus || (WaterTrackingStatus = {}));

/***/ }),

/***/ 4477:
/*!****************************************!*\
  !*** ./src/app/models/client.model.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ActivityLevelEnum: () => (/* binding */ ActivityLevelEnum),
/* harmony export */   ClientModel: () => (/* binding */ ClientModel),
/* harmony export */   GenderEnum: () => (/* binding */ GenderEnum),
/* harmony export */   UserRoleEnum: () => (/* binding */ UserRoleEnum)
/* harmony export */ });
/* harmony import */ var _user_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./user.model */ 3873);

class ClientModel extends _user_model__WEBPACK_IMPORTED_MODULE_0__.UserModel {
  constructor(name, email, password, phoneNumber, profilePictureUrl, gender, birthDate, role, height, weight, favoriteRecipes = [], objectif, activityLevel, reservedSlots = [], reservedSlotsCount = 0, id) {
    super(name, email, password, phoneNumber, profilePictureUrl, gender, birthDate, role, id);
    this.height = height;
    this.weight = weight;
    this.favoriteRecipes = favoriteRecipes;
    this.objectif = objectif;
    this.activityLevel = activityLevel;
    this.reservedSlots = reservedSlots;
    this.reservedSlotsCount = reservedSlotsCount;
  }
  /**
   * Calculates the age of the client based on their birth date.
   * @returns The calculated age as a number.
   */
  getClientAge() {
    const today = new Date();
    const birthDate = new Date(this.birthDate);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || monthDiff === 0 && today.getDate() < birthDate.getDate()) {
      age--;
    }
    return age;
  }
}
var GenderEnum;
(function (GenderEnum) {
  GenderEnum["MALE"] = "homme";
  GenderEnum["FEMALE"] = "femme";
})(GenderEnum || (GenderEnum = {}));
var UserRoleEnum;
(function (UserRoleEnum) {
  UserRoleEnum["CLIENT"] = "Client";
  UserRoleEnum["NUTRITIONIST"] = "Nutritionist";
  UserRoleEnum["ADMIN"] = "Admin";
})(UserRoleEnum || (UserRoleEnum = {}));
var ActivityLevelEnum;
(function (ActivityLevelEnum) {
  ActivityLevelEnum["SEDENTAIRE"] = "S\u00E9dentaire";
  ActivityLevelEnum["LEG_ACTIF"] = "L\u00E9g\u00E8rement actif";
  ActivityLevelEnum["MOD_ACTIF"] = "Mod\u00E9r\u00E9ment actif";
  ActivityLevelEnum["TRES_ACTIF"] = "Tr\u00E8s actif";
  ActivityLevelEnum["EXT_ACTIF"] = "Extr\u00EAmement actif";
})(ActivityLevelEnum || (ActivityLevelEnum = {}));

/***/ }),

/***/ 4942:
/*!**********************************************!*\
  !*** ./src/app/models/nutritionist.model.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   NutritionistModel: () => (/* binding */ NutritionistModel),
/* harmony export */   StatusEnum: () => (/* binding */ StatusEnum),
/* harmony export */   StatusEnumFilter: () => (/* binding */ StatusEnumFilter),
/* harmony export */   TrieEnum: () => (/* binding */ TrieEnum)
/* harmony export */ });
/* harmony import */ var _user_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./user.model */ 3873);

class NutritionistModel extends _user_model__WEBPACK_IMPORTED_MODULE_0__.UserModel {
  constructor(name, email, password, phoneNumber, profilePictureUrl, gender, birthDate, role, experienceYears, certificateUrl, status, location, id, patientsNumber = 0, stars) {
    super(name, email, password, phoneNumber, profilePictureUrl, gender, birthDate, role, id);
    this.experienceYears = experienceYears;
    this.certificateUrl = certificateUrl;
    this.status = status;
    this.location = location;
    this.patientsNumber = patientsNumber;
    this.stars = stars;
    this.stars = stars ?? 4;
  }
}
var TrieEnum;
(function (TrieEnum) {
  TrieEnum["ALL"] = "Tous";
  TrieEnum["PlusRecents"] = "Plus R\u00E9cents";
  TrieEnum["PlusAnciens"] = "Plus Anciens";
})(TrieEnum || (TrieEnum = {}));
var StatusEnum;
(function (StatusEnum) {
  StatusEnum["Approved"] = "Approuv\u00E9";
  StatusEnum["Rejected"] = "Rejet\u00E9";
  StatusEnum["Waiting"] = "En attente";
})(StatusEnum || (StatusEnum = {}));
var StatusEnumFilter;
(function (StatusEnumFilter) {
  StatusEnumFilter["ALL"] = "Tous";
  StatusEnumFilter["Approved"] = "Approuv\u00E9";
  StatusEnumFilter["Rejected"] = "Rejet\u00E9";
  StatusEnumFilter["Waiting"] = "En attente";
})(StatusEnumFilter || (StatusEnumFilter = {}));

/***/ }),

/***/ 6464:
/*!****************************************!*\
  !*** ./src/app/models/recipe.model.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CategoryEnum: () => (/* binding */ CategoryEnum),
/* harmony export */   ExperienceEnum: () => (/* binding */ ExperienceEnum),
/* harmony export */   ObjectifEnum: () => (/* binding */ ObjectifEnum),
/* harmony export */   PreparationTimeEnum: () => (/* binding */ PreparationTimeEnum)
/* harmony export */ });
var ObjectifEnum;
(function (ObjectifEnum) {
  ObjectifEnum["ALL"] = "Tous";
  ObjectifEnum["PERDRE_POIDS"] = "Perdre du poids";
  ObjectifEnum["PRENDRE_POIDS"] = "Prendre du poids";
  ObjectifEnum["MUSCLER"] = "Se muscler";
})(ObjectifEnum || (ObjectifEnum = {}));
var CategoryEnum;
(function (CategoryEnum) {
  CategoryEnum["ALL"] = "Tous";
  CategoryEnum["DINER"] = "Diner";
  CategoryEnum["DEJ"] = "D\u00E9jeuner";
  CategoryEnum["PETIT_DEJ"] = "Petit D\u00E9jeuner";
  CategoryEnum["SNACK"] = "Snack";
  CategoryEnum["ENTREE"] = "Entr\u00E9e";
  CategoryEnum["PRINCIPAL"] = "Plat principal";
})(CategoryEnum || (CategoryEnum = {}));
var PreparationTimeEnum;
(function (PreparationTimeEnum) {
  PreparationTimeEnum["ALL"] = "Tous";
  PreparationTimeEnum["VERY_SHORT"] = "Moins de 15 minutes";
  PreparationTimeEnum["SHORT"] = "15-30 minutes";
  PreparationTimeEnum["MEDIUM"] = "30-45 minutes";
  PreparationTimeEnum["LONG"] = "45-60 minutes";
  PreparationTimeEnum["VERY_LONG"] = "Plus de 60 minutes";
})(PreparationTimeEnum || (PreparationTimeEnum = {}));
var ExperienceEnum;
(function (ExperienceEnum) {
  ExperienceEnum["ALL"] = "Tous";
  ExperienceEnum["JUNIOR"] = "1-3 ans";
  ExperienceEnum["MID_LEVEL"] = "4-6 ans";
  ExperienceEnum["SENIOR"] = "7-10 ans";
  ExperienceEnum["SENIOR_PLUS"] = "Plus de 10 ans";
})(ExperienceEnum || (ExperienceEnum = {}));

/***/ }),

/***/ 3873:
/*!**************************************!*\
  !*** ./src/app/models/user.model.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   UserModel: () => (/* binding */ UserModel)
/* harmony export */ });
class UserModel {
  constructor(name, email, password, phoneNumber, profilePictureUrl, gender, birthDate, role, id) {
    this.name = name;
    this.email = email;
    this.password = password;
    this.phoneNumber = phoneNumber;
    this.profilePictureUrl = profilePictureUrl;
    this.gender = gender;
    this.birthDate = birthDate;
    this.role = role;
    this.id = id;
  }
  getPass() {
    return this.password;
  }
}

/***/ }),

/***/ 4796:
/*!******************************************!*\
  !*** ./src/app/services/auth.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthService: () => (/* binding */ AuthService)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _models_client_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../models/client.model */ 4477);
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ngx-toastr */ 4285);
/* harmony import */ var _core_constants_constants_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../core/constants/constants.config */ 8111);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ 6443);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 5072);
/* harmony import */ var _core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../core/utils/functions.utils */ 3584);
/* harmony import */ var _client_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./client.service */ 8281);
/* harmony import */ var _nutritionists_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./nutritionists.service */ 1895);










class AuthService {
  constructor() {
    this.isAuthenticated = true;
    this.userRole = 'client';
    this.toastr = (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.inject)(ngx_toastr__WEBPACK_IMPORTED_MODULE_6__.ToastrService);
    this.http = (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.inject)(_angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpClient);
    this.apiUrl = _core_constants_constants_config__WEBPACK_IMPORTED_MODULE_1__.APP_API.base_url + '/auth';
    this.router = (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.inject)(_angular_router__WEBPACK_IMPORTED_MODULE_8__.Router);
    this.clientService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.inject)(_client_service__WEBPACK_IMPORTED_MODULE_3__.ClientService);
    this.nutritionistService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.inject)(_nutritionists_service__WEBPACK_IMPORTED_MODULE_4__.NutritionistsService);
  }
  addUser(user) {
    return this.http.post(`${this.apiUrl}/signup`, user);
  }
  signupUser(user) {
    this.addUser(user).subscribe({
      next: response => {
        this.toastr.success('User Signed up successfully', 'Success');
        if (user.role == _models_client_model__WEBPACK_IMPORTED_MODULE_0__.UserRoleEnum.CLIENT) this.login(user.email, user.getPass());else this.toastr.info('Please wait until the Admin approves your candidature.', 'Candidature Validation', {
          timeOut: 10000 // Stay for 10 seconds
        });

        this.router.navigate(['/']);
      },
      error: error => {
        this.toastr.error(_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_2__.AppUtils.getErrorMessage(error), 'Error');
      }
    });
    this.userRole = user.role;
  }
  // signupNutritionist(nutritionist: NutritionistModel): void {
  //   this.addUser(nutritionist).subscribe({
  //     next: (response) => {
  //       this.toastr.success('User created successfully', 'Success');
  //       // this.login(nutritionist.email, nutritionist.getPass());
  //     },
  //     error: (error) => {
  //       this.toastr.error(AppUtils.getErrorMessage(error), 'Error');
  //     },
  //   });
  //   this.userRole = nutritionist.role;
  // }
  login(email, password) {
    const credentials = {
      email: email,
      password: password
    };
    this.http.post(`${this.apiUrl}/login`, credentials).subscribe({
      next: response => {
        this.toastr.success('Login successful', 'Success');
        const token = response.accessToken;
        const user = response.user;
        localStorage.setItem(_core_constants_constants_config__WEBPACK_IMPORTED_MODULE_1__.APP_CONST.tokenLocalStorage, token);
        localStorage.setItem(_core_constants_constants_config__WEBPACK_IMPORTED_MODULE_1__.APP_CONST.role, user.role);
        localStorage.setItem(_core_constants_constants_config__WEBPACK_IMPORTED_MODULE_1__.APP_CONST.payloadIdKey, user.id);
        localStorage.setItem(_core_constants_constants_config__WEBPACK_IMPORTED_MODULE_1__.APP_CONST.nameLocalStorage, user.name);
        console.log('====================================');
        console.log('role is', user.role);
        console.log('====================================');
        if (user.role === _models_client_model__WEBPACK_IMPORTED_MODULE_0__.UserRoleEnum.CLIENT) {
          this.router.navigate(['/client-home']);
        } else if (user.role === _models_client_model__WEBPACK_IMPORTED_MODULE_0__.UserRoleEnum.NUTRITIONIST) {
          this.router.navigate(['/nutritionist-home']);
        } else {
          this.router.navigate(['/admin-home']);
        }
      },
      error: error => {
        this.toastr.error(_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_2__.AppUtils.getErrorMessage(error), 'Error');
      }
    });
    this.isAuthenticated = true;
    localStorage.setItem('isAuthenticated', 'true');
  }
  logout() {
    this.isAuthenticated = false;
    this.userRole = '';
    localStorage.clear();
  }
  resetPasswordRequest(email) {
    return this.http.post(`${this.apiUrl}/request-password-reset`, {
      email
    });
  }
  resetPassword(resetToken, oldPassword, newPassword) {
    return this.http.post(`${this.apiUrl}/reset-password`, {
      resetToken,
      oldPassword,
      newPassword
    });
  }
  isLoggedIn() {
    return localStorage.getItem('isAuthenticated') === 'true';
  }
  getUserRole() {
    return localStorage.getItem(_core_constants_constants_config__WEBPACK_IMPORTED_MODULE_1__.APP_CONST.role) || 'client';
  }
  getUserId() {
    return localStorage.getItem(_core_constants_constants_config__WEBPACK_IMPORTED_MODULE_1__.APP_CONST.payloadIdKey) || '';
  }
  getUserName() {
    return localStorage.getItem(_core_constants_constants_config__WEBPACK_IMPORTED_MODULE_1__.APP_CONST.nameLocalStorage) || '';
  }
  getUserInfos() {
    const role = this.getUserRole();
    if (role === _models_client_model__WEBPACK_IMPORTED_MODULE_0__.UserRoleEnum.CLIENT) {
      return this.clientService.getClientById(this.getUserId());
    } else if (role === _models_client_model__WEBPACK_IMPORTED_MODULE_0__.UserRoleEnum.NUTRITIONIST) {
      return this.nutritionistService.getNutritionistById(this.getUserId());
    } else {
      return undefined;
    }
  }
  static {
    this.ɵfac = function AuthService_Factory(t) {
      return new (t || AuthService)();
    };
  }
  static {
    this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjectable"]({
      token: AuthService,
      factory: AuthService.ɵfac,
      providedIn: 'root'
    });
  }
}

/***/ }),

/***/ 8281:
/*!********************************************!*\
  !*** ./src/app/services/client.service.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ClientService: () => (/* binding */ ClientService)
/* harmony export */ });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ 6443);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 819);
/* harmony import */ var _core_constants_constants_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../core/constants/constants.config */ 8111);





class ClientService {
  #clients;
  #selectPatientSubject$;
  constructor() {
    this.clients = [];
    this.#clients = [];
    this.apiUrl = _core_constants_constants_config__WEBPACK_IMPORTED_MODULE_0__.APP_API.base_url + '/clients';
    this.#selectPatientSubject$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    this.selectPatient$ = this.#selectPatientSubject$.asObservable();
    this.http = (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.inject)(_angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient);
  }
  selectPatient(patient) {
    this.#selectPatientSubject$.next(patient);
  }
  getAllClients() {
    return this.http.get(this.apiUrl);
  }
  getClientById(id) {
    return this.http.get(`${this.apiUrl}/${id}`);
  }
  deleteClient(id) {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }
  updateClient(id, nutritionnist) {
    return this.http.patch(`${this.apiUrl}/${id}`, nutritionnist);
  }
  addRecipeToFavourite(recipeID, clientId) {
    return this.http.post(`${this.apiUrl}/${clientId}/favorites`, {
      recipeId: recipeID
    });
  }
  getAppointment(clientId, nutritionnistId, appointmentNumber = 0) {
    let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpParams();
    // Append the query parameter if appointementNumber is specified
    if (appointmentNumber > 0) {
      params = params.set('appointmentNumber', appointmentNumber);
    }
    return this.http.get(`${this.apiUrl}/${clientId}/appointments/${nutritionnistId}`, {
      params
    });
  }
  static {
    this.ɵfac = function ClientService_Factory(t) {
      return new (t || ClientService)();
    };
  }
  static {
    this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
      token: ClientService,
      factory: ClientService.ɵfac,
      providedIn: 'root'
    });
  }
}

/***/ }),

/***/ 8222:
/*!*************************************************!*\
  !*** ./src/app/services/file-upload.service.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FileUploadService: () => (/* binding */ FileUploadService)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _core_constants_constants_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../core/constants/constants.config */ 8111);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 6443);




class FileUploadService {
  constructor() {
    this.apiUrl = _core_constants_constants_config__WEBPACK_IMPORTED_MODULE_0__.APP_API.base_url + '/upload';
    this.http = (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.inject)(_angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClient);
  }
  uploadImage(image) {
    var formData = new FormData();
    formData.append('file', image);
    console.log(formData.get('file'));
    return this.http.post(`${this.apiUrl}/image`, formData);
  }
  uploadFile(file) {
    var formData = new FormData();
    formData.append('file', file);
    console.log(formData.get('file'));
    return this.http.post(`${this.apiUrl}/file`, formData);
  }
  downloadCertificate(filename) {
    return this.http.get(this.apiUrl + '/' + filename, {
      responseType: 'blob'
    });
  }
  static {
    this.ɵfac = function FileUploadService_Factory(t) {
      return new (t || FileUploadService)();
    };
  }
  static {
    this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
      token: FileUploadService,
      factory: FileUploadService.ɵfac,
      providedIn: 'root'
    });
  }
}

/***/ }),

/***/ 4798:
/*!********************************************!*\
  !*** ./src/app/services/logger.service.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LoggerService: () => (/* binding */ LoggerService)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 7580);

class LoggerService {
  static log(arg0) {
    throw new Error('Method not implemented.');
  }
  constructor() {
    // Set the environment dynamically if needed.
    this.isProduction = false; // Replace with your environment condition
  }

  info(message, ...optionalParams) {
    if (!this.isProduction) {
      console.info(`INFO: ${message}`, ...optionalParams);
    }
  }
  warn(message, ...optionalParams) {
    if (!this.isProduction) {
      console.warn(`WARN: ${message}`, ...optionalParams);
    }
  }
  error(message, ...optionalParams) {
    console.error(`ERROR: ${message}`, ...optionalParams);
  }
  debug(message, ...optionalParams) {
    if (!this.isProduction) {
      console.debug(`DEBUG: ${message}`, ...optionalParams);
    }
  }
  log(message, ...optionalParams) {
    if (!this.isProduction) {
      console.log(`LOG: ${message}`, ...optionalParams);
    }
  }
  static {
    this.ɵfac = function LoggerService_Factory(t) {
      return new (t || LoggerService)();
    };
  }
  static {
    this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
      token: LoggerService,
      factory: LoggerService.ɵfac,
      providedIn: 'root'
    });
  }
}

/***/ }),

/***/ 1895:
/*!***************************************************!*\
  !*** ./src/app/services/nutritionists.service.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   NutritionistsService: () => (/* binding */ NutritionistsService)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _core_constants_constants_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../core/constants/constants.config */ 8111);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 6443);

// import { generateFakeNutritionist } from '../core/helpers/faker.helper';



class NutritionistsService {
  #nutritionists;
  constructor() {
    this.nutritionists = [];
    this.#nutritionists = [];
    this.apiUrl = _core_constants_constants_config__WEBPACK_IMPORTED_MODULE_0__.APP_API.base_url + '/nutritionists';
    this.http = (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.inject)(_angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClient);
  }
  getAllNutritionists(page = 1, limit = 12) {
    let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpParams();
    if (page > 0) {
      params = params.set('page', page.toString());
    }
    if (limit > 0) {
      params = params.set('limit', limit.toString());
    }
    return this.http.get(this.apiUrl, {
      params
    });
  }
  getBestNutritionists() {
    return this.http.get(this.apiUrl + '/top');
  }
  getNutritionistById(id) {
    return this.http.get(`${this.apiUrl}/${id}`);
  }
  getPatientsByNutritionist(id) {
    return this.http.get(`${this.apiUrl}/${id}/patients`);
  }
  deleteNutritionist(id) {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }
  // addNutritionist(
  //   nutritionnist: NutritionistModel
  // ): Observable<NutritionistModel> {
  //   return this.http.post<NutritionistModel>(this.apiUrl, nutritionnist);
  // }
  updateNutritionist(id, status) {
    return this.http.patch(`${this.apiUrl}/${id}`, {
      status
    });
  }
  static {
    this.ɵfac = function NutritionistsService_Factory(t) {
      return new (t || NutritionistsService)();
    };
  }
  static {
    this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
      token: NutritionistsService,
      factory: NutritionistsService.ɵfac,
      providedIn: 'root'
    });
  }
}

/***/ }),

/***/ 6543:
/*!**********************************************!*\
  !*** ./src/app/services/planning.service.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PlanningService: () => (/* binding */ PlanningService)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _core_constants_constants_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../core/constants/constants.config */ 8111);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 6443);




class PlanningService {
  constructor() {
    this.apiUrl = _core_constants_constants_config__WEBPACK_IMPORTED_MODULE_0__.APP_API.base_url + '/planning';
    this.http = (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.inject)(_angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClient);
  }
  getUnavailableSlotsByNutritionist(nutritionistId) {
    return this.http.get(`${this.apiUrl}/${nutritionistId}`);
  }
  addSlot(slot) {
    return this.http.post(`${this.apiUrl}`, slot);
  }
  addNote(slotId, notes) {
    return this.http.patch(`${this.apiUrl}/${slotId}`, {
      notes
    });
  }
  cancelSlotReservation(id) {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }
  static {
    this.ɵfac = function PlanningService_Factory(t) {
      return new (t || PlanningService)();
    };
  }
  static {
    this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
      token: PlanningService,
      factory: PlanningService.ɵfac,
      providedIn: 'root'
    });
  }
}

/***/ }),

/***/ 4964:
/*!********************************************!*\
  !*** ./src/app/services/recipe.service.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RecipesService: () => (/* binding */ RecipesService)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ 6443);
/* harmony import */ var _core_helpers_faker_helper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../core/helpers/faker.helper */ 4113);
/* harmony import */ var _core_constants_constants_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../core/constants/constants.config */ 8111);





class RecipesService {
  #recipes;
  constructor() {
    this.#recipes = [];
    this.apiUrl = _core_constants_constants_config__WEBPACK_IMPORTED_MODULE_1__.APP_API.base_url + '/recipes';
    this.http = (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.inject)(_angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient);
  }
  getAllRecipes(page = 1, limit = 12) {
    let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpParams();
    if (page > 0) {
      params = params.set('page', page.toString());
    }
    if (limit > 0) {
      params = params.set('limit', limit.toString());
    }
    return this.http.get(this.apiUrl, {
      params
    });
  }
  getRecipeById(id) {
    return this.http.get(`${this.apiUrl}/${id}`);
  }
  deleteRecipe(id) {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }
  addRecipe(recipe) {
    return this.http.post(this.apiUrl, recipe);
  }
  updateRecipe(id, recipe) {
    return this.http.patch(`${this.apiUrl}/${id}`, recipe);
  }
  /**
   *
   * Retourne un liste fictive de cvs
   *
   * @returns RecipeModel[]
   *
   */
  // Get all recipes
  // getAllRecipes(): RecipeModel[] {
  //   return this.recipes.length
  //     ? this.recipes
  //     : this.generateFakeRecipesList(12);
  // }
  getPopularRecipes() {
    return this.generateFakeRecipesList(4);
  }
  generateFakeRecipesList(count) {
    return Array.from({
      length: count
    }, () => (0,_core_helpers_faker_helper__WEBPACK_IMPORTED_MODULE_0__.generateFakeRecipe)());
  }
  static {
    this.ɵfac = function RecipesService_Factory(t) {
      return new (t || RecipesService)();
    };
  }
  static {
    this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
      token: RecipesService,
      factory: RecipesService.ɵfac,
      providedIn: 'root'
    });
  }
}

/***/ }),

/***/ 1765:
/*!************************************************************************************!*\
  !*** ./src/app/shared/components/auth-account-type/auth-account-type.component.ts ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthAccountTypeComponent: () => (/* binding */ AuthAccountTypeComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 7580);


class AuthAccountTypeComponent {
  constructor() {
    this.type = '';
    this.description = '';
    this.selectedType = '';
    // Default values for iconType1 and iconType2
    this.iconType1 = 'assets/images/type1.png';
    this.iconType2 = 'assets/images/type2.png';
    this.typeSelected = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
  }
  selectType() {
    this.typeSelected.emit(this.type);
  }
  static {
    this.ɵfac = function AuthAccountTypeComponent_Factory(t) {
      return new (t || AuthAccountTypeComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: AuthAccountTypeComponent,
      selectors: [["app-auth-account-type"]],
      inputs: {
        type: "type",
        description: "description",
        selectedType: "selectedType"
      },
      outputs: {
        typeSelected: "typeSelected"
      },
      decls: 8,
      vars: 8,
      consts: [[1, "account-type-card", 3, "click"], [1, "icon-container"], [1, "icon", 3, "src", "alt"], [1, "account-info"], [1, "account-title"]],
      template: function AuthAccountTypeComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AuthAccountTypeComponent_Template_div_click_0_listener() {
            return ctx.selectType();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "img", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 3)(4, "h3", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("selected", ctx.selectedType === ctx.type);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("active", ctx.selectedType === ctx.type);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("src", ctx.selectedType === ctx.type ? ctx.iconType2 : ctx.iconType1, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"])("alt", ctx.type);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.type);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.description);
        }
      },
      styles: [".account-type-card[_ngcontent-%COMP%] {\n  gap: 20px;\n  display: flex;\n  align-items: center;\n  padding: 0.8rem 1rem;\n  border-radius: 8px;\n  background-color: #f9f6f2;\n  cursor: pointer;\n  transition: background-color 0.3s ease, box-shadow 0.3s ease;\n  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.1);\n}\n\n.account-type-card.selected[_ngcontent-%COMP%] {\n  background-color: #ffffff;\n  box-shadow: 0 4px 10px var(--light-green);\n}\n\n.icon-container[_ngcontent-%COMP%] {\n  width: 100px;\n  height: 60px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  border-radius: 4px;\n  transition: background-color 0.3s ease;\n}\n\n.icon-container.active[_ngcontent-%COMP%] {\n  background-color: var(--secondary-color);\n}\n\n.icon[_ngcontent-%COMP%] {\n  width: 40px;\n  height: 40px;\n}\n\n.account-info[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: clamp(0.8rem, 2vw, 1.1rem);\n  color: var(--text-color);\n}\n\n.account-info[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 5px 0 0;\n  font-size: clamp(0.6rem, 2vw, 0.9rem);\n  color: var(--hint-text);\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvYXV0aC1hY2NvdW50LXR5cGUvYXV0aC1hY2NvdW50LXR5cGUuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFNBQVM7RUFDVCxhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLG9CQUFvQjtFQUNwQixrQkFBa0I7RUFDbEIseUJBQXlCO0VBQ3pCLGVBQWU7RUFDZiw0REFBNEQ7RUFDNUQsd0NBQXdDO0FBQzFDOztBQUVBO0VBQ0UseUJBQXlCO0VBQ3pCLHlDQUF5QztBQUMzQzs7QUFFQTtFQUNFLFlBQVk7RUFDWixZQUFZO0VBQ1osYUFBYTtFQUNiLG1CQUFtQjtFQUNuQix1QkFBdUI7RUFDdkIsa0JBQWtCO0VBQ2xCLHNDQUFzQztBQUN4Qzs7QUFFQTtFQUNFLHdDQUF3QztBQUMxQzs7QUFFQTtFQUNFLFdBQVc7RUFDWCxZQUFZO0FBQ2Q7O0FBRUE7RUFDRSxTQUFTO0VBQ1QscUNBQXFDO0VBQ3JDLHdCQUF3QjtBQUMxQjs7QUFFQTtFQUNFLGVBQWU7RUFDZixxQ0FBcUM7RUFDckMsdUJBQXVCO0FBQ3pCIiwic291cmNlc0NvbnRlbnQiOlsiLmFjY291bnQtdHlwZS1jYXJkIHtcclxuICBnYXA6IDIwcHg7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIHBhZGRpbmc6IDAuOHJlbSAxcmVtO1xyXG4gIGJvcmRlci1yYWRpdXM6IDhweDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjlmNmYyO1xyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxuICB0cmFuc2l0aW9uOiBiYWNrZ3JvdW5kLWNvbG9yIDAuM3MgZWFzZSwgYm94LXNoYWRvdyAwLjNzIGVhc2U7XHJcbiAgYm94LXNoYWRvdzogMCAxcHggNHB4IHJnYmEoMCwgMCwgMCwgMC4xKTtcclxufVxyXG5cclxuLmFjY291bnQtdHlwZS1jYXJkLnNlbGVjdGVkIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmO1xyXG4gIGJveC1zaGFkb3c6IDAgNHB4IDEwcHggdmFyKC0tbGlnaHQtZ3JlZW4pO1xyXG59XHJcblxyXG4uaWNvbi1jb250YWluZXIge1xyXG4gIHdpZHRoOiAxMDBweDtcclxuICBoZWlnaHQ6IDYwcHg7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICB0cmFuc2l0aW9uOiBiYWNrZ3JvdW5kLWNvbG9yIDAuM3MgZWFzZTtcclxufVxyXG5cclxuLmljb24tY29udGFpbmVyLmFjdGl2ZSB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tc2Vjb25kYXJ5LWNvbG9yKTtcclxufVxyXG5cclxuLmljb24ge1xyXG4gIHdpZHRoOiA0MHB4O1xyXG4gIGhlaWdodDogNDBweDtcclxufVxyXG5cclxuLmFjY291bnQtaW5mbyBoMyB7XHJcbiAgbWFyZ2luOiAwO1xyXG4gIGZvbnQtc2l6ZTogY2xhbXAoMC44cmVtLCAydncsIDEuMXJlbSk7XHJcbiAgY29sb3I6IHZhcigtLXRleHQtY29sb3IpO1xyXG59XHJcblxyXG4uYWNjb3VudC1pbmZvIHAge1xyXG4gIG1hcmdpbjogNXB4IDAgMDtcclxuICBmb250LXNpemU6IGNsYW1wKDAuNnJlbSwgMnZ3LCAwLjlyZW0pO1xyXG4gIGNvbG9yOiB2YXIoLS1oaW50LXRleHQpO1xyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
    });
  }
}

/***/ }),

/***/ 3793:
/*!********************************************************************************!*\
  !*** ./src/app/shared/components/auth-background/auth-background.component.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthBackgroundComponent: () => (/* binding */ AuthBackgroundComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 7580);

const _c0 = ["*"];
class AuthBackgroundComponent {
  static {
    this.ɵfac = function AuthBackgroundComponent_Factory(t) {
      return new (t || AuthBackgroundComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: AuthBackgroundComponent,
      selectors: [["app-auth-background"]],
      ngContentSelectors: _c0,
      decls: 7,
      vars: 0,
      consts: [[1, "background"], [1, "left-section"], ["src", "assets/images/nutri-logo.png", "alt", "nutri-logo", 1, "logo"], [1, "right-section"], [1, "right-img-wrapper"], ["src", "assets/images/nutrition1.png", "alt", "nutrition1", 1, "right-section-img"]],
      template: function AuthBackgroundComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojectionDef"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "div", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "img", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 3)(5, "div", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](6, "img", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
        }
      },
      styles: [".background[_ngcontent-%COMP%] {\n  display: flex;\n  position: relative;\n  background-color: var(--background-color);\n  width: 100%;\n  height: 100vh;\n}\n\n.right-section[_ngcontent-%COMP%] {\n  flex: 25%;\n  display: flex;\n  justify-content: end;\n  align-items: center;\n  position: relative;\n  background-color: var(--primary-color);\n}\n.left-section[_ngcontent-%COMP%] {\n  flex: 75%;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n  position: relative;\n}\n\n.right-img-wrapper[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 20%;\n  width: 120%;\n  height: 80%;\n  display: flex;\n  align-items: center;\n\n  border-radius: 15px;\n  overflow: hidden;\n}\n.right-section-img[_ngcontent-%COMP%] {\n  height: 100%;\n  width: 100%;\n  object-fit: cover;\n  border-radius: 15px;\n\n  transition: transform 0.5s;\n}\n.right-section-img[_ngcontent-%COMP%]:hover {\n  transform: scale(1.2);\n}\n\n@media screen and (max-width: 768px) {\n  .left-section[_ngcontent-%COMP%] {\n    flex: 90%;\n  }\n  .right-section[_ngcontent-%COMP%] {\n    flex: 10%;\n  }\n  .background[_ngcontent-%COMP%] {\n    flex-direction: column;\n  }\n  .right-img-wrapper[_ngcontent-%COMP%] {\n    display: none;\n  }\n  .right-section-img[_ngcontent-%COMP%] {\n    width: 90%;\n    height: 100%;\n\n    bottom: 17%;\n    left: auto;\n  }\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvYXV0aC1iYWNrZ3JvdW5kL2F1dGgtYmFja2dyb3VuZC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsYUFBYTtFQUNiLGtCQUFrQjtFQUNsQix5Q0FBeUM7RUFDekMsV0FBVztFQUNYLGFBQWE7QUFDZjs7QUFFQTtFQUNFLFNBQVM7RUFDVCxhQUFhO0VBQ2Isb0JBQW9CO0VBQ3BCLG1CQUFtQjtFQUNuQixrQkFBa0I7RUFDbEIsc0NBQXNDO0FBQ3hDO0FBQ0E7RUFDRSxTQUFTO0VBQ1QsYUFBYTtFQUNiLHNCQUFzQjtFQUN0Qix1QkFBdUI7RUFDdkIsbUJBQW1CO0VBQ25CLGtCQUFrQjtBQUNwQjs7QUFFQTtFQUNFLGtCQUFrQjtFQUNsQixVQUFVO0VBQ1YsV0FBVztFQUNYLFdBQVc7RUFDWCxhQUFhO0VBQ2IsbUJBQW1COztFQUVuQixtQkFBbUI7RUFDbkIsZ0JBQWdCO0FBQ2xCO0FBQ0E7RUFDRSxZQUFZO0VBQ1osV0FBVztFQUNYLGlCQUFpQjtFQUNqQixtQkFBbUI7O0VBRW5CLDBCQUEwQjtBQUM1QjtBQUNBO0VBQ0UscUJBQXFCO0FBQ3ZCOztBQUVBO0VBQ0U7SUFDRSxTQUFTO0VBQ1g7RUFDQTtJQUNFLFNBQVM7RUFDWDtFQUNBO0lBQ0Usc0JBQXNCO0VBQ3hCO0VBQ0E7SUFDRSxhQUFhO0VBQ2Y7RUFDQTtJQUNFLFVBQVU7SUFDVixZQUFZOztJQUVaLFdBQVc7SUFDWCxVQUFVO0VBQ1o7QUFDRiIsInNvdXJjZXNDb250ZW50IjpbIi5iYWNrZ3JvdW5kIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1iYWNrZ3JvdW5kLWNvbG9yKTtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDEwMHZoO1xyXG59XHJcblxyXG4ucmlnaHQtc2VjdGlvbiB7XHJcbiAgZmxleDogMjUlO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBlbmQ7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tcHJpbWFyeS1jb2xvcik7XHJcbn1cclxuLmxlZnQtc2VjdGlvbiB7XHJcbiAgZmxleDogNzUlO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxufVxyXG5cclxuLnJpZ2h0LWltZy13cmFwcGVyIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgcmlnaHQ6IDIwJTtcclxuICB3aWR0aDogMTIwJTtcclxuICBoZWlnaHQ6IDgwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcblxyXG4gIGJvcmRlci1yYWRpdXM6IDE1cHg7XHJcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcclxufVxyXG4ucmlnaHQtc2VjdGlvbi1pbWcge1xyXG4gIGhlaWdodDogMTAwJTtcclxuICB3aWR0aDogMTAwJTtcclxuICBvYmplY3QtZml0OiBjb3ZlcjtcclxuICBib3JkZXItcmFkaXVzOiAxNXB4O1xyXG5cclxuICB0cmFuc2l0aW9uOiB0cmFuc2Zvcm0gMC41cztcclxufVxyXG4ucmlnaHQtc2VjdGlvbi1pbWc6aG92ZXIge1xyXG4gIHRyYW5zZm9ybTogc2NhbGUoMS4yKTtcclxufVxyXG5cclxuQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNzY4cHgpIHtcclxuICAubGVmdC1zZWN0aW9uIHtcclxuICAgIGZsZXg6IDkwJTtcclxuICB9XHJcbiAgLnJpZ2h0LXNlY3Rpb24ge1xyXG4gICAgZmxleDogMTAlO1xyXG4gIH1cclxuICAuYmFja2dyb3VuZCB7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gIH1cclxuICAucmlnaHQtaW1nLXdyYXBwZXIge1xyXG4gICAgZGlzcGxheTogbm9uZTtcclxuICB9XHJcbiAgLnJpZ2h0LXNlY3Rpb24taW1nIHtcclxuICAgIHdpZHRoOiA5MCU7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcblxyXG4gICAgYm90dG9tOiAxNyU7XHJcbiAgICBsZWZ0OiBhdXRvO1xyXG4gIH1cclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */", "form[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%] {\n  font-size: 2.1rem;\n  font-weight: 600;\n  color: var(--primary-color);\n  text-align: center;\n  margin-bottom: 2rem;\n}\n.background[_ngcontent-%COMP%]   .logo[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: clamp(100px, 20%, 150px);\n}\n\nform[_ngcontent-%COMP%] {\n  width: 60%;\n  height: 90%;\n  display: flex;\n  flex-direction: column;\n  justify-content: space-between;\n  align-items: center;\n}\nform[_ngcontent-%COMP%]   .inputs[_ngcontent-%COMP%] {\n  width: 70%;\n  height: 100%;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  gap: 10px;\n}\ninput[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 0.7rem 0rem 0.7rem 0.5rem;\n  font-size: 0.8rem;\n  border: 1px solid #ccc;\n  border-radius: 6px;\n  position: relative;\n}\n\ninput[_ngcontent-%COMP%]:focus {\n  border: 2px solid var(--secondary-color);\n  box-shadow: 0 0 10px var(--light-green);\n  outline: none;\n}\n\ninput.ng-valid.ng-dirty[_ngcontent-%COMP%] {\n  border-bottom: 5px solid var(--secondary-color);\n}\n\ninput.valid.ng-dirty[_ngcontent-%COMP%] {\n  border-bottom: 5px solid var(--secondary-color) !important;\n}\n\ninput.ng-invalid.ng-dirty[_ngcontent-%COMP%] {\n  border-bottom: 5px solid red;\n}\ninput.ng-invalid.ng-dirty[_ngcontent-%COMP%]:focus {\n  border: 2px solid red;\n  box-shadow: 0 0 10px rgba(255, 0, 0, 0.3);\n}\ninput.invalid.ng-dirty[_ngcontent-%COMP%] {\n  border-bottom: 5px solid red !important;\n}\ninput.invalid.ng-dirty[_ngcontent-%COMP%]:focus {\n  border: 2px solid red;\n  box-shadow: 0 0 10px rgba(255, 0, 0, 0.3);\n}\n\ninput[_ngcontent-%COMP%]::placeholder {\n  color: var(--hint-text);\n}\n\n@media screen and (max-width: 768px) {\n  form[_ngcontent-%COMP%] {\n    width: max(80%, 500px);\n  }\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hc3NldHMvY3NzL2F1dGgtY29tbW9uLmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGlCQUFpQjtFQUNqQixnQkFBZ0I7RUFDaEIsMkJBQTJCO0VBQzNCLGtCQUFrQjtFQUNsQixtQkFBbUI7QUFDckI7QUFDQTtFQUNFLGtCQUFrQjtFQUNsQixNQUFNO0VBQ04sT0FBTztFQUNQLCtCQUErQjtBQUNqQzs7QUFFQTtFQUNFLFVBQVU7RUFDVixXQUFXO0VBQ1gsYUFBYTtFQUNiLHNCQUFzQjtFQUN0Qiw4QkFBOEI7RUFDOUIsbUJBQW1CO0FBQ3JCO0FBQ0E7RUFDRSxVQUFVO0VBQ1YsWUFBWTtFQUNaLGFBQWE7RUFDYixzQkFBc0I7RUFDdEIsdUJBQXVCO0VBQ3ZCLFNBQVM7QUFDWDtBQUNBO0VBQ0UsV0FBVztFQUNYLGtDQUFrQztFQUNsQyxpQkFBaUI7RUFDakIsc0JBQXNCO0VBQ3RCLGtCQUFrQjtFQUNsQixrQkFBa0I7QUFDcEI7O0FBRUE7RUFDRSx3Q0FBd0M7RUFDeEMsdUNBQXVDO0VBQ3ZDLGFBQWE7QUFDZjs7QUFFQTtFQUNFLCtDQUErQztBQUNqRDs7QUFFQTtFQUNFLDBEQUEwRDtBQUM1RDs7QUFFQTtFQUNFLDRCQUE0QjtBQUM5QjtBQUNBO0VBQ0UscUJBQXFCO0VBQ3JCLHlDQUF5QztBQUMzQztBQUNBO0VBQ0UsdUNBQXVDO0FBQ3pDO0FBQ0E7RUFDRSxxQkFBcUI7RUFDckIseUNBQXlDO0FBQzNDOztBQUVBO0VBQ0UsdUJBQXVCO0FBQ3pCOztBQUVBO0VBQ0U7SUFDRSxzQkFBc0I7RUFDeEI7QUFDRiIsInNvdXJjZXNDb250ZW50IjpbImZvcm0gaDEge1xyXG4gIGZvbnQtc2l6ZTogMi4xcmVtO1xyXG4gIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgY29sb3I6IHZhcigtLXByaW1hcnktY29sb3IpO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBtYXJnaW4tYm90dG9tOiAycmVtO1xyXG59XHJcbi5iYWNrZ3JvdW5kIC5sb2dvIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiAwO1xyXG4gIGxlZnQ6IDA7XHJcbiAgd2lkdGg6IGNsYW1wKDEwMHB4LCAyMCUsIDE1MHB4KTtcclxufVxyXG5cclxuZm9ybSB7XHJcbiAgd2lkdGg6IDYwJTtcclxuICBoZWlnaHQ6IDkwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuZm9ybSAuaW5wdXRzIHtcclxuICB3aWR0aDogNzAlO1xyXG4gIGhlaWdodDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgZ2FwOiAxMHB4O1xyXG59XHJcbmlucHV0IHtcclxuICB3aWR0aDogMTAwJTtcclxuICBwYWRkaW5nOiAwLjdyZW0gMHJlbSAwLjdyZW0gMC41cmVtO1xyXG4gIGZvbnQtc2l6ZTogMC44cmVtO1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkICNjY2M7XHJcbiAgYm9yZGVyLXJhZGl1czogNnB4O1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxufVxyXG5cclxuaW5wdXQ6Zm9jdXMge1xyXG4gIGJvcmRlcjogMnB4IHNvbGlkIHZhcigtLXNlY29uZGFyeS1jb2xvcik7XHJcbiAgYm94LXNoYWRvdzogMCAwIDEwcHggdmFyKC0tbGlnaHQtZ3JlZW4pO1xyXG4gIG91dGxpbmU6IG5vbmU7XHJcbn1cclxuXHJcbmlucHV0Lm5nLXZhbGlkLm5nLWRpcnR5IHtcclxuICBib3JkZXItYm90dG9tOiA1cHggc29saWQgdmFyKC0tc2Vjb25kYXJ5LWNvbG9yKTtcclxufVxyXG5cclxuaW5wdXQudmFsaWQubmctZGlydHkge1xyXG4gIGJvcmRlci1ib3R0b206IDVweCBzb2xpZCB2YXIoLS1zZWNvbmRhcnktY29sb3IpICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlucHV0Lm5nLWludmFsaWQubmctZGlydHkge1xyXG4gIGJvcmRlci1ib3R0b206IDVweCBzb2xpZCByZWQ7XHJcbn1cclxuaW5wdXQubmctaW52YWxpZC5uZy1kaXJ0eTpmb2N1cyB7XHJcbiAgYm9yZGVyOiAycHggc29saWQgcmVkO1xyXG4gIGJveC1zaGFkb3c6IDAgMCAxMHB4IHJnYmEoMjU1LCAwLCAwLCAwLjMpO1xyXG59XHJcbmlucHV0LmludmFsaWQubmctZGlydHkge1xyXG4gIGJvcmRlci1ib3R0b206IDVweCBzb2xpZCByZWQgIWltcG9ydGFudDtcclxufVxyXG5pbnB1dC5pbnZhbGlkLm5nLWRpcnR5OmZvY3VzIHtcclxuICBib3JkZXI6IDJweCBzb2xpZCByZWQ7XHJcbiAgYm94LXNoYWRvdzogMCAwIDEwcHggcmdiYSgyNTUsIDAsIDAsIDAuMyk7XHJcbn1cclxuXHJcbmlucHV0OjpwbGFjZWhvbGRlciB7XHJcbiAgY29sb3I6IHZhcigtLWhpbnQtdGV4dCk7XHJcbn1cclxuXHJcbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgZm9ybSB7XHJcbiAgICB3aWR0aDogbWF4KDgwJSwgNTAwcHgpO1xyXG4gIH1cclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
    });
  }
}

/***/ }),

/***/ 8249:
/*!****************************************************************************!*\
  !*** ./src/app/shared/components/auth-dropdown/auth-dropdown.component.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthDropdownComponent: () => (/* binding */ AuthDropdownComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 4456);




function AuthDropdownComponent_option_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "option", 5)(1, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const option_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", option_r1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](option_r1);
  }
}
class AuthDropdownComponent {
  constructor() {
    this.label = 'test';
    this.options = ['Options1', 'Option2'];
    this.selectedOption = '';
    this.onInputChange = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
  }
  ngOnInit() {
    if (!this.selectedOption) this.selectedOption = this.options[0];
  }
  notifyParent(newValue) {
    this.onInputChange.emit(newValue);
    console.log('emitted new value : ' + newValue);
  }
  static {
    this.ɵfac = function AuthDropdownComponent_Factory(t) {
      return new (t || AuthDropdownComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: AuthDropdownComponent,
      selectors: [["app-auth-dropdown"]],
      inputs: {
        label: "label",
        options: "options",
        selectedOption: "selectedOption"
      },
      outputs: {
        onInputChange: "onInputChange"
      },
      decls: 6,
      vars: 3,
      consts: [[1, "dropdown-container"], [1, "input-label"], [1, "dropdown-wrapper"], [1, "dropdown", 3, "ngModel", "ngModelChange"], [3, "value", 4, "ngFor", "ngForOf"], [3, "value"], [1, "option"]],
      template: function AuthDropdownComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "label", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 2)(4, "select", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function AuthDropdownComponent_Template_select_ngModelChange_4_listener($event) {
            return ctx.selectedOption = $event;
          })("ngModelChange", function AuthDropdownComponent_Template_select_ngModelChange_4_listener($event) {
            return ctx.notifyParent($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, AuthDropdownComponent_option_5_Template, 3, 2, "option", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.label);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.selectedOption);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.options);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgForOf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgModel],
      styles: [".dropdown-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  margin-bottom: 0.8rem;\n}\n.dropdown[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 0.7rem 2rem 0.7rem 0.5rem; \n\n  font-size: 0.8rem;\n  border: 1px solid #ccc;\n  border-radius: 6px;\n  background-color: #fff;\n  appearance: none; \n\n  -webkit-appearance: none;\n  -moz-appearance: none;\n}\n\nselect.dropdown[_ngcontent-%COMP%]:focus {\n  border: 1px solid var(--secondary-color);\n  box-shadow: 0 0 10px var(--light-green);\n\n  border-radius: 6px;\n  outline: none;\n}\n.dropdown-wrapper[_ngcontent-%COMP%] {\n  position: relative;\n  width: 100%;\n}\n.dropdown-wrapper[_ngcontent-%COMP%]::after {\n  content: \"\u25BC\"; \n\n  position: absolute;\n  top: 50%;\n  right: 10px; \n\n  transform: translateY(-50%);\n  pointer-events: none; \n\n  color: black;\n  font-size: 0.8rem;\n}\n\n.dropdown-wrapper[_ngcontent-%COMP%]:focus-within::after {\n  color: var(--secondary-color);\n}\n\noption[_ngcontent-%COMP%]:checked {\n  background-color: var(--secondary-color);\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvYXV0aC1kcm9wZG93bi9hdXRoLWRyb3Bkb3duLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLHFCQUFxQjtBQUN2QjtBQUNBO0VBQ0UsV0FBVztFQUNYLGtDQUFrQyxFQUFFLG9DQUFvQztFQUN4RSxpQkFBaUI7RUFDakIsc0JBQXNCO0VBQ3RCLGtCQUFrQjtFQUNsQixzQkFBc0I7RUFDdEIsZ0JBQWdCLEVBQUUsa0NBQWtDO0VBQ3BELHdCQUF3QjtFQUN4QixxQkFBcUI7QUFDdkI7O0FBRUE7RUFDRSx3Q0FBd0M7RUFDeEMsdUNBQXVDOztFQUV2QyxrQkFBa0I7RUFDbEIsYUFBYTtBQUNmO0FBQ0E7RUFDRSxrQkFBa0I7RUFDbEIsV0FBVztBQUNiO0FBQ0E7RUFDRSxZQUFZLEVBQUUseUNBQXlDO0VBQ3ZELGtCQUFrQjtFQUNsQixRQUFRO0VBQ1IsV0FBVyxFQUFFLGtDQUFrQztFQUMvQywyQkFBMkI7RUFDM0Isb0JBQW9CLEVBQUUsZ0RBQWdEO0VBQ3RFLFlBQVk7RUFDWixpQkFBaUI7QUFDbkI7O0FBRUE7RUFDRSw2QkFBNkI7QUFDL0I7O0FBRUE7RUFDRSx3Q0FBd0M7QUFDMUMiLCJzb3VyY2VzQ29udGVudCI6WyIuZHJvcGRvd24tY29udGFpbmVyIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgbWFyZ2luLWJvdHRvbTogMC44cmVtO1xyXG59XHJcbi5kcm9wZG93biB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgcGFkZGluZzogMC43cmVtIDJyZW0gMC43cmVtIDAuNXJlbTsgLyogQWRkIHJpZ2h0IHBhZGRpbmcgZm9yIHRoZSBhcnJvdyAqL1xyXG4gIGZvbnQtc2l6ZTogMC44cmVtO1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkICNjY2M7XHJcbiAgYm9yZGVyLXJhZGl1czogNnB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XHJcbiAgYXBwZWFyYW5jZTogbm9uZTsgLyogUmVtb3ZlIGRlZmF1bHQgZHJvcGRvd24gYXJyb3cgKi9cclxuICAtd2Via2l0LWFwcGVhcmFuY2U6IG5vbmU7XHJcbiAgLW1vei1hcHBlYXJhbmNlOiBub25lO1xyXG59XHJcblxyXG5zZWxlY3QuZHJvcGRvd246Zm9jdXMge1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkIHZhcigtLXNlY29uZGFyeS1jb2xvcik7XHJcbiAgYm94LXNoYWRvdzogMCAwIDEwcHggdmFyKC0tbGlnaHQtZ3JlZW4pO1xyXG5cclxuICBib3JkZXItcmFkaXVzOiA2cHg7XHJcbiAgb3V0bGluZTogbm9uZTtcclxufVxyXG4uZHJvcGRvd24td3JhcHBlciB7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG59XHJcbi5kcm9wZG93bi13cmFwcGVyOjphZnRlciB7XHJcbiAgY29udGVudDogXCLDosKWwrxcIjsgLyogVW5pY29kZSBjaGFyYWN0ZXIgZm9yIGRyb3Bkb3duIGFycm93ICovXHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHRvcDogNTAlO1xyXG4gIHJpZ2h0OiAxMHB4OyAvKiBQb3NpdGlvbiBhcnJvdyBpbnNpZGUgd3JhcHBlciAqL1xyXG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtNTAlKTtcclxuICBwb2ludGVyLWV2ZW50czogbm9uZTsgLyogUHJldmVudCBpbnRlcmFjdGlvbiB3aXRoIHRoZSBwc2V1ZG8tZWxlbWVudCAqL1xyXG4gIGNvbG9yOiBibGFjaztcclxuICBmb250LXNpemU6IDAuOHJlbTtcclxufVxyXG5cclxuLmRyb3Bkb3duLXdyYXBwZXI6Zm9jdXMtd2l0aGluOjphZnRlciB7XHJcbiAgY29sb3I6IHZhcigtLXNlY29uZGFyeS1jb2xvcik7XHJcbn1cclxuXHJcbm9wdGlvbjpjaGVja2VkIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1zZWNvbmRhcnktY29sb3IpO1xyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
    });
  }
}

/***/ }),

/***/ 4591:
/*!**********************************************************************************!*\
  !*** ./src/app/shared/components/auth-input-field/auth-input-field.component.ts ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthInputFieldComponent: () => (/* binding */ AuthInputFieldComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 4456);




const _c0 = function (a0, a1) {
  return {
    "valid-input-note": a0,
    "error-input-note": a1
  };
};
function AuthInputFieldComponent_small_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "small", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](2, _c0, ctx_r0.valid && _r1.valid, !ctx_r0.valid || _r1.invalid));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r0.inputNote);
  }
}
const _c1 = function (a0, a1) {
  return {
    "fa-eye": a0,
    "fa-eye-slash": a1
  };
};
function AuthInputFieldComponent_span_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AuthInputFieldComponent_span_8_Template_span_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r4);
      const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r3.togglePasswordVisibility());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "i", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](1, _c1, !ctx_r2.isPasswordVisible, ctx_r2.isPasswordVisible));
  }
}
const _c2 = function (a0, a1) {
  return {
    "valid": a0,
    "invalid": a1
  };
};
class AuthInputFieldComponent {
  constructor() {
    this.label = '';
    this.placeholder = '';
    this.type = 'text';
    this.isPassword = false;
    this.required = false;
    this.inputValue = '';
    this.valid = true;
    this.updateInputNote = (newValue, errors) => {
      if (errors) {
        if (errors['required']) {
          return 'Required Field..';
        } else {
          return 'Invalid input..';
        }
      } else {
        return '';
      }
    };
    this.onInputChange = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    this.inputNote = '';
    this.isPasswordVisible = false;
  }
  updateValue(newValue, errors) {
    this.onInputChange.emit(newValue);
    console.log('errors: ' + errors);
    this.inputNote = this.updateInputNote(newValue, errors);
  }
  // Toggle password visibility
  togglePasswordVisibility() {
    this.isPasswordVisible = !this.isPasswordVisible;
  }
  static {
    this.ɵfac = function AuthInputFieldComponent_Factory(t) {
      return new (t || AuthInputFieldComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: AuthInputFieldComponent,
      selectors: [["app-auth-input-field"]],
      inputs: {
        label: "label",
        placeholder: "placeholder",
        type: "type",
        isPassword: "isPassword",
        required: "required",
        inputValue: "inputValue",
        valid: "valid",
        updateInputNote: "updateInputNote"
      },
      outputs: {
        onInputChange: "onInputChange"
      },
      decls: 9,
      vars: 13,
      consts: [[1, "input-field-container"], [1, "input-header"], [1, "input-label"], ["class", "input-note", 3, "ngClass", 4, "ngIf"], [1, "input-wrapper"], ["ngModel", "", 3, "type", "placeholder", "required", "ngModel", "minlength", "email", "ngClass", "ngModelChange"], ["input", "ngModel"], ["class", "toggle-icon", 3, "click", 4, "ngIf"], [1, "input-note", 3, "ngClass"], [1, "toggle-icon", 3, "click"], [1, "fa", 3, "ngClass"]],
      template: function AuthInputFieldComponent_Template(rf, ctx) {
        if (rf & 1) {
          const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "label", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, AuthInputFieldComponent_small_4_Template, 2, 5, "small", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 4)(6, "input", 5, 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function AuthInputFieldComponent_Template_input_ngModelChange_6_listener($event) {
            return ctx.inputValue = $event;
          })("ngModelChange", function AuthInputFieldComponent_Template_input_ngModelChange_6_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r5);
            const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](7);
            return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx.updateValue(_r1.control.value, _r1.control.errors));
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](8, AuthInputFieldComponent_span_8_Template, 2, 4, "span", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
        }
        if (rf & 2) {
          const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](7);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.label);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.inputNote);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("type", ctx.isPassword && !ctx.isPasswordVisible ? "password" : "text")("placeholder", ctx.placeholder)("required", ctx.required)("ngModel", ctx.inputValue)("minlength", ctx.isPassword ? 8 : null)("email", ctx.type == "email")("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](10, _c2, ctx.valid && _r1.valid, !ctx.valid || !_r1.valid));
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.isPassword);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.RequiredValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.MinLengthValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.EmailValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgModel],
      styles: [".input-field-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n}\n\n.input-wrapper[_ngcontent-%COMP%] {\n  position: relative;\n}\n\ninput[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 0.7rem 0rem 0.7rem 0.5rem;\n  font-size: 0.8rem;\n  border: 1px solid #ccc;\n  border-radius: 6px;\n  position: relative;\n}\n\ninput[_ngcontent-%COMP%]:focus {\n  border: 2px solid var(--secondary-color);\n  box-shadow: 0 0 10px var(--light-green);\n  outline: none;\n}\n\ninput.ng-valid.ng-dirty[_ngcontent-%COMP%] {\n  border-bottom: 5px solid var(--secondary-color);\n}\n\ninput.valid.ng-dirty[_ngcontent-%COMP%] {\n  border-bottom: 5px solid var(--secondary-color) !important;\n}\n\ninput.ng-invalid.ng-dirty[_ngcontent-%COMP%] {\n  border-bottom: 5px solid red;\n}\ninput.ng-invalid.ng-dirty[_ngcontent-%COMP%]:focus {\n  border: 2px solid red;\n  box-shadow: 0 0 10px rgba(255, 0, 0, 0.3);\n}\ninput.invalid.ng-dirty[_ngcontent-%COMP%] {\n  border-bottom: 5px solid red !important;\n}\ninput.invalid.ng-dirty[_ngcontent-%COMP%]:focus {\n  border: 2px solid red;\n  box-shadow: 0 0 10px rgba(255, 0, 0, 0.3);\n}\n\ninput[_ngcontent-%COMP%]::placeholder {\n  color: var(--hint-text);\n}\n.toggle-icon[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 10px;\n  top: 50%;\n  transform: translateY(-50%);\n  cursor: pointer;\n  color: var(--hint-text);\n}\ninput[type=\"password\"][_ngcontent-%COMP%]::-ms-reveal, input[type=\"password\"][_ngcontent-%COMP%]::-ms-clear, input[type=\"password\"][_ngcontent-%COMP%]::-webkit-textfield-decoration-container {\n  display: none;\n}\n\n.toggle-icon[_ngcontent-%COMP%]:hover {\n  color: #555;\n}\n\n.input-header[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-bottom: 0.2rem;\n}\n\n.input-note[_ngcontent-%COMP%] {\n  padding: 0.2rem 1rem;\n  border-radius: 15px;\n  font-size: 0.7rem;\n}\n\n.error-input-note[_ngcontent-%COMP%] {\n  color: var(--red);\n  background-color: var(--light-red);\n}\n\n.valid-input-note[_ngcontent-%COMP%] {\n  background-color: var(--light-green);\n  color: var(--secondary-color);\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvYXV0aC1pbnB1dC1maWVsZC9hdXRoLWlucHV0LWZpZWxkLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxhQUFhO0VBQ2Isc0JBQXNCO0FBQ3hCOztBQUVBO0VBQ0Usa0JBQWtCO0FBQ3BCOztBQUVBO0VBQ0UsV0FBVztFQUNYLGtDQUFrQztFQUNsQyxpQkFBaUI7RUFDakIsc0JBQXNCO0VBQ3RCLGtCQUFrQjtFQUNsQixrQkFBa0I7QUFDcEI7O0FBRUE7RUFDRSx3Q0FBd0M7RUFDeEMsdUNBQXVDO0VBQ3ZDLGFBQWE7QUFDZjs7QUFFQTtFQUNFLCtDQUErQztBQUNqRDs7QUFFQTtFQUNFLDBEQUEwRDtBQUM1RDs7QUFFQTtFQUNFLDRCQUE0QjtBQUM5QjtBQUNBO0VBQ0UscUJBQXFCO0VBQ3JCLHlDQUF5QztBQUMzQztBQUNBO0VBQ0UsdUNBQXVDO0FBQ3pDO0FBQ0E7RUFDRSxxQkFBcUI7RUFDckIseUNBQXlDO0FBQzNDOztBQUVBO0VBQ0UsdUJBQXVCO0FBQ3pCO0FBQ0E7RUFDRSxrQkFBa0I7RUFDbEIsV0FBVztFQUNYLFFBQVE7RUFDUiwyQkFBMkI7RUFDM0IsZUFBZTtFQUNmLHVCQUF1QjtBQUN6QjtBQUNBOzs7RUFHRSxhQUFhO0FBQ2Y7O0FBRUE7RUFDRSxXQUFXO0FBQ2I7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsOEJBQThCO0VBQzlCLG1CQUFtQjtFQUNuQixxQkFBcUI7QUFDdkI7O0FBRUE7RUFDRSxvQkFBb0I7RUFDcEIsbUJBQW1CO0VBQ25CLGlCQUFpQjtBQUNuQjs7QUFFQTtFQUNFLGlCQUFpQjtFQUNqQixrQ0FBa0M7QUFDcEM7O0FBRUE7RUFDRSxvQ0FBb0M7RUFDcEMsNkJBQTZCO0FBQy9CIiwic291cmNlc0NvbnRlbnQiOlsiLmlucHV0LWZpZWxkLWNvbnRhaW5lciB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG59XHJcblxyXG4uaW5wdXQtd3JhcHBlciB7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG59XHJcblxyXG5pbnB1dCB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgcGFkZGluZzogMC43cmVtIDByZW0gMC43cmVtIDAuNXJlbTtcclxuICBmb250LXNpemU6IDAuOHJlbTtcclxuICBib3JkZXI6IDFweCBzb2xpZCAjY2NjO1xyXG4gIGJvcmRlci1yYWRpdXM6IDZweDtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbn1cclxuXHJcbmlucHV0OmZvY3VzIHtcclxuICBib3JkZXI6IDJweCBzb2xpZCB2YXIoLS1zZWNvbmRhcnktY29sb3IpO1xyXG4gIGJveC1zaGFkb3c6IDAgMCAxMHB4IHZhcigtLWxpZ2h0LWdyZWVuKTtcclxuICBvdXRsaW5lOiBub25lO1xyXG59XHJcblxyXG5pbnB1dC5uZy12YWxpZC5uZy1kaXJ0eSB7XHJcbiAgYm9yZGVyLWJvdHRvbTogNXB4IHNvbGlkIHZhcigtLXNlY29uZGFyeS1jb2xvcik7XHJcbn1cclxuXHJcbmlucHV0LnZhbGlkLm5nLWRpcnR5IHtcclxuICBib3JkZXItYm90dG9tOiA1cHggc29saWQgdmFyKC0tc2Vjb25kYXJ5LWNvbG9yKSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pbnB1dC5uZy1pbnZhbGlkLm5nLWRpcnR5IHtcclxuICBib3JkZXItYm90dG9tOiA1cHggc29saWQgcmVkO1xyXG59XHJcbmlucHV0Lm5nLWludmFsaWQubmctZGlydHk6Zm9jdXMge1xyXG4gIGJvcmRlcjogMnB4IHNvbGlkIHJlZDtcclxuICBib3gtc2hhZG93OiAwIDAgMTBweCByZ2JhKDI1NSwgMCwgMCwgMC4zKTtcclxufVxyXG5pbnB1dC5pbnZhbGlkLm5nLWRpcnR5IHtcclxuICBib3JkZXItYm90dG9tOiA1cHggc29saWQgcmVkICFpbXBvcnRhbnQ7XHJcbn1cclxuaW5wdXQuaW52YWxpZC5uZy1kaXJ0eTpmb2N1cyB7XHJcbiAgYm9yZGVyOiAycHggc29saWQgcmVkO1xyXG4gIGJveC1zaGFkb3c6IDAgMCAxMHB4IHJnYmEoMjU1LCAwLCAwLCAwLjMpO1xyXG59XHJcblxyXG5pbnB1dDo6cGxhY2Vob2xkZXIge1xyXG4gIGNvbG9yOiB2YXIoLS1oaW50LXRleHQpO1xyXG59XHJcbi50b2dnbGUtaWNvbiB7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHJpZ2h0OiAxMHB4O1xyXG4gIHRvcDogNTAlO1xyXG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtNTAlKTtcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgY29sb3I6IHZhcigtLWhpbnQtdGV4dCk7XHJcbn1cclxuaW5wdXRbdHlwZT1cInBhc3N3b3JkXCJdOjotbXMtcmV2ZWFsLFxyXG5pbnB1dFt0eXBlPVwicGFzc3dvcmRcIl06Oi1tcy1jbGVhcixcclxuaW5wdXRbdHlwZT1cInBhc3N3b3JkXCJdOjotd2Via2l0LXRleHRmaWVsZC1kZWNvcmF0aW9uLWNvbnRhaW5lciB7XHJcbiAgZGlzcGxheTogbm9uZTtcclxufVxyXG5cclxuLnRvZ2dsZS1pY29uOmhvdmVyIHtcclxuICBjb2xvcjogIzU1NTtcclxufVxyXG5cclxuLmlucHV0LWhlYWRlciB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBtYXJnaW4tYm90dG9tOiAwLjJyZW07XHJcbn1cclxuXHJcbi5pbnB1dC1ub3RlIHtcclxuICBwYWRkaW5nOiAwLjJyZW0gMXJlbTtcclxuICBib3JkZXItcmFkaXVzOiAxNXB4O1xyXG4gIGZvbnQtc2l6ZTogMC43cmVtO1xyXG59XHJcblxyXG4uZXJyb3ItaW5wdXQtbm90ZSB7XHJcbiAgY29sb3I6IHZhcigtLXJlZCk7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tbGlnaHQtcmVkKTtcclxufVxyXG5cclxuLnZhbGlkLWlucHV0LW5vdGUge1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWxpZ2h0LWdyZWVuKTtcclxuICBjb2xvcjogdmFyKC0tc2Vjb25kYXJ5LWNvbG9yKTtcclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */", "form[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%] {\n  font-size: 2.1rem;\n  font-weight: 600;\n  color: var(--primary-color);\n  text-align: center;\n  margin-bottom: 2rem;\n}\n.background[_ngcontent-%COMP%]   .logo[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: clamp(100px, 20%, 150px);\n}\n\nform[_ngcontent-%COMP%] {\n  width: 60%;\n  height: 90%;\n  display: flex;\n  flex-direction: column;\n  justify-content: space-between;\n  align-items: center;\n}\nform[_ngcontent-%COMP%]   .inputs[_ngcontent-%COMP%] {\n  width: 70%;\n  height: 100%;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  gap: 10px;\n}\ninput[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 0.7rem 0rem 0.7rem 0.5rem;\n  font-size: 0.8rem;\n  border: 1px solid #ccc;\n  border-radius: 6px;\n  position: relative;\n}\n\ninput[_ngcontent-%COMP%]:focus {\n  border: 2px solid var(--secondary-color);\n  box-shadow: 0 0 10px var(--light-green);\n  outline: none;\n}\n\ninput.ng-valid.ng-dirty[_ngcontent-%COMP%] {\n  border-bottom: 5px solid var(--secondary-color);\n}\n\ninput.valid.ng-dirty[_ngcontent-%COMP%] {\n  border-bottom: 5px solid var(--secondary-color) !important;\n}\n\ninput.ng-invalid.ng-dirty[_ngcontent-%COMP%] {\n  border-bottom: 5px solid red;\n}\ninput.ng-invalid.ng-dirty[_ngcontent-%COMP%]:focus {\n  border: 2px solid red;\n  box-shadow: 0 0 10px rgba(255, 0, 0, 0.3);\n}\ninput.invalid.ng-dirty[_ngcontent-%COMP%] {\n  border-bottom: 5px solid red !important;\n}\ninput.invalid.ng-dirty[_ngcontent-%COMP%]:focus {\n  border: 2px solid red;\n  box-shadow: 0 0 10px rgba(255, 0, 0, 0.3);\n}\n\ninput[_ngcontent-%COMP%]::placeholder {\n  color: var(--hint-text);\n}\n\n@media screen and (max-width: 768px) {\n  form[_ngcontent-%COMP%] {\n    width: max(80%, 500px);\n  }\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hc3NldHMvY3NzL2F1dGgtY29tbW9uLmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGlCQUFpQjtFQUNqQixnQkFBZ0I7RUFDaEIsMkJBQTJCO0VBQzNCLGtCQUFrQjtFQUNsQixtQkFBbUI7QUFDckI7QUFDQTtFQUNFLGtCQUFrQjtFQUNsQixNQUFNO0VBQ04sT0FBTztFQUNQLCtCQUErQjtBQUNqQzs7QUFFQTtFQUNFLFVBQVU7RUFDVixXQUFXO0VBQ1gsYUFBYTtFQUNiLHNCQUFzQjtFQUN0Qiw4QkFBOEI7RUFDOUIsbUJBQW1CO0FBQ3JCO0FBQ0E7RUFDRSxVQUFVO0VBQ1YsWUFBWTtFQUNaLGFBQWE7RUFDYixzQkFBc0I7RUFDdEIsdUJBQXVCO0VBQ3ZCLFNBQVM7QUFDWDtBQUNBO0VBQ0UsV0FBVztFQUNYLGtDQUFrQztFQUNsQyxpQkFBaUI7RUFDakIsc0JBQXNCO0VBQ3RCLGtCQUFrQjtFQUNsQixrQkFBa0I7QUFDcEI7O0FBRUE7RUFDRSx3Q0FBd0M7RUFDeEMsdUNBQXVDO0VBQ3ZDLGFBQWE7QUFDZjs7QUFFQTtFQUNFLCtDQUErQztBQUNqRDs7QUFFQTtFQUNFLDBEQUEwRDtBQUM1RDs7QUFFQTtFQUNFLDRCQUE0QjtBQUM5QjtBQUNBO0VBQ0UscUJBQXFCO0VBQ3JCLHlDQUF5QztBQUMzQztBQUNBO0VBQ0UsdUNBQXVDO0FBQ3pDO0FBQ0E7RUFDRSxxQkFBcUI7RUFDckIseUNBQXlDO0FBQzNDOztBQUVBO0VBQ0UsdUJBQXVCO0FBQ3pCOztBQUVBO0VBQ0U7SUFDRSxzQkFBc0I7RUFDeEI7QUFDRiIsInNvdXJjZXNDb250ZW50IjpbImZvcm0gaDEge1xyXG4gIGZvbnQtc2l6ZTogMi4xcmVtO1xyXG4gIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgY29sb3I6IHZhcigtLXByaW1hcnktY29sb3IpO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBtYXJnaW4tYm90dG9tOiAycmVtO1xyXG59XHJcbi5iYWNrZ3JvdW5kIC5sb2dvIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiAwO1xyXG4gIGxlZnQ6IDA7XHJcbiAgd2lkdGg6IGNsYW1wKDEwMHB4LCAyMCUsIDE1MHB4KTtcclxufVxyXG5cclxuZm9ybSB7XHJcbiAgd2lkdGg6IDYwJTtcclxuICBoZWlnaHQ6IDkwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuZm9ybSAuaW5wdXRzIHtcclxuICB3aWR0aDogNzAlO1xyXG4gIGhlaWdodDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgZ2FwOiAxMHB4O1xyXG59XHJcbmlucHV0IHtcclxuICB3aWR0aDogMTAwJTtcclxuICBwYWRkaW5nOiAwLjdyZW0gMHJlbSAwLjdyZW0gMC41cmVtO1xyXG4gIGZvbnQtc2l6ZTogMC44cmVtO1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkICNjY2M7XHJcbiAgYm9yZGVyLXJhZGl1czogNnB4O1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxufVxyXG5cclxuaW5wdXQ6Zm9jdXMge1xyXG4gIGJvcmRlcjogMnB4IHNvbGlkIHZhcigtLXNlY29uZGFyeS1jb2xvcik7XHJcbiAgYm94LXNoYWRvdzogMCAwIDEwcHggdmFyKC0tbGlnaHQtZ3JlZW4pO1xyXG4gIG91dGxpbmU6IG5vbmU7XHJcbn1cclxuXHJcbmlucHV0Lm5nLXZhbGlkLm5nLWRpcnR5IHtcclxuICBib3JkZXItYm90dG9tOiA1cHggc29saWQgdmFyKC0tc2Vjb25kYXJ5LWNvbG9yKTtcclxufVxyXG5cclxuaW5wdXQudmFsaWQubmctZGlydHkge1xyXG4gIGJvcmRlci1ib3R0b206IDVweCBzb2xpZCB2YXIoLS1zZWNvbmRhcnktY29sb3IpICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlucHV0Lm5nLWludmFsaWQubmctZGlydHkge1xyXG4gIGJvcmRlci1ib3R0b206IDVweCBzb2xpZCByZWQ7XHJcbn1cclxuaW5wdXQubmctaW52YWxpZC5uZy1kaXJ0eTpmb2N1cyB7XHJcbiAgYm9yZGVyOiAycHggc29saWQgcmVkO1xyXG4gIGJveC1zaGFkb3c6IDAgMCAxMHB4IHJnYmEoMjU1LCAwLCAwLCAwLjMpO1xyXG59XHJcbmlucHV0LmludmFsaWQubmctZGlydHkge1xyXG4gIGJvcmRlci1ib3R0b206IDVweCBzb2xpZCByZWQgIWltcG9ydGFudDtcclxufVxyXG5pbnB1dC5pbnZhbGlkLm5nLWRpcnR5OmZvY3VzIHtcclxuICBib3JkZXI6IDJweCBzb2xpZCByZWQ7XHJcbiAgYm94LXNoYWRvdzogMCAwIDEwcHggcmdiYSgyNTUsIDAsIDAsIDAuMyk7XHJcbn1cclxuXHJcbmlucHV0OjpwbGFjZWhvbGRlciB7XHJcbiAgY29sb3I6IHZhcigtLWhpbnQtdGV4dCk7XHJcbn1cclxuXHJcbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgZm9ybSB7XHJcbiAgICB3aWR0aDogbWF4KDgwJSwgNTAwcHgpO1xyXG4gIH1cclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
    });
  }
}

/***/ }),

/***/ 8219:
/*!**************************************************************!*\
  !*** ./src/app/shared/components/button/button.component.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ButtonComponent: () => (/* binding */ ButtonComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 5072);
/* harmony import */ var src_app_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/utils/functions.utils */ 3584);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 316);





class ButtonComponent {
  constructor() {
    this.router = (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.inject)(_angular_router__WEBPACK_IMPORTED_MODULE_2__.Router);
    this.text = '';
    this.type = 'button';
    this.width = '100%';
    this.fontWeight = 'bold';
    this.backgroundColor = '';
    this.textColor = 'white';
    this.boxShadow = '';
    this.borderRadius = '8px';
    this.disabled = false;
    this.hasBorder = false;
    this.onClick = () => {};
    this.isHovered = false;
  }
  ngOnInit() {
    // Set default colors using CSS variables if not explicitly provided
    this.backgroundColor = this.backgroundColor || src_app_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_0__.AppUtils.getCssVariable('--secondary-color');
    this.boxShadow = this.boxShadow || `0 4px 8px 2px ${src_app_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_0__.AppUtils.getCssVariable('--light-green')}`;
  }
  getStyles() {
    return {
      width: this.width,
      disabled: this.disabled,
      type: this.type,
      fontWeight: this.fontWeight,
      color: this.textColor,
      boxShadow: this.isHovered ? this.boxShadow : 'none',
      backgroundColor: this.backgroundColor,
      borderRadius: this.borderRadius,
      border: this.hasBorder ? `1px solid ${src_app_core_utils_functions_utils__WEBPACK_IMPORTED_MODULE_0__.AppUtils.getCssVariable('--secondary-color')}` : 'none'
    };
  }
  static {
    this.ɵfac = function ButtonComponent_Factory(t) {
      return new (t || ButtonComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: ButtonComponent,
      selectors: [["app-button"]],
      inputs: {
        text: "text",
        type: "type",
        width: "width",
        fontWeight: "fontWeight",
        backgroundColor: "backgroundColor",
        textColor: "textColor",
        boxShadow: "boxShadow",
        borderRadius: "borderRadius",
        disabled: "disabled",
        hasBorder: "hasBorder",
        onClick: "onClick"
      },
      decls: 2,
      vars: 4,
      consts: [[1, "button", 3, "ngStyle", "type", "disabled", "mouseover", "mouseleave", "click"]],
      template: function ButtonComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "button", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("mouseover", function ButtonComponent_Template_button_mouseover_0_listener() {
            return ctx.isHovered = true;
          })("mouseleave", function ButtonComponent_Template_button_mouseleave_0_listener() {
            return ctx.isHovered = false;
          })("click", function ButtonComponent_Template_button_click_0_listener() {
            return ctx.onClick();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate"]("type", ctx.type);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngStyle", ctx.getStyles())("disabled", ctx.disabled);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", ctx.text, "\n");
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgStyle],
      styles: [".button[_ngcontent-%COMP%] {\n  padding: 0.7rem 1rem 0.7rem 1rem;\n  text-align: center;\n  border: none;\n  cursor: \"pointer\";\n  transition: \"border-color 0.3s ease\";\n  position: relative;\n  overflow: hidden;\n  &::before {\n    content: \"\";\n    position: absolute;\n    top: 0;\n    left: -100%;\n    width: 100%;\n    height: 100%;\n    background: linear-gradient(\n      120deg,\n      transparent,\n      rgba(255, 255, 255, 0.2),\n      transparent\n    );\n\n    transition: all 0.65s ease-in-out;\n  }\n  &:hover::before {\n    left: 100%;\n  }\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvYnV0dG9uL2J1dHRvbi5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZ0NBQWdDO0VBQ2hDLGtCQUFrQjtFQUNsQixZQUFZO0VBQ1osaUJBQWlCO0VBQ2pCLG9DQUFvQztFQUNwQyxrQkFBa0I7RUFDbEIsZ0JBQWdCO0VBQ2hCO0lBQ0UsV0FBVztJQUNYLGtCQUFrQjtJQUNsQixNQUFNO0lBQ04sV0FBVztJQUNYLFdBQVc7SUFDWCxZQUFZO0lBQ1o7Ozs7O0tBS0M7O0lBRUQsaUNBQWlDO0VBQ25DO0VBQ0E7SUFDRSxVQUFVO0VBQ1o7QUFDRiIsInNvdXJjZXNDb250ZW50IjpbIi5idXR0b24ge1xyXG4gIHBhZGRpbmc6IDAuN3JlbSAxcmVtIDAuN3JlbSAxcmVtO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBib3JkZXI6IG5vbmU7XHJcbiAgY3Vyc29yOiBcInBvaW50ZXJcIjtcclxuICB0cmFuc2l0aW9uOiBcImJvcmRlci1jb2xvciAwLjNzIGVhc2VcIjtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICAmOjpiZWZvcmUge1xyXG4gICAgY29udGVudDogXCJcIjtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRvcDogMDtcclxuICAgIGxlZnQ6IC0xMDAlO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoXHJcbiAgICAgIDEyMGRlZyxcclxuICAgICAgdHJhbnNwYXJlbnQsXHJcbiAgICAgIHJnYmEoMjU1LCAyNTUsIDI1NSwgMC4yKSxcclxuICAgICAgdHJhbnNwYXJlbnRcclxuICAgICk7XHJcblxyXG4gICAgdHJhbnNpdGlvbjogYWxsIDAuNjVzIGVhc2UtaW4tb3V0O1xyXG4gIH1cclxuICAmOmhvdmVyOjpiZWZvcmUge1xyXG4gICAgbGVmdDogMTAwJTtcclxuICB9XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 4538:
/*!******************************************************************!*\
  !*** ./src/app/shared/components/dropdown/dropdown.component.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DropdownComponent: () => (/* binding */ DropdownComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ 4456);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 316);




function DropdownComponent_option_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "option", 3)(1, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const option_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", option_r1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](option_r1);
  }
}
class DropdownComponent {
  constructor() {
    this.name = 'Objectif';
    this.options = ['Options1', 'Option2'];
    this.formControlName = new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormControl('');
  }
  static {
    this.ɵfac = function DropdownComponent_Factory(t) {
      return new (t || DropdownComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: DropdownComponent,
      selectors: [["app-dropdown"]],
      inputs: {
        name: "name",
        options: "options",
        formControlName: "formControlName"
      },
      decls: 3,
      vars: 2,
      consts: [[1, "dropdown-wrapper"], [1, "dropdown-input", 3, "formControl"], [3, "value", 4, "ngFor", "ngForOf"], [3, "value"], [1, "option"]],
      template: function DropdownComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "select", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, DropdownComponent_option_2_Template, 3, 2, "option", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("formControl", ctx.formControlName);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.options);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.NgForOf, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormControlDirective],
      styles: [".dropdown-wrapper[_ngcontent-%COMP%] {\n  position: relative;\n  width: 100%;\n  max-width: 400px;\n}\n\n.dropdown-input[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 8px 40px 8px 12px;\n  font-size: clamp(9px, 14px, 1.4vw);\n  border: 1px solid transparent;\n  border-radius: 25px;\n  background: linear-gradient(white, white) padding-box,\n    linear-gradient(90deg, var(--primary-color), var(--secondary-color))\n      border-box;\n  outline: none;\n  appearance: none; \n\n  cursor: pointer;\n}\n\n.dropdown-wrapper[_ngcontent-%COMP%]::after {\n  content: \"\u25BC\"; \n  position: absolute;\n  top: 50%;\n  right: 12px; \n  transform: translateY(-50%);\n  pointer-events: none; \n  color: var(--primary-color);\n  font-size: 0.8rem;\n}\n\n.dropdown-input[_ngcontent-%COMP%]:focus {\n  border: 1px solid transparent;\n  background: linear-gradient(white, white) padding-box,\n    linear-gradient(90deg, var(--secondary-color), var(--primary-color))\n      border-box; \n\n  box-shadow: 0 0 1px var(--primary-color), 0 0 1px var(--secondary-color),\n    0 0 1px var(--primary-color);\n}\n\noption[_ngcontent-%COMP%]:checked {\n  background-color: var(--secondary-color);\n}\n\n\n.dropdown-input[_ngcontent-%COMP%]   option[value=\"\"][_ngcontent-%COMP%] {\n  color: var(--primary-color); \n}\n\n.dropdown-input[_ngcontent-%COMP%]:not(:invalid) {\n  color: var(--primary-color); \n\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvZHJvcGRvd24vZHJvcGRvd24uY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGtCQUFrQjtFQUNsQixXQUFXO0VBQ1gsZ0JBQWdCO0FBQ2xCOztBQUVBO0VBQ0UsV0FBVztFQUNYLDBCQUEwQjtFQUMxQixrQ0FBa0M7RUFDbEMsNkJBQTZCO0VBQzdCLG1CQUFtQjtFQUNuQjs7Z0JBRWM7RUFDZCxhQUFhO0VBQ2IsZ0JBQWdCLEVBQUUscUNBQXFDO0VBQ3ZELGVBQWU7QUFDakI7O0FBRUE7RUFDRSxZQUFZO0VBQ1osa0JBQWtCO0VBQ2xCLFFBQVE7RUFDUixXQUFXO0VBQ1gsMkJBQTJCO0VBQzNCLG9CQUFvQjtFQUNwQiwyQkFBMkI7RUFDM0IsaUJBQWlCO0FBQ25COztBQUVBO0VBQ0UsNkJBQTZCO0VBQzdCOztnQkFFYyxFQUFFLGlDQUFpQztFQUNqRDtnQ0FDOEI7QUFDaEM7O0FBRUE7RUFDRSx3Q0FBd0M7QUFDMUM7OztBQUdBO0VBQ0UsMkJBQTJCO0FBQzdCOztBQUVBO0VBQ0UsMkJBQTJCLEVBQUUsa0NBQWtDO0FBQ2pFIiwic291cmNlc0NvbnRlbnQiOlsiLmRyb3Bkb3duLXdyYXBwZXIge1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICB3aWR0aDogMTAwJTtcclxuICBtYXgtd2lkdGg6IDQwMHB4O1xyXG59XHJcblxyXG4uZHJvcGRvd24taW5wdXQge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIHBhZGRpbmc6IDhweCA0MHB4IDhweCAxMnB4O1xyXG4gIGZvbnQtc2l6ZTogY2xhbXAoOXB4LCAxNHB4LCAxLjR2dyk7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgdHJhbnNwYXJlbnQ7XHJcbiAgYm9yZGVyLXJhZGl1czogMjVweDtcclxuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQod2hpdGUsIHdoaXRlKSBwYWRkaW5nLWJveCxcclxuICAgIGxpbmVhci1ncmFkaWVudCg5MGRlZywgdmFyKC0tcHJpbWFyeS1jb2xvciksIHZhcigtLXNlY29uZGFyeS1jb2xvcikpXHJcbiAgICAgIGJvcmRlci1ib3g7XHJcbiAgb3V0bGluZTogbm9uZTtcclxuICBhcHBlYXJhbmNlOiBub25lOyAvKiBIaWRlcyB0aGUgZGVmYXVsdCBkcm9wZG93biBhcnJvdyAqL1xyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5cclxuLmRyb3Bkb3duLXdyYXBwZXI6OmFmdGVyIHtcclxuICBjb250ZW50OiBcIsOiwpbCvFwiOyBcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiA1MCU7XHJcbiAgcmlnaHQ6IDEycHg7IFxyXG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtNTAlKTtcclxuICBwb2ludGVyLWV2ZW50czogbm9uZTsgXHJcbiAgY29sb3I6IHZhcigtLXByaW1hcnktY29sb3IpO1xyXG4gIGZvbnQtc2l6ZTogMC44cmVtO1xyXG59XHJcblxyXG4uZHJvcGRvd24taW5wdXQ6Zm9jdXMge1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkIHRyYW5zcGFyZW50O1xyXG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh3aGl0ZSwgd2hpdGUpIHBhZGRpbmctYm94LFxyXG4gICAgbGluZWFyLWdyYWRpZW50KDkwZGVnLCB2YXIoLS1zZWNvbmRhcnktY29sb3IpLCB2YXIoLS1wcmltYXJ5LWNvbG9yKSlcclxuICAgICAgYm9yZGVyLWJveDsgLyogU2xpZ2h0IGNvbG9yIHNoaWZ0IGZvciBmb2N1cyAqL1xyXG4gIGJveC1zaGFkb3c6IDAgMCAxcHggdmFyKC0tcHJpbWFyeS1jb2xvciksIDAgMCAxcHggdmFyKC0tc2Vjb25kYXJ5LWNvbG9yKSxcclxuICAgIDAgMCAxcHggdmFyKC0tcHJpbWFyeS1jb2xvcik7XHJcbn1cclxuXHJcbm9wdGlvbjpjaGVja2VkIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1zZWNvbmRhcnktY29sb3IpO1xyXG59XHJcblxyXG5cclxuLmRyb3Bkb3duLWlucHV0IG9wdGlvblt2YWx1ZT1cIlwiXSB7XHJcbiAgY29sb3I6IHZhcigtLXByaW1hcnktY29sb3IpOyBcclxufVxyXG5cclxuLmRyb3Bkb3duLWlucHV0Om5vdCg6aW52YWxpZCkge1xyXG4gIGNvbG9yOiB2YXIoLS1wcmltYXJ5LWNvbG9yKTsgLyogQ2hhbmdlIHRvIHlvdXIgc2VsZWN0ZWQgY29sb3IgKi9cclxufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
    });
  }
}

/***/ }),

/***/ 1029:
/*!************************************************************************!*\
  !*** ./src/app/shared/components/input-field/input-field.component.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   InputFieldComponent: () => (/* binding */ InputFieldComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/forms */ 4456);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 316);





class InputFieldComponent {
  constructor() {
    this.control = new _angular_forms__WEBPACK_IMPORTED_MODULE_0__.FormControl('');
    this.placeholder = 'Type your Recipe title here';
    this.placeholderColor = 'var(--primary-color)';
    this.fontSize = 'clamp(9px, 14px, 1.4vw)';
    this.color = 'var(--primary-color)';
    this.fontWeight = '';
    this.enterPressed = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
  }
  ngOnInit() {
    console.log('InputFieldComponent initialized');
    console.log('Placeholder:', this.placeholder);
    console.log('Font Size:', this.fontSize);
  }
  getStyles() {
    return {
      placeholder: this.placeholder,
      fontSize: this.fontSize,
      fontWeight: this.fontWeight,
      color: this.color
    };
  }
  onEnter() {
    this.enterPressed.emit(this.control.value);
    this.control.reset();
  }
  static {
    this.ɵfac = function InputFieldComponent_Factory(t) {
      return new (t || InputFieldComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: InputFieldComponent,
      selectors: [["app-input-field"]],
      inputs: {
        control: "control",
        placeholder: "placeholder",
        placeholderColor: "placeholderColor",
        fontSize: "fontSize",
        color: "color",
        fontWeight: "fontWeight"
      },
      outputs: {
        enterPressed: "enterPressed"
      },
      decls: 2,
      vars: 5,
      consts: [[1, "input-field-container"], ["type", "text", 1, "input-field", 3, "formControl", "placeholder", "ngStyle", "keydown.enter"]],
      template: function InputFieldComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "input", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("keydown.enter", function InputFieldComponent_Template_input_keydown_enter_1_listener() {
            return ctx.onEnter();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵstyleProp"]("--placeholderColor", ctx.placeholderColor);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formControl", ctx.control)("placeholder", ctx.placeholder)("ngStyle", ctx.getStyles());
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.NgStyle, _angular_forms__WEBPACK_IMPORTED_MODULE_0__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_0__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_0__.FormControlDirective],
      styles: [".input-field-container[_ngcontent-%COMP%] {\n  width: 100%;\n}\n\n.input-field[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 8px 40px 8px 12px;\n  border: 1px solid transparent;\n  border-radius: 25px;\n  background-color: var(--background-color);\n  background: linear-gradient(white, white) padding-box,\n    linear-gradient(90deg, var(--primary-color), var(--secondary-color))\n      border-box;\n  outline: none;\n}\n.input-field[_ngcontent-%COMP%]::placeholder {\n  \n\n  color: var(--placeholderColor);\n}\n\n.input-field[_ngcontent-%COMP%]:-ms-input-placeholder {\n  \n\n  color: var(--placeholderColor);\n}\n\n.input-field[_ngcontent-%COMP%]::-ms-input-placeholder {\n  \n\n  color: var(--placeholderColor);\n}\n\n.input-field[_ngcontent-%COMP%]::-webkit-input-placeholder {\n  \n\n  color: var(--placeholderColor);\n}\n\n.input-field[_ngcontent-%COMP%]:focus {\n  border: 1px solid transparent; \n\n  background: linear-gradient(white, white) padding-box,\n    linear-gradient(90deg, var(--secondary-color), var(--primary-color))\n      border-box; \n\n  box-shadow: 0 0 1px var(--primary-color), 0 0 1px var(--secondary-color),\n    0 0 1px var(--primary-color);\n  outline: none;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvaW5wdXQtZmllbGQvaW5wdXQtZmllbGQuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFdBQVc7QUFDYjs7QUFFQTtFQUNFLFdBQVc7RUFDWCwwQkFBMEI7RUFDMUIsNkJBQTZCO0VBQzdCLG1CQUFtQjtFQUNuQix5Q0FBeUM7RUFDekM7O2dCQUVjO0VBQ2QsYUFBYTtBQUNmO0FBQ0E7RUFDRSxvQkFBb0I7RUFDcEIsOEJBQThCO0FBQ2hDOztBQUVBO0VBQ0UsNEJBQTRCO0VBQzVCLDhCQUE4QjtBQUNoQzs7QUFFQTtFQUNFLDRCQUE0QjtFQUM1Qiw4QkFBOEI7QUFDaEM7O0FBRUE7RUFDRSwwQkFBMEI7RUFDMUIsOEJBQThCO0FBQ2hDOztBQUVBO0VBQ0UsNkJBQTZCLEVBQUUsNEJBQTRCO0VBQzNEOztnQkFFYyxFQUFFLGlDQUFpQztFQUNqRDtnQ0FDOEI7RUFDOUIsYUFBYTtBQUNmIiwic291cmNlc0NvbnRlbnQiOlsiLmlucHV0LWZpZWxkLWNvbnRhaW5lciB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbn1cclxuXHJcbi5pbnB1dC1maWVsZCB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgcGFkZGluZzogOHB4IDQwcHggOHB4IDEycHg7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgdHJhbnNwYXJlbnQ7XHJcbiAgYm9yZGVyLXJhZGl1czogMjVweDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1iYWNrZ3JvdW5kLWNvbG9yKTtcclxuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQod2hpdGUsIHdoaXRlKSBwYWRkaW5nLWJveCxcclxuICAgIGxpbmVhci1ncmFkaWVudCg5MGRlZywgdmFyKC0tcHJpbWFyeS1jb2xvciksIHZhcigtLXNlY29uZGFyeS1jb2xvcikpXHJcbiAgICAgIGJvcmRlci1ib3g7XHJcbiAgb3V0bGluZTogbm9uZTtcclxufVxyXG4uaW5wdXQtZmllbGQ6OnBsYWNlaG9sZGVyIHtcclxuICAvKiBTdGFuZGFyZCBzeW50YXggKi9cclxuICBjb2xvcjogdmFyKC0tcGxhY2Vob2xkZXJDb2xvcik7XHJcbn1cclxuXHJcbi5pbnB1dC1maWVsZDotbXMtaW5wdXQtcGxhY2Vob2xkZXIge1xyXG4gIC8qIEludGVybmV0IEV4cGxvcmVyIDEwLTExICovXHJcbiAgY29sb3I6IHZhcigtLXBsYWNlaG9sZGVyQ29sb3IpO1xyXG59XHJcblxyXG4uaW5wdXQtZmllbGQ6Oi1tcy1pbnB1dC1wbGFjZWhvbGRlciB7XHJcbiAgLyogTWljcm9zb2Z0IEVkZ2UgKGxlZ2FjeSkgKi9cclxuICBjb2xvcjogdmFyKC0tcGxhY2Vob2xkZXJDb2xvcik7XHJcbn1cclxuXHJcbi5pbnB1dC1maWVsZDo6LXdlYmtpdC1pbnB1dC1wbGFjZWhvbGRlciB7XHJcbiAgLyogQ2hyb21lLCBTYWZhcmksIE9wZXJhICovXHJcbiAgY29sb3I6IHZhcigtLXBsYWNlaG9sZGVyQ29sb3IpO1xyXG59XHJcblxyXG4uaW5wdXQtZmllbGQ6Zm9jdXMge1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkIHRyYW5zcGFyZW50OyAvKiBNYWludGFpbiBncmFkaWVudCB0cmljayAqL1xyXG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh3aGl0ZSwgd2hpdGUpIHBhZGRpbmctYm94LFxyXG4gICAgbGluZWFyLWdyYWRpZW50KDkwZGVnLCB2YXIoLS1zZWNvbmRhcnktY29sb3IpLCB2YXIoLS1wcmltYXJ5LWNvbG9yKSlcclxuICAgICAgYm9yZGVyLWJveDsgLyogU2xpZ2h0IGNvbG9yIHNoaWZ0IGZvciBmb2N1cyAqL1xyXG4gIGJveC1zaGFkb3c6IDAgMCAxcHggdmFyKC0tcHJpbWFyeS1jb2xvciksIDAgMCAxcHggdmFyKC0tc2Vjb25kYXJ5LWNvbG9yKSxcclxuICAgIDAgMCAxcHggdmFyKC0tcHJpbWFyeS1jb2xvcik7XHJcbiAgb3V0bGluZTogbm9uZTtcclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
    });
  }
}

/***/ }),

/***/ 349:
/*!****************************************************************!*\
  !*** ./src/app/shared/components/nav-bar/nav-bar.component.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   NavBarComponent: () => (/* binding */ NavBarComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 5072);
/* harmony import */ var src_app_models_client_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/models/client.model */ 4477);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/auth.service */ 4796);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _button_button_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../button/button.component */ 8219);








const _c0 = ["toggle"];
const _c1 = ["itemsTitles"];
const _c2 = ["navBar"];
const _c3 = ["itemsIcons"];
const _c4 = ["logo"];
const _c5 = ["logout"];
function NavBarComponent_li_11_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "li", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function NavBarComponent_li_11_Template_li_click_0_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r11);
      const i_r9 = restoredCtx.index;
      const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r10.selectItem(i_r9));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "span", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "i");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const item_r8 = ctx.$implicit;
    const i_r9 = ctx.index;
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassProp"]("selected", ctx_r3.selectedItem === i_r9);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("routerLink", item_r8.route);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassMap"](item_r8.iconClass);
  }
}
function NavBarComponent_li_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r15 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "li", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function NavBarComponent_li_14_Template_li_click_0_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r15);
      const i_r13 = restoredCtx.index;
      const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r14.selectItem(i_r13));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "span", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const item_r12 = ctx.$implicit;
    const i_r13 = ctx.index;
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassProp"]("selected", ctx_r5.selectedItem === i_r13);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("routerLink", item_r12.route);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](item_r12.title);
  }
}
class NavBarComponent {
  constructor() {
    this.authService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.inject)(src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_1__.AuthService);
    this.menuItems = [{
      title: 'Acceuil',
      iconClass: 'fas fa-home',
      route: '/client-home'
    }, {
      title: 'Profile',
      iconClass: 'fas fa-user',
      route: '/profile'
    }, {
      title: 'Recettes',
      iconClass: 'fas fa-utensils',
      route: '/recipes'
    }, {
      title: 'Nutritionnistes',
      iconClass: 'fas fa-user-md',
      route: '/nutritionists'
    }, {
      title: 'Messenger',
      iconClass: 'fab fa-facebook-messenger',
      route: '/messenger'
    }, {
      title: 'Gallery',
      iconClass: 'fas fa-image',
      route: '/gallery'
    }, {
      title: 'Analytics',
      iconClass: 'fas fa-chart-line',
      route: '/analytics'
    }, {
      title: 'Settings',
      iconClass: 'fas fa-cog',
      route: '/settings'
    }];
    this.selectedItem = null;
    this.isHovered = false;
    this.router = (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.inject)(_angular_router__WEBPACK_IMPORTED_MODULE_4__.Router);
    this.signout = () => {
      this.authService.logout();
      this.router.navigate(['/login']);
    };
  }
  ngOnInit() {
    const role = this.authService.getUserRole();
    const nutritionistId = this.authService.getUserId();
    switch (role) {
      case src_app_models_client_model__WEBPACK_IMPORTED_MODULE_0__.UserRoleEnum.CLIENT:
        this.menuItems = [{
          title: 'Acceuil',
          iconClass: 'fas fa-home',
          route: '/client-home'
        }, {
          title: 'Profile',
          iconClass: 'fas fa-user',
          route: '/profile'
        }, {
          title: 'Recettes',
          iconClass: 'fas fa-utensils',
          route: '/recipes'
        }, {
          title: 'Nutritionnistes',
          iconClass: 'fas fa-user-md',
          route: '/nutritionists'
        }, {
          title: 'Messenger',
          iconClass: 'fab fa-facebook-messenger',
          route: '/messenger'
        }, {
          title: 'Gallery',
          iconClass: 'fas fa-image',
          route: '/gallery'
        }, {
          title: 'Analytics',
          iconClass: 'fas fa-chart-line',
          route: '/analytics'
        }, {
          title: 'Settings',
          iconClass: 'fas fa-cog',
          route: '/settings'
        }];
        break;
      case src_app_models_client_model__WEBPACK_IMPORTED_MODULE_0__.UserRoleEnum.NUTRITIONIST:
        this.menuItems = [{
          title: 'Acceuil',
          iconClass: 'fas fa-home',
          route: '/nutritionist-home'
        }, {
          title: 'Recettes',
          iconClass: 'fas fa-utensils',
          route: '/recipes'
        }, {
          title: 'Planning',
          iconClass: 'fa-solid fa-calendar-days',
          route: `/nutritionnists/${nutritionistId}/planning`
        }, {
          title: 'Messenger',
          iconClass: 'fab fa-facebook-messenger',
          route: '/messenger'
        }, {
          title: 'Gallery',
          iconClass: 'fas fa-image',
          route: '/gallery'
        }, {
          title: 'Analytics',
          iconClass: 'fas fa-chart-line',
          route: '/analytics'
        }, {
          title: 'Settings',
          iconClass: 'fas fa-cog',
          route: '/settings'
        }];
        break;
      default:
        this.menuItems = [{
          title: 'Acceuil',
          iconClass: 'fas fa-home',
          route: '/admin-home'
        }, {
          title: 'Recettes',
          iconClass: 'fas fa-utensils',
          route: '/recipes'
        }, {
          title: 'Messenger',
          iconClass: 'fab fa-facebook-messenger',
          route: '/messenger'
        }, {
          title: 'Gallery',
          iconClass: 'fas fa-image',
          route: '/gallery'
        }, {
          title: 'Analytics',
          iconClass: 'fas fa-chart-line',
          route: '/analytics'
        }, {
          title: 'Settings',
          iconClass: 'fas fa-cog',
          route: '/settings'
        }];
        break;
    }
  }
  selectItem(index) {
    this.selectedItem = index;
  }
  ngAfterViewInit() {
    this.toggle.nativeElement.addEventListener('click', this.onToggleClick.bind(this));
  }
  onToggleClick() {
    this.itemsTitles.nativeElement.classList.toggle('active');
    this.navBar.nativeElement.classList.toggle('active');
    this.itemsIcons.nativeElement.classList.toggle('active');
    this.logo.nativeElement.classList.toggle('active');
    this.logout.nativeElement.classList.toggle('active');
    this.toggle.nativeElement.classList.toggle('active');
  }
  static {
    this.ɵfac = function NavBarComponent_Factory(t) {
      return new (t || NavBarComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
      type: NavBarComponent,
      selectors: [["app-nav-bar"]],
      viewQuery: function NavBarComponent_Query(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵviewQuery"](_c0, 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵviewQuery"](_c1, 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵviewQuery"](_c2, 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵviewQuery"](_c3, 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵviewQuery"](_c4, 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵviewQuery"](_c5, 5);
        }
        if (rf & 2) {
          let _t;
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵloadQuery"]()) && (ctx.toggle = _t.first);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵloadQuery"]()) && (ctx.itemsTitles = _t.first);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵloadQuery"]()) && (ctx.navBar = _t.first);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵloadQuery"]()) && (ctx.itemsIcons = _t.first);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵloadQuery"]()) && (ctx.logo = _t.first);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵloadQuery"]()) && (ctx.logout = _t.first);
        }
      },
      decls: 22,
      vars: 5,
      consts: [[1, "nav-bar"], [1, "nav-bar-container"], [1, "bg-img"], ["src", "assets/images/oranges.png", "alt", "oranges"], [1, "nav-bar-content"], ["navBar", ""], ["src", "assets/images/nutri-logo.png", "alt", "nutri-logo", 1, "logo"], ["logo", ""], [1, "menu-items"], [1, "itemsIcons"], ["itemsIcons", ""], ["class", "menu-item", 3, "selected", "routerLink", "click", 4, "ngFor", "ngForOf"], [1, "itemsTitles"], ["itemsTitles", ""], [1, "toggle"], ["toggle", ""], [1, "icon-toggle"], [1, "fas", "fa-bars"], [1, "logout"], ["logout", ""], [3, "onClick", "text", "fontWeight"], [1, "menu-item", 3, "routerLink", "click"], [1, "icon"], [1, "title"]],
      template: function NavBarComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](3, "img", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "div", 4, 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](6, "img", 6, 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](8, "div", 8)(9, "ul", 9, 10);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](11, NavBarComponent_li_11_Template, 3, 5, "li", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](12, "ul", 12, 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](14, NavBarComponent_li_14_Template, 3, 4, "li", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](15, "div", 14, 15)(17, "span", 16);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](18, "i", 17);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](19, "div", 18, 19);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](21, "app-button", 20);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](11);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngForOf", ctx.menuItems);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngForOf", ctx.menuItems);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](7);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("onClick", ctx.signout)("text", "D\u00E9connexion")("fontWeight", "500");
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.NgForOf, _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterLink, _button_button_component__WEBPACK_IMPORTED_MODULE_2__.ButtonComponent],
      styles: [".nav-bar[_ngcontent-%COMP%] {\n  height: 100vh;\n  display: flex;\n  gap: 20px;\n  position: fixed;\n  left: 0;\n  top: 0;\n  z-index: 1;\n  \n\n  width: 28%;\n}\n.nav-bar-container[_ngcontent-%COMP%] {\n  position: relative;\n  width: 100%;\n  height: 100%;\n}\n.bg-img[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  left: -25%;\n  z-index: -1;\n}\n.bg-img[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  transform: rotate(21deg);\n  height: 100vh;\n  width: 100%;\n  object-fit: cover;\n}\n\n.nav-bar-content[_ngcontent-%COMP%] {\n  height: 100vh;\n  width: 200px;\n  transition: width 0.3s ease-out;\n  background-color: var(--brown);\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  position: relative;\n  &.active {\n    width: 60px;\n    padding: 0.4rem;\n    justify-content: center;\n  }\n}\n\n.logo[_ngcontent-%COMP%] {\n  width: clamp(160px, 20%, 200px);\n  &.active {\n    display: none;\n  }\n}\n\n.menu-items[_ngcontent-%COMP%] {\n  overflow: hidden;\n  width: 90%;\n  display: flex;\n}\n\n.menu-item[_ngcontent-%COMP%] {\n  padding: 0.5rem 0.2rem 0.5rem 0.5rem;\n  display: flex;\n  cursor: pointer;\n  color: #ffffff;\n  position: relative;\n  &::before {\n    content: \"\";\n    position: absolute;\n    top: 0;\n    left: -100%;\n    width: 50%;\n    height: 100%;\n    background: linear-gradient(90deg, var(--light-orange), transparent);\n    transition: all 0.2s ease-in-out;\n  }\n  &:hover {\n    color: var(--light-orange);\n  }\n  &:hover::before {\n    left: -30%;\n  }\n}\n\n.menu-item[_ngcontent-%COMP%]   .icon[_ngcontent-%COMP%], .menu-item[_ngcontent-%COMP%]   .title[_ngcontent-%COMP%] {\n  z-index: 1000;\n  transition: color 0.3s ease;\n}\n\n.menu-item.selected[_ngcontent-%COMP%]   .icon[_ngcontent-%COMP%], .menu-item.selected[_ngcontent-%COMP%]   .title[_ngcontent-%COMP%] {\n  color: var(--light-orange);\n}\n.menu-item.hovered[_ngcontent-%COMP%]   .icon[_ngcontent-%COMP%], .menu-item.hovered[_ngcontent-%COMP%]   .title[_ngcontent-%COMP%] {\n  color: var(--light-orange);\n}\n\n.toggle[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 5%;\n  left: 85%;\n  border-radius: 10px;\n  width: 50px; \n\n  height: 50px;\n  font-size: 2rem;\n  cursor: pointer;\n  background-color: var(--brown);\n  display: flex;\n  justify-content: center; \n\n  align-items: center; \n\n  &.active {\n    top: 5%;\n    left: 50%;\n  }\n}\n\n.icon-toggle[_ngcontent-%COMP%] {\n  color: white;\n  width: 30px; \n\n  text-align: center; \n\n}\n\n.itemsTitles[_ngcontent-%COMP%] {\n  &.active {\n    display: none;\n  }\n}\n\n.logout[_ngcontent-%COMP%] {\n  margin-top: auto;\n  margin-bottom: 25px;\n  &.active {\n    display: none;\n    transition: display 0.3s ease;\n  }\n}\n\n.itemsIcons[_ngcontent-%COMP%] {\n  &.active {\n    font-size: 1.5rem;\n    transition: font-size 0.3s ease-in-out;\n  }\n}\n\n@media screen and (max-width: 768px) {\n  .icon-toggle[_ngcontent-%COMP%] {\n    width: 20px;\n  }\n  .itemsIcons[_ngcontent-%COMP%] {\n    &.active {\n      font-size: 4vw;\n    }\n  }\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvbmF2LWJhci9uYXYtYmFyLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxhQUFhO0VBQ2IsYUFBYTtFQUNiLFNBQVM7RUFDVCxlQUFlO0VBQ2YsT0FBTztFQUNQLE1BQU07RUFDTixVQUFVO0VBQ1YsMkJBQTJCO0VBQzNCLFVBQVU7QUFDWjtBQUNBO0VBQ0Usa0JBQWtCO0VBQ2xCLFdBQVc7RUFDWCxZQUFZO0FBQ2Q7QUFDQTtFQUNFLGtCQUFrQjtFQUNsQixNQUFNO0VBQ04sVUFBVTtFQUNWLFdBQVc7QUFDYjtBQUNBO0VBQ0Usd0JBQXdCO0VBQ3hCLGFBQWE7RUFDYixXQUFXO0VBQ1gsaUJBQWlCO0FBQ25COztBQUVBO0VBQ0UsYUFBYTtFQUNiLFlBQVk7RUFDWiwrQkFBK0I7RUFDL0IsOEJBQThCO0VBQzlCLGFBQWE7RUFDYixzQkFBc0I7RUFDdEIsbUJBQW1CO0VBQ25CLGtCQUFrQjtFQUNsQjtJQUNFLFdBQVc7SUFDWCxlQUFlO0lBQ2YsdUJBQXVCO0VBQ3pCO0FBQ0Y7O0FBRUE7RUFDRSwrQkFBK0I7RUFDL0I7SUFDRSxhQUFhO0VBQ2Y7QUFDRjs7QUFFQTtFQUNFLGdCQUFnQjtFQUNoQixVQUFVO0VBQ1YsYUFBYTtBQUNmOztBQUVBO0VBQ0Usb0NBQW9DO0VBQ3BDLGFBQWE7RUFDYixlQUFlO0VBQ2YsY0FBYztFQUNkLGtCQUFrQjtFQUNsQjtJQUNFLFdBQVc7SUFDWCxrQkFBa0I7SUFDbEIsTUFBTTtJQUNOLFdBQVc7SUFDWCxVQUFVO0lBQ1YsWUFBWTtJQUNaLG9FQUFvRTtJQUNwRSxnQ0FBZ0M7RUFDbEM7RUFDQTtJQUNFLDBCQUEwQjtFQUM1QjtFQUNBO0lBQ0UsVUFBVTtFQUNaO0FBQ0Y7O0FBRUE7O0VBRUUsYUFBYTtFQUNiLDJCQUEyQjtBQUM3Qjs7QUFFQTs7RUFFRSwwQkFBMEI7QUFDNUI7QUFDQTs7RUFFRSwwQkFBMEI7QUFDNUI7O0FBRUE7RUFDRSxrQkFBa0I7RUFDbEIsT0FBTztFQUNQLFNBQVM7RUFDVCxtQkFBbUI7RUFDbkIsV0FBVyxFQUFFLDBCQUEwQjtFQUN2QyxZQUFZO0VBQ1osZUFBZTtFQUNmLGVBQWU7RUFDZiw4QkFBOEI7RUFDOUIsYUFBYTtFQUNiLHVCQUF1QixFQUFFLGlDQUFpQztFQUMxRCxtQkFBbUIsRUFBRSwrQkFBK0I7RUFDcEQ7SUFDRSxPQUFPO0lBQ1AsU0FBUztFQUNYO0FBQ0Y7O0FBRUE7RUFDRSxZQUFZO0VBQ1osV0FBVyxFQUFFLDBCQUEwQjtFQUN2QyxrQkFBa0IsRUFBRSxxREFBcUQ7QUFDM0U7O0FBRUE7RUFDRTtJQUNFLGFBQWE7RUFDZjtBQUNGOztBQUVBO0VBQ0UsZ0JBQWdCO0VBQ2hCLG1CQUFtQjtFQUNuQjtJQUNFLGFBQWE7SUFDYiw2QkFBNkI7RUFDL0I7QUFDRjs7QUFFQTtFQUNFO0lBQ0UsaUJBQWlCO0lBQ2pCLHNDQUFzQztFQUN4QztBQUNGOztBQUVBO0VBQ0U7SUFDRSxXQUFXO0VBQ2I7RUFDQTtJQUNFO01BQ0UsY0FBYztJQUNoQjtFQUNGO0FBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyIubmF2LWJhciB7XHJcbiAgaGVpZ2h0OiAxMDB2aDtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGdhcDogMjBweDtcclxuICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgbGVmdDogMDtcclxuICB0b3A6IDA7XHJcbiAgei1pbmRleDogMTtcclxuICAvKiBib3JkZXI6IDNweCBzb2xpZCByZWQ7ICovXHJcbiAgd2lkdGg6IDI4JTtcclxufVxyXG4ubmF2LWJhci1jb250YWluZXIge1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbn1cclxuLmJnLWltZyB7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHRvcDogMDtcclxuICBsZWZ0OiAtMjUlO1xyXG4gIHotaW5kZXg6IC0xO1xyXG59XHJcbi5iZy1pbWcgaW1nIHtcclxuICB0cmFuc2Zvcm06IHJvdGF0ZSgyMWRlZyk7XHJcbiAgaGVpZ2h0OiAxMDB2aDtcclxuICB3aWR0aDogMTAwJTtcclxuICBvYmplY3QtZml0OiBjb3ZlcjtcclxufVxyXG5cclxuLm5hdi1iYXItY29udGVudCB7XHJcbiAgaGVpZ2h0OiAxMDB2aDtcclxuICB3aWR0aDogMjAwcHg7XHJcbiAgdHJhbnNpdGlvbjogd2lkdGggMC4zcyBlYXNlLW91dDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1icm93bik7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICYuYWN0aXZlIHtcclxuICAgIHdpZHRoOiA2MHB4O1xyXG4gICAgcGFkZGluZzogMC40cmVtO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgfVxyXG59XHJcblxyXG4ubG9nbyB7XHJcbiAgd2lkdGg6IGNsYW1wKDE2MHB4LCAyMCUsIDIwMHB4KTtcclxuICAmLmFjdGl2ZSB7XHJcbiAgICBkaXNwbGF5OiBub25lO1xyXG4gIH1cclxufVxyXG5cclxuLm1lbnUtaXRlbXMge1xyXG4gIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgd2lkdGg6IDkwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG59XHJcblxyXG4ubWVudS1pdGVtIHtcclxuICBwYWRkaW5nOiAwLjVyZW0gMC4ycmVtIDAuNXJlbSAwLjVyZW07XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgY29sb3I6ICNmZmZmZmY7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICY6OmJlZm9yZSB7XHJcbiAgICBjb250ZW50OiBcIlwiO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiAwO1xyXG4gICAgbGVmdDogLTEwMCU7XHJcbiAgICB3aWR0aDogNTAlO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCB2YXIoLS1saWdodC1vcmFuZ2UpLCB0cmFuc3BhcmVudCk7XHJcbiAgICB0cmFuc2l0aW9uOiBhbGwgMC4ycyBlYXNlLWluLW91dDtcclxuICB9XHJcbiAgJjpob3ZlciB7XHJcbiAgICBjb2xvcjogdmFyKC0tbGlnaHQtb3JhbmdlKTtcclxuICB9XHJcbiAgJjpob3Zlcjo6YmVmb3JlIHtcclxuICAgIGxlZnQ6IC0zMCU7XHJcbiAgfVxyXG59XHJcblxyXG4ubWVudS1pdGVtIC5pY29uLFxyXG4ubWVudS1pdGVtIC50aXRsZSB7XHJcbiAgei1pbmRleDogMTAwMDtcclxuICB0cmFuc2l0aW9uOiBjb2xvciAwLjNzIGVhc2U7XHJcbn1cclxuXHJcbi5tZW51LWl0ZW0uc2VsZWN0ZWQgLmljb24sXHJcbi5tZW51LWl0ZW0uc2VsZWN0ZWQgLnRpdGxlIHtcclxuICBjb2xvcjogdmFyKC0tbGlnaHQtb3JhbmdlKTtcclxufVxyXG4ubWVudS1pdGVtLmhvdmVyZWQgLmljb24sXHJcbi5tZW51LWl0ZW0uaG92ZXJlZCAudGl0bGUge1xyXG4gIGNvbG9yOiB2YXIoLS1saWdodC1vcmFuZ2UpO1xyXG59XHJcblxyXG4udG9nZ2xlIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiA1JTtcclxuICBsZWZ0OiA4NSU7XHJcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICB3aWR0aDogNTBweDsgLyogQWRqdXN0IHRoaXMgaWYgbmVlZGVkICovXHJcbiAgaGVpZ2h0OiA1MHB4O1xyXG4gIGZvbnQtc2l6ZTogMnJlbTtcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tYnJvd24pO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7IC8qIENlbnRlciB0aGUgaWNvbiBob3Jpem9udGFsbHkgKi9cclxuICBhbGlnbi1pdGVtczogY2VudGVyOyAvKiBDZW50ZXIgdGhlIGljb24gdmVydGljYWxseSAqL1xyXG4gICYuYWN0aXZlIHtcclxuICAgIHRvcDogNSU7XHJcbiAgICBsZWZ0OiA1MCU7XHJcbiAgfVxyXG59XHJcblxyXG4uaWNvbi10b2dnbGUge1xyXG4gIGNvbG9yOiB3aGl0ZTtcclxuICB3aWR0aDogMzBweDsgLyogU2V0IHRoZSBkZXNpcmVkIHdpZHRoICovXHJcbiAgdGV4dC1hbGlnbjogY2VudGVyOyAvKiBFbnN1cmUgdGhlIGljb24gaXMgY2VudGVyZWQgaW5zaWRlIGl0cyBjb250YWluZXIgKi9cclxufVxyXG5cclxuLml0ZW1zVGl0bGVzIHtcclxuICAmLmFjdGl2ZSB7XHJcbiAgICBkaXNwbGF5OiBub25lO1xyXG4gIH1cclxufVxyXG5cclxuLmxvZ291dCB7XHJcbiAgbWFyZ2luLXRvcDogYXV0bztcclxuICBtYXJnaW4tYm90dG9tOiAyNXB4O1xyXG4gICYuYWN0aXZlIHtcclxuICAgIGRpc3BsYXk6IG5vbmU7XHJcbiAgICB0cmFuc2l0aW9uOiBkaXNwbGF5IDAuM3MgZWFzZTtcclxuICB9XHJcbn1cclxuXHJcbi5pdGVtc0ljb25zIHtcclxuICAmLmFjdGl2ZSB7XHJcbiAgICBmb250LXNpemU6IDEuNXJlbTtcclxuICAgIHRyYW5zaXRpb246IGZvbnQtc2l6ZSAwLjNzIGVhc2UtaW4tb3V0O1xyXG4gIH1cclxufVxyXG5cclxuQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNzY4cHgpIHtcclxuICAuaWNvbi10b2dnbGUge1xyXG4gICAgd2lkdGg6IDIwcHg7XHJcbiAgfVxyXG4gIC5pdGVtc0ljb25zIHtcclxuICAgICYuYWN0aXZlIHtcclxuICAgICAgZm9udC1zaXplOiA0dnc7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
    });
  }
}

/***/ }),

/***/ 1469:
/*!********************************************************************************!*\
  !*** ./src/app/shared/components/page-background/page-background.component.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PageBackgroundComponent: () => (/* binding */ PageBackgroundComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _nav_bar_nav_bar_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../nav-bar/nav-bar.component */ 349);
/* harmony import */ var _search_header_search_header_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../search-header/search-header.component */ 4093);



const _c0 = ["*"];
class PageBackgroundComponent {
  constructor() {
    this.quote = '';
  }
  static {
    this.ɵfac = function PageBackgroundComponent_Factory(t) {
      return new (t || PageBackgroundComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
      type: PageBackgroundComponent,
      selectors: [["app-page-background"]],
      inputs: {
        quote: "quote"
      },
      ngContentSelectors: _c0,
      decls: 6,
      vars: 0,
      consts: [[1, "page-container"], [1, "right-section"], [1, "list-container"]],
      template: function PageBackgroundComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵprojectionDef"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](1, "app-nav-bar");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "div", 1)(3, "div", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](4, "app-search-header");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵprojection"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()();
        }
      },
      dependencies: [_nav_bar_nav_bar_component__WEBPACK_IMPORTED_MODULE_0__.NavBarComponent, _search_header_search_header_component__WEBPACK_IMPORTED_MODULE_1__.SearchHeaderComponent],
      styles: [".page-container[_ngcontent-%COMP%] {\n  justify-content: end;\n  display: flex;\n  width: 100%;\n  position: relative;\n  padding-bottom: 20px;\n  padding-top: 20px;\n}\n\n.left-section[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  left: -25%;\n  z-index: 0;\n}\n.left-section[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  transform: rotate(21deg);\n  height: 900px;\n  width: 100%;\n  object-fit: cover;\n}\n.list-container[_ngcontent-%COMP%] {\n  width: max(90%, 600px);\n  height: auto;\n  overflow: visible;\n  display: flex;\n  flex-direction: column;\n  gap: 15px;\n}\n.right-section[_ngcontent-%COMP%] {\n  width: 80%;\n  display: flex;\n  flex-direction: column;\n  justify-content: start;\n  align-items: center;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvcGFnZS1iYWNrZ3JvdW5kL3BhZ2UtYmFja2dyb3VuZC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usb0JBQW9CO0VBQ3BCLGFBQWE7RUFDYixXQUFXO0VBQ1gsa0JBQWtCO0VBQ2xCLG9CQUFvQjtFQUNwQixpQkFBaUI7QUFDbkI7O0FBRUE7RUFDRSxrQkFBa0I7RUFDbEIsTUFBTTtFQUNOLFVBQVU7RUFDVixVQUFVO0FBQ1o7QUFDQTtFQUNFLHdCQUF3QjtFQUN4QixhQUFhO0VBQ2IsV0FBVztFQUNYLGlCQUFpQjtBQUNuQjtBQUNBO0VBQ0Usc0JBQXNCO0VBQ3RCLFlBQVk7RUFDWixpQkFBaUI7RUFDakIsYUFBYTtFQUNiLHNCQUFzQjtFQUN0QixTQUFTO0FBQ1g7QUFDQTtFQUNFLFVBQVU7RUFDVixhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLHNCQUFzQjtFQUN0QixtQkFBbUI7QUFDckIiLCJzb3VyY2VzQ29udGVudCI6WyIucGFnZS1jb250YWluZXIge1xyXG4gIGp1c3RpZnktY29udGVudDogZW5kO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIHBhZGRpbmctYm90dG9tOiAyMHB4O1xyXG4gIHBhZGRpbmctdG9wOiAyMHB4O1xyXG59XHJcblxyXG4ubGVmdC1zZWN0aW9uIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiAwO1xyXG4gIGxlZnQ6IC0yNSU7XHJcbiAgei1pbmRleDogMDtcclxufVxyXG4ubGVmdC1zZWN0aW9uIGltZyB7XHJcbiAgdHJhbnNmb3JtOiByb3RhdGUoMjFkZWcpO1xyXG4gIGhlaWdodDogOTAwcHg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgb2JqZWN0LWZpdDogY292ZXI7XHJcbn1cclxuLmxpc3QtY29udGFpbmVyIHtcclxuICB3aWR0aDogbWF4KDkwJSwgNjAwcHgpO1xyXG4gIGhlaWdodDogYXV0bztcclxuICBvdmVyZmxvdzogdmlzaWJsZTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgZ2FwOiAxNXB4O1xyXG59XHJcbi5yaWdodC1zZWN0aW9uIHtcclxuICB3aWR0aDogODAlO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHN0YXJ0O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 4815:
/*!**********************************************************************!*\
  !*** ./src/app/shared/components/pagination/pagination.component.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PaginationComponent: () => (/* binding */ PaginationComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 316);



function PaginationComponent_a_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "a", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PaginationComponent_a_1_Template_a_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r12);
      const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r11.setPage(ctx_r11.selectedPageIndex - 1));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Prev");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
}
function PaginationComponent_a_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "a");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "2");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("active", ctx_r1.selectedPageIndex == 2);
  }
}
function PaginationComponent_a_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "a");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "...");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
}
function PaginationComponent_a_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "a");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "3");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("active", ctx_r3.selectedPageIndex == 3);
  }
}
function PaginationComponent_a_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "a");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("active", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r4.selectedPageIndex);
  }
}
function PaginationComponent_a_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "a");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("active", false);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r5.selectedPageIndex + 1);
  }
}
function PaginationComponent_a_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "a");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "...");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
}
function PaginationComponent_a_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "a");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("active", ctx_r7.selectedPageIndex == ctx_r7.totalPages - 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r7.totalPages - 2);
  }
}
function PaginationComponent_a_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "a");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("active", ctx_r8.selectedPageIndex == ctx_r8.totalPages - 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r8.totalPages - 1);
  }
}
function PaginationComponent_a_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "a");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("active", ctx_r9.selectedPageIndex == ctx_r9.totalPages);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r9.totalPages);
  }
}
function PaginationComponent_a_13_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "a", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PaginationComponent_a_13_Template_a_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r14);
      const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r13.setPage(ctx_r13.selectedPageIndex + 1));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Next");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
}
class PaginationComponent {
  constructor() {
    this.totalPages = 20;
    this.selectedPageIndex = 1;
    this.pageChanged = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
  }
  setPage(index) {
    this.pageChanged.emit(index);
    this.selectedPageIndex = index;
  }
  getNumberSequence() {
    return Array.from({
      length: 2
    }, (_, i) => this.selectedPageIndex + i);
  }
  static {
    this.ɵfac = function PaginationComponent_Factory(t) {
      return new (t || PaginationComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: PaginationComponent,
      selectors: [["app-pagination"]],
      inputs: {
        totalPages: "totalPages"
      },
      outputs: {
        pageChanged: "pageChanged"
      },
      decls: 14,
      vars: 13,
      consts: [[1, "pagination-container"], [3, "click", 4, "ngIf"], [3, "active", 4, "ngIf"], [4, "ngIf"], [3, "click"]],
      template: function PaginationComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, PaginationComponent_a_1_Template, 2, 0, "a", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "a");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "1");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, PaginationComponent_a_4_Template, 2, 2, "a", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, PaginationComponent_a_5_Template, 2, 0, "a", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](6, PaginationComponent_a_6_Template, 2, 2, "a", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](7, PaginationComponent_a_7_Template, 2, 3, "a", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](8, PaginationComponent_a_8_Template, 2, 3, "a", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](9, PaginationComponent_a_9_Template, 2, 0, "a", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](10, PaginationComponent_a_10_Template, 2, 3, "a", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](11, PaginationComponent_a_11_Template, 2, 3, "a", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](12, PaginationComponent_a_12_Template, 2, 3, "a", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](13, PaginationComponent_a_13_Template, 2, 0, "a", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.selectedPageIndex > 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("active", ctx.selectedPageIndex == 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.selectedPageIndex <= 2 && ctx.totalPages > 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.selectedPageIndex > 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.selectedPageIndex <= 3 && ctx.totalPages > 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.selectedPageIndex >= 4 && ctx.selectedPageIndex <= ctx.totalPages - 3 && ctx.totalPages > 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.selectedPageIndex >= 3 && ctx.selectedPageIndex <= ctx.totalPages - 4 && ctx.totalPages > 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.totalPages - ctx.selectedPageIndex >= 3 && ctx.totalPages > 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.selectedPageIndex > ctx.totalPages - 3 && ctx.totalPages > 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.selectedPageIndex >= ctx.totalPages - 2 && ctx.totalPages > 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.totalPages > 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.selectedPageIndex < ctx.totalPages);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgIf],
      styles: [".pagination-container[_ngcontent-%COMP%] {\n  display: flex;\n  padding-right: 30px;\n  gap: 7px;\n}\n.pagination-container[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  color: var(--primary-color);\n  background-color: white;\n  padding: 6px 10px;\n  position: relative;\n  border-radius: 10px;\n  text-decoration: none;\n  overflow: hidden;\n  &.active::before {\n    content: \"\";\n    position: absolute;\n    top: 0;\n    left: -100%;\n    width: 100%;\n    height: 100%;\n    background: linear-gradient(\n      120deg,\n      transparent,\n      rgba(255, 255, 255, 0.2),\n      transparent\n    );\n\n    transition: all 0.65s ease-in-out;\n  }\n  &.active:hover::before {\n    left: 100%;\n  }\n}\n\n.pagination-container[_ngcontent-%COMP%]   a.active[_ngcontent-%COMP%] {\n  background-color: var(--secondary-color);\n  color: white;\n  border-radius: 5px;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvcGFnaW5hdGlvbi9wYWdpbmF0aW9uLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLFFBQVE7QUFDVjtBQUNBO0VBQ0UsMkJBQTJCO0VBQzNCLHVCQUF1QjtFQUN2QixpQkFBaUI7RUFDakIsa0JBQWtCO0VBQ2xCLG1CQUFtQjtFQUNuQixxQkFBcUI7RUFDckIsZ0JBQWdCO0VBQ2hCO0lBQ0UsV0FBVztJQUNYLGtCQUFrQjtJQUNsQixNQUFNO0lBQ04sV0FBVztJQUNYLFdBQVc7SUFDWCxZQUFZO0lBQ1o7Ozs7O0tBS0M7O0lBRUQsaUNBQWlDO0VBQ25DO0VBQ0E7SUFDRSxVQUFVO0VBQ1o7QUFDRjs7QUFFQTtFQUNFLHdDQUF3QztFQUN4QyxZQUFZO0VBQ1osa0JBQWtCO0FBQ3BCIiwic291cmNlc0NvbnRlbnQiOlsiLnBhZ2luYXRpb24tY29udGFpbmVyIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIHBhZGRpbmctcmlnaHQ6IDMwcHg7XHJcbiAgZ2FwOiA3cHg7XHJcbn1cclxuLnBhZ2luYXRpb24tY29udGFpbmVyIGEge1xyXG4gIGNvbG9yOiB2YXIoLS1wcmltYXJ5LWNvbG9yKTtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICBwYWRkaW5nOiA2cHggMTBweDtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICAmLmFjdGl2ZTo6YmVmb3JlIHtcclxuICAgIGNvbnRlbnQ6IFwiXCI7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDA7XHJcbiAgICBsZWZ0OiAtMTAwJTtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KFxyXG4gICAgICAxMjBkZWcsXHJcbiAgICAgIHRyYW5zcGFyZW50LFxyXG4gICAgICByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMiksXHJcbiAgICAgIHRyYW5zcGFyZW50XHJcbiAgICApO1xyXG5cclxuICAgIHRyYW5zaXRpb246IGFsbCAwLjY1cyBlYXNlLWluLW91dDtcclxuICB9XHJcbiAgJi5hY3RpdmU6aG92ZXI6OmJlZm9yZSB7XHJcbiAgICBsZWZ0OiAxMDAlO1xyXG4gIH1cclxufVxyXG5cclxuLnBhZ2luYXRpb24tY29udGFpbmVyIGEuYWN0aXZlIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1zZWNvbmRhcnktY29sb3IpO1xyXG4gIGNvbG9yOiB3aGl0ZTtcclxuICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 4061:
/*!************************************************************!*\
  !*** ./src/app/shared/components/popup/popup.component.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PopupComponent: () => (/* binding */ PopupComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 7580);


const _c0 = ["*"];
class PopupComponent {
  constructor() {
    this.text = '';
    this.popupClosed = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
  }
  clsoePopup() {
    this.popupClosed.emit(false);
  }
  static {
    this.ɵfac = function PopupComponent_Factory(t) {
      return new (t || PopupComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: PopupComponent,
      selectors: [["app-popup"]],
      inputs: {
        text: "text"
      },
      outputs: {
        popupClosed: "popupClosed"
      },
      ngContentSelectors: _c0,
      decls: 7,
      vars: 1,
      consts: [[1, "modal"], [1, "modal-content"], [1, "close-btn", 3, "click"]],
      template: function PopupComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojectionDef"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "span", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PopupComponent_Template_span_click_2_listener() {
            return ctx.clsoePopup();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "\u00D7");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "h4");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.text);
        }
      },
      styles: [".modal {\n  position: relative;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n  z-index: 2000000;\n}\n\n\n\n.modal-content[_ngcontent-%COMP%] {\n  position: fixed;\n  top: 0;\n  left: 50%;\n  transform: translate(-50%, 0);\n  background-color: white;\n  padding: 20px 40px 20px 20px;\n  border-radius: 12px;\n  width: clamp(auto, 50vw, 90vw);\n  box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);\n  z-index: 10000;\n  display: flex;\n  flex-direction: column;\n  gap: 20px;\n}\n\n\n\n.close-btn[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 10px;\n  right: 10px;\n  background: none;\n  border: none;\n  font-size: 24px;\n  cursor: pointer;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvcG9wdXAvcG9wdXAuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGtCQUFrQjtFQUNsQixNQUFNO0VBQ04sT0FBTztFQUNQLFdBQVc7RUFDWCxZQUFZO0VBQ1osZ0JBQWdCO0FBQ2xCOztBQUVBLGtCQUFrQjtBQUNsQjtFQUNFLGVBQWU7RUFDZixNQUFNO0VBQ04sU0FBUztFQUNULDZCQUE2QjtFQUM3Qix1QkFBdUI7RUFDdkIsNEJBQTRCO0VBQzVCLG1CQUFtQjtFQUNuQiw4QkFBOEI7RUFDOUIsMkNBQTJDO0VBQzNDLGNBQWM7RUFDZCxhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLFNBQVM7QUFDWDs7QUFFQSxpQkFBaUI7QUFDakI7RUFDRSxrQkFBa0I7RUFDbEIsU0FBUztFQUNULFdBQVc7RUFDWCxnQkFBZ0I7RUFDaEIsWUFBWTtFQUNaLGVBQWU7RUFDZixlQUFlO0FBQ2pCIiwic291cmNlc0NvbnRlbnQiOlsiOjpuZy1kZWVwIC5tb2RhbCB7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIHRvcDogMDtcclxuICBsZWZ0OiAwO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMTAwJTtcclxuICB6LWluZGV4OiAyMDAwMDAwO1xyXG59XHJcblxyXG4vKiBQb3B1cCBjb250ZW50ICovXHJcbi5tb2RhbC1jb250ZW50IHtcclxuICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgdG9wOiAwO1xyXG4gIGxlZnQ6IDUwJTtcclxuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAwKTtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICBwYWRkaW5nOiAyMHB4IDQwcHggMjBweCAyMHB4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDEycHg7XHJcbiAgd2lkdGg6IGNsYW1wKGF1dG8sIDUwdncsIDkwdncpO1xyXG4gIGJveC1zaGFkb3c6IDBweCA0cHggMTBweCByZ2JhKDAsIDAsIDAsIDAuMik7XHJcbiAgei1pbmRleDogMTAwMDA7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gIGdhcDogMjBweDtcclxufVxyXG5cclxuLyogQ2xvc2UgYnV0dG9uICovXHJcbi5jbG9zZS1idG4ge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB0b3A6IDEwcHg7XHJcbiAgcmlnaHQ6IDEwcHg7XHJcbiAgYmFja2dyb3VuZDogbm9uZTtcclxuICBib3JkZXI6IG5vbmU7XHJcbiAgZm9udC1zaXplOiAyNHB4O1xyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
    });
  }
}

/***/ }),

/***/ 9485:
/*!********************************************************************!*\
  !*** ./src/app/shared/components/preloader/preloader.component.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PreloaderComponent: () => (/* binding */ PreloaderComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 7580);

class PreloaderComponent {
  static {
    this.ɵfac = function PreloaderComponent_Factory(t) {
      return new (t || PreloaderComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: PreloaderComponent,
      selectors: [["app-preloader"]],
      decls: 7,
      vars: 0,
      consts: [["viewBox", "0 0 200 200", "width", "200", "height", "200", "xmlns", "http://www.w3.org/2000/svg", 1, "pl"], ["id", "linear", "x1", "0", "y1", "0", "x2", "0", "y2", "1"], ["offset", "0%", "stop-color", "#cc5500"], ["offset", "100%", "stop-color", "#9dc209"], ["cx", "100", "cy", "100", "r", "82", "fill", "none", "stroke", "url(#linear)", "stroke-width", "36", "stroke-dasharray", "0 257 1 257", "stroke-dashoffset", "0.01", "stroke-linecap", "round", "transform", "rotate(-90,100,100)", 1, "pl__ring"], ["stroke", "url(#linear)", "x1", "100", "y1", "18", "x2", "100.01", "y2", "182", "stroke-width", "36", "stroke-dasharray", "1 165", "stroke-linecap", "round", 1, "pl__ball"]],
      template: function PreloaderComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnamespaceSVG"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "svg", 0)(1, "defs")(2, "linearGradient", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "stop", 2)(4, "stop", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](5, "circle", 4)(6, "line", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      },
      styles: [".pl[_ngcontent-%COMP%] {\n  display: block;\n  width: 70px;\n  height: 70px;\n}\n.pl__ring[_ngcontent-%COMP%], .pl__ball[_ngcontent-%COMP%] {\n  animation: _ngcontent-%COMP%_ring 2s ease-out infinite;\n}\n.pl__ball[_ngcontent-%COMP%] {\n  animation-name: _ngcontent-%COMP%_ball;\n}\n\n\n\n@keyframes _ngcontent-%COMP%_ring {\n  from {\n    stroke-dasharray: 0 257 0 0 1 0 0 258;\n  }\n  25% {\n    stroke-dasharray: 0 0 0 0 257 0 258 0;\n  }\n  50%,\n  to {\n    stroke-dasharray: 0 0 0 0 0 515 0 0;\n  }\n}\n@keyframes _ngcontent-%COMP%_ball {\n  from,\n  50% {\n    animation-timing-function: ease-in;\n    stroke-dashoffset: 1;\n  }\n  64% {\n    animation-timing-function: ease-in;\n    stroke-dashoffset: -109;\n  }\n  78% {\n    animation-timing-function: ease-in;\n    stroke-dashoffset: -145;\n  }\n  92% {\n    animation-timing-function: ease-in;\n    stroke-dashoffset: -157;\n  }\n  57%,\n  71%,\n  85%,\n  99%,\n  to {\n    animation-timing-function: ease-out;\n    stroke-dashoffset: -163;\n  }\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvcHJlbG9hZGVyL3ByZWxvYWRlci5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsY0FBYztFQUNkLFdBQVc7RUFDWCxZQUFZO0FBQ2Q7QUFDQTs7RUFFRSxvQ0FBb0M7QUFDdEM7QUFDQTtFQUNFLG9CQUFvQjtBQUN0Qjs7QUFFQSxjQUFjO0FBQ2Q7RUFDRTtJQUNFLHFDQUFxQztFQUN2QztFQUNBO0lBQ0UscUNBQXFDO0VBQ3ZDO0VBQ0E7O0lBRUUsbUNBQW1DO0VBQ3JDO0FBQ0Y7QUFDQTtFQUNFOztJQUVFLGtDQUFrQztJQUNsQyxvQkFBb0I7RUFDdEI7RUFDQTtJQUNFLGtDQUFrQztJQUNsQyx1QkFBdUI7RUFDekI7RUFDQTtJQUNFLGtDQUFrQztJQUNsQyx1QkFBdUI7RUFDekI7RUFDQTtJQUNFLGtDQUFrQztJQUNsQyx1QkFBdUI7RUFDekI7RUFDQTs7Ozs7SUFLRSxtQ0FBbUM7SUFDbkMsdUJBQXVCO0VBQ3pCO0FBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyIucGwge1xyXG4gIGRpc3BsYXk6IGJsb2NrO1xyXG4gIHdpZHRoOiA3MHB4O1xyXG4gIGhlaWdodDogNzBweDtcclxufVxyXG4ucGxfX3JpbmcsXHJcbi5wbF9fYmFsbCB7XHJcbiAgYW5pbWF0aW9uOiByaW5nIDJzIGVhc2Utb3V0IGluZmluaXRlO1xyXG59XHJcbi5wbF9fYmFsbCB7XHJcbiAgYW5pbWF0aW9uLW5hbWU6IGJhbGw7XHJcbn1cclxuXHJcbi8qIEFuaW1hdGlvbiAqL1xyXG5Aa2V5ZnJhbWVzIHJpbmcge1xyXG4gIGZyb20ge1xyXG4gICAgc3Ryb2tlLWRhc2hhcnJheTogMCAyNTcgMCAwIDEgMCAwIDI1ODtcclxuICB9XHJcbiAgMjUlIHtcclxuICAgIHN0cm9rZS1kYXNoYXJyYXk6IDAgMCAwIDAgMjU3IDAgMjU4IDA7XHJcbiAgfVxyXG4gIDUwJSxcclxuICB0byB7XHJcbiAgICBzdHJva2UtZGFzaGFycmF5OiAwIDAgMCAwIDAgNTE1IDAgMDtcclxuICB9XHJcbn1cclxuQGtleWZyYW1lcyBiYWxsIHtcclxuICBmcm9tLFxyXG4gIDUwJSB7XHJcbiAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluO1xyXG4gICAgc3Ryb2tlLWRhc2hvZmZzZXQ6IDE7XHJcbiAgfVxyXG4gIDY0JSB7XHJcbiAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluO1xyXG4gICAgc3Ryb2tlLWRhc2hvZmZzZXQ6IC0xMDk7XHJcbiAgfVxyXG4gIDc4JSB7XHJcbiAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluO1xyXG4gICAgc3Ryb2tlLWRhc2hvZmZzZXQ6IC0xNDU7XHJcbiAgfVxyXG4gIDkyJSB7XHJcbiAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluO1xyXG4gICAgc3Ryb2tlLWRhc2hvZmZzZXQ6IC0xNTc7XHJcbiAgfVxyXG4gIDU3JSxcclxuICA3MSUsXHJcbiAgODUlLFxyXG4gIDk5JSxcclxuICB0byB7XHJcbiAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLW91dDtcclxuICAgIHN0cm9rZS1kYXNob2Zmc2V0OiAtMTYzO1xyXG4gIH1cclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
    });
  }
}

/***/ }),

/***/ 2229:
/*!**************************************************************************************!*\
  !*** ./src/app/shared/components/progress-indicator/progress-indicator.component.ts ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ProgressIndicatorComponent: () => (/* binding */ ProgressIndicatorComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 316);


function ProgressIndicatorComponent_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 3)(1, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const step_r1 = ctx.$implicit;
    const i_r2 = ctx.index;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("active", i_r2 <= ctx_r0.activeStep);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](i_r2 + 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](step_r1);
  }
}
class ProgressIndicatorComponent {
  constructor() {
    this.steps = [];
    this.activeStep = 0;
  }
  static {
    this.ɵfac = function ProgressIndicatorComponent_Factory(t) {
      return new (t || ProgressIndicatorComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: ProgressIndicatorComponent,
      selectors: [["app-progress-indicator"]],
      inputs: {
        steps: "steps",
        activeStep: "activeStep"
      },
      decls: 3,
      vars: 1,
      consts: [[1, "steps-container"], [1, "line-background"], ["class", "step", 3, "active", 4, "ngFor", "ngForOf"], [1, "step"], [1, "progress-circle"], [1, "label"]],
      template: function ProgressIndicatorComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "div", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, ProgressIndicatorComponent_div_2_Template, 5, 4, "div", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.steps);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgForOf],
      styles: [".line-background[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 1.25rem;\n  width: 100%;\n  height: 1.3px; \n\n  background-color: var(--hint-text);\n  z-index: 0; \n\n}\n\n.steps-container[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  display: flex;\n  justify-content: space-evenly;\n  align-items: start;\n  position: relative;\n  z-index: 1;\n}\n\n.step[_ngcontent-%COMP%] {\n  width: 8rem;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: start;\n  text-align: center;\n}\n\n.progress-circle[_ngcontent-%COMP%] {\n  width: 2.5rem;\n  height: 2.5rem;\n  font-size: 0.8rem;\n  border-radius: 50%;\n  background-color: white;\n  border-color: var(--hint-text);\n  color: var(--hint-text);\n  font-weight: bold;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin-bottom: 8px;\n  z-index: 0;\n}\n\n.step.active[_ngcontent-%COMP%]   .progress-circle[_ngcontent-%COMP%] {\n  background-color: var(--secondary-color);\n  color: #fff;\n}\n\n.label[_ngcontent-%COMP%] {\n  height: 2rem;\n  font-size: 0.7rem;\n  color: var(--hint-text);\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvcHJvZ3Jlc3MtaW5kaWNhdG9yL3Byb2dyZXNzLWluZGljYXRvci5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usa0JBQWtCO0VBQ2xCLFlBQVk7RUFDWixXQUFXO0VBQ1gsYUFBYSxFQUFFLGdDQUFnQztFQUMvQyxrQ0FBa0M7RUFDbEMsVUFBVSxFQUFFLHNDQUFzQztBQUNwRDs7QUFFQTtFQUNFLFdBQVc7RUFDWCxZQUFZO0VBQ1osYUFBYTtFQUNiLDZCQUE2QjtFQUM3QixrQkFBa0I7RUFDbEIsa0JBQWtCO0VBQ2xCLFVBQVU7QUFDWjs7QUFFQTtFQUNFLFdBQVc7RUFDWCxhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLG1CQUFtQjtFQUNuQixzQkFBc0I7RUFDdEIsa0JBQWtCO0FBQ3BCOztBQUVBO0VBQ0UsYUFBYTtFQUNiLGNBQWM7RUFDZCxpQkFBaUI7RUFDakIsa0JBQWtCO0VBQ2xCLHVCQUF1QjtFQUN2Qiw4QkFBOEI7RUFDOUIsdUJBQXVCO0VBQ3ZCLGlCQUFpQjtFQUNqQixhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLHVCQUF1QjtFQUN2QixrQkFBa0I7RUFDbEIsVUFBVTtBQUNaOztBQUVBO0VBQ0Usd0NBQXdDO0VBQ3hDLFdBQVc7QUFDYjs7QUFFQTtFQUNFLFlBQVk7RUFDWixpQkFBaUI7RUFDakIsdUJBQXVCO0FBQ3pCIiwic291cmNlc0NvbnRlbnQiOlsiLmxpbmUtYmFja2dyb3VuZCB7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHRvcDogMS4yNXJlbTtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDEuM3B4OyAvKiBCaWcgbGluZSBiZWhpbmQgdGhlIGNpcmNsZXMgKi9cclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1oaW50LXRleHQpO1xyXG4gIHotaW5kZXg6IDA7IC8qIEVuc3VyZSB0aGlzIGlzIGJlaGluZCB0aGUgY2lyY2xlcyAqL1xyXG59XHJcblxyXG4uc3RlcHMtY29udGFpbmVyIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWV2ZW5seTtcclxuICBhbGlnbi1pdGVtczogc3RhcnQ7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIHotaW5kZXg6IDE7XHJcbn1cclxuXHJcbi5zdGVwIHtcclxuICB3aWR0aDogOHJlbTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHN0YXJ0O1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuLnByb2dyZXNzLWNpcmNsZSB7XHJcbiAgd2lkdGg6IDIuNXJlbTtcclxuICBoZWlnaHQ6IDIuNXJlbTtcclxuICBmb250LXNpemU6IDAuOHJlbTtcclxuICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgYm9yZGVyLWNvbG9yOiB2YXIoLS1oaW50LXRleHQpO1xyXG4gIGNvbG9yOiB2YXIoLS1oaW50LXRleHQpO1xyXG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBtYXJnaW4tYm90dG9tOiA4cHg7XHJcbiAgei1pbmRleDogMDtcclxufVxyXG5cclxuLnN0ZXAuYWN0aXZlIC5wcm9ncmVzcy1jaXJjbGUge1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLXNlY29uZGFyeS1jb2xvcik7XHJcbiAgY29sb3I6ICNmZmY7XHJcbn1cclxuXHJcbi5sYWJlbCB7XHJcbiAgaGVpZ2h0OiAycmVtO1xyXG4gIGZvbnQtc2l6ZTogMC43cmVtO1xyXG4gIGNvbG9yOiB2YXIoLS1oaW50LXRleHQpO1xyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
    });
  }
}

/***/ }),

/***/ 6981:
/*!**************************************************************************************!*\
  !*** ./src/app/shared/components/recipe-description/recipe-description.component.ts ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RecipeDescriptionComponent: () => (/* binding */ RecipeDescriptionComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 4456);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _input_field_input_field_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../input-field/input-field.component */ 1029);





function RecipeDescriptionComponent_li_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "li")(1, "div", 4)(2, "img", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function RecipeDescriptionComponent_li_6_Template_img_click_2_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r4);
      const i_r2 = restoredCtx.index;
      const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵresetView"](ctx_r3.deleteDetail(i_r2));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "span", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const detail_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](detail_r1);
  }
}
class RecipeDescriptionComponent {
  constructor() {
    this.title = 'Ingredients :';
    this.placeholder = 'Ingredients :';
    this.details = [];
    this.detailControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControl('');
    this.enterPressed = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
  }
  addDetail(value) {
    if (value.trim()) {
      this.details.push(value);
      this.enterPressed.emit(this.details);
      this.detailControl.reset();
    }
  }
  deleteDetail(index) {
    this.details.splice(index, 1);
    this.enterPressed.emit(this.details);
  }
  static {
    this.ɵfac = function RecipeDescriptionComponent_Factory(t) {
      return new (t || RecipeDescriptionComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: RecipeDescriptionComponent,
      selectors: [["app-recipe-description"]],
      inputs: {
        title: "title",
        placeholder: "placeholder",
        details: "details"
      },
      outputs: {
        enterPressed: "enterPressed"
      },
      decls: 7,
      vars: 4,
      consts: [[1, "recipe-detail-item"], [1, "input"], [3, "control", "placeholder", "enterPressed"], [4, "ngFor", "ngForOf"], [1, "detail-list"], ["src", "assets/images/cancel.png", "alt", "delete", 1, "delete-icon", 3, "click"], [1, "detail-text"]],
      template: function RecipeDescriptionComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "h2");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "div", 1)(4, "app-input-field", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("enterPressed", function RecipeDescriptionComponent_Template_app_input_field_enterPressed_4_listener($event) {
            return ctx.addDetail($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "ul");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](6, RecipeDescriptionComponent_li_6_Template, 5, 1, "li", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx.title);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("control", ctx.detailControl)("placeholder", ctx.placeholder);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx.details);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgForOf, _input_field_input_field_component__WEBPACK_IMPORTED_MODULE_0__.InputFieldComponent],
      styles: [".recipe-detail-item[_ngcontent-%COMP%]   .input[_ngcontent-%COMP%] {\n  width: 100%;\n}\n\n\n.delete-icon[_ngcontent-%COMP%]{\n  width: 25px;\n  height: 25px;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvcmVjaXBlLWRlc2NyaXB0aW9uL3JlY2lwZS1kZXNjcmlwdGlvbi5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsV0FBVztBQUNiOzs7QUFHQTtFQUNFLFdBQVc7RUFDWCxZQUFZO0FBQ2QiLCJzb3VyY2VzQ29udGVudCI6WyIucmVjaXBlLWRldGFpbC1pdGVtIC5pbnB1dCB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbn1cclxuXHJcblxyXG4uZGVsZXRlLWljb257XHJcbiAgd2lkdGg6IDI1cHg7XHJcbiAgaGVpZ2h0OiAyNXB4O1xyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0= */", ".quote[_ngcontent-%COMP%] {\n  margin: auto;\n  width: 100%;\n  max-width: 21rem;\n  text-align: center;\n  white-space: normal;\n  line-height: 1.5;\n}\n.quote[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  font-family: \"Dancing Script\";\n  color: var(--primary-color);\n  font-size: 1.7rem;\n}\n\n.pagination[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n  justify-content: end;\n}\n.recipe-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  padding: 0 40px 40px 40px;\n  justify-content: start;\n  align-items: center;\n  gap: 20px;\n  width: 100%;\n}\n\n.first-section-recipe[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 30px;\n  align-items: center;\n  justify-content: center;\n  width: 100%;\n  margin-top: 15px;\n}\n.recipe-details[_ngcontent-%COMP%] {\n  height: 100%;\n  width: 65%;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  gap: 20px;\n  align-items: center;\n}\n.details-grid-container[_ngcontent-%COMP%] {\n  padding-top: 10px;\n  width: 100%;\n  display: grid;\n  grid-template-columns: repeat(auto-fit, 210px);\n  grid-template-rows: repeat(3, 50px);\n  justify-content: center;\n  row-gap: 10px;\n  column-gap: 20px;\n}\n.detail-item[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n}\n.detail-item[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 40px;\n  height: 40px;\n}\n.separation-line[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 0.5px;\n  background-color: var(--secondary-color);\n}\n.second-section-recipe[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n}\n.recipe-detail-item[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  gap: 15px;\n}\n.recipe-detail-item[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  color: var(--brown);\n  font-weight: 600;\n  font-size: 26px;\n}\n\n.detail-list[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  z-index: 1000;\n}\n.recipe-detail-item[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n  margin-bottom: 10px;\n}\n.detail-text[_ngcontent-%COMP%] {\n  font-weight: 500;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hc3NldHMvY3NzL2xpc3QtY29tbW9uLmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFlBQVk7RUFDWixXQUFXO0VBQ1gsZ0JBQWdCO0VBQ2hCLGtCQUFrQjtFQUNsQixtQkFBbUI7RUFDbkIsZ0JBQWdCO0FBQ2xCO0FBQ0E7RUFDRSw2QkFBNkI7RUFDN0IsMkJBQTJCO0VBQzNCLGlCQUFpQjtBQUNuQjs7QUFFQTtFQUNFLFdBQVc7RUFDWCxhQUFhO0VBQ2Isb0JBQW9CO0FBQ3RCO0FBQ0E7RUFDRSxhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLHlCQUF5QjtFQUN6QixzQkFBc0I7RUFDdEIsbUJBQW1CO0VBQ25CLFNBQVM7RUFDVCxXQUFXO0FBQ2I7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsU0FBUztFQUNULG1CQUFtQjtFQUNuQix1QkFBdUI7RUFDdkIsV0FBVztFQUNYLGdCQUFnQjtBQUNsQjtBQUNBO0VBQ0UsWUFBWTtFQUNaLFVBQVU7RUFDVixhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLHVCQUF1QjtFQUN2QixTQUFTO0VBQ1QsbUJBQW1CO0FBQ3JCO0FBQ0E7RUFDRSxpQkFBaUI7RUFDakIsV0FBVztFQUNYLGFBQWE7RUFDYiw4Q0FBOEM7RUFDOUMsbUNBQW1DO0VBQ25DLHVCQUF1QjtFQUN2QixhQUFhO0VBQ2IsZ0JBQWdCO0FBQ2xCO0FBQ0E7RUFDRSxhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLFNBQVM7QUFDWDtBQUNBO0VBQ0UsV0FBVztFQUNYLFlBQVk7QUFDZDtBQUNBO0VBQ0UsV0FBVztFQUNYLGFBQWE7RUFDYix3Q0FBd0M7QUFDMUM7QUFDQTtFQUNFLFdBQVc7RUFDWCxhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLFNBQVM7QUFDWDtBQUNBO0VBQ0UsYUFBYTtFQUNiLHNCQUFzQjtFQUN0Qix1QkFBdUI7RUFDdkIsU0FBUztBQUNYO0FBQ0E7RUFDRSxtQkFBbUI7RUFDbkIsZ0JBQWdCO0VBQ2hCLGVBQWU7QUFDakI7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLFNBQVM7RUFDVCxhQUFhO0FBQ2Y7QUFDQTtFQUNFLG1CQUFtQjtBQUNyQjtBQUNBO0VBQ0UsZ0JBQWdCO0FBQ2xCIiwic291cmNlc0NvbnRlbnQiOlsiLnF1b3RlIHtcclxuICBtYXJnaW46IGF1dG87XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgbWF4LXdpZHRoOiAyMXJlbTtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgd2hpdGUtc3BhY2U6IG5vcm1hbDtcclxuICBsaW5lLWhlaWdodDogMS41O1xyXG59XHJcbi5xdW90ZSBoMyB7XHJcbiAgZm9udC1mYW1pbHk6IFwiRGFuY2luZyBTY3JpcHRcIjtcclxuICBjb2xvcjogdmFyKC0tcHJpbWFyeS1jb2xvcik7XHJcbiAgZm9udC1zaXplOiAxLjdyZW07XHJcbn1cclxuXHJcbi5wYWdpbmF0aW9uIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogZW5kO1xyXG59XHJcbi5yZWNpcGUtY29udGFpbmVyIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgcGFkZGluZzogMCA0MHB4IDQwcHggNDBweDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHN0YXJ0O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgZ2FwOiAyMHB4O1xyXG4gIHdpZHRoOiAxMDAlO1xyXG59XHJcblxyXG4uZmlyc3Qtc2VjdGlvbi1yZWNpcGUge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZ2FwOiAzMHB4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgbWFyZ2luLXRvcDogMTVweDtcclxufVxyXG4ucmVjaXBlLWRldGFpbHMge1xyXG4gIGhlaWdodDogMTAwJTtcclxuICB3aWR0aDogNjUlO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBnYXA6IDIwcHg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG4uZGV0YWlscy1ncmlkLWNvbnRhaW5lciB7XHJcbiAgcGFkZGluZy10b3A6IDEwcHg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgZGlzcGxheTogZ3JpZDtcclxuICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IHJlcGVhdChhdXRvLWZpdCwgMjEwcHgpO1xyXG4gIGdyaWQtdGVtcGxhdGUtcm93czogcmVwZWF0KDMsIDUwcHgpO1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIHJvdy1nYXA6IDEwcHg7XHJcbiAgY29sdW1uLWdhcDogMjBweDtcclxufVxyXG4uZGV0YWlsLWl0ZW0ge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBnYXA6IDEwcHg7XHJcbn1cclxuLmRldGFpbC1pdGVtIGltZyB7XHJcbiAgd2lkdGg6IDQwcHg7XHJcbiAgaGVpZ2h0OiA0MHB4O1xyXG59XHJcbi5zZXBhcmF0aW9uLWxpbmUge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMC41cHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tc2Vjb25kYXJ5LWNvbG9yKTtcclxufVxyXG4uc2Vjb25kLXNlY3Rpb24tcmVjaXBlIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgZ2FwOiAxMHB4O1xyXG59XHJcbi5yZWNpcGUtZGV0YWlsLWl0ZW0ge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBnYXA6IDE1cHg7XHJcbn1cclxuLnJlY2lwZS1kZXRhaWwtaXRlbSBoMiB7XHJcbiAgY29sb3I6IHZhcigtLWJyb3duKTtcclxuICBmb250LXdlaWdodDogNjAwO1xyXG4gIGZvbnQtc2l6ZTogMjZweDtcclxufVxyXG5cclxuLmRldGFpbC1saXN0IHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgZ2FwOiAxMHB4O1xyXG4gIHotaW5kZXg6IDEwMDA7XHJcbn1cclxuLnJlY2lwZS1kZXRhaWwtaXRlbSBsaSB7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcclxufVxyXG4uZGV0YWlsLXRleHQge1xyXG4gIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 4093:
/*!****************************************************************************!*\
  !*** ./src/app/shared/components/search-header/search-header.component.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SearchHeaderComponent: () => (/* binding */ SearchHeaderComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 4456);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 5072);
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ngx-toastr */ 4285);
/* harmony import */ var src_app_core_constants_constants_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/constants/constants.config */ 8111);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/auth.service */ 4796);








class SearchHeaderComponent {
  constructor() {
    this.formControlName = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControl('');
    this.base_url = src_app_core_constants_constants_config__WEBPACK_IMPORTED_MODULE_0__.APP_API.base_url;
    this.defaultImage = src_app_core_constants_constants_config__WEBPACK_IMPORTED_MODULE_0__.APP_CONST.defaultImageUrl;
    this.user = undefined;
    this.authService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.inject)(src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_1__.AuthService);
    this.toastr = (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.inject)(ngx_toastr__WEBPACK_IMPORTED_MODULE_4__.ToastrService);
    this.router = (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.inject)(_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router);
    this.signout = () => {
      this.authService.logout();
      this.router.navigate(['/login']);
    };
  }
  ngOnInit() {
    this.authService.getUserInfos()?.subscribe({
      next: response => {
        this.user = response;
      },
      error: error => {
        // Error callback
        this.toastr.error('Error fetching user', 'Error');
      }
    });
  }
  static {
    this.ɵfac = function SearchHeaderComponent_Factory(t) {
      return new (t || SearchHeaderComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
      type: SearchHeaderComponent,
      selectors: [["app-search-header"]],
      inputs: {
        formControlName: "formControlName"
      },
      decls: 10,
      vars: 3,
      consts: [[1, "search-header"], [1, "search-container"], ["type", "text", "placeholder", "Search...", 1, "search-input", 3, "formControl"], ["src", "assets/images/search-icon.svg", "alt", "search", 1, "search-icon"], [1, "name-logout"], [1, "logout", 3, "click"], ["alt", "", 1, "avatar", 3, "src"]],
      template: function SearchHeaderComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0)(1, "div", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "input", 2)(3, "img", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "div", 4)(5, "h4");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](7, "button", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function SearchHeaderComponent_Template_button_click_7_listener() {
            return ctx.signout();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](8, "Logout");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](9, "img", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        }
        if (rf & 2) {
          let tmp_1_0;
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("formControl", ctx.formControlName);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"]((tmp_1_0 = ctx.user == null ? null : ctx.user.name) !== null && tmp_1_0 !== undefined ? tmp_1_0 : "Admin");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("src", (ctx.user == null ? null : ctx.user.profilePictureUrl) ? ctx.base_url + (ctx.user == null ? null : ctx.user.profilePictureUrl) : ctx.defaultImage, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsanitizeUrl"]);
        }
      },
      dependencies: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlDirective],
      styles: [".search-header[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 10px;\n  height: 100%;\n  width: 100%;\n  align-items: center;\n}\n.search-container[_ngcontent-%COMP%] {\n  position: relative;\n  height: 100%;\n  flex: 1;\n}\n\n.search-input[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  padding: 8px 40px 8px 40px;\n  font-size: clamp(9px, 14px, 1.4vw);\n  color: var(--brown);\n  border: 1px solid transparent;\n  border-radius: 10px;\n\n  outline: none;\n}\n.search-input[_ngcontent-%COMP%]::placeholder {\n  \n\n  color: var(--brown);\n}\n\n.search-input[_ngcontent-%COMP%]:-ms-input-placeholder {\n  \n\n  color: var(--brown);\n}\n\n.search-input[_ngcontent-%COMP%]::-ms-input-placeholder {\n  \n\n  color: var(--brown);\n}\n\n.search-input[_ngcontent-%COMP%]::-webkit-input-placeholder {\n  \n\n  color: var(--brown);\n}\n\n.search-input[_ngcontent-%COMP%]:focus {\n  border: 1px solid transparent; \n\n  background: linear-gradient(white, white) padding-box,\n    linear-gradient(90deg, var(--secondary-color), var(--primary-color))\n      border-box; \n\n  box-shadow: 0 0 1px var(--primary-color), 0 0 1px var(--secondary-color),\n    0 0 1px var(--primary-color);\n  outline: none;\n}\n\n.search-icon[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 50%;\n  left: 12px;\n  transform: translateY(-50%);\n  color: var(--primary-color);\n  pointer-events: none;\n}\n\n.name-logout[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: var(--brown);\n  font-weight: 600;\n}\nbutton.logout[_ngcontent-%COMP%] {\n  border: none;\n  font-size: 10px;\n  margin: 0;\n  padding: 0;\n  color: var(--brown);\n  cursor: pointer;\n}\n\n.avatar[_ngcontent-%COMP%] {\n  width: 60px; \n\n  height: 60px; \n\n  border-radius: 50%;\n  object-fit: cover; \n\n  display: block; \n\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvc2VhcmNoLWhlYWRlci9zZWFyY2gtaGVhZGVyLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxhQUFhO0VBQ2IsU0FBUztFQUNULFlBQVk7RUFDWixXQUFXO0VBQ1gsbUJBQW1CO0FBQ3JCO0FBQ0E7RUFDRSxrQkFBa0I7RUFDbEIsWUFBWTtFQUNaLE9BQU87QUFDVDs7QUFFQTtFQUNFLFdBQVc7RUFDWCxZQUFZO0VBQ1osMEJBQTBCO0VBQzFCLGtDQUFrQztFQUNsQyxtQkFBbUI7RUFDbkIsNkJBQTZCO0VBQzdCLG1CQUFtQjs7RUFFbkIsYUFBYTtBQUNmO0FBQ0E7RUFDRSxvQkFBb0I7RUFDcEIsbUJBQW1CO0FBQ3JCOztBQUVBO0VBQ0UsNEJBQTRCO0VBQzVCLG1CQUFtQjtBQUNyQjs7QUFFQTtFQUNFLDRCQUE0QjtFQUM1QixtQkFBbUI7QUFDckI7O0FBRUE7RUFDRSwwQkFBMEI7RUFDMUIsbUJBQW1CO0FBQ3JCOztBQUVBO0VBQ0UsNkJBQTZCLEVBQUUsNEJBQTRCO0VBQzNEOztnQkFFYyxFQUFFLGlDQUFpQztFQUNqRDtnQ0FDOEI7RUFDOUIsYUFBYTtBQUNmOztBQUVBO0VBQ0Usa0JBQWtCO0VBQ2xCLFFBQVE7RUFDUixVQUFVO0VBQ1YsMkJBQTJCO0VBQzNCLDJCQUEyQjtFQUMzQixvQkFBb0I7QUFDdEI7O0FBRUE7RUFDRSxlQUFlO0VBQ2YsbUJBQW1CO0VBQ25CLGdCQUFnQjtBQUNsQjtBQUNBO0VBQ0UsWUFBWTtFQUNaLGVBQWU7RUFDZixTQUFTO0VBQ1QsVUFBVTtFQUNWLG1CQUFtQjtFQUNuQixlQUFlO0FBQ2pCOztBQUVBO0VBQ0UsV0FBVyxFQUFFLHFCQUFxQjtFQUNsQyxZQUFZLEVBQUUscUJBQXFCO0VBQ25DLGtCQUFrQjtFQUNsQixpQkFBaUIsRUFBRSwyREFBMkQ7RUFDOUUsY0FBYyxFQUFFLDhDQUE4QztBQUNoRSIsInNvdXJjZXNDb250ZW50IjpbIi5zZWFyY2gtaGVhZGVyIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGdhcDogMTBweDtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG4uc2VhcmNoLWNvbnRhaW5lciB7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIGhlaWdodDogMTAwJTtcclxuICBmbGV4OiAxO1xyXG59XHJcblxyXG4uc2VhcmNoLWlucHV0IHtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAgcGFkZGluZzogOHB4IDQwcHggOHB4IDQwcHg7XHJcbiAgZm9udC1zaXplOiBjbGFtcCg5cHgsIDE0cHgsIDEuNHZ3KTtcclxuICBjb2xvcjogdmFyKC0tYnJvd24pO1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkIHRyYW5zcGFyZW50O1xyXG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcblxyXG4gIG91dGxpbmU6IG5vbmU7XHJcbn1cclxuLnNlYXJjaC1pbnB1dDo6cGxhY2Vob2xkZXIge1xyXG4gIC8qIFN0YW5kYXJkIHN5bnRheCAqL1xyXG4gIGNvbG9yOiB2YXIoLS1icm93bik7XHJcbn1cclxuXHJcbi5zZWFyY2gtaW5wdXQ6LW1zLWlucHV0LXBsYWNlaG9sZGVyIHtcclxuICAvKiBJbnRlcm5ldCBFeHBsb3JlciAxMC0xMSAqL1xyXG4gIGNvbG9yOiB2YXIoLS1icm93bik7XHJcbn1cclxuXHJcbi5zZWFyY2gtaW5wdXQ6Oi1tcy1pbnB1dC1wbGFjZWhvbGRlciB7XHJcbiAgLyogTWljcm9zb2Z0IEVkZ2UgKGxlZ2FjeSkgKi9cclxuICBjb2xvcjogdmFyKC0tYnJvd24pO1xyXG59XHJcblxyXG4uc2VhcmNoLWlucHV0Ojotd2Via2l0LWlucHV0LXBsYWNlaG9sZGVyIHtcclxuICAvKiBDaHJvbWUsIFNhZmFyaSwgT3BlcmEgKi9cclxuICBjb2xvcjogdmFyKC0tYnJvd24pO1xyXG59XHJcblxyXG4uc2VhcmNoLWlucHV0OmZvY3VzIHtcclxuICBib3JkZXI6IDFweCBzb2xpZCB0cmFuc3BhcmVudDsgLyogTWFpbnRhaW4gZ3JhZGllbnQgdHJpY2sgKi9cclxuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQod2hpdGUsIHdoaXRlKSBwYWRkaW5nLWJveCxcclxuICAgIGxpbmVhci1ncmFkaWVudCg5MGRlZywgdmFyKC0tc2Vjb25kYXJ5LWNvbG9yKSwgdmFyKC0tcHJpbWFyeS1jb2xvcikpXHJcbiAgICAgIGJvcmRlci1ib3g7IC8qIFNsaWdodCBjb2xvciBzaGlmdCBmb3IgZm9jdXMgKi9cclxuICBib3gtc2hhZG93OiAwIDAgMXB4IHZhcigtLXByaW1hcnktY29sb3IpLCAwIDAgMXB4IHZhcigtLXNlY29uZGFyeS1jb2xvciksXHJcbiAgICAwIDAgMXB4IHZhcigtLXByaW1hcnktY29sb3IpO1xyXG4gIG91dGxpbmU6IG5vbmU7XHJcbn1cclxuXHJcbi5zZWFyY2gtaWNvbiB7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHRvcDogNTAlO1xyXG4gIGxlZnQ6IDEycHg7XHJcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC01MCUpO1xyXG4gIGNvbG9yOiB2YXIoLS1wcmltYXJ5LWNvbG9yKTtcclxuICBwb2ludGVyLWV2ZW50czogbm9uZTtcclxufVxyXG5cclxuLm5hbWUtbG9nb3V0IGg0IHtcclxuICBmb250LXNpemU6IDEycHg7XHJcbiAgY29sb3I6IHZhcigtLWJyb3duKTtcclxuICBmb250LXdlaWdodDogNjAwO1xyXG59XHJcbmJ1dHRvbi5sb2dvdXQge1xyXG4gIGJvcmRlcjogbm9uZTtcclxuICBmb250LXNpemU6IDEwcHg7XHJcbiAgbWFyZ2luOiAwO1xyXG4gIHBhZGRpbmc6IDA7XHJcbiAgY29sb3I6IHZhcigtLWJyb3duKTtcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbi5hdmF0YXIge1xyXG4gIHdpZHRoOiA2MHB4OyAvKiBBZGp1c3QgYXMgbmVlZGVkICovXHJcbiAgaGVpZ2h0OiA2MHB4OyAvKiBBZGp1c3QgYXMgbmVlZGVkICovXHJcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gIG9iamVjdC1maXQ6IGNvdmVyOyAvKiBFbnN1cmVzIHRoZSBpbWFnZSBpcyBwcm9wZXJseSBzY2FsZWQgd2l0aGluIHRoZSBjaXJjbGUgKi9cclxuICBkaXNwbGF5OiBibG9jazsgLyogT3B0aW9uYWw6IFRvIHJlbW92ZSBpbmxpbmUgc3BhY2luZyBpc3N1ZXMgKi9cclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
    });
  }
}

/***/ }),

/***/ 1163:
/*!**************************************************************!*\
  !*** ./src/app/shared/components/search/search.component.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SearchComponent: () => (/* binding */ SearchComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/forms */ 4456);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7580);



class SearchComponent {
  constructor() {
    this.formControlName = new _angular_forms__WEBPACK_IMPORTED_MODULE_0__.FormControl('');
  }
  static {
    this.ɵfac = function SearchComponent_Factory(t) {
      return new (t || SearchComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: SearchComponent,
      selectors: [["app-search"]],
      inputs: {
        formControlName: "formControlName"
      },
      decls: 3,
      vars: 1,
      consts: [[1, "search-container"], ["type", "text", "placeholder", "Search...", 1, "search-input", 3, "formControl"], [1, "fas", "fa-search", "search-icon"]],
      template: function SearchComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](1, "input", 1)(2, "i", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formControl", ctx.formControlName);
        }
      },
      dependencies: [_angular_forms__WEBPACK_IMPORTED_MODULE_0__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_0__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_0__.FormControlDirective],
      styles: [".search-container[_ngcontent-%COMP%] {\n  position: relative;\n  width: 100%;\n  max-width: 400px;\n}\n\n.search-input[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 8px 40px 8px 12px;\n  font-size: clamp(9px, 14px, 1.4vw);\n  color: var(--primary-color);\n  border: 1px solid transparent;\n  border-radius: 25px;\n  background: linear-gradient(white, white) padding-box,\n    linear-gradient(90deg, var(--primary-color), var(--secondary-color))\n      border-box;\n  outline: none;\n}\n.search-input[_ngcontent-%COMP%]::placeholder {\n  \n\n  color: var(--primary-color);\n}\n\n.search-input[_ngcontent-%COMP%]:-ms-input-placeholder {\n  \n\n  color: var(--primary-color);\n}\n\n.search-input[_ngcontent-%COMP%]::-ms-input-placeholder {\n  \n\n  color: var(--primary-color);\n}\n\n.search-input[_ngcontent-%COMP%]::-webkit-input-placeholder {\n  \n\n  color: var(--primary-color);\n}\n\n.search-input[_ngcontent-%COMP%]:focus {\n  border: 1px solid transparent; \n\n  background: linear-gradient(white, white) padding-box,\n    linear-gradient(90deg, var(--secondary-color), var(--primary-color))\n      border-box; \n\n  box-shadow: 0 0 1px var(--primary-color), 0 0 1px var(--secondary-color),\n    0 0 1px var(--primary-color);\n  outline: none;\n}\n\n.search-icon[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 50%;\n  right: 12px;\n  transform: translateY(-50%);\n  color: var(--primary-color);\n  width: 1.2rem;\n  height: 1.2rem;\n  pointer-events: none;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvc2VhcmNoL3NlYXJjaC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usa0JBQWtCO0VBQ2xCLFdBQVc7RUFDWCxnQkFBZ0I7QUFDbEI7O0FBRUE7RUFDRSxXQUFXO0VBQ1gsMEJBQTBCO0VBQzFCLGtDQUFrQztFQUNsQywyQkFBMkI7RUFDM0IsNkJBQTZCO0VBQzdCLG1CQUFtQjtFQUNuQjs7Z0JBRWM7RUFDZCxhQUFhO0FBQ2Y7QUFDQTtFQUNFLG9CQUFvQjtFQUNwQiwyQkFBMkI7QUFDN0I7O0FBRUE7RUFDRSw0QkFBNEI7RUFDNUIsMkJBQTJCO0FBQzdCOztBQUVBO0VBQ0UsNEJBQTRCO0VBQzVCLDJCQUEyQjtBQUM3Qjs7QUFFQTtFQUNFLDBCQUEwQjtFQUMxQiwyQkFBMkI7QUFDN0I7O0FBRUE7RUFDRSw2QkFBNkIsRUFBRSw0QkFBNEI7RUFDM0Q7O2dCQUVjLEVBQUUsaUNBQWlDO0VBQ2pEO2dDQUM4QjtFQUM5QixhQUFhO0FBQ2Y7O0FBRUE7RUFDRSxrQkFBa0I7RUFDbEIsUUFBUTtFQUNSLFdBQVc7RUFDWCwyQkFBMkI7RUFDM0IsMkJBQTJCO0VBQzNCLGFBQWE7RUFDYixjQUFjO0VBQ2Qsb0JBQW9CO0FBQ3RCIiwic291cmNlc0NvbnRlbnQiOlsiLnNlYXJjaC1jb250YWluZXIge1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICB3aWR0aDogMTAwJTtcclxuICBtYXgtd2lkdGg6IDQwMHB4O1xyXG59XHJcblxyXG4uc2VhcmNoLWlucHV0IHtcclxuICB3aWR0aDogMTAwJTtcclxuICBwYWRkaW5nOiA4cHggNDBweCA4cHggMTJweDtcclxuICBmb250LXNpemU6IGNsYW1wKDlweCwgMTRweCwgMS40dncpO1xyXG4gIGNvbG9yOiB2YXIoLS1wcmltYXJ5LWNvbG9yKTtcclxuICBib3JkZXI6IDFweCBzb2xpZCB0cmFuc3BhcmVudDtcclxuICBib3JkZXItcmFkaXVzOiAyNXB4O1xyXG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh3aGl0ZSwgd2hpdGUpIHBhZGRpbmctYm94LFxyXG4gICAgbGluZWFyLWdyYWRpZW50KDkwZGVnLCB2YXIoLS1wcmltYXJ5LWNvbG9yKSwgdmFyKC0tc2Vjb25kYXJ5LWNvbG9yKSlcclxuICAgICAgYm9yZGVyLWJveDtcclxuICBvdXRsaW5lOiBub25lO1xyXG59XHJcbi5zZWFyY2gtaW5wdXQ6OnBsYWNlaG9sZGVyIHtcclxuICAvKiBTdGFuZGFyZCBzeW50YXggKi9cclxuICBjb2xvcjogdmFyKC0tcHJpbWFyeS1jb2xvcik7XHJcbn1cclxuXHJcbi5zZWFyY2gtaW5wdXQ6LW1zLWlucHV0LXBsYWNlaG9sZGVyIHtcclxuICAvKiBJbnRlcm5ldCBFeHBsb3JlciAxMC0xMSAqL1xyXG4gIGNvbG9yOiB2YXIoLS1wcmltYXJ5LWNvbG9yKTtcclxufVxyXG5cclxuLnNlYXJjaC1pbnB1dDo6LW1zLWlucHV0LXBsYWNlaG9sZGVyIHtcclxuICAvKiBNaWNyb3NvZnQgRWRnZSAobGVnYWN5KSAqL1xyXG4gIGNvbG9yOiB2YXIoLS1wcmltYXJ5LWNvbG9yKTtcclxufVxyXG5cclxuLnNlYXJjaC1pbnB1dDo6LXdlYmtpdC1pbnB1dC1wbGFjZWhvbGRlciB7XHJcbiAgLyogQ2hyb21lLCBTYWZhcmksIE9wZXJhICovXHJcbiAgY29sb3I6IHZhcigtLXByaW1hcnktY29sb3IpO1xyXG59XHJcblxyXG4uc2VhcmNoLWlucHV0OmZvY3VzIHtcclxuICBib3JkZXI6IDFweCBzb2xpZCB0cmFuc3BhcmVudDsgLyogTWFpbnRhaW4gZ3JhZGllbnQgdHJpY2sgKi9cclxuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQod2hpdGUsIHdoaXRlKSBwYWRkaW5nLWJveCxcclxuICAgIGxpbmVhci1ncmFkaWVudCg5MGRlZywgdmFyKC0tc2Vjb25kYXJ5LWNvbG9yKSwgdmFyKC0tcHJpbWFyeS1jb2xvcikpXHJcbiAgICAgIGJvcmRlci1ib3g7IC8qIFNsaWdodCBjb2xvciBzaGlmdCBmb3IgZm9jdXMgKi9cclxuICBib3gtc2hhZG93OiAwIDAgMXB4IHZhcigtLXByaW1hcnktY29sb3IpLCAwIDAgMXB4IHZhcigtLXNlY29uZGFyeS1jb2xvciksXHJcbiAgICAwIDAgMXB4IHZhcigtLXByaW1hcnktY29sb3IpO1xyXG4gIG91dGxpbmU6IG5vbmU7XHJcbn1cclxuXHJcbi5zZWFyY2gtaWNvbiB7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHRvcDogNTAlO1xyXG4gIHJpZ2h0OiAxMnB4O1xyXG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtNTAlKTtcclxuICBjb2xvcjogdmFyKC0tcHJpbWFyeS1jb2xvcik7XHJcbiAgd2lkdGg6IDEuMnJlbTtcclxuICBoZWlnaHQ6IDEuMnJlbTtcclxuICBwb2ludGVyLWV2ZW50czogbm9uZTtcclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
    });
  }
}

/***/ }),

/***/ 9023:
/*!**********************************************************!*\
  !*** ./src/app/shared/components/star/star.component.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   StarComponent: () => (/* binding */ StarComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 316);


function StarComponent_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "div", 2);
  }
  if (rf & 2) {
    const index_r2 = ctx.index;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("active", index_r2 < ctx_r0.selectedStars);
  }
}
const _c0 = function () {
  return [];
};
class StarComponent {
  constructor() {
    this.number = 5;
    this.selectedStars = 5;
  }
  static {
    this.ɵfac = function StarComponent_Factory(t) {
      return new (t || StarComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: StarComponent,
      selectors: [["app-star"]],
      inputs: {
        number: "number",
        selectedStars: "selectedStars"
      },
      decls: 2,
      vars: 2,
      consts: [[1, "stars-container"], ["class", "star", 3, "active", 4, "ngFor", "ngForOf"], [1, "star"]],
      template: function StarComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, StarComponent_div_1_Template, 1, 2, "div", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](1, _c0).constructor(ctx.number));
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgForOf],
      styles: [".stars-container[_ngcontent-%COMP%] {\n  width: inherit;\n  display: flex;\n  gap: 5px;\n}\n\n.star[_ngcontent-%COMP%] {\n  width: 20px;\n  height: 20px;\n  background-color: var(--hint-text);\n  clip-path: polygon(\n    50% 0%,\n    61% 35%,\n    98% 35%,\n    68% 57%,\n    79% 91%,\n    50% 70%,\n    21% 91%,\n    32% 57%,\n    2% 35%,\n    39% 35%\n  );\n  &.active {\n    background-color: var(--star-color);\n  }\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvc3Rhci9zdGFyLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxjQUFjO0VBQ2QsYUFBYTtFQUNiLFFBQVE7QUFDVjs7QUFFQTtFQUNFLFdBQVc7RUFDWCxZQUFZO0VBQ1osa0NBQWtDO0VBQ2xDOzs7Ozs7Ozs7OztHQVdDO0VBQ0Q7SUFDRSxtQ0FBbUM7RUFDckM7QUFDRiIsInNvdXJjZXNDb250ZW50IjpbIi5zdGFycy1jb250YWluZXIge1xyXG4gIHdpZHRoOiBpbmhlcml0O1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZ2FwOiA1cHg7XHJcbn1cclxuXHJcbi5zdGFyIHtcclxuICB3aWR0aDogMjBweDtcclxuICBoZWlnaHQ6IDIwcHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taGludC10ZXh0KTtcclxuICBjbGlwLXBhdGg6IHBvbHlnb24oXHJcbiAgICA1MCUgMCUsXHJcbiAgICA2MSUgMzUlLFxyXG4gICAgOTglIDM1JSxcclxuICAgIDY4JSA1NyUsXHJcbiAgICA3OSUgOTElLFxyXG4gICAgNTAlIDcwJSxcclxuICAgIDIxJSA5MSUsXHJcbiAgICAzMiUgNTclLFxyXG4gICAgMiUgMzUlLFxyXG4gICAgMzklIDM1JVxyXG4gICk7XHJcbiAgJi5hY3RpdmUge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tc3Rhci1jb2xvcik7XHJcbiAgfVxyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
    });
  }
}

/***/ }),

/***/ 6145:
/*!****************************************************************!*\
  !*** ./src/app/shared/components/svg-box/svg-box.component.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SvgBoxComponent: () => (/* binding */ SvgBoxComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ 436);


const _c0 = ["svgContainer"];
const _c1 = ["*"];
class SvgBoxComponent {
  constructor(sanitizer) {
    this.sanitizer = sanitizer;
    this.width = 'auto';
    this.height = 'auto';
    this.actualWidth = 0;
    this.actualHeight = 0;
    this.backgroundStyle = '';
  }
  ngOnInit() {}
  ngAfterViewInit() {
    this.observeContainerSize();
  }
  ngOnDestroy() {
    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
    }
  }
  observeContainerSize() {
    const container = this.svgContainer.nativeElement;
    this.updateDimensions();
    // Initialize the ResizeObserver
    this.resizeObserver = new ResizeObserver(() => {
      this.updateDimensions();
      this.generateSVGBackground();
    });
    // Start observing the container
    this.resizeObserver.observe(container);
  }
  updateDimensions() {
    const container = this.svgContainer.nativeElement;
    this.actualWidth = container.offsetWidth || 200;
    this.actualHeight = container.offsetHeight || 200;
  }
  generateSVGBackground() {
    const svgElement = `
      <svg
        viewBox="0 0 ${this.actualWidth} ${this.actualHeight}"
        width="${this.actualWidth}"
        height="${this.actualHeight}"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <linearGradient id="gradientStroke" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" style="stop-color: #9dc209; stop-opacity: 1" />
            <stop offset="52%" style="stop-color: #cc5500; stop-opacity: 1" />
          </linearGradient>
        </defs>

        <path
          d="${this.getPathD()}"
          fill="transparent"
          stroke="url(#gradientStroke)"
          stroke-width="2"
        />
      </svg>
    `;
    const encodedSVG = encodeURIComponent(svgElement);
    const dataURL = `url('data:image/svg+xml,${encodedSVG}')`;
    // Sanitize the URL to safely bind it in the template
    this.backgroundStyle = this.sanitizer.bypassSecurityTrustStyle(dataURL);
  }
  getPathD() {
    const w = this.actualWidth || 200; // Fallback to default value
    const h = this.actualHeight || 200;
    return `
      M 0,${0.1 * h}
      Q 0,0 ${0.1 * w},0
      Q ${0.5 * w},${0.05 * h} ${0.9 * w},0
      Q ${w},0 ${w},${0.1 * h}
      L ${w},${0.9 * h}
      Q ${w},${h} ${0.9 * w},${h}
      L ${0.1 * w},${h}
      Q 0,${h} 0,${0.9 * h}
      L 0,${0.1 * h}
      Z
    `;
  }
  static {
    this.ɵfac = function SvgBoxComponent_Factory(t) {
      return new (t || SvgBoxComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__.DomSanitizer));
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: SvgBoxComponent,
      selectors: [["app-svg-box"]],
      viewQuery: function SvgBoxComponent_Query(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_c0, 5);
        }
        if (rf & 2) {
          let _t;
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.svgContainer = _t.first);
        }
      },
      inputs: {
        width: "width",
        height: "height"
      },
      ngContentSelectors: _c1,
      decls: 4,
      vars: 6,
      consts: [[1, "svg-container"], ["svgContainer", ""], [1, "svg-content"]],
      template: function SvgBoxComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojectionDef"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0, 1)(2, "div", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("background-image", ctx.backgroundStyle)("--width", ctx.width)("--height", ctx.height);
        }
      },
      styles: [".svg-container[_ngcontent-%COMP%] {\n  width: var(--width);\n  height: var(--height);\n  border-radius: 8%;\n  box-shadow: var(--drop-shadow);\n  margin: auto;\n  display: block;\n  align-items: center;\n  justify-content: center;\n  background-position: center;\n  background-size: contain;\n  background-repeat: no-repeat;\n}\n.svg-content[_ngcontent-%COMP%] {\n  padding: 3%;\n  width: 100%;\n  height: 100%;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  text-overflow: ellipsis;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvc3ZnLWJveC9zdmctYm94LmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxtQkFBbUI7RUFDbkIscUJBQXFCO0VBQ3JCLGlCQUFpQjtFQUNqQiw4QkFBOEI7RUFDOUIsWUFBWTtFQUNaLGNBQWM7RUFDZCxtQkFBbUI7RUFDbkIsdUJBQXVCO0VBQ3ZCLDJCQUEyQjtFQUMzQix3QkFBd0I7RUFDeEIsNEJBQTRCO0FBQzlCO0FBQ0E7RUFDRSxXQUFXO0VBQ1gsV0FBVztFQUNYLFlBQVk7RUFDWixhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLG1CQUFtQjtFQUNuQix1QkFBdUI7QUFDekIiLCJzb3VyY2VzQ29udGVudCI6WyIuc3ZnLWNvbnRhaW5lciB7XHJcbiAgd2lkdGg6IHZhcigtLXdpZHRoKTtcclxuICBoZWlnaHQ6IHZhcigtLWhlaWdodCk7XHJcbiAgYm9yZGVyLXJhZGl1czogOCU7XHJcbiAgYm94LXNoYWRvdzogdmFyKC0tZHJvcC1zaGFkb3cpO1xyXG4gIG1hcmdpbjogYXV0bztcclxuICBkaXNwbGF5OiBibG9jaztcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcclxuICBiYWNrZ3JvdW5kLXNpemU6IGNvbnRhaW47XHJcbiAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcclxufVxyXG4uc3ZnLWNvbnRlbnQge1xyXG4gIHBhZGRpbmc6IDMlO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
    });
  }
}

/***/ }),

/***/ 6881:
/*!**************************************************************************!*\
  !*** ./src/app/shared/components/upload-image/upload-image.component.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   UploadImageComponent: () => (/* binding */ UploadImageComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var src_app_core_constants_constants_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/constants/constants.config */ 8111);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _svg_box_svg_box_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../svg-box/svg-box.component */ 6145);





const _c0 = ["fileInput"];
function UploadImageComponent_div_0_div_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](1, "img", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](3, "img", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("src", ctx_r3.getImageUrl(), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeUrl"]);
  }
}
function UploadImageComponent_div_0_div_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](1, "img", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](5, "img", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](ctx_r4.uploadedFileName);
  }
}
function UploadImageComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function UploadImageComponent_div_0_Template_div_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r6);
      const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r5.triggerFileInput());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "input", 3, 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("change", function UploadImageComponent_div_0_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r6);
      const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r7.onFileSelected($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](3, UploadImageComponent_div_0_div_3_Template, 4, 1, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](4, UploadImageComponent_div_0_div_4_Template, 6, 1, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("accept", ctx_r0.acceptedFileTypes);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx_r0.isImage);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !ctx_r0.isImage);
  }
}
function UploadImageComponent_app_svg_box_1_h3_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1, "Upload Picture");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
  }
}
function UploadImageComponent_app_svg_box_1_ng_template_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1, "Upload File");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
  }
}
function UploadImageComponent_app_svg_box_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "app-svg-box", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function UploadImageComponent_app_svg_box_1_Template_app_svg_box_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r13);
      const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r12.triggerFileInput());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "input", 3, 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("change", function UploadImageComponent_app_svg_box_1_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r13);
      const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r14.onFileSelected($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](4, "img", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](5, UploadImageComponent_app_svg_box_1_h3_5_Template, 2, 0, "h3", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](6, UploadImageComponent_app_svg_box_1_ng_template_6_Template, 2, 0, "ng-template", null, 17, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵreference"](7);
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("accept", ctx_r1.acceptedFileTypes);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx_r1.isImage)("ngIfElse", _r10);
  }
}
class UploadImageComponent {
  constructor() {
    this.uploadedImage = '';
    this.acceptedFileTypes = 'image/*'; // Default to images
    this.fileSelected = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.EventEmitter();
    this.base_url = src_app_core_constants_constants_config__WEBPACK_IMPORTED_MODULE_0__.APP_API.base_url;
    this.uploadedFileName = ''; // For non-image file names
    this.isImage = true; // Determines if the file is an image
  }

  ngOnInit() {
    this.isImage = this.uploadedImage ? true : false;
  }
  triggerFileInput() {
    if (this.fileInput?.nativeElement) {
      this.fileInput.nativeElement.click();
    }
  }
  onFileSelected(event) {
    const input = event.target;
    if (input.files && input.files.length > 0) {
      const file = input.files[0];
      this.fileSelected.emit(file); // Emit the selected file to the parent component
      const fileType = file.type;
      this.isImage = fileType.startsWith('image/');
      if (this.isImage) {
        // Preview the image
        const reader = new FileReader();
        reader.onload = e => {
          this.uploadedImage = e.target?.result;
        };
        reader.readAsDataURL(file);
      } else {
        // Handle non-image files (e.g., PDFs)
        this.uploadedImage = ''; // Clear the image preview
        this.uploadedFileName = file.name;
      }
    }
  }
  getImageUrl() {
    return this.uploadedImage.includes('/uploads') ? `${this.base_url}${this.uploadedImage}` : this.uploadedImage;
  }
  static {
    this.ɵfac = function UploadImageComponent_Factory(t) {
      return new (t || UploadImageComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
      type: UploadImageComponent,
      selectors: [["app-upload-image"]],
      viewQuery: function UploadImageComponent_Query(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵviewQuery"](_c0, 5);
        }
        if (rf & 2) {
          let _t;
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵloadQuery"]()) && (ctx.fileInput = _t.first);
        }
      },
      inputs: {
        uploadedImage: "uploadedImage",
        acceptedFileTypes: "acceptedFileTypes",
        uploadedFileName: "uploadedFileName"
      },
      outputs: {
        fileSelected: "fileSelected"
      },
      decls: 2,
      vars: 2,
      consts: [["class", "uploaded-image-wrapper", 3, "click", 4, "ngIf"], [3, "click", 4, "ngIf"], [1, "uploaded-image-wrapper", 3, "click"], ["type", "file", "hidden", "", 3, "accept", "change"], ["fileInput", ""], ["class", "uploaded-image", 4, "ngIf"], ["class", "uploaded-file", 4, "ngIf"], [1, "uploaded-image"], ["alt", "Uploaded Image", 3, "src"], [1, "edit-icon"], ["src", "assets/images/edit.png", "alt", "Edit"], [1, "uploaded-file"], ["width", "150px", "height", "150px", "src", "assets/images/pdf-file.png", "alt", "File Icon"], [3, "click"], [1, "upload-image"], ["src", "assets/images/upload-image.png", "alt", "Upload"], [4, "ngIf", "ngIfElse"], ["uploadFile", ""]],
      template: function UploadImageComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](0, UploadImageComponent_div_0_Template, 5, 3, "div", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](1, UploadImageComponent_app_svg_box_1_Template, 8, 3, "app-svg-box", 1);
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.uploadedImage || ctx.uploadedFileName);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !ctx.uploadedImage && !ctx.uploadedFileName);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _svg_box_svg_box_component__WEBPACK_IMPORTED_MODULE_1__.SvgBoxComponent],
      styles: [".upload-image[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n  gap: 10px;\n}\n\n.upload-image[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  color: var(--primary-color);\n  font-size: 1.5vw;\n  font-weight: bold;\n  text-align: center;\n}\n\n.upload-image[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 50%;\n}\n\n.uploaded-image-wrapper[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  width: 90%;\n  height: 100%;\n}\n\n.uploaded-image[_ngcontent-%COMP%] {\n  width: 180px;\n  height: 180px;\n  position: relative;\n}\n.uploaded-image[_ngcontent-%COMP%]    > img[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n  border-radius: 50%;\n  position: relative;\n}\n.edit-icon[_ngcontent-%COMP%] {\n  background-color: var(--light-gray);\n  border: 5px solid white;\n  width: 60px;\n  height: 60px;\n  border-radius: 50%;\n  position: absolute;\n  bottom: 0px;\n  right: 0px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n.edit-icon[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 50%;\n  height: 50%;\n}\n.uploaded-file[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvdXBsb2FkLWltYWdlL3VwbG9hZC1pbWFnZS5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsV0FBVztFQUNYLFlBQVk7RUFDWixhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLHVCQUF1QjtFQUN2QixtQkFBbUI7RUFDbkIsU0FBUztBQUNYOztBQUVBO0VBQ0UsMkJBQTJCO0VBQzNCLGdCQUFnQjtFQUNoQixpQkFBaUI7RUFDakIsa0JBQWtCO0FBQ3BCOztBQUVBO0VBQ0UsVUFBVTtBQUNaOztBQUVBO0VBQ0UsYUFBYTtFQUNiLHVCQUF1QjtFQUN2QixtQkFBbUI7RUFDbkIsVUFBVTtFQUNWLFlBQVk7QUFDZDs7QUFFQTtFQUNFLFlBQVk7RUFDWixhQUFhO0VBQ2Isa0JBQWtCO0FBQ3BCO0FBQ0E7RUFDRSxXQUFXO0VBQ1gsWUFBWTtFQUNaLGlCQUFpQjtFQUNqQixrQkFBa0I7RUFDbEIsa0JBQWtCO0FBQ3BCO0FBQ0E7RUFDRSxtQ0FBbUM7RUFDbkMsdUJBQXVCO0VBQ3ZCLFdBQVc7RUFDWCxZQUFZO0VBQ1osa0JBQWtCO0VBQ2xCLGtCQUFrQjtFQUNsQixXQUFXO0VBQ1gsVUFBVTtFQUNWLGFBQWE7RUFDYix1QkFBdUI7RUFDdkIsbUJBQW1CO0FBQ3JCO0FBQ0E7RUFDRSxVQUFVO0VBQ1YsV0FBVztBQUNiO0FBQ0E7RUFDRSxhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLG1CQUFtQjtBQUNyQiIsInNvdXJjZXNDb250ZW50IjpbIi51cGxvYWQtaW1hZ2Uge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBnYXA6IDEwcHg7XHJcbn1cclxuXHJcbi51cGxvYWQtaW1hZ2UgaDMge1xyXG4gIGNvbG9yOiB2YXIoLS1wcmltYXJ5LWNvbG9yKTtcclxuICBmb250LXNpemU6IDEuNXZ3O1xyXG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuLnVwbG9hZC1pbWFnZSBpbWcge1xyXG4gIHdpZHRoOiA1MCU7XHJcbn1cclxuXHJcbi51cGxvYWRlZC1pbWFnZS13cmFwcGVyIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgd2lkdGg6IDkwJTtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbn1cclxuXHJcbi51cGxvYWRlZC1pbWFnZSB7XHJcbiAgd2lkdGg6IDE4MHB4O1xyXG4gIGhlaWdodDogMTgwcHg7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG59XHJcbi51cGxvYWRlZC1pbWFnZSA+IGltZyB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIG9iamVjdC1maXQ6IGNvdmVyO1xyXG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbn1cclxuLmVkaXQtaWNvbiB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tbGlnaHQtZ3JheSk7XHJcbiAgYm9yZGVyOiA1cHggc29saWQgd2hpdGU7XHJcbiAgd2lkdGg6IDYwcHg7XHJcbiAgaGVpZ2h0OiA2MHB4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgYm90dG9tOiAwcHg7XHJcbiAgcmlnaHQ6IDBweDtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuLmVkaXQtaWNvbiBpbWcge1xyXG4gIHdpZHRoOiA1MCU7XHJcbiAgaGVpZ2h0OiA1MCU7XHJcbn1cclxuLnVwbG9hZGVkLWZpbGUge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
    });
  }
}

/***/ }),

/***/ 3887:
/*!*****************************************!*\
  !*** ./src/app/shared/shared.module.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SharedModule: () => (/* binding */ SharedModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _components_auth_background_auth_background_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./components/auth-background/auth-background.component */ 3793);
/* harmony import */ var _components_auth_input_field_auth_input_field_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./components/auth-input-field/auth-input-field.component */ 4591);
/* harmony import */ var _components_progress_indicator_progress_indicator_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/progress-indicator/progress-indicator.component */ 2229);
/* harmony import */ var _components_button_button_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/button/button.component */ 8219);
/* harmony import */ var _components_auth_dropdown_auth_dropdown_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/auth-dropdown/auth-dropdown.component */ 8249);
/* harmony import */ var _components_auth_account_type_auth_account_type_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/auth-account-type/auth-account-type.component */ 1765);
/* harmony import */ var _components_svg_box_svg_box_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./components/svg-box/svg-box.component */ 6145);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/forms */ 4456);
/* harmony import */ var _components_nav_bar_nav_bar_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./components/nav-bar/nav-bar.component */ 349);
/* harmony import */ var _components_page_background_page_background_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./components/page-background/page-background.component */ 1469);
/* harmony import */ var _features_recipes_recette_item_recette_item_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../features/recipes/recette-item/recette-item.component */ 5404);
/* harmony import */ var _components_star_star_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./components/star/star.component */ 9023);
/* harmony import */ var _components_search_search_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./components/search/search.component */ 1163);
/* harmony import */ var _components_dropdown_dropdown_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./components/dropdown/dropdown.component */ 4538);
/* harmony import */ var _components_pagination_pagination_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./components/pagination/pagination.component */ 4815);
/* harmony import */ var _components_upload_image_upload_image_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./components/upload-image/upload-image.component */ 6881);
/* harmony import */ var _components_input_field_input_field_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./components/input-field/input-field.component */ 1029);
/* harmony import */ var _components_recipe_description_recipe_description_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./components/recipe-description/recipe-description.component */ 6981);
/* harmony import */ var _components_search_header_search_header_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./components/search-header/search-header.component */ 4093);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/router */ 5072);
/* harmony import */ var _components_preloader_preloader_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./components/preloader/preloader.component */ 9485);
/* harmony import */ var _components_popup_popup_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./components/popup/popup.component */ 4061);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/core */ 7580);
























class SharedModule {
  static {
    this.ɵfac = function SharedModule_Factory(t) {
      return new (t || SharedModule)();
    };
  }
  static {
    this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵdefineNgModule"]({
      type: SharedModule
    });
  }
  static {
    this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_21__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.FormsModule, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.ReactiveFormsModule, _angular_router__WEBPACK_IMPORTED_MODULE_23__.RouterModule]
    });
  }
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵsetNgModuleScope"](SharedModule, {
    declarations: [_components_auth_background_auth_background_component__WEBPACK_IMPORTED_MODULE_0__.AuthBackgroundComponent, _components_auth_input_field_auth_input_field_component__WEBPACK_IMPORTED_MODULE_1__.AuthInputFieldComponent, _components_progress_indicator_progress_indicator_component__WEBPACK_IMPORTED_MODULE_2__.ProgressIndicatorComponent, _components_button_button_component__WEBPACK_IMPORTED_MODULE_3__.ButtonComponent, _components_auth_dropdown_auth_dropdown_component__WEBPACK_IMPORTED_MODULE_4__.AuthDropdownComponent, _components_auth_account_type_auth_account_type_component__WEBPACK_IMPORTED_MODULE_5__.AuthAccountTypeComponent, _components_svg_box_svg_box_component__WEBPACK_IMPORTED_MODULE_6__.SvgBoxComponent, _components_nav_bar_nav_bar_component__WEBPACK_IMPORTED_MODULE_7__.NavBarComponent, _components_page_background_page_background_component__WEBPACK_IMPORTED_MODULE_8__.PageBackgroundComponent, _features_recipes_recette_item_recette_item_component__WEBPACK_IMPORTED_MODULE_9__.RecetteItemComponent, _components_star_star_component__WEBPACK_IMPORTED_MODULE_10__.StarComponent, _components_search_search_component__WEBPACK_IMPORTED_MODULE_11__.SearchComponent, _components_dropdown_dropdown_component__WEBPACK_IMPORTED_MODULE_12__.DropdownComponent, _components_pagination_pagination_component__WEBPACK_IMPORTED_MODULE_13__.PaginationComponent, _components_upload_image_upload_image_component__WEBPACK_IMPORTED_MODULE_14__.UploadImageComponent, _components_input_field_input_field_component__WEBPACK_IMPORTED_MODULE_15__.InputFieldComponent, _components_recipe_description_recipe_description_component__WEBPACK_IMPORTED_MODULE_16__.RecipeDescriptionComponent, _components_search_header_search_header_component__WEBPACK_IMPORTED_MODULE_17__.SearchHeaderComponent, _components_preloader_preloader_component__WEBPACK_IMPORTED_MODULE_18__.PreloaderComponent, _components_popup_popup_component__WEBPACK_IMPORTED_MODULE_19__.PopupComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_21__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.FormsModule, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.ReactiveFormsModule, _angular_router__WEBPACK_IMPORTED_MODULE_23__.RouterModule],
    exports: [_components_auth_background_auth_background_component__WEBPACK_IMPORTED_MODULE_0__.AuthBackgroundComponent, _components_auth_input_field_auth_input_field_component__WEBPACK_IMPORTED_MODULE_1__.AuthInputFieldComponent, _components_progress_indicator_progress_indicator_component__WEBPACK_IMPORTED_MODULE_2__.ProgressIndicatorComponent, _components_button_button_component__WEBPACK_IMPORTED_MODULE_3__.ButtonComponent, _components_auth_dropdown_auth_dropdown_component__WEBPACK_IMPORTED_MODULE_4__.AuthDropdownComponent, _components_auth_account_type_auth_account_type_component__WEBPACK_IMPORTED_MODULE_5__.AuthAccountTypeComponent, _components_svg_box_svg_box_component__WEBPACK_IMPORTED_MODULE_6__.SvgBoxComponent, _components_nav_bar_nav_bar_component__WEBPACK_IMPORTED_MODULE_7__.NavBarComponent, _components_page_background_page_background_component__WEBPACK_IMPORTED_MODULE_8__.PageBackgroundComponent, _features_recipes_recette_item_recette_item_component__WEBPACK_IMPORTED_MODULE_9__.RecetteItemComponent, _components_pagination_pagination_component__WEBPACK_IMPORTED_MODULE_13__.PaginationComponent, _components_upload_image_upload_image_component__WEBPACK_IMPORTED_MODULE_14__.UploadImageComponent, _components_star_star_component__WEBPACK_IMPORTED_MODULE_10__.StarComponent, _components_search_search_component__WEBPACK_IMPORTED_MODULE_11__.SearchComponent, _components_dropdown_dropdown_component__WEBPACK_IMPORTED_MODULE_12__.DropdownComponent, _components_input_field_input_field_component__WEBPACK_IMPORTED_MODULE_15__.InputFieldComponent, _components_recipe_description_recipe_description_component__WEBPACK_IMPORTED_MODULE_16__.RecipeDescriptionComponent, _components_search_header_search_header_component__WEBPACK_IMPORTED_MODULE_17__.SearchHeaderComponent, _components_preloader_preloader_component__WEBPACK_IMPORTED_MODULE_18__.PreloaderComponent, _components_popup_popup_component__WEBPACK_IMPORTED_MODULE_19__.PopupComponent]
  });
})();

/***/ }),

/***/ 4429:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ 436);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 635);


_angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__.platformBrowser().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule).catch(err => console.error(err));

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(4429)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map